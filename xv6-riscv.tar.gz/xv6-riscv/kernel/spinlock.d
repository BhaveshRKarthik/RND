kernel/spinlock.o: kernel/spinlock.cpp kernel/types.h kernel/param.h \
 kernel/memlayout.h kernel/spinlock.h kernel/riscv.h kernel/proc.h \
 kernel/defs.h
