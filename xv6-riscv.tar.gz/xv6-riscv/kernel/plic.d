kernel/plic.o: kernel/plic.cpp kernel/types.h kernel/param.h \
 kernel/memlayout.h kernel/riscv.h kernel/defs.h
