kernel/log.o: kernel/log.cpp kernel/types.h kernel/riscv.h kernel/defs.h \
 kernel/param.h kernel/spinlock.h kernel/sleeplock.h kernel/fs.h \
 kernel/buf.h
