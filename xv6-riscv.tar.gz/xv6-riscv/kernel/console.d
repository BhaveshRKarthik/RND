kernel/console.o: kernel/console.cpp \
 /usr/lib/gcc/riscv64-unknown-elf/13.2.0/include/stdarg.h kernel/types.h \
 kernel/param.h kernel/spinlock.h kernel/sleeplock.h kernel/fs.h \
 kernel/file.h kernel/memlayout.h kernel/riscv.h kernel/defs.h \
 kernel/proc.h
