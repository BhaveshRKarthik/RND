kernel/sysproc.o: kernel/sysproc.cpp kernel/types.h kernel/riscv.h \
 kernel/defs.h kernel/param.h kernel/memlayout.h kernel/spinlock.h \
 kernel/proc.h kernel/vm.h
