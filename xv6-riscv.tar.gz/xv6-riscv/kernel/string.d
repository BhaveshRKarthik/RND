kernel/string.o: kernel/string.cpp kernel/types.h
