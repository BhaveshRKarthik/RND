kernel/syscall.o: kernel/syscall.cpp kernel/types.h kernel/param.h \
 kernel/memlayout.h kernel/riscv.h kernel/spinlock.h kernel/proc.h \
 kernel/syscall.h kernel/defs.h
