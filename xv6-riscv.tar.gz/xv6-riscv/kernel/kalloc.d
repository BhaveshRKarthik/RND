kernel/kalloc.o: kernel/kalloc.cpp kernel/types.h kernel/param.h \
 kernel/memlayout.h kernel/spinlock.h kernel/riscv.h kernel/defs.h
