
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	00008117          	auipc	sp,0x8
    80000004:	87010113          	addi	sp,sp,-1936 # 80007870 <stack0>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	03e000ef          	jal	80000054 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <_Z9timerinitv>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    80000022:	30a027f3          	csrr	a5,0x30a
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | MENVCFG_STCE);
    80000026:	577d                	li	a4,-1
    80000028:	177e                	slli	a4,a4,0x3f
    8000002a:	8fd9                	or	a5,a5,a4

static inline void
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    8000002c:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r"(x));
    80000030:	306027f3          	csrr	a5,mcounteren

  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000034:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r"(x));
    80000038:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r"(x));
    8000003c:	c01027f3          	rdtime	a5

  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80000040:	000f4737          	lui	a4,0xf4
    80000044:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000048:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    8000004a:	14d79073          	csrw	stimecmp,a5
}
    8000004e:	6422                	ld	s0,8(sp)
    80000050:	0141                	addi	sp,sp,16
    80000052:	8082                	ret

0000000080000054 <start>:
{
    80000054:	1141                	addi	sp,sp,-16
    80000056:	e406                	sd	ra,8(sp)
    80000058:	e022                	sd	s0,0(sp)
    8000005a:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r"(x));
    8000005c:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000060:	7779                	lui	a4,0xffffe
    80000062:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffddc87>
    80000066:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000068:	6705                	lui	a4,0x1
    8000006a:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000006e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r"(x));
    80000070:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r"(x));
    80000074:	00001797          	auipc	a5,0x1
    80000078:	db078793          	addi	a5,a5,-592 # 80000e24 <main>
    8000007c:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r"(x));
    80000080:	4781                	li	a5,0
    80000082:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r"(x));
    80000086:	67c1                	lui	a5,0x10
    80000088:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000008a:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r"(x));
    8000008e:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r"(x));
    80000092:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    80000096:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r"(x));
    8000009a:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r"(x));
    8000009e:	57fd                	li	a5,-1
    800000a0:	83a9                	srli	a5,a5,0xa
    800000a2:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r"(x));
    800000a6:	47bd                	li	a5,15
    800000a8:	3a079073          	csrw	pmpcfg0,a5
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    800000ac:	30a027f3          	csrr	a5,0x30a
  w_menvcfg(r_menvcfg() | MENVCFG_ADUE);
    800000b0:	4705                	li	a4,1
    800000b2:	1776                	slli	a4,a4,0x3d
    800000b4:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    800000b6:	30a79073          	csrw	0x30a,a5
  timerinit();
    800000ba:	f63ff0ef          	jal	8000001c <_Z9timerinitv>
  asm volatile("csrr %0, mhartid" : "=r"(x));
    800000be:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c2:	2781                	sext.w	a5,a5
}

static inline void
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r"(x));
    800000c4:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c6:	30200073          	mret
}
    800000ca:	60a2                	ld	ra,8(sp)
    800000cc:	6402                	ld	s0,0(sp)
    800000ce:	0141                	addi	sp,sp,16
    800000d0:	8082                	ret

00000000800000d2 <_Z12consolewriteimj>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, uint n)
{
    800000d2:	7159                	addi	sp,sp,-112
    800000d4:	f486                	sd	ra,104(sp)
    800000d6:	f0a2                	sd	s0,96(sp)
    800000d8:	e8ca                	sd	s2,80(sp)
    800000da:	e4ce                	sd	s3,72(sp)
    800000dc:	1880                	addi	s0,sp,112
    800000de:	89b2                	mv	s3,a2
  char buf[32]; // move batches from user space to uart.
  uint i = 0;

  while (i < n) {
    800000e0:	c63d                	beqz	a2,8000014e <_Z12consolewriteimj+0x7c>
    800000e2:	eca6                	sd	s1,88(sp)
    800000e4:	e0d2                	sd	s4,64(sp)
    800000e6:	fc56                	sd	s5,56(sp)
    800000e8:	f85a                	sd	s6,48(sp)
    800000ea:	f45e                	sd	s7,40(sp)
    800000ec:	f062                	sd	s8,32(sp)
    800000ee:	8a2a                	mv	s4,a0
    800000f0:	8aae                	mv	s5,a1
  uint i = 0;
    800000f2:	4901                	li	s2,0
    uint nn = sizeof(buf);
    if (nn > n - i)
    800000f4:	02000b93          	li	s7,32
    800000f8:	02000c13          	li	s8,32
      nn = n - i;
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    800000fc:	5b7d                	li	s6,-1
    800000fe:	a80d                	j	80000130 <_Z12consolewriteimj+0x5e>
    80000100:	02091613          	slli	a2,s2,0x20
    80000104:	9201                	srli	a2,a2,0x20
    80000106:	02049693          	slli	a3,s1,0x20
    8000010a:	9281                	srli	a3,a3,0x20
    8000010c:	9656                	add	a2,a2,s5
    8000010e:	85d2                	mv	a1,s4
    80000110:	f9040513          	addi	a0,s0,-112
    80000114:	152020ef          	jal	80002266 <_Z13either_copyinPvimm>
    80000118:	03650d63          	beq	a0,s6,80000152 <_Z12consolewriteimj+0x80>
      break;
    uartwrite(buf, nn);
    8000011c:	0004859b          	sext.w	a1,s1
    80000120:	f9040513          	addi	a0,s0,-112
    80000124:	786000ef          	jal	800008aa <_Z9uartwritePci>
    i += nn;
    80000128:	0124893b          	addw	s2,s1,s2
  while (i < n) {
    8000012c:	01397a63          	bgeu	s2,s3,80000140 <_Z12consolewriteimj+0x6e>
    if (nn > n - i)
    80000130:	412984bb          	subw	s1,s3,s2
    80000134:	0004879b          	sext.w	a5,s1
    80000138:	fcfbf4e3          	bgeu	s7,a5,80000100 <_Z12consolewriteimj+0x2e>
    8000013c:	84e2                	mv	s1,s8
    8000013e:	b7c9                	j	80000100 <_Z12consolewriteimj+0x2e>
    80000140:	64e6                	ld	s1,88(sp)
    80000142:	6a06                	ld	s4,64(sp)
    80000144:	7ae2                	ld	s5,56(sp)
    80000146:	7b42                	ld	s6,48(sp)
    80000148:	7ba2                	ld	s7,40(sp)
    8000014a:	7c02                	ld	s8,32(sp)
    8000014c:	a809                	j	8000015e <_Z12consolewriteimj+0x8c>
  uint i = 0;
    8000014e:	8932                	mv	s2,a2
    80000150:	a039                	j	8000015e <_Z12consolewriteimj+0x8c>
    80000152:	64e6                	ld	s1,88(sp)
    80000154:	6a06                	ld	s4,64(sp)
    80000156:	7ae2                	ld	s5,56(sp)
    80000158:	7b42                	ld	s6,48(sp)
    8000015a:	7ba2                	ld	s7,40(sp)
    8000015c:	7c02                	ld	s8,32(sp)
  }

  return i;
}
    8000015e:	854a                	mv	a0,s2
    80000160:	70a6                	ld	ra,104(sp)
    80000162:	7406                	ld	s0,96(sp)
    80000164:	6946                	ld	s2,80(sp)
    80000166:	69a6                	ld	s3,72(sp)
    80000168:	6165                	addi	sp,sp,112
    8000016a:	8082                	ret

000000008000016c <_Z11consolereadimj>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, uint n)
{
    8000016c:	711d                	addi	sp,sp,-96
    8000016e:	ec86                	sd	ra,88(sp)
    80000170:	e8a2                	sd	s0,80(sp)
    80000172:	e4a6                	sd	s1,72(sp)
    80000174:	e0ca                	sd	s2,64(sp)
    80000176:	fc4e                	sd	s3,56(sp)
    80000178:	f852                	sd	s4,48(sp)
    8000017a:	f456                	sd	s5,40(sp)
    8000017c:	f05a                	sd	s6,32(sp)
    8000017e:	1080                	addi	s0,sp,96
    80000180:	8b2a                	mv	s6,a0
    80000182:	8aae                	mv	s5,a1
    80000184:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
  acquire(&cons.lock);
    80000186:	0000f517          	auipc	a0,0xf
    8000018a:	6ea50513          	addi	a0,a0,1770 # 8000f870 <cons>
    8000018e:	233000ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  while (n > 0) {
    80000192:	8a4e                	mv	s4,s3
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while (cons.r == cons.w) {
    80000194:	0000f497          	auipc	s1,0xf
    80000198:	6dc48493          	addi	s1,s1,1756 # 8000f870 <cons>
      if (killed(myproc())) {
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    8000019c:	0000f917          	auipc	s2,0xf
    800001a0:	76c90913          	addi	s2,s2,1900 # 8000f908 <cons+0x98>
  while (n > 0) {
    800001a4:	0a0a0b63          	beqz	s4,8000025a <_Z11consolereadimj+0xee>
    while (cons.r == cons.w) {
    800001a8:	0984a783          	lw	a5,152(s1)
    800001ac:	09c4a703          	lw	a4,156(s1)
    800001b0:	0af71063          	bne	a4,a5,80000250 <_Z11consolereadimj+0xe4>
      if (killed(myproc())) {
    800001b4:	706010ef          	jal	800018ba <_Z6myprocv>
    800001b8:	741010ef          	jal	800020f8 <_Z6killedP4proc>
    800001bc:	e12d                	bnez	a0,8000021e <_Z11consolereadimj+0xb2>
      sleep(&cons.r, &cons.lock);
    800001be:	85a6                	mv	a1,s1
    800001c0:	854a                	mv	a0,s2
    800001c2:	4ff010ef          	jal	80001ec0 <_Z5sleepPvP8spinlock>
    while (cons.r == cons.w) {
    800001c6:	0984a783          	lw	a5,152(s1)
    800001ca:	09c4a703          	lw	a4,156(s1)
    800001ce:	fef703e3          	beq	a4,a5,800001b4 <_Z11consolereadimj+0x48>
    800001d2:	ec5e                	sd	s7,24(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001d4:	0000f717          	auipc	a4,0xf
    800001d8:	69c70713          	addi	a4,a4,1692 # 8000f870 <cons>
    800001dc:	0017869b          	addiw	a3,a5,1
    800001e0:	08d72c23          	sw	a3,152(a4)
    800001e4:	07f7f693          	andi	a3,a5,127
    800001e8:	9736                	add	a4,a4,a3
    800001ea:	01874703          	lbu	a4,24(a4)
    800001ee:	00070b9b          	sext.w	s7,a4

    if (c == C('D')) { // end-of-file
    800001f2:	4691                	li	a3,4
    800001f4:	04db8663          	beq	s7,a3,80000240 <_Z11consolereadimj+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    800001f8:	fae407a3          	sb	a4,-81(s0)
    if (either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800001fc:	4685                	li	a3,1
    800001fe:	faf40613          	addi	a2,s0,-81
    80000202:	85d6                	mv	a1,s5
    80000204:	855a                	mv	a0,s6
    80000206:	016020ef          	jal	8000221c <_Z14either_copyoutimPKvm>
    8000020a:	57fd                	li	a5,-1
    8000020c:	04f50663          	beq	a0,a5,80000258 <_Z11consolereadimj+0xec>
      break;

    dst++;
    80000210:	0a85                	addi	s5,s5,1
    --n;
    80000212:	3a7d                	addiw	s4,s4,-1

    if (c == '\n') {
    80000214:	47a9                	li	a5,10
    80000216:	04fb8b63          	beq	s7,a5,8000026c <_Z11consolereadimj+0x100>
    8000021a:	6be2                	ld	s7,24(sp)
    8000021c:	b761                	j	800001a4 <_Z11consolereadimj+0x38>
        release(&cons.lock);
    8000021e:	0000f517          	auipc	a0,0xf
    80000222:	65250513          	addi	a0,a0,1618 # 8000f870 <cons>
    80000226:	227000ef          	jal	80000c4c <_Z7releaseP8spinlock>
        return -1;
    8000022a:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    8000022c:	60e6                	ld	ra,88(sp)
    8000022e:	6446                	ld	s0,80(sp)
    80000230:	64a6                	ld	s1,72(sp)
    80000232:	6906                	ld	s2,64(sp)
    80000234:	79e2                	ld	s3,56(sp)
    80000236:	7a42                	ld	s4,48(sp)
    80000238:	7aa2                	ld	s5,40(sp)
    8000023a:	7b02                	ld	s6,32(sp)
    8000023c:	6125                	addi	sp,sp,96
    8000023e:	8082                	ret
      if (n < target) {
    80000240:	013a7a63          	bgeu	s4,s3,80000254 <_Z11consolereadimj+0xe8>
        cons.r--;
    80000244:	0000f717          	auipc	a4,0xf
    80000248:	6cf72223          	sw	a5,1732(a4) # 8000f908 <cons+0x98>
    8000024c:	6be2                	ld	s7,24(sp)
    8000024e:	a031                	j	8000025a <_Z11consolereadimj+0xee>
    80000250:	ec5e                	sd	s7,24(sp)
    80000252:	b749                	j	800001d4 <_Z11consolereadimj+0x68>
    80000254:	6be2                	ld	s7,24(sp)
    80000256:	a011                	j	8000025a <_Z11consolereadimj+0xee>
    80000258:	6be2                	ld	s7,24(sp)
  release(&cons.lock);
    8000025a:	0000f517          	auipc	a0,0xf
    8000025e:	61650513          	addi	a0,a0,1558 # 8000f870 <cons>
    80000262:	1eb000ef          	jal	80000c4c <_Z7releaseP8spinlock>
  return target - n;
    80000266:	4149853b          	subw	a0,s3,s4
    8000026a:	b7c9                	j	8000022c <_Z11consolereadimj+0xc0>
    8000026c:	6be2                	ld	s7,24(sp)
    8000026e:	b7f5                	j	8000025a <_Z11consolereadimj+0xee>

0000000080000270 <_Z8consputci>:
{
    80000270:	1141                	addi	sp,sp,-16
    80000272:	e406                	sd	ra,8(sp)
    80000274:	e022                	sd	s0,0(sp)
    80000276:	0800                	addi	s0,sp,16
  if (c == BACKSPACE) {
    80000278:	10000793          	li	a5,256
    8000027c:	00f50863          	beq	a0,a5,8000028c <_Z8consputci+0x1c>
    uartputc_sync(c);
    80000280:	6be000ef          	jal	8000093e <_Z13uartputc_synci>
}
    80000284:	60a2                	ld	ra,8(sp)
    80000286:	6402                	ld	s0,0(sp)
    80000288:	0141                	addi	sp,sp,16
    8000028a:	8082                	ret
    uartputc_sync('\b');
    8000028c:	4521                	li	a0,8
    8000028e:	6b0000ef          	jal	8000093e <_Z13uartputc_synci>
    uartputc_sync(' ');
    80000292:	02000513          	li	a0,32
    80000296:	6a8000ef          	jal	8000093e <_Z13uartputc_synci>
    uartputc_sync('\b');
    8000029a:	4521                	li	a0,8
    8000029c:	6a2000ef          	jal	8000093e <_Z13uartputc_synci>
    800002a0:	b7d5                	j	80000284 <_Z8consputci+0x14>

00000000800002a2 <_Z11consoleintri>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002a2:	1101                	addi	sp,sp,-32
    800002a4:	ec06                	sd	ra,24(sp)
    800002a6:	e822                	sd	s0,16(sp)
    800002a8:	e426                	sd	s1,8(sp)
    800002aa:	1000                	addi	s0,sp,32
    800002ac:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002ae:	0000f517          	auipc	a0,0xf
    800002b2:	5c250513          	addi	a0,a0,1474 # 8000f870 <cons>
    800002b6:	10b000ef          	jal	80000bc0 <_Z7acquireP8spinlock>

  switch (c) {
    800002ba:	47d5                	li	a5,21
    800002bc:	08f48f63          	beq	s1,a5,8000035a <_Z11consoleintri+0xb8>
    800002c0:	0297c563          	blt	a5,s1,800002ea <_Z11consoleintri+0x48>
    800002c4:	47a1                	li	a5,8
    800002c6:	0ef48463          	beq	s1,a5,800003ae <_Z11consoleintri+0x10c>
    800002ca:	47c1                	li	a5,16
    800002cc:	10f49563          	bne	s1,a5,800003d6 <_Z11consoleintri+0x134>
  case C('P'): // Print process list.
    procdump();
    800002d0:	7e1010ef          	jal	800022b0 <_Z8procdumpv>
      }
    }
    break;
  }

  release(&cons.lock);
    800002d4:	0000f517          	auipc	a0,0xf
    800002d8:	59c50513          	addi	a0,a0,1436 # 8000f870 <cons>
    800002dc:	171000ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    800002e0:	60e2                	ld	ra,24(sp)
    800002e2:	6442                	ld	s0,16(sp)
    800002e4:	64a2                	ld	s1,8(sp)
    800002e6:	6105                	addi	sp,sp,32
    800002e8:	8082                	ret
  switch (c) {
    800002ea:	07f00793          	li	a5,127
    800002ee:	0cf48063          	beq	s1,a5,800003ae <_Z11consoleintri+0x10c>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    800002f2:	0000f717          	auipc	a4,0xf
    800002f6:	57e70713          	addi	a4,a4,1406 # 8000f870 <cons>
    800002fa:	0a072783          	lw	a5,160(a4)
    800002fe:	09872703          	lw	a4,152(a4)
    80000302:	9f99                	subw	a5,a5,a4
    80000304:	07f00713          	li	a4,127
    80000308:	fcf766e3          	bltu	a4,a5,800002d4 <_Z11consoleintri+0x32>
      c = (c == '\r') ? '\n' : c;
    8000030c:	47b5                	li	a5,13
    8000030e:	0cf48763          	beq	s1,a5,800003dc <_Z11consoleintri+0x13a>
      consputc(c);
    80000312:	8526                	mv	a0,s1
    80000314:	f5dff0ef          	jal	80000270 <_Z8consputci>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000318:	0000f797          	auipc	a5,0xf
    8000031c:	55878793          	addi	a5,a5,1368 # 8000f870 <cons>
    80000320:	0a07a683          	lw	a3,160(a5)
    80000324:	0016871b          	addiw	a4,a3,1
    80000328:	0007061b          	sext.w	a2,a4
    8000032c:	0ae7a023          	sw	a4,160(a5)
    80000330:	07f6f693          	andi	a3,a3,127
    80000334:	97b6                	add	a5,a5,a3
    80000336:	00978c23          	sb	s1,24(a5)
      if (c == '\n' || c == C('D') || cons.e - cons.r == INPUT_BUF_SIZE) {
    8000033a:	47a9                	li	a5,10
    8000033c:	0cf48563          	beq	s1,a5,80000406 <_Z11consoleintri+0x164>
    80000340:	4791                	li	a5,4
    80000342:	0cf48263          	beq	s1,a5,80000406 <_Z11consoleintri+0x164>
    80000346:	0000f797          	auipc	a5,0xf
    8000034a:	5c27a783          	lw	a5,1474(a5) # 8000f908 <cons+0x98>
    8000034e:	9f1d                	subw	a4,a4,a5
    80000350:	08000793          	li	a5,128
    80000354:	f8f710e3          	bne	a4,a5,800002d4 <_Z11consoleintri+0x32>
    80000358:	a07d                	j	80000406 <_Z11consoleintri+0x164>
    8000035a:	e04a                	sd	s2,0(sp)
    while (cons.e != cons.w &&
    8000035c:	0000f717          	auipc	a4,0xf
    80000360:	51470713          	addi	a4,a4,1300 # 8000f870 <cons>
    80000364:	0a072783          	lw	a5,160(a4)
    80000368:	09c72703          	lw	a4,156(a4)
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    8000036c:	0000f497          	auipc	s1,0xf
    80000370:	50448493          	addi	s1,s1,1284 # 8000f870 <cons>
    while (cons.e != cons.w &&
    80000374:	4929                	li	s2,10
    80000376:	02f70863          	beq	a4,a5,800003a6 <_Z11consoleintri+0x104>
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    8000037a:	37fd                	addiw	a5,a5,-1
    8000037c:	07f7f713          	andi	a4,a5,127
    80000380:	9726                	add	a4,a4,s1
    while (cons.e != cons.w &&
    80000382:	01874703          	lbu	a4,24(a4)
    80000386:	03270263          	beq	a4,s2,800003aa <_Z11consoleintri+0x108>
      cons.e--;
    8000038a:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    8000038e:	10000513          	li	a0,256
    80000392:	edfff0ef          	jal	80000270 <_Z8consputci>
    while (cons.e != cons.w &&
    80000396:	0a04a783          	lw	a5,160(s1)
    8000039a:	09c4a703          	lw	a4,156(s1)
    8000039e:	fcf71ee3          	bne	a4,a5,8000037a <_Z11consoleintri+0xd8>
    800003a2:	6902                	ld	s2,0(sp)
    800003a4:	bf05                	j	800002d4 <_Z11consoleintri+0x32>
    800003a6:	6902                	ld	s2,0(sp)
    800003a8:	b735                	j	800002d4 <_Z11consoleintri+0x32>
    800003aa:	6902                	ld	s2,0(sp)
    800003ac:	b725                	j	800002d4 <_Z11consoleintri+0x32>
    if (cons.e != cons.w) {
    800003ae:	0000f717          	auipc	a4,0xf
    800003b2:	4c270713          	addi	a4,a4,1218 # 8000f870 <cons>
    800003b6:	0a072783          	lw	a5,160(a4)
    800003ba:	09c72703          	lw	a4,156(a4)
    800003be:	f0f70be3          	beq	a4,a5,800002d4 <_Z11consoleintri+0x32>
      cons.e--;
    800003c2:	37fd                	addiw	a5,a5,-1
    800003c4:	0000f717          	auipc	a4,0xf
    800003c8:	54f72623          	sw	a5,1356(a4) # 8000f910 <cons+0xa0>
      consputc(BACKSPACE);
    800003cc:	10000513          	li	a0,256
    800003d0:	ea1ff0ef          	jal	80000270 <_Z8consputci>
    800003d4:	b701                	j	800002d4 <_Z11consoleintri+0x32>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    800003d6:	ee048fe3          	beqz	s1,800002d4 <_Z11consoleintri+0x32>
    800003da:	bf21                	j	800002f2 <_Z11consoleintri+0x50>
      consputc(c);
    800003dc:	4529                	li	a0,10
    800003de:	e93ff0ef          	jal	80000270 <_Z8consputci>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003e2:	0000f797          	auipc	a5,0xf
    800003e6:	48e78793          	addi	a5,a5,1166 # 8000f870 <cons>
    800003ea:	0a07a703          	lw	a4,160(a5)
    800003ee:	0017069b          	addiw	a3,a4,1
    800003f2:	0006861b          	sext.w	a2,a3
    800003f6:	0ad7a023          	sw	a3,160(a5)
    800003fa:	07f77713          	andi	a4,a4,127
    800003fe:	97ba                	add	a5,a5,a4
    80000400:	4729                	li	a4,10
    80000402:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    80000406:	0000f797          	auipc	a5,0xf
    8000040a:	50c7a323          	sw	a2,1286(a5) # 8000f90c <cons+0x9c>
        wakeup(&cons.r);
    8000040e:	0000f517          	auipc	a0,0xf
    80000412:	4fa50513          	addi	a0,a0,1274 # 8000f908 <cons+0x98>
    80000416:	2f7010ef          	jal	80001f0c <_Z6wakeupPv>
    8000041a:	bd6d                	j	800002d4 <_Z11consoleintri+0x32>

000000008000041c <_Z11consoleinitv>:

void
consoleinit(void)
{
    8000041c:	1141                	addi	sp,sp,-16
    8000041e:	e406                	sd	ra,8(sp)
    80000420:	e022                	sd	s0,0(sp)
    80000422:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000424:	00007597          	auipc	a1,0x7
    80000428:	bdc58593          	addi	a1,a1,-1060 # 80007000 <etext>
    8000042c:	0000f517          	auipc	a0,0xf
    80000430:	44450513          	addi	a0,a0,1092 # 8000f870 <cons>
    80000434:	716000ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>

  uartinit();
    80000438:	41a000ef          	jal	80000852 <_Z8uartinitv>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    8000043c:	0001f797          	auipc	a5,0x1f
    80000440:	5a478793          	addi	a5,a5,1444 # 8001f9e0 <devsw>
    80000444:	00000717          	auipc	a4,0x0
    80000448:	d2870713          	addi	a4,a4,-728 # 8000016c <_Z11consolereadimj>
    8000044c:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    8000044e:	00000717          	auipc	a4,0x0
    80000452:	c8470713          	addi	a4,a4,-892 # 800000d2 <_Z12consolewriteimj>
    80000456:	ef98                	sd	a4,24(a5)
}
    80000458:	60a2                	ld	ra,8(sp)
    8000045a:	6402                	ld	s0,0(sp)
    8000045c:	0141                	addi	sp,sp,16
    8000045e:	8082                	ret

0000000080000460 <_ZL8printintxii>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000460:	7139                	addi	sp,sp,-64
    80000462:	fc06                	sd	ra,56(sp)
    80000464:	f822                	sd	s0,48(sp)
    80000466:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if (sign && (sign = (xx < 0)))
    80000468:	c219                	beqz	a2,8000046e <_ZL8printintxii+0xe>
    8000046a:	08054063          	bltz	a0,800004ea <_ZL8printintxii+0x8a>
    x = -xx;
  else
    x = xx;
    8000046e:	4881                	li	a7,0
    80000470:	fc840693          	addi	a3,s0,-56

  i = 0;
    80000474:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    80000476:	00007617          	auipc	a2,0x7
    8000047a:	29a60613          	addi	a2,a2,666 # 80007710 <_ZL6digits>
    8000047e:	883e                	mv	a6,a5
    80000480:	2785                	addiw	a5,a5,1
    80000482:	02b57733          	remu	a4,a0,a1
    80000486:	9732                	add	a4,a4,a2
    80000488:	00074703          	lbu	a4,0(a4)
    8000048c:	00e68023          	sb	a4,0(a3)
  } while ((x /= base) != 0);
    80000490:	872a                	mv	a4,a0
    80000492:	02b55533          	divu	a0,a0,a1
    80000496:	0685                	addi	a3,a3,1
    80000498:	feb773e3          	bgeu	a4,a1,8000047e <_ZL8printintxii+0x1e>

  if (sign)
    8000049c:	00088a63          	beqz	a7,800004b0 <_ZL8printintxii+0x50>
    buf[i++] = '-';
    800004a0:	1781                	addi	a5,a5,-32
    800004a2:	97a2                	add	a5,a5,s0
    800004a4:	02d00713          	li	a4,45
    800004a8:	fee78423          	sb	a4,-24(a5)
    800004ac:	0028079b          	addiw	a5,a6,2

  while (--i >= 0)
    800004b0:	02f05963          	blez	a5,800004e2 <_ZL8printintxii+0x82>
    800004b4:	f426                	sd	s1,40(sp)
    800004b6:	f04a                	sd	s2,32(sp)
    800004b8:	fc840713          	addi	a4,s0,-56
    800004bc:	00f704b3          	add	s1,a4,a5
    800004c0:	fff70913          	addi	s2,a4,-1
    800004c4:	993e                	add	s2,s2,a5
    800004c6:	37fd                	addiw	a5,a5,-1
    800004c8:	1782                	slli	a5,a5,0x20
    800004ca:	9381                	srli	a5,a5,0x20
    800004cc:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    800004d0:	fff4c503          	lbu	a0,-1(s1)
    800004d4:	d9dff0ef          	jal	80000270 <_Z8consputci>
  while (--i >= 0)
    800004d8:	14fd                	addi	s1,s1,-1
    800004da:	ff249be3          	bne	s1,s2,800004d0 <_ZL8printintxii+0x70>
    800004de:	74a2                	ld	s1,40(sp)
    800004e0:	7902                	ld	s2,32(sp)
}
    800004e2:	70e2                	ld	ra,56(sp)
    800004e4:	7442                	ld	s0,48(sp)
    800004e6:	6121                	addi	sp,sp,64
    800004e8:	8082                	ret
    x = -xx;
    800004ea:	40a00533          	neg	a0,a0
  if (sign && (sign = (xx < 0)))
    800004ee:	4885                	li	a7,1
    800004f0:	b741                	j	80000470 <_ZL8printintxii+0x10>

00000000800004f2 <_Z6printkPKcz>:
}

// Print to the console.
int
printk(const char *fmt, ...)
{
    800004f2:	7131                	addi	sp,sp,-192
    800004f4:	fc86                	sd	ra,120(sp)
    800004f6:	f8a2                	sd	s0,112(sp)
    800004f8:	e8d2                	sd	s4,80(sp)
    800004fa:	0100                	addi	s0,sp,128
    800004fc:	8a2a                	mv	s4,a0
    800004fe:	e40c                	sd	a1,8(s0)
    80000500:	e810                	sd	a2,16(s0)
    80000502:	ec14                	sd	a3,24(s0)
    80000504:	f018                	sd	a4,32(s0)
    80000506:	f41c                	sd	a5,40(s0)
    80000508:	03043823          	sd	a6,48(s0)
    8000050c:	03143c23          	sd	a7,56(s0)
  va_list ap;
  uint i;
  int cx, c0, c1, c2;
  const char *s;

  if (panicking == 0)
    80000510:	00007797          	auipc	a5,0x7
    80000514:	3347a783          	lw	a5,820(a5) # 80007844 <panicking>
    80000518:	c3a9                	beqz	a5,8000055a <_Z6printkPKcz+0x68>
    acquire(&pr.lock);

  va_start(ap, fmt);
    8000051a:	00840793          	addi	a5,s0,8
    8000051e:	f8f43423          	sd	a5,-120(s0)
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000522:	000a4503          	lbu	a0,0(s4)
    80000526:	2a050463          	beqz	a0,800007ce <_Z6printkPKcz+0x2dc>
    8000052a:	f4a6                	sd	s1,104(sp)
    8000052c:	f0ca                	sd	s2,96(sp)
    8000052e:	ecce                	sd	s3,88(sp)
    80000530:	e4d6                	sd	s5,72(sp)
    80000532:	e0da                	sd	s6,64(sp)
    80000534:	fc5e                	sd	s7,56(sp)
    80000536:	f862                	sd	s8,48(sp)
    80000538:	f466                	sd	s9,40(sp)
    8000053a:	f06a                	sd	s10,32(sp)
    8000053c:	ec6e                	sd	s11,24(sp)
    8000053e:	4981                	li	s3,0
    if (cx != '%') {
    80000540:	02500a93          	li	s5,37
    c1 = c2 = 0;
    if (c0)
      c1 = fmt[i + 1] & 0xff;
    if (c1)
      c2 = fmt[i + 2] & 0xff;
    if (c0 == 'd') {
    80000544:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if (c0 == 'l' && c1 == 'd') {
    80000548:	06c00b93          	li	s7,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if (c0 == 'u') {
    8000054c:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if (c0 == 'x') {
    80000550:	07800c93          	li	s9,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if (c0 == 'p') {
    80000554:	07000d13          	li	s10,112
    80000558:	a02d                	j	80000582 <_Z6printkPKcz+0x90>
    acquire(&pr.lock);
    8000055a:	0000f517          	auipc	a0,0xf
    8000055e:	3be50513          	addi	a0,a0,958 # 8000f918 <_ZL2pr>
    80000562:	65e000ef          	jal	80000bc0 <_Z7acquireP8spinlock>
    80000566:	bf55                	j	8000051a <_Z6printkPKcz+0x28>
      consputc(cx);
    80000568:	d09ff0ef          	jal	80000270 <_Z8consputci>
      continue;
    8000056c:	84ce                	mv	s1,s3
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    8000056e:	2485                	addiw	s1,s1,1
    80000570:	0004899b          	sext.w	s3,s1
    80000574:	1482                	slli	s1,s1,0x20
    80000576:	9081                	srli	s1,s1,0x20
    80000578:	94d2                	add	s1,s1,s4
    8000057a:	0004c503          	lbu	a0,0(s1)
    8000057e:	22050363          	beqz	a0,800007a4 <_Z6printkPKcz+0x2b2>
    if (cx != '%') {
    80000582:	ff5513e3          	bne	a0,s5,80000568 <_Z6printkPKcz+0x76>
    i++;
    80000586:	0019879b          	addiw	a5,s3,1
    8000058a:	0007849b          	sext.w	s1,a5
    c0 = fmt[i + 0] & 0xff;
    8000058e:	1782                	slli	a5,a5,0x20
    80000590:	9381                	srli	a5,a5,0x20
    80000592:	97d2                	add	a5,a5,s4
    80000594:	0007c903          	lbu	s2,0(a5)
    if (c0)
    80000598:	22090163          	beqz	s2,800007ba <_Z6printkPKcz+0x2c8>
      c1 = fmt[i + 1] & 0xff;
    8000059c:	0029879b          	addiw	a5,s3,2
    800005a0:	00078d9b          	sext.w	s11,a5
    800005a4:	1782                	slli	a5,a5,0x20
    800005a6:	9381                	srli	a5,a5,0x20
    800005a8:	97d2                	add	a5,a5,s4
    800005aa:	0007c783          	lbu	a5,0(a5)
    c1 = c2 = 0;
    800005ae:	873e                	mv	a4,a5
    if (c1)
    800005b0:	cb81                	beqz	a5,800005c0 <_Z6printkPKcz+0xce>
      c2 = fmt[i + 2] & 0xff;
    800005b2:	0039871b          	addiw	a4,s3,3
    800005b6:	1702                	slli	a4,a4,0x20
    800005b8:	9301                	srli	a4,a4,0x20
    800005ba:	9752                	add	a4,a4,s4
    800005bc:	00074703          	lbu	a4,0(a4)
    if (c0 == 'd') {
    800005c0:	03690963          	beq	s2,s6,800005f2 <_Z6printkPKcz+0x100>
    } else if (c0 == 'l' && c1 == 'd') {
    800005c4:	05790363          	beq	s2,s7,8000060a <_Z6printkPKcz+0x118>
    } else if (c0 == 'u') {
    800005c8:	0d890563          	beq	s2,s8,80000692 <_Z6printkPKcz+0x1a0>
    } else if (c0 == 'x') {
    800005cc:	11990b63          	beq	s2,s9,800006e2 <_Z6printkPKcz+0x1f0>
    } else if (c0 == 'p') {
    800005d0:	15a90363          	beq	s2,s10,80000716 <_Z6printkPKcz+0x224>
      printptr(va_arg(ap, uint64));
    } else if (c0 == 'c') {
    800005d4:	06300793          	li	a5,99
    800005d8:	18f90063          	beq	s2,a5,80000758 <_Z6printkPKcz+0x266>
      consputc(va_arg(ap, uint));
    } else if (c0 == 's') {
    800005dc:	07300793          	li	a5,115
    800005e0:	18f90663          	beq	s2,a5,8000076c <_Z6printkPKcz+0x27a>
      if ((s = va_arg(ap, const char *)) == 0)
        s = "(null)";
      for (; *s; s++)
        consputc(*s);
    } else if (c0 == '%') {
    800005e4:	03591b63          	bne	s2,s5,8000061a <_Z6printkPKcz+0x128>
      consputc('%');
    800005e8:	02500513          	li	a0,37
    800005ec:	c85ff0ef          	jal	80000270 <_Z8consputci>
    800005f0:	bfbd                	j	8000056e <_Z6printkPKcz+0x7c>
      printint(va_arg(ap, int), 10, 1);
    800005f2:	f8843783          	ld	a5,-120(s0)
    800005f6:	00878713          	addi	a4,a5,8
    800005fa:	f8e43423          	sd	a4,-120(s0)
    800005fe:	4605                	li	a2,1
    80000600:	45a9                	li	a1,10
    80000602:	4388                	lw	a0,0(a5)
    80000604:	e5dff0ef          	jal	80000460 <_ZL8printintxii>
    80000608:	b79d                	j	8000056e <_Z6printkPKcz+0x7c>
    } else if (c0 == 'l' && c1 == 'd') {
    8000060a:	01678f63          	beq	a5,s6,80000628 <_Z6printkPKcz+0x136>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    8000060e:	03778a63          	beq	a5,s7,80000642 <_Z6printkPKcz+0x150>
    } else if (c0 == 'l' && c1 == 'u') {
    80000612:	09878d63          	beq	a5,s8,800006ac <_Z6printkPKcz+0x1ba>
    } else if (c0 == 'l' && c1 == 'x') {
    80000616:	0f978363          	beq	a5,s9,800006fc <_Z6printkPKcz+0x20a>
    } else if (c0 == 0) {
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    8000061a:	8556                	mv	a0,s5
    8000061c:	c55ff0ef          	jal	80000270 <_Z8consputci>
      consputc(c0);
    80000620:	854a                	mv	a0,s2
    80000622:	c4fff0ef          	jal	80000270 <_Z8consputci>
    80000626:	b7a1                	j	8000056e <_Z6printkPKcz+0x7c>
      printint(va_arg(ap, uint64), 10, 1);
    80000628:	f8843783          	ld	a5,-120(s0)
    8000062c:	00878713          	addi	a4,a5,8
    80000630:	f8e43423          	sd	a4,-120(s0)
    80000634:	4605                	li	a2,1
    80000636:	45a9                	li	a1,10
    80000638:	6388                	ld	a0,0(a5)
    8000063a:	e27ff0ef          	jal	80000460 <_ZL8printintxii>
      i += 1;
    8000063e:	84ee                	mv	s1,s11
    80000640:	b73d                	j	8000056e <_Z6printkPKcz+0x7c>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    80000642:	06400793          	li	a5,100
    80000646:	02f70863          	beq	a4,a5,80000676 <_Z6printkPKcz+0x184>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    8000064a:	07500793          	li	a5,117
    8000064e:	06f70c63          	beq	a4,a5,800006c6 <_Z6printkPKcz+0x1d4>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    80000652:	07800793          	li	a5,120
    80000656:	fcf712e3          	bne	a4,a5,8000061a <_Z6printkPKcz+0x128>
      printint(va_arg(ap, uint64), 16, 0);
    8000065a:	f8843783          	ld	a5,-120(s0)
    8000065e:	00878713          	addi	a4,a5,8
    80000662:	f8e43423          	sd	a4,-120(s0)
    80000666:	4601                	li	a2,0
    80000668:	45c1                	li	a1,16
    8000066a:	6388                	ld	a0,0(a5)
    8000066c:	df5ff0ef          	jal	80000460 <_ZL8printintxii>
      i += 2;
    80000670:	0039849b          	addiw	s1,s3,3
    80000674:	bded                	j	8000056e <_Z6printkPKcz+0x7c>
      printint(va_arg(ap, uint64), 10, 1);
    80000676:	f8843783          	ld	a5,-120(s0)
    8000067a:	00878713          	addi	a4,a5,8
    8000067e:	f8e43423          	sd	a4,-120(s0)
    80000682:	4605                	li	a2,1
    80000684:	45a9                	li	a1,10
    80000686:	6388                	ld	a0,0(a5)
    80000688:	dd9ff0ef          	jal	80000460 <_ZL8printintxii>
      i += 2;
    8000068c:	0039849b          	addiw	s1,s3,3
    80000690:	bdf9                	j	8000056e <_Z6printkPKcz+0x7c>
      printint(va_arg(ap, uint32), 10, 0);
    80000692:	f8843783          	ld	a5,-120(s0)
    80000696:	00878713          	addi	a4,a5,8
    8000069a:	f8e43423          	sd	a4,-120(s0)
    8000069e:	4601                	li	a2,0
    800006a0:	45a9                	li	a1,10
    800006a2:	0007e503          	lwu	a0,0(a5)
    800006a6:	dbbff0ef          	jal	80000460 <_ZL8printintxii>
    800006aa:	b5d1                	j	8000056e <_Z6printkPKcz+0x7c>
      printint(va_arg(ap, uint64), 10, 0);
    800006ac:	f8843783          	ld	a5,-120(s0)
    800006b0:	00878713          	addi	a4,a5,8
    800006b4:	f8e43423          	sd	a4,-120(s0)
    800006b8:	4601                	li	a2,0
    800006ba:	45a9                	li	a1,10
    800006bc:	6388                	ld	a0,0(a5)
    800006be:	da3ff0ef          	jal	80000460 <_ZL8printintxii>
      i += 1;
    800006c2:	84ee                	mv	s1,s11
    800006c4:	b56d                	j	8000056e <_Z6printkPKcz+0x7c>
      printint(va_arg(ap, uint64), 10, 0);
    800006c6:	f8843783          	ld	a5,-120(s0)
    800006ca:	00878713          	addi	a4,a5,8
    800006ce:	f8e43423          	sd	a4,-120(s0)
    800006d2:	4601                	li	a2,0
    800006d4:	45a9                	li	a1,10
    800006d6:	6388                	ld	a0,0(a5)
    800006d8:	d89ff0ef          	jal	80000460 <_ZL8printintxii>
      i += 2;
    800006dc:	0039849b          	addiw	s1,s3,3
    800006e0:	b579                	j	8000056e <_Z6printkPKcz+0x7c>
      printint(va_arg(ap, uint32), 16, 0);
    800006e2:	f8843783          	ld	a5,-120(s0)
    800006e6:	00878713          	addi	a4,a5,8
    800006ea:	f8e43423          	sd	a4,-120(s0)
    800006ee:	4601                	li	a2,0
    800006f0:	45c1                	li	a1,16
    800006f2:	0007e503          	lwu	a0,0(a5)
    800006f6:	d6bff0ef          	jal	80000460 <_ZL8printintxii>
    800006fa:	bd95                	j	8000056e <_Z6printkPKcz+0x7c>
      printint(va_arg(ap, uint64), 16, 0);
    800006fc:	f8843783          	ld	a5,-120(s0)
    80000700:	00878713          	addi	a4,a5,8
    80000704:	f8e43423          	sd	a4,-120(s0)
    80000708:	4601                	li	a2,0
    8000070a:	45c1                	li	a1,16
    8000070c:	6388                	ld	a0,0(a5)
    8000070e:	d53ff0ef          	jal	80000460 <_ZL8printintxii>
      i += 1;
    80000712:	84ee                	mv	s1,s11
    80000714:	bda9                	j	8000056e <_Z6printkPKcz+0x7c>
      printptr(va_arg(ap, uint64));
    80000716:	f8843783          	ld	a5,-120(s0)
    8000071a:	00878713          	addi	a4,a5,8
    8000071e:	f8e43423          	sd	a4,-120(s0)
    80000722:	0007b983          	ld	s3,0(a5)
  consputc('0');
    80000726:	03000513          	li	a0,48
    8000072a:	b47ff0ef          	jal	80000270 <_Z8consputci>
  consputc('x');
    8000072e:	07800513          	li	a0,120
    80000732:	b3fff0ef          	jal	80000270 <_Z8consputci>
    80000736:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80000738:	00007d97          	auipc	s11,0x7
    8000073c:	fd8d8d93          	addi	s11,s11,-40 # 80007710 <_ZL6digits>
    80000740:	03c9d793          	srli	a5,s3,0x3c
    80000744:	97ee                	add	a5,a5,s11
    80000746:	0007c503          	lbu	a0,0(a5)
    8000074a:	b27ff0ef          	jal	80000270 <_Z8consputci>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    8000074e:	0992                	slli	s3,s3,0x4
    80000750:	397d                	addiw	s2,s2,-1
    80000752:	fe0917e3          	bnez	s2,80000740 <_Z6printkPKcz+0x24e>
    80000756:	bd21                	j	8000056e <_Z6printkPKcz+0x7c>
      consputc(va_arg(ap, uint));
    80000758:	f8843783          	ld	a5,-120(s0)
    8000075c:	00878713          	addi	a4,a5,8
    80000760:	f8e43423          	sd	a4,-120(s0)
    80000764:	4388                	lw	a0,0(a5)
    80000766:	b0bff0ef          	jal	80000270 <_Z8consputci>
    8000076a:	b511                	j	8000056e <_Z6printkPKcz+0x7c>
      if ((s = va_arg(ap, const char *)) == 0)
    8000076c:	f8843783          	ld	a5,-120(s0)
    80000770:	00878713          	addi	a4,a5,8
    80000774:	f8e43423          	sd	a4,-120(s0)
    80000778:	0007b903          	ld	s2,0(a5)
    8000077c:	00090d63          	beqz	s2,80000796 <_Z6printkPKcz+0x2a4>
      for (; *s; s++)
    80000780:	00094503          	lbu	a0,0(s2)
    80000784:	de0505e3          	beqz	a0,8000056e <_Z6printkPKcz+0x7c>
        consputc(*s);
    80000788:	ae9ff0ef          	jal	80000270 <_Z8consputci>
      for (; *s; s++)
    8000078c:	0905                	addi	s2,s2,1
    8000078e:	00094503          	lbu	a0,0(s2)
    80000792:	f97d                	bnez	a0,80000788 <_Z6printkPKcz+0x296>
    80000794:	bbe9                	j	8000056e <_Z6printkPKcz+0x7c>
        s = "(null)";
    80000796:	00007917          	auipc	s2,0x7
    8000079a:	87290913          	addi	s2,s2,-1934 # 80007008 <etext+0x8>
      for (; *s; s++)
    8000079e:	02800513          	li	a0,40
    800007a2:	b7dd                	j	80000788 <_Z6printkPKcz+0x296>
    800007a4:	74a6                	ld	s1,104(sp)
    800007a6:	7906                	ld	s2,96(sp)
    800007a8:	69e6                	ld	s3,88(sp)
    800007aa:	6aa6                	ld	s5,72(sp)
    800007ac:	6b06                	ld	s6,64(sp)
    800007ae:	7be2                	ld	s7,56(sp)
    800007b0:	7c42                	ld	s8,48(sp)
    800007b2:	7ca2                	ld	s9,40(sp)
    800007b4:	7d02                	ld	s10,32(sp)
    800007b6:	6de2                	ld	s11,24(sp)
    800007b8:	a819                	j	800007ce <_Z6printkPKcz+0x2dc>
    800007ba:	74a6                	ld	s1,104(sp)
    800007bc:	7906                	ld	s2,96(sp)
    800007be:	69e6                	ld	s3,88(sp)
    800007c0:	6aa6                	ld	s5,72(sp)
    800007c2:	6b06                	ld	s6,64(sp)
    800007c4:	7be2                	ld	s7,56(sp)
    800007c6:	7c42                	ld	s8,48(sp)
    800007c8:	7ca2                	ld	s9,40(sp)
    800007ca:	7d02                	ld	s10,32(sp)
    800007cc:	6de2                	ld	s11,24(sp)
    }
  }
  va_end(ap);

  if (panicking == 0)
    800007ce:	00007797          	auipc	a5,0x7
    800007d2:	0767a783          	lw	a5,118(a5) # 80007844 <panicking>
    800007d6:	c799                	beqz	a5,800007e4 <_Z6printkPKcz+0x2f2>
    release(&pr.lock);

  return 0;
}
    800007d8:	4501                	li	a0,0
    800007da:	70e6                	ld	ra,120(sp)
    800007dc:	7446                	ld	s0,112(sp)
    800007de:	6a46                	ld	s4,80(sp)
    800007e0:	6129                	addi	sp,sp,192
    800007e2:	8082                	ret
    release(&pr.lock);
    800007e4:	0000f517          	auipc	a0,0xf
    800007e8:	13450513          	addi	a0,a0,308 # 8000f918 <_ZL2pr>
    800007ec:	460000ef          	jal	80000c4c <_Z7releaseP8spinlock>
  return 0;
    800007f0:	b7e5                	j	800007d8 <_Z6printkPKcz+0x2e6>

00000000800007f2 <_Z5panicPKc>:

void
panic(const char *s)
{
    800007f2:	1101                	addi	sp,sp,-32
    800007f4:	ec06                	sd	ra,24(sp)
    800007f6:	e822                	sd	s0,16(sp)
    800007f8:	e426                	sd	s1,8(sp)
    800007fa:	e04a                	sd	s2,0(sp)
    800007fc:	1000                	addi	s0,sp,32
    800007fe:	84aa                	mv	s1,a0
  panicking = 1;
    80000800:	4905                	li	s2,1
    80000802:	00007797          	auipc	a5,0x7
    80000806:	0527a123          	sw	s2,66(a5) # 80007844 <panicking>
  printk("panic: ");
    8000080a:	00007517          	auipc	a0,0x7
    8000080e:	80e50513          	addi	a0,a0,-2034 # 80007018 <etext+0x18>
    80000812:	ce1ff0ef          	jal	800004f2 <_Z6printkPKcz>
  printk("%s\n", s);
    80000816:	85a6                	mv	a1,s1
    80000818:	00007517          	auipc	a0,0x7
    8000081c:	80850513          	addi	a0,a0,-2040 # 80007020 <etext+0x20>
    80000820:	cd3ff0ef          	jal	800004f2 <_Z6printkPKcz>
  panicked = 1; // freeze uart output from other CPUs
    80000824:	00007797          	auipc	a5,0x7
    80000828:	0127ae23          	sw	s2,28(a5) # 80007840 <panicked>
  for (;;)
    8000082c:	a001                	j	8000082c <_Z5panicPKc+0x3a>

000000008000082e <_Z10printkinitv>:
    ;
}

void
printkinit(void)
{
    8000082e:	1141                	addi	sp,sp,-16
    80000830:	e406                	sd	ra,8(sp)
    80000832:	e022                	sd	s0,0(sp)
    80000834:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000836:	00006597          	auipc	a1,0x6
    8000083a:	7f258593          	addi	a1,a1,2034 # 80007028 <etext+0x28>
    8000083e:	0000f517          	auipc	a0,0xf
    80000842:	0da50513          	addi	a0,a0,218 # 8000f918 <_ZL2pr>
    80000846:	304000ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>
}
    8000084a:	60a2                	ld	ra,8(sp)
    8000084c:	6402                	ld	s0,0(sp)
    8000084e:	0141                	addi	sp,sp,16
    80000850:	8082                	ret

0000000080000852 <_Z8uartinitv>:
extern volatile int panicking; // from printk.c
extern volatile int panicked;  // from printk.c

void
uartinit(void)
{
    80000852:	1141                	addi	sp,sp,-16
    80000854:	e406                	sd	ra,8(sp)
    80000856:	e022                	sd	s0,0(sp)
    80000858:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000085a:	100007b7          	lui	a5,0x10000
    8000085e:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000862:	10000737          	lui	a4,0x10000
    80000866:	f8000693          	li	a3,-128
    8000086a:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    8000086e:	468d                	li	a3,3
    80000870:	10000637          	lui	a2,0x10000
    80000874:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80000878:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    8000087c:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80000880:	10000737          	lui	a4,0x10000
    80000884:	461d                	li	a2,7
    80000886:	00c70123          	sb	a2,2(a4) # 10000002 <_entry-0x6ffffffe>

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    8000088a:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    8000088e:	00006597          	auipc	a1,0x6
    80000892:	7a258593          	addi	a1,a1,1954 # 80007030 <etext+0x30>
    80000896:	0000f517          	auipc	a0,0xf
    8000089a:	09a50513          	addi	a0,a0,154 # 8000f930 <_ZL7tx_lock>
    8000089e:	2ac000ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>
}
    800008a2:	60a2                	ld	ra,8(sp)
    800008a4:	6402                	ld	s0,0(sp)
    800008a6:	0141                	addi	sp,sp,16
    800008a8:	8082                	ret

00000000800008aa <_Z9uartwritePci>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008aa:	715d                	addi	sp,sp,-80
    800008ac:	e486                	sd	ra,72(sp)
    800008ae:	e0a2                	sd	s0,64(sp)
    800008b0:	fc26                	sd	s1,56(sp)
    800008b2:	ec56                	sd	s5,24(sp)
    800008b4:	0880                	addi	s0,sp,80
    800008b6:	8aaa                	mv	s5,a0
    800008b8:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008ba:	0000f517          	auipc	a0,0xf
    800008be:	07650513          	addi	a0,a0,118 # 8000f930 <_ZL7tx_lock>
    800008c2:	2fe000ef          	jal	80000bc0 <_Z7acquireP8spinlock>

  int i = 0;
  while (i < n) {
    800008c6:	06905063          	blez	s1,80000926 <_Z9uartwritePci+0x7c>
    800008ca:	f84a                	sd	s2,48(sp)
    800008cc:	f44e                	sd	s3,40(sp)
    800008ce:	f052                	sd	s4,32(sp)
    800008d0:	e85a                	sd	s6,16(sp)
    800008d2:	e45e                	sd	s7,8(sp)
    800008d4:	8a56                	mv	s4,s5
    800008d6:	9aa6                	add	s5,s5,s1
    while (tx_busy != 0) {
    800008d8:	00007497          	auipc	s1,0x7
    800008dc:	f7448493          	addi	s1,s1,-140 # 8000784c <_ZL7tx_busy>
      // wait for a UART transmit-complete interrupt
      // to set tx_busy to 0.
      sleep(&tx_chan, &tx_lock);
    800008e0:	0000f997          	auipc	s3,0xf
    800008e4:	05098993          	addi	s3,s3,80 # 8000f930 <_ZL7tx_lock>
    800008e8:	00007917          	auipc	s2,0x7
    800008ec:	f6090913          	addi	s2,s2,-160 # 80007848 <_ZL7tx_chan>
    }

    WriteReg(THR, buf[i]);
    800008f0:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    800008f4:	4b05                	li	s6,1
    800008f6:	a005                	j	80000916 <_Z9uartwritePci+0x6c>
      sleep(&tx_chan, &tx_lock);
    800008f8:	85ce                	mv	a1,s3
    800008fa:	854a                	mv	a0,s2
    800008fc:	5c4010ef          	jal	80001ec0 <_Z5sleepPvP8spinlock>
    while (tx_busy != 0) {
    80000900:	409c                	lw	a5,0(s1)
    80000902:	fbfd                	bnez	a5,800008f8 <_Z9uartwritePci+0x4e>
    WriteReg(THR, buf[i]);
    80000904:	000a4783          	lbu	a5,0(s4)
    80000908:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    8000090c:	0164a023          	sw	s6,0(s1)
  while (i < n) {
    80000910:	0a05                	addi	s4,s4,1
    80000912:	015a0563          	beq	s4,s5,8000091c <_Z9uartwritePci+0x72>
    while (tx_busy != 0) {
    80000916:	409c                	lw	a5,0(s1)
    80000918:	f3e5                	bnez	a5,800008f8 <_Z9uartwritePci+0x4e>
    8000091a:	b7ed                	j	80000904 <_Z9uartwritePci+0x5a>
    8000091c:	7942                	ld	s2,48(sp)
    8000091e:	79a2                	ld	s3,40(sp)
    80000920:	7a02                	ld	s4,32(sp)
    80000922:	6b42                	ld	s6,16(sp)
    80000924:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000926:	0000f517          	auipc	a0,0xf
    8000092a:	00a50513          	addi	a0,a0,10 # 8000f930 <_ZL7tx_lock>
    8000092e:	31e000ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80000932:	60a6                	ld	ra,72(sp)
    80000934:	6406                	ld	s0,64(sp)
    80000936:	74e2                	ld	s1,56(sp)
    80000938:	6ae2                	ld	s5,24(sp)
    8000093a:	6161                	addi	sp,sp,80
    8000093c:	8082                	ret

000000008000093e <_Z13uartputc_synci>:
// interrupts, for use by kernel printk() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000093e:	1101                	addi	sp,sp,-32
    80000940:	ec06                	sd	ra,24(sp)
    80000942:	e822                	sd	s0,16(sp)
    80000944:	e426                	sd	s1,8(sp)
    80000946:	1000                	addi	s0,sp,32
    80000948:	84aa                	mv	s1,a0
  if (panicking == 0)
    8000094a:	00007797          	auipc	a5,0x7
    8000094e:	efa7a783          	lw	a5,-262(a5) # 80007844 <panicking>
    80000952:	cf95                	beqz	a5,8000098e <_Z13uartputc_synci+0x50>
    push_off();

  if (panicked) {
    80000954:	00007797          	auipc	a5,0x7
    80000958:	eec7a783          	lw	a5,-276(a5) # 80007840 <panicked>
    8000095c:	ef85                	bnez	a5,80000994 <_Z13uartputc_synci+0x56>
    for (;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000095e:	10000737          	lui	a4,0x10000
    80000962:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000964:	00074783          	lbu	a5,0(a4)
    80000968:	0207f793          	andi	a5,a5,32
    8000096c:	dfe5                	beqz	a5,80000964 <_Z13uartputc_synci+0x26>
    ;
  WriteReg(THR, c);
    8000096e:	0ff4f513          	zext.b	a0,s1
    80000972:	100007b7          	lui	a5,0x10000
    80000976:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if (panicking == 0)
    8000097a:	00007797          	auipc	a5,0x7
    8000097e:	eca7a783          	lw	a5,-310(a5) # 80007844 <panicking>
    80000982:	cb91                	beqz	a5,80000996 <_Z13uartputc_synci+0x58>
    pop_off();
}
    80000984:	60e2                	ld	ra,24(sp)
    80000986:	6442                	ld	s0,16(sp)
    80000988:	64a2                	ld	s1,8(sp)
    8000098a:	6105                	addi	sp,sp,32
    8000098c:	8082                	ret
    push_off();
    8000098e:	1fc000ef          	jal	80000b8a <_Z8push_offv>
    80000992:	b7c9                	j	80000954 <_Z13uartputc_synci+0x16>
    for (;;)
    80000994:	a001                	j	80000994 <_Z13uartputc_synci+0x56>
    pop_off();
    80000996:	26a000ef          	jal	80000c00 <_Z7pop_offv>
}
    8000099a:	b7ed                	j	80000984 <_Z13uartputc_synci+0x46>

000000008000099c <_Z8uartintrv>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    8000099c:	1101                	addi	sp,sp,-32
    8000099e:	ec06                	sd	ra,24(sp)
    800009a0:	e822                	sd	s0,16(sp)
    800009a2:	e426                	sd	s1,8(sp)
    800009a4:	e04a                	sd	s2,0(sp)
    800009a6:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009a8:	100007b7          	lui	a5,0x10000
    800009ac:	0789                	addi	a5,a5,2 # 10000002 <_entry-0x6ffffffe>
    800009ae:	0007c783          	lbu	a5,0(a5)

  acquire(&tx_lock);
    800009b2:	0000f517          	auipc	a0,0xf
    800009b6:	f7e50513          	addi	a0,a0,-130 # 8000f930 <_ZL7tx_lock>
    800009ba:	206000ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  if (ReadReg(LSR) & LSR_TX_IDLE) {
    800009be:	100007b7          	lui	a5,0x10000
    800009c2:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    800009c4:	0007c783          	lbu	a5,0(a5)
    800009c8:	0207f793          	andi	a5,a5,32
    800009cc:	ef89                	bnez	a5,800009e6 <_Z8uartintrv+0x4a>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    800009ce:	0000f517          	auipc	a0,0xf
    800009d2:	f6250513          	addi	a0,a0,-158 # 8000f930 <_ZL7tx_lock>
    800009d6:	276000ef          	jal	80000c4c <_Z7releaseP8spinlock>
  if (ReadReg(LSR) & LSR_RX_READY) {
    800009da:	100004b7          	lui	s1,0x10000
    800009de:	0495                	addi	s1,s1,5 # 10000005 <_entry-0x6ffffffb>
    return ReadReg(RHR);
    800009e0:	10000937          	lui	s2,0x10000
    800009e4:	a005                	j	80000a04 <_Z8uartintrv+0x68>
    tx_busy = 0;
    800009e6:	00007797          	auipc	a5,0x7
    800009ea:	e607a323          	sw	zero,-410(a5) # 8000784c <_ZL7tx_busy>
    wakeup(&tx_chan);
    800009ee:	00007517          	auipc	a0,0x7
    800009f2:	e5a50513          	addi	a0,a0,-422 # 80007848 <_ZL7tx_chan>
    800009f6:	516010ef          	jal	80001f0c <_Z6wakeupPv>
    800009fa:	bfd1                	j	800009ce <_Z8uartintrv+0x32>
    return ReadReg(RHR);
    800009fc:	00094503          	lbu	a0,0(s2) # 10000000 <_entry-0x70000000>
  // read and process incoming characters, if any.
  while (1) {
    int c = uartgetc();
    if (c == -1)
      break;
    consoleintr(c);
    80000a00:	8a3ff0ef          	jal	800002a2 <_Z11consoleintri>
  if (ReadReg(LSR) & LSR_RX_READY) {
    80000a04:	0004c783          	lbu	a5,0(s1)
    80000a08:	8b85                	andi	a5,a5,1
    80000a0a:	fbed                	bnez	a5,800009fc <_Z8uartintrv+0x60>
  }
}
    80000a0c:	60e2                	ld	ra,24(sp)
    80000a0e:	6442                	ld	s0,16(sp)
    80000a10:	64a2                	ld	s1,8(sp)
    80000a12:	6902                	ld	s2,0(sp)
    80000a14:	6105                	addi	sp,sp,32
    80000a16:	8082                	ret

0000000080000a18 <_Z5kfreePv>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a18:	1101                	addi	sp,sp,-32
    80000a1a:	ec06                	sd	ra,24(sp)
    80000a1c:	e822                	sd	s0,16(sp)
    80000a1e:	e426                	sd	s1,8(sp)
    80000a20:	e04a                	sd	s2,0(sp)
    80000a22:	1000                	addi	s0,sp,32
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (char *)pa < end || (uint64)pa >= PHYSTOP)
    80000a24:	03451793          	slli	a5,a0,0x34
    80000a28:	e7a9                	bnez	a5,80000a72 <_Z5kfreePv+0x5a>
    80000a2a:	84aa                	mv	s1,a0
    80000a2c:	00020797          	auipc	a5,0x20
    80000a30:	14c78793          	addi	a5,a5,332 # 80020b78 <end>
    80000a34:	02f56f63          	bltu	a0,a5,80000a72 <_Z5kfreePv+0x5a>
    80000a38:	47c5                	li	a5,17
    80000a3a:	07ee                	slli	a5,a5,0x1b
    80000a3c:	02f57b63          	bgeu	a0,a5,80000a72 <_Z5kfreePv+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a40:	6605                	lui	a2,0x1
    80000a42:	4585                	li	a1,1
    80000a44:	240000ef          	jal	80000c84 <_Z6memsetPvij>

  r = (struct run *)pa;

  acquire(&kmem.lock);
    80000a48:	0000f917          	auipc	s2,0xf
    80000a4c:	f0090913          	addi	s2,s2,-256 # 8000f948 <kmem>
    80000a50:	854a                	mv	a0,s2
    80000a52:	16e000ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  r->next = kmem.freelist;
    80000a56:	01893783          	ld	a5,24(s2)
    80000a5a:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a5c:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a60:	854a                	mv	a0,s2
    80000a62:	1ea000ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80000a66:	60e2                	ld	ra,24(sp)
    80000a68:	6442                	ld	s0,16(sp)
    80000a6a:	64a2                	ld	s1,8(sp)
    80000a6c:	6902                	ld	s2,0(sp)
    80000a6e:	6105                	addi	sp,sp,32
    80000a70:	8082                	ret
    panic("kfree");
    80000a72:	00006517          	auipc	a0,0x6
    80000a76:	5c650513          	addi	a0,a0,1478 # 80007038 <etext+0x38>
    80000a7a:	d79ff0ef          	jal	800007f2 <_Z5panicPKc>

0000000080000a7e <_Z9freerangePvS_>:
{
    80000a7e:	7179                	addi	sp,sp,-48
    80000a80:	f406                	sd	ra,40(sp)
    80000a82:	f022                	sd	s0,32(sp)
    80000a84:	ec26                	sd	s1,24(sp)
    80000a86:	1800                	addi	s0,sp,48
  p = (char *)PGROUNDUP((uint64)pa_start);
    80000a88:	6785                	lui	a5,0x1
    80000a8a:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000a8e:	00e504b3          	add	s1,a0,a4
    80000a92:	777d                	lui	a4,0xfffff
    80000a94:	8cf9                	and	s1,s1,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000a96:	94be                	add	s1,s1,a5
    80000a98:	0295e263          	bltu	a1,s1,80000abc <_Z9freerangePvS_+0x3e>
    80000a9c:	e84a                	sd	s2,16(sp)
    80000a9e:	e44e                	sd	s3,8(sp)
    80000aa0:	e052                	sd	s4,0(sp)
    80000aa2:	892e                	mv	s2,a1
    kfree(p);
    80000aa4:	7a7d                	lui	s4,0xfffff
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000aa6:	6985                	lui	s3,0x1
    kfree(p);
    80000aa8:	01448533          	add	a0,s1,s4
    80000aac:	f6dff0ef          	jal	80000a18 <_Z5kfreePv>
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000ab0:	94ce                	add	s1,s1,s3
    80000ab2:	fe997be3          	bgeu	s2,s1,80000aa8 <_Z9freerangePvS_+0x2a>
    80000ab6:	6942                	ld	s2,16(sp)
    80000ab8:	69a2                	ld	s3,8(sp)
    80000aba:	6a02                	ld	s4,0(sp)
}
    80000abc:	70a2                	ld	ra,40(sp)
    80000abe:	7402                	ld	s0,32(sp)
    80000ac0:	64e2                	ld	s1,24(sp)
    80000ac2:	6145                	addi	sp,sp,48
    80000ac4:	8082                	ret

0000000080000ac6 <_Z5kinitv>:
{
    80000ac6:	1141                	addi	sp,sp,-16
    80000ac8:	e406                	sd	ra,8(sp)
    80000aca:	e022                	sd	s0,0(sp)
    80000acc:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000ace:	00006597          	auipc	a1,0x6
    80000ad2:	57258593          	addi	a1,a1,1394 # 80007040 <etext+0x40>
    80000ad6:	0000f517          	auipc	a0,0xf
    80000ada:	e7250513          	addi	a0,a0,-398 # 8000f948 <kmem>
    80000ade:	06c000ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>
  freerange(end, (void *)PHYSTOP);
    80000ae2:	45c5                	li	a1,17
    80000ae4:	05ee                	slli	a1,a1,0x1b
    80000ae6:	00020517          	auipc	a0,0x20
    80000aea:	09250513          	addi	a0,a0,146 # 80020b78 <end>
    80000aee:	f91ff0ef          	jal	80000a7e <_Z9freerangePvS_>
}
    80000af2:	60a2                	ld	ra,8(sp)
    80000af4:	6402                	ld	s0,0(sp)
    80000af6:	0141                	addi	sp,sp,16
    80000af8:	8082                	ret

0000000080000afa <_Z6kallocv>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000afa:	1101                	addi	sp,sp,-32
    80000afc:	ec06                	sd	ra,24(sp)
    80000afe:	e822                	sd	s0,16(sp)
    80000b00:	e426                	sd	s1,8(sp)
    80000b02:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b04:	0000f497          	auipc	s1,0xf
    80000b08:	e4448493          	addi	s1,s1,-444 # 8000f948 <kmem>
    80000b0c:	8526                	mv	a0,s1
    80000b0e:	0b2000ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  r = kmem.freelist;
    80000b12:	6c84                	ld	s1,24(s1)
  if (r)
    80000b14:	c485                	beqz	s1,80000b3c <_Z6kallocv+0x42>
    kmem.freelist = r->next;
    80000b16:	609c                	ld	a5,0(s1)
    80000b18:	0000f517          	auipc	a0,0xf
    80000b1c:	e3050513          	addi	a0,a0,-464 # 8000f948 <kmem>
    80000b20:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000b22:	12a000ef          	jal	80000c4c <_Z7releaseP8spinlock>

  if (r)
    memset((char *)r, 5, PGSIZE); // fill with junk
    80000b26:	6605                	lui	a2,0x1
    80000b28:	4595                	li	a1,5
    80000b2a:	8526                	mv	a0,s1
    80000b2c:	158000ef          	jal	80000c84 <_Z6memsetPvij>
  return (void *)r;
}
    80000b30:	8526                	mv	a0,s1
    80000b32:	60e2                	ld	ra,24(sp)
    80000b34:	6442                	ld	s0,16(sp)
    80000b36:	64a2                	ld	s1,8(sp)
    80000b38:	6105                	addi	sp,sp,32
    80000b3a:	8082                	ret
  release(&kmem.lock);
    80000b3c:	0000f517          	auipc	a0,0xf
    80000b40:	e0c50513          	addi	a0,a0,-500 # 8000f948 <kmem>
    80000b44:	108000ef          	jal	80000c4c <_Z7releaseP8spinlock>
  if (r)
    80000b48:	b7e5                	j	80000b30 <_Z6kallocv+0x36>

0000000080000b4a <_Z8initlockP8spinlockPKc>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, const char *name)
{
    80000b4a:	1141                	addi	sp,sp,-16
    80000b4c:	e422                	sd	s0,8(sp)
    80000b4e:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b50:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b52:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b56:	00053823          	sd	zero,16(a0)
}
    80000b5a:	6422                	ld	s0,8(sp)
    80000b5c:	0141                	addi	sp,sp,16
    80000b5e:	8082                	ret

0000000080000b60 <_Z7holdingPK8spinlock>:
// Interrupts must be off.
int
holding(const struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b60:	411c                	lw	a5,0(a0)
    80000b62:	e399                	bnez	a5,80000b68 <_Z7holdingPK8spinlock+0x8>
    80000b64:	4501                	li	a0,0
  return r;
}
    80000b66:	8082                	ret
{
    80000b68:	1101                	addi	sp,sp,-32
    80000b6a:	ec06                	sd	ra,24(sp)
    80000b6c:	e822                	sd	s0,16(sp)
    80000b6e:	e426                	sd	s1,8(sp)
    80000b70:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b72:	6904                	ld	s1,16(a0)
    80000b74:	52b000ef          	jal	8000189e <_Z5mycpuv>
    80000b78:	40a48533          	sub	a0,s1,a0
    80000b7c:	00153513          	seqz	a0,a0
}
    80000b80:	60e2                	ld	ra,24(sp)
    80000b82:	6442                	ld	s0,16(sp)
    80000b84:	64a2                	ld	s1,8(sp)
    80000b86:	6105                	addi	sp,sp,32
    80000b88:	8082                	ret

0000000080000b8a <_Z8push_offv>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000b8a:	1101                	addi	sp,sp,-32
    80000b8c:	ec06                	sd	ra,24(sp)
    80000b8e:	e822                	sd	s0,16(sp)
    80000b90:	e426                	sd	s1,8(sp)
    80000b92:	1000                	addi	s0,sp,32
  __asm__ __volatile__("csrrc %0, sstatus, %1" : "=r"(x) : "rK"(x) : "memory");
    80000b94:	100174f3          	csrrci	s1,sstatus,2
  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  uint64 flags = rc_sstatus(SSTATUS_SIE);
  int old = !!(flags & SSTATUS_SIE);

  if (mycpu()->noff == 0)
    80000b98:	507000ef          	jal	8000189e <_Z5mycpuv>
    80000b9c:	5d3c                	lw	a5,120(a0)
    80000b9e:	cb99                	beqz	a5,80000bb4 <_Z8push_offv+0x2a>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000ba0:	4ff000ef          	jal	8000189e <_Z5mycpuv>
    80000ba4:	5d3c                	lw	a5,120(a0)
    80000ba6:	2785                	addiw	a5,a5,1
    80000ba8:	dd3c                	sw	a5,120(a0)
}
    80000baa:	60e2                	ld	ra,24(sp)
    80000bac:	6442                	ld	s0,16(sp)
    80000bae:	64a2                	ld	s1,8(sp)
    80000bb0:	6105                	addi	sp,sp,32
    80000bb2:	8082                	ret
    mycpu()->intena = old;
    80000bb4:	4eb000ef          	jal	8000189e <_Z5mycpuv>
  int old = !!(flags & SSTATUS_SIE);
    80000bb8:	8085                	srli	s1,s1,0x1
    80000bba:	8885                	andi	s1,s1,1
    mycpu()->intena = old;
    80000bbc:	dd64                	sw	s1,124(a0)
    80000bbe:	b7cd                	j	80000ba0 <_Z8push_offv+0x16>

0000000080000bc0 <_Z7acquireP8spinlock>:
{
    80000bc0:	1101                	addi	sp,sp,-32
    80000bc2:	ec06                	sd	ra,24(sp)
    80000bc4:	e822                	sd	s0,16(sp)
    80000bc6:	e426                	sd	s1,8(sp)
    80000bc8:	1000                	addi	s0,sp,32
    80000bca:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000bcc:	fbfff0ef          	jal	80000b8a <_Z8push_offv>
  if (holding(lk))
    80000bd0:	8526                	mv	a0,s1
    80000bd2:	f8fff0ef          	jal	80000b60 <_Z7holdingPK8spinlock>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000bd6:	4705                	li	a4,1
  if (holding(lk))
    80000bd8:	ed11                	bnez	a0,80000bf4 <_Z7acquireP8spinlock+0x34>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000bda:	87ba                	mv	a5,a4
    80000bdc:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000be0:	2781                	sext.w	a5,a5
    80000be2:	ffe5                	bnez	a5,80000bda <_Z7acquireP8spinlock+0x1a>
  lk->cpu = mycpu();
    80000be4:	4bb000ef          	jal	8000189e <_Z5mycpuv>
    80000be8:	e888                	sd	a0,16(s1)
}
    80000bea:	60e2                	ld	ra,24(sp)
    80000bec:	6442                	ld	s0,16(sp)
    80000bee:	64a2                	ld	s1,8(sp)
    80000bf0:	6105                	addi	sp,sp,32
    80000bf2:	8082                	ret
    panic("acquire");
    80000bf4:	00006517          	auipc	a0,0x6
    80000bf8:	45450513          	addi	a0,a0,1108 # 80007048 <etext+0x48>
    80000bfc:	bf7ff0ef          	jal	800007f2 <_Z5panicPKc>

0000000080000c00 <_Z7pop_offv>:

void
pop_off(void)
{
    80000c00:	1141                	addi	sp,sp,-16
    80000c02:	e406                	sd	ra,8(sp)
    80000c04:	e022                	sd	s0,0(sp)
    80000c06:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c08:	497000ef          	jal	8000189e <_Z5mycpuv>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000c0c:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c10:	8b89                	andi	a5,a5,2
  if (intr_get())
    80000c12:	e38d                	bnez	a5,80000c34 <_Z7pop_offv+0x34>
    panic("pop_off - interruptible");
  if (c->noff < 1)
    80000c14:	5d3c                	lw	a5,120(a0)
    80000c16:	02f05563          	blez	a5,80000c40 <_Z7pop_offv+0x40>
    panic("pop_off");
  c->noff -= 1;
    80000c1a:	37fd                	addiw	a5,a5,-1
    80000c1c:	0007871b          	sext.w	a4,a5
    80000c20:	dd3c                	sw	a5,120(a0)
  if (c->noff == 0 && c->intena)
    80000c22:	e709                	bnez	a4,80000c2c <_Z7pop_offv+0x2c>
    80000c24:	5d7c                	lw	a5,124(a0)
    80000c26:	c399                	beqz	a5,80000c2c <_Z7pop_offv+0x2c>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80000c28:	10016073          	csrsi	sstatus,2
    intr_on();
}
    80000c2c:	60a2                	ld	ra,8(sp)
    80000c2e:	6402                	ld	s0,0(sp)
    80000c30:	0141                	addi	sp,sp,16
    80000c32:	8082                	ret
    panic("pop_off - interruptible");
    80000c34:	00006517          	auipc	a0,0x6
    80000c38:	41c50513          	addi	a0,a0,1052 # 80007050 <etext+0x50>
    80000c3c:	bb7ff0ef          	jal	800007f2 <_Z5panicPKc>
    panic("pop_off");
    80000c40:	00006517          	auipc	a0,0x6
    80000c44:	42850513          	addi	a0,a0,1064 # 80007068 <etext+0x68>
    80000c48:	babff0ef          	jal	800007f2 <_Z5panicPKc>

0000000080000c4c <_Z7releaseP8spinlock>:
{
    80000c4c:	1101                	addi	sp,sp,-32
    80000c4e:	ec06                	sd	ra,24(sp)
    80000c50:	e822                	sd	s0,16(sp)
    80000c52:	e426                	sd	s1,8(sp)
    80000c54:	1000                	addi	s0,sp,32
    80000c56:	84aa                	mv	s1,a0
  if (!holding(lk))
    80000c58:	f09ff0ef          	jal	80000b60 <_Z7holdingPK8spinlock>
    80000c5c:	cd11                	beqz	a0,80000c78 <_Z7releaseP8spinlock+0x2c>
  lk->cpu = 0;
    80000c5e:	0004b823          	sd	zero,16(s1)
  __atomic_store_n(&lk->locked, 0, __ATOMIC_RELEASE);
    80000c62:	0f50000f          	fence	iorw,ow
    80000c66:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    80000c6a:	f97ff0ef          	jal	80000c00 <_Z7pop_offv>
}
    80000c6e:	60e2                	ld	ra,24(sp)
    80000c70:	6442                	ld	s0,16(sp)
    80000c72:	64a2                	ld	s1,8(sp)
    80000c74:	6105                	addi	sp,sp,32
    80000c76:	8082                	ret
    panic("release");
    80000c78:	00006517          	auipc	a0,0x6
    80000c7c:	3f850513          	addi	a0,a0,1016 # 80007070 <etext+0x70>
    80000c80:	b73ff0ef          	jal	800007f2 <_Z5panicPKc>

0000000080000c84 <_Z6memsetPvij>:
#include "types.h"

void *
memset(void *dst, int c, uint n)
{
    80000c84:	1141                	addi	sp,sp,-16
    80000c86:	e422                	sd	s0,8(sp)
    80000c88:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  uint i;
  for (i = 0; i < n; i++) {
    80000c8a:	ca19                	beqz	a2,80000ca0 <_Z6memsetPvij+0x1c>
    80000c8c:	87aa                	mv	a5,a0
    80000c8e:	1602                	slli	a2,a2,0x20
    80000c90:	9201                	srli	a2,a2,0x20
    80000c92:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000c96:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    80000c9a:	0785                	addi	a5,a5,1
    80000c9c:	fee79de3          	bne	a5,a4,80000c96 <_Z6memsetPvij+0x12>
  }
  return dst;
}
    80000ca0:	6422                	ld	s0,8(sp)
    80000ca2:	0141                	addi	sp,sp,16
    80000ca4:	8082                	ret

0000000080000ca6 <_Z6memcmpPKvS0_j>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000ca6:	1141                	addi	sp,sp,-16
    80000ca8:	e422                	sd	s0,8(sp)
    80000caa:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = static_cast<const uchar*>(v1);
  s2 = static_cast<const uchar*>(v2);
  while (n-- > 0) {
    80000cac:	ca05                	beqz	a2,80000cdc <_Z6memcmpPKvS0_j+0x36>
    80000cae:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000cb2:	1682                	slli	a3,a3,0x20
    80000cb4:	9281                	srli	a3,a3,0x20
    80000cb6:	0685                	addi	a3,a3,1
    80000cb8:	96aa                	add	a3,a3,a0
    if (*s1 != *s2)
    80000cba:	00054783          	lbu	a5,0(a0)
    80000cbe:	0005c703          	lbu	a4,0(a1)
    80000cc2:	00e79863          	bne	a5,a4,80000cd2 <_Z6memcmpPKvS0_j+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000cc6:	0505                	addi	a0,a0,1
    80000cc8:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    80000cca:	fed518e3          	bne	a0,a3,80000cba <_Z6memcmpPKvS0_j+0x14>
  }

  return 0;
    80000cce:	4501                	li	a0,0
    80000cd0:	a019                	j	80000cd6 <_Z6memcmpPKvS0_j+0x30>
      return *s1 - *s2;
    80000cd2:	40e7853b          	subw	a0,a5,a4
}
    80000cd6:	6422                	ld	s0,8(sp)
    80000cd8:	0141                	addi	sp,sp,16
    80000cda:	8082                	ret
  return 0;
    80000cdc:	4501                	li	a0,0
    80000cde:	bfe5                	j	80000cd6 <_Z6memcmpPKvS0_j+0x30>

0000000080000ce0 <_Z7memmovePvPKvj>:

void *
memmove(void *dst, const void *src, uint n)
{
    80000ce0:	1141                	addi	sp,sp,-16
    80000ce2:	e422                	sd	s0,8(sp)
    80000ce4:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if (n == 0)
    80000ce6:	c205                	beqz	a2,80000d06 <_Z7memmovePvPKvj+0x26>
    return dst;

  s = static_cast<const char*>(src);
  d = static_cast<char*>(dst);
  if (s < d && s + n > d) {
    80000ce8:	02a5e263          	bltu	a1,a0,80000d0c <_Z7memmovePvPKvj+0x2c>
    s += n;
    d += n;
    while (n-- > 0)
      *--d = *--s;
  } else
    while (n-- > 0)
    80000cec:	1602                	slli	a2,a2,0x20
    80000cee:	9201                	srli	a2,a2,0x20
    80000cf0:	00c587b3          	add	a5,a1,a2
{
    80000cf4:	872a                	mv	a4,a0
      *d++ = *s++;
    80000cf6:	0585                	addi	a1,a1,1
    80000cf8:	fff5c683          	lbu	a3,-1(a1)
    80000cfc:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffde489>
    80000cfe:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    80000d02:	feb79ae3          	bne	a5,a1,80000cf6 <_Z7memmovePvPKvj+0x16>

  return dst;
}
    80000d06:	6422                	ld	s0,8(sp)
    80000d08:	0141                	addi	sp,sp,16
    80000d0a:	8082                	ret
  if (s < d && s + n > d) {
    80000d0c:	02061693          	slli	a3,a2,0x20
    80000d10:	9281                	srli	a3,a3,0x20
    80000d12:	00d58733          	add	a4,a1,a3
    80000d16:	fce57be3          	bgeu	a0,a4,80000cec <_Z7memmovePvPKvj+0xc>
    d += n;
    80000d1a:	96aa                	add	a3,a3,a0
    while (n-- > 0)
    80000d1c:	fff6079b          	addiw	a5,a2,-1
    80000d20:	1782                	slli	a5,a5,0x20
    80000d22:	9381                	srli	a5,a5,0x20
    80000d24:	fff7c793          	not	a5,a5
    80000d28:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d2a:	177d                	addi	a4,a4,-1
    80000d2c:	00074603          	lbu	a2,0(a4)
    80000d30:	16fd                	addi	a3,a3,-1
    80000d32:	00c68023          	sb	a2,0(a3)
    while (n-- > 0)
    80000d36:	fef71ae3          	bne	a4,a5,80000d2a <_Z7memmovePvPKvj+0x4a>
    80000d3a:	b7f1                	j	80000d06 <_Z7memmovePvPKvj+0x26>

0000000080000d3c <_Z6memcpyPvPKvj>:

// memcpy exists to placate GCC.  Use memmove.
void *
memcpy(void *dst, const void *src, uint n)
{
    80000d3c:	1141                	addi	sp,sp,-16
    80000d3e:	e406                	sd	ra,8(sp)
    80000d40:	e022                	sd	s0,0(sp)
    80000d42:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d44:	f9dff0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
}
    80000d48:	60a2                	ld	ra,8(sp)
    80000d4a:	6402                	ld	s0,0(sp)
    80000d4c:	0141                	addi	sp,sp,16
    80000d4e:	8082                	ret

0000000080000d50 <_Z7strncmpPKcS0_j>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000d50:	1141                	addi	sp,sp,-16
    80000d52:	e422                	sd	s0,8(sp)
    80000d54:	0800                	addi	s0,sp,16
  while (n > 0 && *p && *p == *q)
    80000d56:	ce11                	beqz	a2,80000d72 <_Z7strncmpPKcS0_j+0x22>
    80000d58:	00054783          	lbu	a5,0(a0)
    80000d5c:	cf89                	beqz	a5,80000d76 <_Z7strncmpPKcS0_j+0x26>
    80000d5e:	0005c703          	lbu	a4,0(a1)
    80000d62:	00f71a63          	bne	a4,a5,80000d76 <_Z7strncmpPKcS0_j+0x26>
    n--, p++, q++;
    80000d66:	367d                	addiw	a2,a2,-1
    80000d68:	0505                	addi	a0,a0,1
    80000d6a:	0585                	addi	a1,a1,1
  while (n > 0 && *p && *p == *q)
    80000d6c:	f675                	bnez	a2,80000d58 <_Z7strncmpPKcS0_j+0x8>
  if (n == 0)
    return 0;
    80000d6e:	4501                	li	a0,0
    80000d70:	a801                	j	80000d80 <_Z7strncmpPKcS0_j+0x30>
    80000d72:	4501                	li	a0,0
    80000d74:	a031                	j	80000d80 <_Z7strncmpPKcS0_j+0x30>
  return (uchar)*p - (uchar)*q;
    80000d76:	00054503          	lbu	a0,0(a0)
    80000d7a:	0005c783          	lbu	a5,0(a1)
    80000d7e:	9d1d                	subw	a0,a0,a5
}
    80000d80:	6422                	ld	s0,8(sp)
    80000d82:	0141                	addi	sp,sp,16
    80000d84:	8082                	ret

0000000080000d86 <_Z7strncpyPcPKci>:

char *
strncpy(char *s, const char *t, int n)
{
    80000d86:	1141                	addi	sp,sp,-16
    80000d88:	e422                	sd	s0,8(sp)
    80000d8a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while (n-- > 0 && (*s++ = *t++) != 0)
    80000d8c:	872a                	mv	a4,a0
    80000d8e:	a011                	j	80000d92 <_Z7strncpyPcPKci+0xc>
    80000d90:	8636                	mv	a2,a3
    80000d92:	02c05763          	blez	a2,80000dc0 <_Z7strncpyPcPKci+0x3a>
    80000d96:	fff6069b          	addiw	a3,a2,-1
    80000d9a:	0005c783          	lbu	a5,0(a1)
    80000d9e:	0705                	addi	a4,a4,1
    80000da0:	fef70fa3          	sb	a5,-1(a4)
    80000da4:	0585                	addi	a1,a1,1
    80000da6:	f7ed                	bnez	a5,80000d90 <_Z7strncpyPcPKci+0xa>
    ;
  while (n-- > 0)
    80000da8:	00d05c63          	blez	a3,80000dc0 <_Z7strncpyPcPKci+0x3a>
    80000dac:	87ba                	mv	a5,a4
    80000dae:	9e39                	addw	a2,a2,a4
    80000db0:	367d                	addiw	a2,a2,-1
    *s++ = 0;
    80000db2:	0785                	addi	a5,a5,1
    80000db4:	fe078fa3          	sb	zero,-1(a5)
  while (n-- > 0)
    80000db8:	40f6073b          	subw	a4,a2,a5
    80000dbc:	fee04be3          	bgtz	a4,80000db2 <_Z7strncpyPcPKci+0x2c>
  return os;
}
    80000dc0:	6422                	ld	s0,8(sp)
    80000dc2:	0141                	addi	sp,sp,16
    80000dc4:	8082                	ret

0000000080000dc6 <_Z10safestrcpyPcPKci>:

// Like strncpy but guaranteed to NUL-terminate.
char *
safestrcpy(char *s, const char *t, int n)
{
    80000dc6:	1141                	addi	sp,sp,-16
    80000dc8:	e422                	sd	s0,8(sp)
    80000dca:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if (n <= 0)
    80000dcc:	02c05463          	blez	a2,80000df4 <_Z10safestrcpyPcPKci+0x2e>
    80000dd0:	fff6079b          	addiw	a5,a2,-1
    80000dd4:	1782                	slli	a5,a5,0x20
    80000dd6:	9381                	srli	a5,a5,0x20
    80000dd8:	97ae                	add	a5,a5,a1
    80000dda:	872a                	mv	a4,a0
    80000ddc:	a801                	j	80000dec <_Z10safestrcpyPcPKci+0x26>
    return os;
  while (--n > 0 && (*s++ = *t++) != 0)
    80000dde:	0585                	addi	a1,a1,1
    80000de0:	fff5c683          	lbu	a3,-1(a1)
    80000de4:	0705                	addi	a4,a4,1
    80000de6:	fed70fa3          	sb	a3,-1(a4)
    80000dea:	c299                	beqz	a3,80000df0 <_Z10safestrcpyPcPKci+0x2a>
    80000dec:	fef599e3          	bne	a1,a5,80000dde <_Z10safestrcpyPcPKci+0x18>
    ;
  *s = 0;
    80000df0:	00070023          	sb	zero,0(a4)
  return os;
}
    80000df4:	6422                	ld	s0,8(sp)
    80000df6:	0141                	addi	sp,sp,16
    80000df8:	8082                	ret

0000000080000dfa <_Z6strlenPKc>:

int
strlen(const char *s)
{
    80000dfa:	1141                	addi	sp,sp,-16
    80000dfc:	e422                	sd	s0,8(sp)
    80000dfe:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    80000e00:	00054783          	lbu	a5,0(a0)
    80000e04:	cf91                	beqz	a5,80000e20 <_Z6strlenPKc+0x26>
    80000e06:	0505                	addi	a0,a0,1
    80000e08:	87aa                	mv	a5,a0
    80000e0a:	86be                	mv	a3,a5
    80000e0c:	0785                	addi	a5,a5,1
    80000e0e:	fff7c703          	lbu	a4,-1(a5)
    80000e12:	ff65                	bnez	a4,80000e0a <_Z6strlenPKc+0x10>
    80000e14:	40a6853b          	subw	a0,a3,a0
    80000e18:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    80000e1a:	6422                	ld	s0,8(sp)
    80000e1c:	0141                	addi	sp,sp,16
    80000e1e:	8082                	ret
  for (n = 0; s[n]; n++)
    80000e20:	4501                	li	a0,0
    80000e22:	bfe5                	j	80000e1a <_Z6strlenPKc+0x20>

0000000080000e24 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e24:	1141                	addi	sp,sp,-16
    80000e26:	e406                	sd	ra,8(sp)
    80000e28:	e022                	sd	s0,0(sp)
    80000e2a:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80000e2c:	263000ef          	jal	8000188e <_Z5cpuidv>
    virtio_disk_init(); // emulated hard disk
    userinit();         // first user process

    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
  } else {
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000e30:	00007717          	auipc	a4,0x7
    80000e34:	a2070713          	addi	a4,a4,-1504 # 80007850 <_ZL7started>
  if (cpuid() == 0) {
    80000e38:	c51d                	beqz	a0,80000e66 <main+0x42>
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000e3a:	431c                	lw	a5,0(a4)
    80000e3c:	0ff0000f          	fence
    80000e40:	2781                	sext.w	a5,a5
    80000e42:	dfe5                	beqz	a5,80000e3a <main+0x16>
      ;

    printk("hart %d starting\n", cpuid());
    80000e44:	24b000ef          	jal	8000188e <_Z5cpuidv>
    80000e48:	85aa                	mv	a1,a0
    80000e4a:	00006517          	auipc	a0,0x6
    80000e4e:	24e50513          	addi	a0,a0,590 # 80007098 <etext+0x98>
    80000e52:	ea0ff0ef          	jal	800004f2 <_Z6printkPKcz>
    kvminithart();  // turn on paging
    80000e56:	084000ef          	jal	80000eda <_Z11kvminithartv>
    trapinithart(); // install kernel trap vector
    80000e5a:	582010ef          	jal	800023dc <_Z12trapinithartv>
    plicinithart(); // ask PLIC for device interrupts
    80000e5e:	56a040ef          	jal	800053c8 <_Z12plicinithartv>
  }

  scheduler();
    80000e62:	6d5000ef          	jal	80001d36 <_Z9schedulerv>
    consoleinit();
    80000e66:	db6ff0ef          	jal	8000041c <_Z11consoleinitv>
    printkinit();
    80000e6a:	9c5ff0ef          	jal	8000082e <_Z10printkinitv>
    printk("\n");
    80000e6e:	00006517          	auipc	a0,0x6
    80000e72:	20a50513          	addi	a0,a0,522 # 80007078 <etext+0x78>
    80000e76:	e7cff0ef          	jal	800004f2 <_Z6printkPKcz>
    printk("xv6 kernel is booting\n");
    80000e7a:	00006517          	auipc	a0,0x6
    80000e7e:	20650513          	addi	a0,a0,518 # 80007080 <etext+0x80>
    80000e82:	e70ff0ef          	jal	800004f2 <_Z6printkPKcz>
    printk("\n");
    80000e86:	00006517          	auipc	a0,0x6
    80000e8a:	1f250513          	addi	a0,a0,498 # 80007078 <etext+0x78>
    80000e8e:	e64ff0ef          	jal	800004f2 <_Z6printkPKcz>
    kinit();            // physical page allocator
    80000e92:	c35ff0ef          	jal	80000ac6 <_Z5kinitv>
    kvminit();          // create kernel page table
    80000e96:	2ce000ef          	jal	80001164 <_Z7kvminitv>
    kvminithart();      // turn on paging
    80000e9a:	040000ef          	jal	80000eda <_Z11kvminithartv>
    procinit();         // process table
    80000e9e:	13b000ef          	jal	800017d8 <_Z8procinitv>
    trapinit();         // trap vectors
    80000ea2:	516010ef          	jal	800023b8 <_Z8trapinitv>
    trapinithart();     // install kernel trap vector
    80000ea6:	536010ef          	jal	800023dc <_Z12trapinithartv>
    plicinit();         // set up interrupt controller
    80000eaa:	504040ef          	jal	800053ae <_Z8plicinitv>
    plicinithart();     // ask PLIC for device interrupts
    80000eae:	51a040ef          	jal	800053c8 <_Z12plicinithartv>
    binit();            // buffer cache
    80000eb2:	3b5010ef          	jal	80002a66 <_Z5binitv>
    iinit();            // inode table
    80000eb6:	126020ef          	jal	80002fdc <_Z5iinitv>
    fileinit();         // file table
    80000eba:	0b2030ef          	jal	80003f6c <_Z8fileinitv>
    virtio_disk_init(); // emulated hard disk
    80000ebe:	5fa040ef          	jal	800054b8 <_Z16virtio_disk_initv>
    userinit();         // first user process
    80000ec2:	4c9000ef          	jal	80001b8a <_Z8userinitv>
    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
    80000ec6:	00007797          	auipc	a5,0x7
    80000eca:	98a78793          	addi	a5,a5,-1654 # 80007850 <_ZL7started>
    80000ece:	4705                	li	a4,1
    80000ed0:	0f50000f          	fence	iorw,ow
    80000ed4:	08e7a02f          	amoswap.w	zero,a4,(a5)
    80000ed8:	b769                	j	80000e62 <main+0x3e>

0000000080000eda <_Z11kvminithartv>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000eda:	1141                	addi	sp,sp,-16
    80000edc:	e422                	sd	s0,8(sp)
    80000ede:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000ee0:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000ee4:	00007797          	auipc	a5,0x7
    80000ee8:	9747b783          	ld	a5,-1676(a5) # 80007858 <kernel_pagetable>
    80000eec:	83b1                	srli	a5,a5,0xc
    80000eee:	577d                	li	a4,-1
    80000ef0:	177e                	slli	a4,a4,0x3f
    80000ef2:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r"(x));
    80000ef4:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000ef8:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000efc:	6422                	ld	s0,8(sp)
    80000efe:	0141                	addi	sp,sp,16
    80000f00:	8082                	ret

0000000080000f02 <_Z4walkPmmi>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f02:	7139                	addi	sp,sp,-64
    80000f04:	fc06                	sd	ra,56(sp)
    80000f06:	f822                	sd	s0,48(sp)
    80000f08:	f426                	sd	s1,40(sp)
    80000f0a:	f04a                	sd	s2,32(sp)
    80000f0c:	ec4e                	sd	s3,24(sp)
    80000f0e:	e852                	sd	s4,16(sp)
    80000f10:	e456                	sd	s5,8(sp)
    80000f12:	e05a                	sd	s6,0(sp)
    80000f14:	0080                	addi	s0,sp,64
    80000f16:	84aa                	mv	s1,a0
    80000f18:	89ae                	mv	s3,a1
    80000f1a:	8ab2                	mv	s5,a2
  if (va >= MAXVA)
    80000f1c:	57fd                	li	a5,-1
    80000f1e:	83e9                	srli	a5,a5,0x1a
    80000f20:	4a79                	li	s4,30
    panic("walk");

  for (int level = 2; level > 0; level--) {
    80000f22:	4b31                	li	s6,12
  if (va >= MAXVA)
    80000f24:	02b7fc63          	bgeu	a5,a1,80000f5c <_Z4walkPmmi+0x5a>
    panic("walk");
    80000f28:	00006517          	auipc	a0,0x6
    80000f2c:	18850513          	addi	a0,a0,392 # 800070b0 <etext+0xb0>
    80000f30:	8c3ff0ef          	jal	800007f2 <_Z5panicPKc>
    pte_t *pte = &pagetable[PX(level, va)];
    if (*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if (!alloc || (pagetable = (pde_t *)kalloc()) == 0)
    80000f34:	060a8263          	beqz	s5,80000f98 <_Z4walkPmmi+0x96>
    80000f38:	bc3ff0ef          	jal	80000afa <_Z6kallocv>
    80000f3c:	84aa                	mv	s1,a0
    80000f3e:	c139                	beqz	a0,80000f84 <_Z4walkPmmi+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000f40:	6605                	lui	a2,0x1
    80000f42:	4581                	li	a1,0
    80000f44:	d41ff0ef          	jal	80000c84 <_Z6memsetPvij>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000f48:	00c4d793          	srli	a5,s1,0xc
    80000f4c:	07aa                	slli	a5,a5,0xa
    80000f4e:	0017e793          	ori	a5,a5,1
    80000f52:	00f93023          	sd	a5,0(s2)
  for (int level = 2; level > 0; level--) {
    80000f56:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffde47f>
    80000f58:	036a0063          	beq	s4,s6,80000f78 <_Z4walkPmmi+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f5c:	0149d933          	srl	s2,s3,s4
    80000f60:	1ff97913          	andi	s2,s2,511
    80000f64:	090e                	slli	s2,s2,0x3
    80000f66:	9926                	add	s2,s2,s1
    if (*pte & PTE_V) {
    80000f68:	00093483          	ld	s1,0(s2)
    80000f6c:	0014f793          	andi	a5,s1,1
    80000f70:	d3f1                	beqz	a5,80000f34 <_Z4walkPmmi+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000f72:	80a9                	srli	s1,s1,0xa
    80000f74:	04b2                	slli	s1,s1,0xc
    80000f76:	b7c5                	j	80000f56 <_Z4walkPmmi+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    80000f78:	00c9d513          	srli	a0,s3,0xc
    80000f7c:	1ff57513          	andi	a0,a0,511
    80000f80:	050e                	slli	a0,a0,0x3
    80000f82:	9526                	add	a0,a0,s1
}
    80000f84:	70e2                	ld	ra,56(sp)
    80000f86:	7442                	ld	s0,48(sp)
    80000f88:	74a2                	ld	s1,40(sp)
    80000f8a:	7902                	ld	s2,32(sp)
    80000f8c:	69e2                	ld	s3,24(sp)
    80000f8e:	6a42                	ld	s4,16(sp)
    80000f90:	6aa2                	ld	s5,8(sp)
    80000f92:	6b02                	ld	s6,0(sp)
    80000f94:	6121                	addi	sp,sp,64
    80000f96:	8082                	ret
        return 0;
    80000f98:	4501                	li	a0,0
    80000f9a:	b7ed                	j	80000f84 <_Z4walkPmmi+0x82>

0000000080000f9c <_Z8walkaddrPmm>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    80000f9c:	57fd                	li	a5,-1
    80000f9e:	83e9                	srli	a5,a5,0x1a
    80000fa0:	00b7f463          	bgeu	a5,a1,80000fa8 <_Z8walkaddrPmm+0xc>
    return 0;
    80000fa4:	4501                	li	a0,0
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000fa6:	8082                	ret
{
    80000fa8:	1141                	addi	sp,sp,-16
    80000faa:	e406                	sd	ra,8(sp)
    80000fac:	e022                	sd	s0,0(sp)
    80000fae:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000fb0:	4601                	li	a2,0
    80000fb2:	f51ff0ef          	jal	80000f02 <_Z4walkPmmi>
  if (pte == 0)
    80000fb6:	c105                	beqz	a0,80000fd6 <_Z8walkaddrPmm+0x3a>
  if ((*pte & PTE_V) == 0)
    80000fb8:	611c                	ld	a5,0(a0)
  if ((*pte & PTE_U) == 0)
    80000fba:	0117f693          	andi	a3,a5,17
    80000fbe:	4745                	li	a4,17
    return 0;
    80000fc0:	4501                	li	a0,0
  if ((*pte & PTE_U) == 0)
    80000fc2:	00e68663          	beq	a3,a4,80000fce <_Z8walkaddrPmm+0x32>
}
    80000fc6:	60a2                	ld	ra,8(sp)
    80000fc8:	6402                	ld	s0,0(sp)
    80000fca:	0141                	addi	sp,sp,16
    80000fcc:	8082                	ret
  pa = PTE2PA(*pte);
    80000fce:	83a9                	srli	a5,a5,0xa
    80000fd0:	00c79513          	slli	a0,a5,0xc
  return pa;
    80000fd4:	bfcd                	j	80000fc6 <_Z8walkaddrPmm+0x2a>
    return 0;
    80000fd6:	4501                	li	a0,0
    80000fd8:	b7fd                	j	80000fc6 <_Z8walkaddrPmm+0x2a>

0000000080000fda <_Z8mappagesPmmmmi>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80000fda:	715d                	addi	sp,sp,-80
    80000fdc:	e486                	sd	ra,72(sp)
    80000fde:	e0a2                	sd	s0,64(sp)
    80000fe0:	fc26                	sd	s1,56(sp)
    80000fe2:	f84a                	sd	s2,48(sp)
    80000fe4:	f44e                	sd	s3,40(sp)
    80000fe6:	f052                	sd	s4,32(sp)
    80000fe8:	ec56                	sd	s5,24(sp)
    80000fea:	e85a                	sd	s6,16(sp)
    80000fec:	e45e                	sd	s7,8(sp)
    80000fee:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    80000ff0:	03459793          	slli	a5,a1,0x34
    80000ff4:	e7a9                	bnez	a5,8000103e <_Z8mappagesPmmmmi+0x64>
    80000ff6:	8aaa                	mv	s5,a0
    80000ff8:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if ((size % PGSIZE) != 0)
    80000ffa:	03461793          	slli	a5,a2,0x34
    80000ffe:	e7b1                	bnez	a5,8000104a <_Z8mappagesPmmmmi+0x70>
    panic("mappages: size not aligned");

  if (size == 0)
    80001000:	ca39                	beqz	a2,80001056 <_Z8mappagesPmmmmi+0x7c>
    panic("mappages: size");

  a = va;
  last = va + size - PGSIZE;
    80001002:	77fd                	lui	a5,0xfffff
    80001004:	963e                	add	a2,a2,a5
    80001006:	00b609b3          	add	s3,a2,a1
  a = va;
    8000100a:	892e                	mv	s2,a1
    8000100c:	40b68a33          	sub	s4,a3,a1
    if (*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if (a == last)
      break;
    a += PGSIZE;
    80001010:	6b85                	lui	s7,0x1
    80001012:	014904b3          	add	s1,s2,s4
    if ((pte = walk(pagetable, a, 1)) == 0)
    80001016:	4605                	li	a2,1
    80001018:	85ca                	mv	a1,s2
    8000101a:	8556                	mv	a0,s5
    8000101c:	ee7ff0ef          	jal	80000f02 <_Z4walkPmmi>
    80001020:	c539                	beqz	a0,8000106e <_Z8mappagesPmmmmi+0x94>
    if (*pte & PTE_V)
    80001022:	611c                	ld	a5,0(a0)
    80001024:	8b85                	andi	a5,a5,1
    80001026:	ef95                	bnez	a5,80001062 <_Z8mappagesPmmmmi+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80001028:	80b1                	srli	s1,s1,0xc
    8000102a:	04aa                	slli	s1,s1,0xa
    8000102c:	0164e4b3          	or	s1,s1,s6
    80001030:	0014e493          	ori	s1,s1,1
    80001034:	e104                	sd	s1,0(a0)
    if (a == last)
    80001036:	05390863          	beq	s2,s3,80001086 <_Z8mappagesPmmmmi+0xac>
    a += PGSIZE;
    8000103a:	995e                	add	s2,s2,s7
    if ((pte = walk(pagetable, a, 1)) == 0)
    8000103c:	bfd9                	j	80001012 <_Z8mappagesPmmmmi+0x38>
    panic("mappages: va not aligned");
    8000103e:	00006517          	auipc	a0,0x6
    80001042:	07a50513          	addi	a0,a0,122 # 800070b8 <etext+0xb8>
    80001046:	facff0ef          	jal	800007f2 <_Z5panicPKc>
    panic("mappages: size not aligned");
    8000104a:	00006517          	auipc	a0,0x6
    8000104e:	08e50513          	addi	a0,a0,142 # 800070d8 <etext+0xd8>
    80001052:	fa0ff0ef          	jal	800007f2 <_Z5panicPKc>
    panic("mappages: size");
    80001056:	00006517          	auipc	a0,0x6
    8000105a:	0a250513          	addi	a0,a0,162 # 800070f8 <etext+0xf8>
    8000105e:	f94ff0ef          	jal	800007f2 <_Z5panicPKc>
      panic("mappages: remap");
    80001062:	00006517          	auipc	a0,0x6
    80001066:	0a650513          	addi	a0,a0,166 # 80007108 <etext+0x108>
    8000106a:	f88ff0ef          	jal	800007f2 <_Z5panicPKc>
      return -1;
    8000106e:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80001070:	60a6                	ld	ra,72(sp)
    80001072:	6406                	ld	s0,64(sp)
    80001074:	74e2                	ld	s1,56(sp)
    80001076:	7942                	ld	s2,48(sp)
    80001078:	79a2                	ld	s3,40(sp)
    8000107a:	7a02                	ld	s4,32(sp)
    8000107c:	6ae2                	ld	s5,24(sp)
    8000107e:	6b42                	ld	s6,16(sp)
    80001080:	6ba2                	ld	s7,8(sp)
    80001082:	6161                	addi	sp,sp,80
    80001084:	8082                	ret
  return 0;
    80001086:	4501                	li	a0,0
    80001088:	b7e5                	j	80001070 <_Z8mappagesPmmmmi+0x96>

000000008000108a <_Z6kvmmapPmmmmi>:
{
    8000108a:	1141                	addi	sp,sp,-16
    8000108c:	e406                	sd	ra,8(sp)
    8000108e:	e022                	sd	s0,0(sp)
    80001090:	0800                	addi	s0,sp,16
    80001092:	87b6                	mv	a5,a3
  if (mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001094:	86b2                	mv	a3,a2
    80001096:	863e                	mv	a2,a5
    80001098:	f43ff0ef          	jal	80000fda <_Z8mappagesPmmmmi>
    8000109c:	e509                	bnez	a0,800010a6 <_Z6kvmmapPmmmmi+0x1c>
}
    8000109e:	60a2                	ld	ra,8(sp)
    800010a0:	6402                	ld	s0,0(sp)
    800010a2:	0141                	addi	sp,sp,16
    800010a4:	8082                	ret
    panic("kvmmap");
    800010a6:	00006517          	auipc	a0,0x6
    800010aa:	07250513          	addi	a0,a0,114 # 80007118 <etext+0x118>
    800010ae:	f44ff0ef          	jal	800007f2 <_Z5panicPKc>

00000000800010b2 <_Z7kvmmakev>:
{
    800010b2:	1101                	addi	sp,sp,-32
    800010b4:	ec06                	sd	ra,24(sp)
    800010b6:	e822                	sd	s0,16(sp)
    800010b8:	e426                	sd	s1,8(sp)
    800010ba:	e04a                	sd	s2,0(sp)
    800010bc:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t)kalloc();
    800010be:	a3dff0ef          	jal	80000afa <_Z6kallocv>
    800010c2:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800010c4:	6605                	lui	a2,0x1
    800010c6:	4581                	li	a1,0
    800010c8:	bbdff0ef          	jal	80000c84 <_Z6memsetPvij>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    800010cc:	4719                	li	a4,6
    800010ce:	6685                	lui	a3,0x1
    800010d0:	10000637          	lui	a2,0x10000
    800010d4:	100005b7          	lui	a1,0x10000
    800010d8:	8526                	mv	a0,s1
    800010da:	fb1ff0ef          	jal	8000108a <_Z6kvmmapPmmmmi>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800010de:	4719                	li	a4,6
    800010e0:	6685                	lui	a3,0x1
    800010e2:	10001637          	lui	a2,0x10001
    800010e6:	100015b7          	lui	a1,0x10001
    800010ea:	8526                	mv	a0,s1
    800010ec:	f9fff0ef          	jal	8000108a <_Z6kvmmapPmmmmi>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800010f0:	4719                	li	a4,6
    800010f2:	040006b7          	lui	a3,0x4000
    800010f6:	0c000637          	lui	a2,0xc000
    800010fa:	0c0005b7          	lui	a1,0xc000
    800010fe:	8526                	mv	a0,s1
    80001100:	f8bff0ef          	jal	8000108a <_Z6kvmmapPmmmmi>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext - KERNBASE, PTE_R | PTE_X);
    80001104:	00006917          	auipc	s2,0x6
    80001108:	efc90913          	addi	s2,s2,-260 # 80007000 <etext>
    8000110c:	4729                	li	a4,10
    8000110e:	80006697          	auipc	a3,0x80006
    80001112:	ef268693          	addi	a3,a3,-270 # 7000 <_entry-0x7fff9000>
    80001116:	4605                	li	a2,1
    80001118:	067e                	slli	a2,a2,0x1f
    8000111a:	85b2                	mv	a1,a2
    8000111c:	8526                	mv	a0,s1
    8000111e:	f6dff0ef          	jal	8000108a <_Z6kvmmapPmmmmi>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP - (uint64)etext,
    80001122:	46c5                	li	a3,17
    80001124:	06ee                	slli	a3,a3,0x1b
    80001126:	4719                	li	a4,6
    80001128:	412686b3          	sub	a3,a3,s2
    8000112c:	864a                	mv	a2,s2
    8000112e:	85ca                	mv	a1,s2
    80001130:	8526                	mv	a0,s1
    80001132:	f59ff0ef          	jal	8000108a <_Z6kvmmapPmmmmi>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80001136:	4729                	li	a4,10
    80001138:	6685                	lui	a3,0x1
    8000113a:	00005617          	auipc	a2,0x5
    8000113e:	ec660613          	addi	a2,a2,-314 # 80006000 <_trampoline>
    80001142:	040005b7          	lui	a1,0x4000
    80001146:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001148:	05b2                	slli	a1,a1,0xc
    8000114a:	8526                	mv	a0,s1
    8000114c:	f3fff0ef          	jal	8000108a <_Z6kvmmapPmmmmi>
  proc_mapstacks(kpgtbl);
    80001150:	8526                	mv	a0,s1
    80001152:	5ee000ef          	jal	80001740 <_Z14proc_mapstacksPm>
}
    80001156:	8526                	mv	a0,s1
    80001158:	60e2                	ld	ra,24(sp)
    8000115a:	6442                	ld	s0,16(sp)
    8000115c:	64a2                	ld	s1,8(sp)
    8000115e:	6902                	ld	s2,0(sp)
    80001160:	6105                	addi	sp,sp,32
    80001162:	8082                	ret

0000000080001164 <_Z7kvminitv>:
{
    80001164:	1141                	addi	sp,sp,-16
    80001166:	e406                	sd	ra,8(sp)
    80001168:	e022                	sd	s0,0(sp)
    8000116a:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000116c:	f47ff0ef          	jal	800010b2 <_Z7kvmmakev>
    80001170:	00006797          	auipc	a5,0x6
    80001174:	6ea7b423          	sd	a0,1768(a5) # 80007858 <kernel_pagetable>
}
    80001178:	60a2                	ld	ra,8(sp)
    8000117a:	6402                	ld	s0,0(sp)
    8000117c:	0141                	addi	sp,sp,16
    8000117e:	8082                	ret

0000000080001180 <_Z9uvmcreatev>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001180:	1101                	addi	sp,sp,-32
    80001182:	ec06                	sd	ra,24(sp)
    80001184:	e822                	sd	s0,16(sp)
    80001186:	e426                	sd	s1,8(sp)
    80001188:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t)kalloc();
    8000118a:	971ff0ef          	jal	80000afa <_Z6kallocv>
    8000118e:	84aa                	mv	s1,a0
  if (pagetable == 0)
    80001190:	c509                	beqz	a0,8000119a <_Z9uvmcreatev+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    80001192:	6605                	lui	a2,0x1
    80001194:	4581                	li	a1,0
    80001196:	aefff0ef          	jal	80000c84 <_Z6memsetPvij>
  return pagetable;
}
    8000119a:	8526                	mv	a0,s1
    8000119c:	60e2                	ld	ra,24(sp)
    8000119e:	6442                	ld	s0,16(sp)
    800011a0:	64a2                	ld	s1,8(sp)
    800011a2:	6105                	addi	sp,sp,32
    800011a4:	8082                	ret

00000000800011a6 <_Z8uvmunmapPmmmi>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800011a6:	7139                	addi	sp,sp,-64
    800011a8:	fc06                	sd	ra,56(sp)
    800011aa:	f822                	sd	s0,48(sp)
    800011ac:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    800011ae:	03459793          	slli	a5,a1,0x34
    800011b2:	e38d                	bnez	a5,800011d4 <_Z8uvmunmapPmmmi+0x2e>
    800011b4:	f04a                	sd	s2,32(sp)
    800011b6:	ec4e                	sd	s3,24(sp)
    800011b8:	e852                	sd	s4,16(sp)
    800011ba:	e456                	sd	s5,8(sp)
    800011bc:	e05a                	sd	s6,0(sp)
    800011be:	8a2a                	mv	s4,a0
    800011c0:	892e                	mv	s2,a1
    800011c2:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    800011c4:	0632                	slli	a2,a2,0xc
    800011c6:	00b609b3          	add	s3,a2,a1
    800011ca:	6b05                	lui	s6,0x1
    800011cc:	0535f963          	bgeu	a1,s3,8000121e <_Z8uvmunmapPmmmi+0x78>
    800011d0:	f426                	sd	s1,40(sp)
    800011d2:	a015                	j	800011f6 <_Z8uvmunmapPmmmi+0x50>
    800011d4:	f426                	sd	s1,40(sp)
    800011d6:	f04a                	sd	s2,32(sp)
    800011d8:	ec4e                	sd	s3,24(sp)
    800011da:	e852                	sd	s4,16(sp)
    800011dc:	e456                	sd	s5,8(sp)
    800011de:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    800011e0:	00006517          	auipc	a0,0x6
    800011e4:	f4050513          	addi	a0,a0,-192 # 80007120 <etext+0x120>
    800011e8:	e0aff0ef          	jal	800007f2 <_Z5panicPKc>
      continue;
    if (do_free) {
      uint64 pa = PTE2PA(*pte);
      kfree((void *)pa);
    }
    *pte = 0;
    800011ec:	0004b023          	sd	zero,0(s1)
  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    800011f0:	995a                	add	s2,s2,s6
    800011f2:	03397563          	bgeu	s2,s3,8000121c <_Z8uvmunmapPmmmi+0x76>
    if ((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    800011f6:	4601                	li	a2,0
    800011f8:	85ca                	mv	a1,s2
    800011fa:	8552                	mv	a0,s4
    800011fc:	d07ff0ef          	jal	80000f02 <_Z4walkPmmi>
    80001200:	84aa                	mv	s1,a0
    80001202:	d57d                	beqz	a0,800011f0 <_Z8uvmunmapPmmmi+0x4a>
    if ((*pte & PTE_V) == 0) // has physical page been allocated?
    80001204:	611c                	ld	a5,0(a0)
    80001206:	0017f713          	andi	a4,a5,1
    8000120a:	d37d                	beqz	a4,800011f0 <_Z8uvmunmapPmmmi+0x4a>
    if (do_free) {
    8000120c:	fe0a80e3          	beqz	s5,800011ec <_Z8uvmunmapPmmmi+0x46>
      uint64 pa = PTE2PA(*pte);
    80001210:	83a9                	srli	a5,a5,0xa
      kfree((void *)pa);
    80001212:	00c79513          	slli	a0,a5,0xc
    80001216:	803ff0ef          	jal	80000a18 <_Z5kfreePv>
    8000121a:	bfc9                	j	800011ec <_Z8uvmunmapPmmmi+0x46>
    8000121c:	74a2                	ld	s1,40(sp)
    8000121e:	7902                	ld	s2,32(sp)
    80001220:	69e2                	ld	s3,24(sp)
    80001222:	6a42                	ld	s4,16(sp)
    80001224:	6aa2                	ld	s5,8(sp)
    80001226:	6b02                	ld	s6,0(sp)
  }
}
    80001228:	70e2                	ld	ra,56(sp)
    8000122a:	7442                	ld	s0,48(sp)
    8000122c:	6121                	addi	sp,sp,64
    8000122e:	8082                	ret

0000000080001230 <_Z10uvmdeallocPmmm>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    80001230:	1101                	addi	sp,sp,-32
    80001232:	ec06                	sd	ra,24(sp)
    80001234:	e822                	sd	s0,16(sp)
    80001236:	e426                	sd	s1,8(sp)
    80001238:	1000                	addi	s0,sp,32
  if (newsz >= oldsz)
    return oldsz;
    8000123a:	84ae                	mv	s1,a1
  if (newsz >= oldsz)
    8000123c:	00b67d63          	bgeu	a2,a1,80001256 <_Z10uvmdeallocPmmm+0x26>
    80001240:	84b2                	mv	s1,a2

  if (PGROUNDUP(newsz) < PGROUNDUP(oldsz)) {
    80001242:	6785                	lui	a5,0x1
    80001244:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001246:	00f60733          	add	a4,a2,a5
    8000124a:	76fd                	lui	a3,0xfffff
    8000124c:	8f75                	and	a4,a4,a3
    8000124e:	97ae                	add	a5,a5,a1
    80001250:	8ff5                	and	a5,a5,a3
    80001252:	00f76863          	bltu	a4,a5,80001262 <_Z10uvmdeallocPmmm+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80001256:	8526                	mv	a0,s1
    80001258:	60e2                	ld	ra,24(sp)
    8000125a:	6442                	ld	s0,16(sp)
    8000125c:	64a2                	ld	s1,8(sp)
    8000125e:	6105                	addi	sp,sp,32
    80001260:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001262:	8f99                	sub	a5,a5,a4
    80001264:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80001266:	4685                	li	a3,1
    80001268:	0007861b          	sext.w	a2,a5
    8000126c:	85ba                	mv	a1,a4
    8000126e:	f39ff0ef          	jal	800011a6 <_Z8uvmunmapPmmmi>
    80001272:	b7d5                	j	80001256 <_Z10uvmdeallocPmmm+0x26>

0000000080001274 <_Z8uvmallocPmmmi>:
  if (newsz < oldsz)
    80001274:	08b66f63          	bltu	a2,a1,80001312 <_Z8uvmallocPmmmi+0x9e>
{
    80001278:	7139                	addi	sp,sp,-64
    8000127a:	fc06                	sd	ra,56(sp)
    8000127c:	f822                	sd	s0,48(sp)
    8000127e:	ec4e                	sd	s3,24(sp)
    80001280:	e852                	sd	s4,16(sp)
    80001282:	e456                	sd	s5,8(sp)
    80001284:	0080                	addi	s0,sp,64
    80001286:	8aaa                	mv	s5,a0
    80001288:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    8000128a:	6785                	lui	a5,0x1
    8000128c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000128e:	95be                	add	a1,a1,a5
    80001290:	77fd                	lui	a5,0xfffff
    80001292:	00f5f9b3          	and	s3,a1,a5
  for (a = oldsz; a < newsz; a += PGSIZE) {
    80001296:	08c9f063          	bgeu	s3,a2,80001316 <_Z8uvmallocPmmmi+0xa2>
    8000129a:	f426                	sd	s1,40(sp)
    8000129c:	f04a                	sd	s2,32(sp)
    8000129e:	e05a                	sd	s6,0(sp)
    800012a0:	894e                	mv	s2,s3
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    800012a2:	0126eb13          	ori	s6,a3,18
    mem = static_cast<char*>(kalloc());
    800012a6:	855ff0ef          	jal	80000afa <_Z6kallocv>
    800012aa:	84aa                	mv	s1,a0
    if (mem == 0) {
    800012ac:	c515                	beqz	a0,800012d8 <_Z8uvmallocPmmmi+0x64>
    memset(mem, 0, PGSIZE);
    800012ae:	6605                	lui	a2,0x1
    800012b0:	4581                	li	a1,0
    800012b2:	9d3ff0ef          	jal	80000c84 <_Z6memsetPvij>
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    800012b6:	875a                	mv	a4,s6
    800012b8:	86a6                	mv	a3,s1
    800012ba:	6605                	lui	a2,0x1
    800012bc:	85ca                	mv	a1,s2
    800012be:	8556                	mv	a0,s5
    800012c0:	d1bff0ef          	jal	80000fda <_Z8mappagesPmmmmi>
    800012c4:	e915                	bnez	a0,800012f8 <_Z8uvmallocPmmmi+0x84>
  for (a = oldsz; a < newsz; a += PGSIZE) {
    800012c6:	6785                	lui	a5,0x1
    800012c8:	993e                	add	s2,s2,a5
    800012ca:	fd496ee3          	bltu	s2,s4,800012a6 <_Z8uvmallocPmmmi+0x32>
  return newsz;
    800012ce:	8552                	mv	a0,s4
    800012d0:	74a2                	ld	s1,40(sp)
    800012d2:	7902                	ld	s2,32(sp)
    800012d4:	6b02                	ld	s6,0(sp)
    800012d6:	a811                	j	800012ea <_Z8uvmallocPmmmi+0x76>
      uvmdealloc(pagetable, a, oldsz);
    800012d8:	864e                	mv	a2,s3
    800012da:	85ca                	mv	a1,s2
    800012dc:	8556                	mv	a0,s5
    800012de:	f53ff0ef          	jal	80001230 <_Z10uvmdeallocPmmm>
      return 0;
    800012e2:	4501                	li	a0,0
    800012e4:	74a2                	ld	s1,40(sp)
    800012e6:	7902                	ld	s2,32(sp)
    800012e8:	6b02                	ld	s6,0(sp)
}
    800012ea:	70e2                	ld	ra,56(sp)
    800012ec:	7442                	ld	s0,48(sp)
    800012ee:	69e2                	ld	s3,24(sp)
    800012f0:	6a42                	ld	s4,16(sp)
    800012f2:	6aa2                	ld	s5,8(sp)
    800012f4:	6121                	addi	sp,sp,64
    800012f6:	8082                	ret
      kfree(mem);
    800012f8:	8526                	mv	a0,s1
    800012fa:	f1eff0ef          	jal	80000a18 <_Z5kfreePv>
      uvmdealloc(pagetable, a, oldsz);
    800012fe:	864e                	mv	a2,s3
    80001300:	85ca                	mv	a1,s2
    80001302:	8556                	mv	a0,s5
    80001304:	f2dff0ef          	jal	80001230 <_Z10uvmdeallocPmmm>
      return 0;
    80001308:	4501                	li	a0,0
    8000130a:	74a2                	ld	s1,40(sp)
    8000130c:	7902                	ld	s2,32(sp)
    8000130e:	6b02                	ld	s6,0(sp)
    80001310:	bfe9                	j	800012ea <_Z8uvmallocPmmmi+0x76>
    return oldsz;
    80001312:	852e                	mv	a0,a1
}
    80001314:	8082                	ret
  return newsz;
    80001316:	8532                	mv	a0,a2
    80001318:	bfc9                	j	800012ea <_Z8uvmallocPmmmi+0x76>

000000008000131a <_Z8freewalkPm>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000131a:	7179                	addi	sp,sp,-48
    8000131c:	f406                	sd	ra,40(sp)
    8000131e:	f022                	sd	s0,32(sp)
    80001320:	ec26                	sd	s1,24(sp)
    80001322:	e84a                	sd	s2,16(sp)
    80001324:	e44e                	sd	s3,8(sp)
    80001326:	e052                	sd	s4,0(sp)
    80001328:	1800                	addi	s0,sp,48
    8000132a:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for (int i = 0; i < 512; i++) {
    8000132c:	84aa                	mv	s1,a0
    8000132e:	6905                	lui	s2,0x1
    80001330:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    80001332:	4985                	li	s3,1
    80001334:	a819                	j	8000134a <_Z8freewalkPm+0x30>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    80001336:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80001338:	00c79513          	slli	a0,a5,0xc
    8000133c:	fdfff0ef          	jal	8000131a <_Z8freewalkPm>
      pagetable[i] = 0;
    80001340:	0004b023          	sd	zero,0(s1)
  for (int i = 0; i < 512; i++) {
    80001344:	04a1                	addi	s1,s1,8
    80001346:	01248f63          	beq	s1,s2,80001364 <_Z8freewalkPm+0x4a>
    pte_t pte = pagetable[i];
    8000134a:	609c                	ld	a5,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    8000134c:	00f7f713          	andi	a4,a5,15
    80001350:	ff3703e3          	beq	a4,s3,80001336 <_Z8freewalkPm+0x1c>
    } else if (pte & PTE_V) {
    80001354:	8b85                	andi	a5,a5,1
    80001356:	d7fd                	beqz	a5,80001344 <_Z8freewalkPm+0x2a>
      panic("freewalk: leaf");
    80001358:	00006517          	auipc	a0,0x6
    8000135c:	de050513          	addi	a0,a0,-544 # 80007138 <etext+0x138>
    80001360:	c92ff0ef          	jal	800007f2 <_Z5panicPKc>
    }
  }
  kfree((void *)pagetable);
    80001364:	8552                	mv	a0,s4
    80001366:	eb2ff0ef          	jal	80000a18 <_Z5kfreePv>
}
    8000136a:	70a2                	ld	ra,40(sp)
    8000136c:	7402                	ld	s0,32(sp)
    8000136e:	64e2                	ld	s1,24(sp)
    80001370:	6942                	ld	s2,16(sp)
    80001372:	69a2                	ld	s3,8(sp)
    80001374:	6a02                	ld	s4,0(sp)
    80001376:	6145                	addi	sp,sp,48
    80001378:	8082                	ret

000000008000137a <_Z7uvmfreePmm>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    8000137a:	1101                	addi	sp,sp,-32
    8000137c:	ec06                	sd	ra,24(sp)
    8000137e:	e822                	sd	s0,16(sp)
    80001380:	e426                	sd	s1,8(sp)
    80001382:	1000                	addi	s0,sp,32
    80001384:	84aa                	mv	s1,a0
  if (sz > 0)
    80001386:	e989                	bnez	a1,80001398 <_Z7uvmfreePmm+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
  freewalk(pagetable);
    80001388:	8526                	mv	a0,s1
    8000138a:	f91ff0ef          	jal	8000131a <_Z8freewalkPm>
}
    8000138e:	60e2                	ld	ra,24(sp)
    80001390:	6442                	ld	s0,16(sp)
    80001392:	64a2                	ld	s1,8(sp)
    80001394:	6105                	addi	sp,sp,32
    80001396:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
    80001398:	6785                	lui	a5,0x1
    8000139a:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000139c:	95be                	add	a1,a1,a5
    8000139e:	4685                	li	a3,1
    800013a0:	00c5d613          	srli	a2,a1,0xc
    800013a4:	4581                	li	a1,0
    800013a6:	e01ff0ef          	jal	800011a6 <_Z8uvmunmapPmmmi>
    800013aa:	bff9                	j	80001388 <_Z7uvmfreePmm+0xe>

00000000800013ac <_Z7uvmcopyPmS_m>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for (i = 0; i < sz; i += PGSIZE) {
    800013ac:	ce49                	beqz	a2,80001446 <_Z7uvmcopyPmS_m+0x9a>
{
    800013ae:	715d                	addi	sp,sp,-80
    800013b0:	e486                	sd	ra,72(sp)
    800013b2:	e0a2                	sd	s0,64(sp)
    800013b4:	fc26                	sd	s1,56(sp)
    800013b6:	f84a                	sd	s2,48(sp)
    800013b8:	f44e                	sd	s3,40(sp)
    800013ba:	f052                	sd	s4,32(sp)
    800013bc:	ec56                	sd	s5,24(sp)
    800013be:	e85a                	sd	s6,16(sp)
    800013c0:	e45e                	sd	s7,8(sp)
    800013c2:	0880                	addi	s0,sp,80
    800013c4:	8aaa                	mv	s5,a0
    800013c6:	8b2e                	mv	s6,a1
    800013c8:	8a32                	mv	s4,a2
  for (i = 0; i < sz; i += PGSIZE) {
    800013ca:	4481                	li	s1,0
    800013cc:	a029                	j	800013d6 <_Z7uvmcopyPmS_m+0x2a>
    800013ce:	6785                	lui	a5,0x1
    800013d0:	94be                	add	s1,s1,a5
    800013d2:	0544fe63          	bgeu	s1,s4,8000142e <_Z7uvmcopyPmS_m+0x82>
    if ((pte = walk(old, i, 0)) == 0)
    800013d6:	4601                	li	a2,0
    800013d8:	85a6                	mv	a1,s1
    800013da:	8556                	mv	a0,s5
    800013dc:	b27ff0ef          	jal	80000f02 <_Z4walkPmmi>
    800013e0:	d57d                	beqz	a0,800013ce <_Z7uvmcopyPmS_m+0x22>
      continue; // page table entry hasn't been allocated
    if ((*pte & PTE_V) == 0)
    800013e2:	6118                	ld	a4,0(a0)
    800013e4:	00177793          	andi	a5,a4,1
    800013e8:	d3fd                	beqz	a5,800013ce <_Z7uvmcopyPmS_m+0x22>
      continue; // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    800013ea:	00a75593          	srli	a1,a4,0xa
    800013ee:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    800013f2:	3ff77913          	andi	s2,a4,1023
    if ((mem = static_cast<char*>(kalloc())) == 0)
    800013f6:	f04ff0ef          	jal	80000afa <_Z6kallocv>
    800013fa:	89aa                	mv	s3,a0
    800013fc:	c105                	beqz	a0,8000141c <_Z7uvmcopyPmS_m+0x70>
      goto err;
    memmove(mem, (char *)pa, PGSIZE);
    800013fe:	6605                	lui	a2,0x1
    80001400:	85de                	mv	a1,s7
    80001402:	8dfff0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
    if (mappages(new_pt, i, PGSIZE, (uint64)mem, flags) != 0) {
    80001406:	874a                	mv	a4,s2
    80001408:	86ce                	mv	a3,s3
    8000140a:	6605                	lui	a2,0x1
    8000140c:	85a6                	mv	a1,s1
    8000140e:	855a                	mv	a0,s6
    80001410:	bcbff0ef          	jal	80000fda <_Z8mappagesPmmmmi>
    80001414:	dd4d                	beqz	a0,800013ce <_Z7uvmcopyPmS_m+0x22>
      kfree(mem);
    80001416:	854e                	mv	a0,s3
    80001418:	e00ff0ef          	jal	80000a18 <_Z5kfreePv>
    }
  }
  return 0;

err:
  uvmunmap(new_pt, 0, i / PGSIZE, 1);
    8000141c:	4685                	li	a3,1
    8000141e:	00c4d613          	srli	a2,s1,0xc
    80001422:	4581                	li	a1,0
    80001424:	855a                	mv	a0,s6
    80001426:	d81ff0ef          	jal	800011a6 <_Z8uvmunmapPmmmi>
  return -1;
    8000142a:	557d                	li	a0,-1
    8000142c:	a011                	j	80001430 <_Z7uvmcopyPmS_m+0x84>
  return 0;
    8000142e:	4501                	li	a0,0
}
    80001430:	60a6                	ld	ra,72(sp)
    80001432:	6406                	ld	s0,64(sp)
    80001434:	74e2                	ld	s1,56(sp)
    80001436:	7942                	ld	s2,48(sp)
    80001438:	79a2                	ld	s3,40(sp)
    8000143a:	7a02                	ld	s4,32(sp)
    8000143c:	6ae2                	ld	s5,24(sp)
    8000143e:	6b42                	ld	s6,16(sp)
    80001440:	6ba2                	ld	s7,8(sp)
    80001442:	6161                	addi	sp,sp,80
    80001444:	8082                	ret
  return 0;
    80001446:	4501                	li	a0,0
}
    80001448:	8082                	ret

000000008000144a <_Z8uvmclearPmm>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    8000144a:	1141                	addi	sp,sp,-16
    8000144c:	e406                	sd	ra,8(sp)
    8000144e:	e022                	sd	s0,0(sp)
    80001450:	0800                	addi	s0,sp,16
  pte_t *pte;

  pte = walk(pagetable, va, 0);
    80001452:	4601                	li	a2,0
    80001454:	aafff0ef          	jal	80000f02 <_Z4walkPmmi>
  if (pte == 0)
    80001458:	c901                	beqz	a0,80001468 <_Z8uvmclearPmm+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    8000145a:	611c                	ld	a5,0(a0)
    8000145c:	9bbd                	andi	a5,a5,-17
    8000145e:	e11c                	sd	a5,0(a0)
}
    80001460:	60a2                	ld	ra,8(sp)
    80001462:	6402                	ld	s0,0(sp)
    80001464:	0141                	addi	sp,sp,16
    80001466:	8082                	ret
    panic("uvmclear");
    80001468:	00006517          	auipc	a0,0x6
    8000146c:	ce050513          	addi	a0,a0,-800 # 80007148 <etext+0x148>
    80001470:	b82ff0ef          	jal	800007f2 <_Z5panicPKc>

0000000080001474 <_Z9copyinstrPmPcmm>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while (got_null == 0 && max > 0) {
    80001474:	c6dd                	beqz	a3,80001522 <_Z9copyinstrPmPcmm+0xae>
{
    80001476:	715d                	addi	sp,sp,-80
    80001478:	e486                	sd	ra,72(sp)
    8000147a:	e0a2                	sd	s0,64(sp)
    8000147c:	fc26                	sd	s1,56(sp)
    8000147e:	f84a                	sd	s2,48(sp)
    80001480:	f44e                	sd	s3,40(sp)
    80001482:	f052                	sd	s4,32(sp)
    80001484:	ec56                	sd	s5,24(sp)
    80001486:	e85a                	sd	s6,16(sp)
    80001488:	e45e                	sd	s7,8(sp)
    8000148a:	0880                	addi	s0,sp,80
    8000148c:	8a2a                	mv	s4,a0
    8000148e:	8b2e                	mv	s6,a1
    80001490:	8bb2                	mv	s7,a2
    80001492:	8936                	mv	s2,a3
    va0 = PGROUNDDOWN(srcva);
    80001494:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if (pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80001496:	6985                	lui	s3,0x1
    80001498:	a825                	j	800014d0 <_Z9copyinstrPmPcmm+0x5c>
      n = max;

    char *p = (char *)(pa0 + (srcva - va0));
    while (n > 0) {
      if (*p == '\0') {
        *dst = '\0';
    8000149a:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    8000149e:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if (got_null) {
    800014a0:	37fd                	addiw	a5,a5,-1
    800014a2:	0007851b          	sext.w	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    800014a6:	60a6                	ld	ra,72(sp)
    800014a8:	6406                	ld	s0,64(sp)
    800014aa:	74e2                	ld	s1,56(sp)
    800014ac:	7942                	ld	s2,48(sp)
    800014ae:	79a2                	ld	s3,40(sp)
    800014b0:	7a02                	ld	s4,32(sp)
    800014b2:	6ae2                	ld	s5,24(sp)
    800014b4:	6b42                	ld	s6,16(sp)
    800014b6:	6ba2                	ld	s7,8(sp)
    800014b8:	6161                	addi	sp,sp,80
    800014ba:	8082                	ret
    800014bc:	fff90713          	addi	a4,s2,-1 # fff <_entry-0x7ffff001>
    800014c0:	9742                	add	a4,a4,a6
      --max;
    800014c2:	40b70933          	sub	s2,a4,a1
    srcva = va0 + PGSIZE;
    800014c6:	01348bb3          	add	s7,s1,s3
  while (got_null == 0 && max > 0) {
    800014ca:	04e58463          	beq	a1,a4,80001512 <_Z9copyinstrPmPcmm+0x9e>
{
    800014ce:	8b3e                	mv	s6,a5
    va0 = PGROUNDDOWN(srcva);
    800014d0:	015bf4b3          	and	s1,s7,s5
    pa0 = walkaddr(pagetable, va0);
    800014d4:	85a6                	mv	a1,s1
    800014d6:	8552                	mv	a0,s4
    800014d8:	ac5ff0ef          	jal	80000f9c <_Z8walkaddrPmm>
    if (pa0 == 0)
    800014dc:	cd0d                	beqz	a0,80001516 <_Z9copyinstrPmPcmm+0xa2>
    n = PGSIZE - (srcva - va0);
    800014de:	417486b3          	sub	a3,s1,s7
    800014e2:	96ce                	add	a3,a3,s3
    if (n > max)
    800014e4:	00d97363          	bgeu	s2,a3,800014ea <_Z9copyinstrPmPcmm+0x76>
    800014e8:	86ca                	mv	a3,s2
    char *p = (char *)(pa0 + (srcva - va0));
    800014ea:	955e                	add	a0,a0,s7
    800014ec:	8d05                	sub	a0,a0,s1
    while (n > 0) {
    800014ee:	c695                	beqz	a3,8000151a <_Z9copyinstrPmPcmm+0xa6>
    800014f0:	87da                	mv	a5,s6
    800014f2:	885a                	mv	a6,s6
      if (*p == '\0') {
    800014f4:	41650633          	sub	a2,a0,s6
    while (n > 0) {
    800014f8:	96da                	add	a3,a3,s6
    800014fa:	85be                	mv	a1,a5
      if (*p == '\0') {
    800014fc:	00f60733          	add	a4,a2,a5
    80001500:	00074703          	lbu	a4,0(a4)
    80001504:	db59                	beqz	a4,8000149a <_Z9copyinstrPmPcmm+0x26>
        *dst = *p;
    80001506:	00e78023          	sb	a4,0(a5)
      dst++;
    8000150a:	0785                	addi	a5,a5,1
    while (n > 0) {
    8000150c:	fed797e3          	bne	a5,a3,800014fa <_Z9copyinstrPmPcmm+0x86>
    80001510:	b775                	j	800014bc <_Z9copyinstrPmPcmm+0x48>
    80001512:	4781                	li	a5,0
    80001514:	b771                	j	800014a0 <_Z9copyinstrPmPcmm+0x2c>
      return -1;
    80001516:	557d                	li	a0,-1
    80001518:	b779                	j	800014a6 <_Z9copyinstrPmPcmm+0x32>
    srcva = va0 + PGSIZE;
    8000151a:	6b85                	lui	s7,0x1
    8000151c:	9ba6                	add	s7,s7,s1
    8000151e:	87da                	mv	a5,s6
    80001520:	b77d                	j	800014ce <_Z9copyinstrPmPcmm+0x5a>
  int got_null = 0;
    80001522:	4781                	li	a5,0
  if (got_null) {
    80001524:	37fd                	addiw	a5,a5,-1
    80001526:	0007851b          	sext.w	a0,a5
}
    8000152a:	8082                	ret

000000008000152c <_Z8ismappedPmm>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    8000152c:	1141                	addi	sp,sp,-16
    8000152e:	e406                	sd	ra,8(sp)
    80001530:	e022                	sd	s0,0(sp)
    80001532:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    80001534:	4601                	li	a2,0
    80001536:	9cdff0ef          	jal	80000f02 <_Z4walkPmmi>
  if (pte == 0) {
    8000153a:	c519                	beqz	a0,80001548 <_Z8ismappedPmm+0x1c>
    return 0;
  }
  if (*pte & PTE_V) {
    8000153c:	6108                	ld	a0,0(a0)
    8000153e:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    80001540:	60a2                	ld	ra,8(sp)
    80001542:	6402                	ld	s0,0(sp)
    80001544:	0141                	addi	sp,sp,16
    80001546:	8082                	ret
    return 0;
    80001548:	4501                	li	a0,0
    8000154a:	bfdd                	j	80001540 <_Z8ismappedPmm+0x14>

000000008000154c <_Z7vmfaultPmmi>:
{
    8000154c:	7179                	addi	sp,sp,-48
    8000154e:	f406                	sd	ra,40(sp)
    80001550:	f022                	sd	s0,32(sp)
    80001552:	ec26                	sd	s1,24(sp)
    80001554:	e44e                	sd	s3,8(sp)
    80001556:	1800                	addi	s0,sp,48
    80001558:	89aa                	mv	s3,a0
    8000155a:	84ae                	mv	s1,a1
  struct proc *p = myproc();
    8000155c:	35e000ef          	jal	800018ba <_Z6myprocv>
  if (va >= p->sz)
    80001560:	653c                	ld	a5,72(a0)
    80001562:	00f4ea63          	bltu	s1,a5,80001576 <_Z7vmfaultPmmi+0x2a>
    return 0;
    80001566:	4981                	li	s3,0
}
    80001568:	854e                	mv	a0,s3
    8000156a:	70a2                	ld	ra,40(sp)
    8000156c:	7402                	ld	s0,32(sp)
    8000156e:	64e2                	ld	s1,24(sp)
    80001570:	69a2                	ld	s3,8(sp)
    80001572:	6145                	addi	sp,sp,48
    80001574:	8082                	ret
    80001576:	e84a                	sd	s2,16(sp)
    80001578:	892a                	mv	s2,a0
  va = PGROUNDDOWN(va);
    8000157a:	77fd                	lui	a5,0xfffff
    8000157c:	8cfd                	and	s1,s1,a5
  if (ismapped(pagetable, va)) {
    8000157e:	85a6                	mv	a1,s1
    80001580:	854e                	mv	a0,s3
    80001582:	fabff0ef          	jal	8000152c <_Z8ismappedPmm>
    return 0;
    80001586:	4981                	li	s3,0
  if (ismapped(pagetable, va)) {
    80001588:	c119                	beqz	a0,8000158e <_Z7vmfaultPmmi+0x42>
    8000158a:	6942                	ld	s2,16(sp)
    8000158c:	bff1                	j	80001568 <_Z7vmfaultPmmi+0x1c>
    8000158e:	e052                	sd	s4,0(sp)
  mem = (uint64)kalloc();
    80001590:	d6aff0ef          	jal	80000afa <_Z6kallocv>
    80001594:	8a2a                	mv	s4,a0
  if (mem == 0)
    80001596:	c90d                	beqz	a0,800015c8 <_Z7vmfaultPmmi+0x7c>
  mem = (uint64)kalloc();
    80001598:	89aa                	mv	s3,a0
  memset((void *)mem, 0, PGSIZE);
    8000159a:	6605                	lui	a2,0x1
    8000159c:	4581                	li	a1,0
    8000159e:	ee6ff0ef          	jal	80000c84 <_Z6memsetPvij>
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W | PTE_U | PTE_R) != 0) {
    800015a2:	4759                	li	a4,22
    800015a4:	86d2                	mv	a3,s4
    800015a6:	6605                	lui	a2,0x1
    800015a8:	85a6                	mv	a1,s1
    800015aa:	05093503          	ld	a0,80(s2)
    800015ae:	a2dff0ef          	jal	80000fda <_Z8mappagesPmmmmi>
    800015b2:	e501                	bnez	a0,800015ba <_Z7vmfaultPmmi+0x6e>
    800015b4:	6942                	ld	s2,16(sp)
    800015b6:	6a02                	ld	s4,0(sp)
    800015b8:	bf45                	j	80001568 <_Z7vmfaultPmmi+0x1c>
    kfree((void *)mem);
    800015ba:	8552                	mv	a0,s4
    800015bc:	c5cff0ef          	jal	80000a18 <_Z5kfreePv>
    return 0;
    800015c0:	4981                	li	s3,0
    800015c2:	6942                	ld	s2,16(sp)
    800015c4:	6a02                	ld	s4,0(sp)
    800015c6:	b74d                	j	80001568 <_Z7vmfaultPmmi+0x1c>
    800015c8:	6942                	ld	s2,16(sp)
    800015ca:	6a02                	ld	s4,0(sp)
    800015cc:	bf71                	j	80001568 <_Z7vmfaultPmmi+0x1c>

00000000800015ce <_Z7copyoutPmmPKcm>:
  while (len > 0) {
    800015ce:	c2cd                	beqz	a3,80001670 <_Z7copyoutPmmPKcm+0xa2>
{
    800015d0:	711d                	addi	sp,sp,-96
    800015d2:	ec86                	sd	ra,88(sp)
    800015d4:	e8a2                	sd	s0,80(sp)
    800015d6:	e4a6                	sd	s1,72(sp)
    800015d8:	f852                	sd	s4,48(sp)
    800015da:	f05a                	sd	s6,32(sp)
    800015dc:	ec5e                	sd	s7,24(sp)
    800015de:	e862                	sd	s8,16(sp)
    800015e0:	1080                	addi	s0,sp,96
    800015e2:	8c2a                	mv	s8,a0
    800015e4:	8b2e                	mv	s6,a1
    800015e6:	8bb2                	mv	s7,a2
    800015e8:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    800015ea:	74fd                	lui	s1,0xfffff
    800015ec:	8ced                	and	s1,s1,a1
    if (va0 >= MAXVA)
    800015ee:	57fd                	li	a5,-1
    800015f0:	83e9                	srli	a5,a5,0x1a
    800015f2:	0897e163          	bltu	a5,s1,80001674 <_Z7copyoutPmmPKcm+0xa6>
    800015f6:	e0ca                	sd	s2,64(sp)
    800015f8:	fc4e                	sd	s3,56(sp)
    800015fa:	f456                	sd	s5,40(sp)
    800015fc:	e466                	sd	s9,8(sp)
    800015fe:	e06a                	sd	s10,0(sp)
    80001600:	6d05                	lui	s10,0x1
    80001602:	8cbe                	mv	s9,a5
    80001604:	a015                	j	80001628 <_Z7copyoutPmmPKcm+0x5a>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001606:	409b0533          	sub	a0,s6,s1
    8000160a:	0009861b          	sext.w	a2,s3
    8000160e:	85de                	mv	a1,s7
    80001610:	954a                	add	a0,a0,s2
    80001612:	eceff0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
    len -= n;
    80001616:	413a0a33          	sub	s4,s4,s3
    src += n;
    8000161a:	9bce                	add	s7,s7,s3
  while (len > 0) {
    8000161c:	040a0363          	beqz	s4,80001662 <_Z7copyoutPmmPKcm+0x94>
    if (va0 >= MAXVA)
    80001620:	055cec63          	bltu	s9,s5,80001678 <_Z7copyoutPmmPKcm+0xaa>
    80001624:	84d6                	mv	s1,s5
    80001626:	8b56                	mv	s6,s5
    pa0 = walkaddr(pagetable, va0);
    80001628:	85a6                	mv	a1,s1
    8000162a:	8562                	mv	a0,s8
    8000162c:	971ff0ef          	jal	80000f9c <_Z8walkaddrPmm>
    80001630:	892a                	mv	s2,a0
    if (pa0 == 0) {
    80001632:	e901                	bnez	a0,80001642 <_Z7copyoutPmmPKcm+0x74>
      if ((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001634:	4601                	li	a2,0
    80001636:	85a6                	mv	a1,s1
    80001638:	8562                	mv	a0,s8
    8000163a:	f13ff0ef          	jal	8000154c <_Z7vmfaultPmmi>
    8000163e:	892a                	mv	s2,a0
    80001640:	c139                	beqz	a0,80001686 <_Z7copyoutPmmPKcm+0xb8>
    pte = walk(pagetable, va0, 0);
    80001642:	4601                	li	a2,0
    80001644:	85a6                	mv	a1,s1
    80001646:	8562                	mv	a0,s8
    80001648:	8bbff0ef          	jal	80000f02 <_Z4walkPmmi>
    if ((*pte & PTE_W) == 0)
    8000164c:	611c                	ld	a5,0(a0)
    8000164e:	8b91                	andi	a5,a5,4
    80001650:	c3b1                	beqz	a5,80001694 <_Z7copyoutPmmPKcm+0xc6>
    n = PGSIZE - (dstva - va0);
    80001652:	01a48ab3          	add	s5,s1,s10
    80001656:	416a89b3          	sub	s3,s5,s6
    if (n > len)
    8000165a:	fb3a76e3          	bgeu	s4,s3,80001606 <_Z7copyoutPmmPKcm+0x38>
    8000165e:	89d2                	mv	s3,s4
    80001660:	b75d                	j	80001606 <_Z7copyoutPmmPKcm+0x38>
  return 0;
    80001662:	4501                	li	a0,0
    80001664:	6906                	ld	s2,64(sp)
    80001666:	79e2                	ld	s3,56(sp)
    80001668:	7aa2                	ld	s5,40(sp)
    8000166a:	6ca2                	ld	s9,8(sp)
    8000166c:	6d02                	ld	s10,0(sp)
    8000166e:	a80d                	j	800016a0 <_Z7copyoutPmmPKcm+0xd2>
    80001670:	4501                	li	a0,0
}
    80001672:	8082                	ret
      return -1;
    80001674:	557d                	li	a0,-1
    80001676:	a02d                	j	800016a0 <_Z7copyoutPmmPKcm+0xd2>
    80001678:	557d                	li	a0,-1
    8000167a:	6906                	ld	s2,64(sp)
    8000167c:	79e2                	ld	s3,56(sp)
    8000167e:	7aa2                	ld	s5,40(sp)
    80001680:	6ca2                	ld	s9,8(sp)
    80001682:	6d02                	ld	s10,0(sp)
    80001684:	a831                	j	800016a0 <_Z7copyoutPmmPKcm+0xd2>
        return -1;
    80001686:	557d                	li	a0,-1
    80001688:	6906                	ld	s2,64(sp)
    8000168a:	79e2                	ld	s3,56(sp)
    8000168c:	7aa2                	ld	s5,40(sp)
    8000168e:	6ca2                	ld	s9,8(sp)
    80001690:	6d02                	ld	s10,0(sp)
    80001692:	a039                	j	800016a0 <_Z7copyoutPmmPKcm+0xd2>
      return -1;
    80001694:	557d                	li	a0,-1
    80001696:	6906                	ld	s2,64(sp)
    80001698:	79e2                	ld	s3,56(sp)
    8000169a:	7aa2                	ld	s5,40(sp)
    8000169c:	6ca2                	ld	s9,8(sp)
    8000169e:	6d02                	ld	s10,0(sp)
}
    800016a0:	60e6                	ld	ra,88(sp)
    800016a2:	6446                	ld	s0,80(sp)
    800016a4:	64a6                	ld	s1,72(sp)
    800016a6:	7a42                	ld	s4,48(sp)
    800016a8:	7b02                	ld	s6,32(sp)
    800016aa:	6be2                	ld	s7,24(sp)
    800016ac:	6c42                	ld	s8,16(sp)
    800016ae:	6125                	addi	sp,sp,96
    800016b0:	8082                	ret

00000000800016b2 <_Z6copyinPmPcmm>:
  while (len > 0) {
    800016b2:	c6c9                	beqz	a3,8000173c <_Z6copyinPmPcmm+0x8a>
{
    800016b4:	715d                	addi	sp,sp,-80
    800016b6:	e486                	sd	ra,72(sp)
    800016b8:	e0a2                	sd	s0,64(sp)
    800016ba:	fc26                	sd	s1,56(sp)
    800016bc:	f84a                	sd	s2,48(sp)
    800016be:	f44e                	sd	s3,40(sp)
    800016c0:	f052                	sd	s4,32(sp)
    800016c2:	ec56                	sd	s5,24(sp)
    800016c4:	e85a                	sd	s6,16(sp)
    800016c6:	e45e                	sd	s7,8(sp)
    800016c8:	e062                	sd	s8,0(sp)
    800016ca:	0880                	addi	s0,sp,80
    800016cc:	8baa                	mv	s7,a0
    800016ce:	8aae                	mv	s5,a1
    800016d0:	8932                	mv	s2,a2
    800016d2:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    800016d4:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    800016d6:	6b05                	lui	s6,0x1
    800016d8:	a035                	j	80001704 <_Z6copyinPmPcmm+0x52>
    800016da:	412984b3          	sub	s1,s3,s2
    800016de:	94da                	add	s1,s1,s6
    if (n > len)
    800016e0:	009a7363          	bgeu	s4,s1,800016e6 <_Z6copyinPmPcmm+0x34>
    800016e4:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    800016e6:	413905b3          	sub	a1,s2,s3
    800016ea:	0004861b          	sext.w	a2,s1
    800016ee:	95aa                	add	a1,a1,a0
    800016f0:	8556                	mv	a0,s5
    800016f2:	deeff0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
    len -= n;
    800016f6:	409a0a33          	sub	s4,s4,s1
    dst += n;
    800016fa:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    800016fc:	01698933          	add	s2,s3,s6
  while (len > 0) {
    80001700:	020a0163          	beqz	s4,80001722 <_Z6copyinPmPcmm+0x70>
    va0 = PGROUNDDOWN(srcva);
    80001704:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    80001708:	85ce                	mv	a1,s3
    8000170a:	855e                	mv	a0,s7
    8000170c:	891ff0ef          	jal	80000f9c <_Z8walkaddrPmm>
    if (pa0 == 0) {
    80001710:	f569                	bnez	a0,800016da <_Z6copyinPmPcmm+0x28>
      if ((pa0 = vmfault(pagetable, va0, 1)) == 0) {
    80001712:	4605                	li	a2,1
    80001714:	85ce                	mv	a1,s3
    80001716:	855e                	mv	a0,s7
    80001718:	e35ff0ef          	jal	8000154c <_Z7vmfaultPmmi>
    8000171c:	fd5d                	bnez	a0,800016da <_Z6copyinPmPcmm+0x28>
        return -1;
    8000171e:	557d                	li	a0,-1
    80001720:	a011                	j	80001724 <_Z6copyinPmPcmm+0x72>
  return 0;
    80001722:	4501                	li	a0,0
}
    80001724:	60a6                	ld	ra,72(sp)
    80001726:	6406                	ld	s0,64(sp)
    80001728:	74e2                	ld	s1,56(sp)
    8000172a:	7942                	ld	s2,48(sp)
    8000172c:	79a2                	ld	s3,40(sp)
    8000172e:	7a02                	ld	s4,32(sp)
    80001730:	6ae2                	ld	s5,24(sp)
    80001732:	6b42                	ld	s6,16(sp)
    80001734:	6ba2                	ld	s7,8(sp)
    80001736:	6c02                	ld	s8,0(sp)
    80001738:	6161                	addi	sp,sp,80
    8000173a:	8082                	ret
  return 0;
    8000173c:	4501                	li	a0,0
}
    8000173e:	8082                	ret

0000000080001740 <_Z14proc_mapstacksPm>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001740:	7139                	addi	sp,sp,-64
    80001742:	fc06                	sd	ra,56(sp)
    80001744:	f822                	sd	s0,48(sp)
    80001746:	f426                	sd	s1,40(sp)
    80001748:	f04a                	sd	s2,32(sp)
    8000174a:	ec4e                	sd	s3,24(sp)
    8000174c:	e852                	sd	s4,16(sp)
    8000174e:	e456                	sd	s5,8(sp)
    80001750:	e05a                	sd	s6,0(sp)
    80001752:	0080                	addi	s0,sp,64
    80001754:	8a2a                	mv	s4,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80001756:	0000e497          	auipc	s1,0xe
    8000175a:	64248493          	addi	s1,s1,1602 # 8000fd98 <proc>
    char *pa = static_cast<char*>(kalloc());
    if (pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int)(p - proc));
    8000175e:	8b26                	mv	s6,s1
    80001760:	04fa5937          	lui	s2,0x4fa5
    80001764:	fa590913          	addi	s2,s2,-91 # 4fa4fa5 <_entry-0x7b05b05b>
    80001768:	0932                	slli	s2,s2,0xc
    8000176a:	fa590913          	addi	s2,s2,-91
    8000176e:	0932                	slli	s2,s2,0xc
    80001770:	fa590913          	addi	s2,s2,-91
    80001774:	0932                	slli	s2,s2,0xc
    80001776:	fa590913          	addi	s2,s2,-91
    8000177a:	040009b7          	lui	s3,0x4000
    8000177e:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001780:	09b2                	slli	s3,s3,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    80001782:	00014a97          	auipc	s5,0x14
    80001786:	016a8a93          	addi	s5,s5,22 # 80015798 <tickslock>
    char *pa = static_cast<char*>(kalloc());
    8000178a:	b70ff0ef          	jal	80000afa <_Z6kallocv>
    8000178e:	862a                	mv	a2,a0
    if (pa == 0)
    80001790:	cd15                	beqz	a0,800017cc <_Z14proc_mapstacksPm+0x8c>
    uint64 va = KSTACK((int)(p - proc));
    80001792:	416485b3          	sub	a1,s1,s6
    80001796:	858d                	srai	a1,a1,0x3
    80001798:	032585b3          	mul	a1,a1,s2
    8000179c:	2585                	addiw	a1,a1,1
    8000179e:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017a2:	4719                	li	a4,6
    800017a4:	6685                	lui	a3,0x1
    800017a6:	40b985b3          	sub	a1,s3,a1
    800017aa:	8552                	mv	a0,s4
    800017ac:	8dfff0ef          	jal	8000108a <_Z6kvmmapPmmmmi>
  for (p = proc; p < &proc[NPROC]; p++) {
    800017b0:	16848493          	addi	s1,s1,360
    800017b4:	fd549be3          	bne	s1,s5,8000178a <_Z14proc_mapstacksPm+0x4a>
  }
}
    800017b8:	70e2                	ld	ra,56(sp)
    800017ba:	7442                	ld	s0,48(sp)
    800017bc:	74a2                	ld	s1,40(sp)
    800017be:	7902                	ld	s2,32(sp)
    800017c0:	69e2                	ld	s3,24(sp)
    800017c2:	6a42                	ld	s4,16(sp)
    800017c4:	6aa2                	ld	s5,8(sp)
    800017c6:	6b02                	ld	s6,0(sp)
    800017c8:	6121                	addi	sp,sp,64
    800017ca:	8082                	ret
      panic("kalloc");
    800017cc:	00006517          	auipc	a0,0x6
    800017d0:	98c50513          	addi	a0,a0,-1652 # 80007158 <etext+0x158>
    800017d4:	81eff0ef          	jal	800007f2 <_Z5panicPKc>

00000000800017d8 <_Z8procinitv>:

// initialize the proc table.
void
procinit(void)
{
    800017d8:	7139                	addi	sp,sp,-64
    800017da:	fc06                	sd	ra,56(sp)
    800017dc:	f822                	sd	s0,48(sp)
    800017de:	f426                	sd	s1,40(sp)
    800017e0:	f04a                	sd	s2,32(sp)
    800017e2:	ec4e                	sd	s3,24(sp)
    800017e4:	e852                	sd	s4,16(sp)
    800017e6:	e456                	sd	s5,8(sp)
    800017e8:	e05a                	sd	s6,0(sp)
    800017ea:	0080                	addi	s0,sp,64
  struct proc *p;

  initlock(&pid_lock, "nextpid");
    800017ec:	00006597          	auipc	a1,0x6
    800017f0:	97458593          	addi	a1,a1,-1676 # 80007160 <etext+0x160>
    800017f4:	0000e517          	auipc	a0,0xe
    800017f8:	17450513          	addi	a0,a0,372 # 8000f968 <pid_lock>
    800017fc:	b4eff0ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>
  initlock(&wait_lock, "wait_lock");
    80001800:	00006597          	auipc	a1,0x6
    80001804:	96858593          	addi	a1,a1,-1688 # 80007168 <etext+0x168>
    80001808:	0000e517          	auipc	a0,0xe
    8000180c:	17850513          	addi	a0,a0,376 # 8000f980 <wait_lock>
    80001810:	b3aff0ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001814:	0000e497          	auipc	s1,0xe
    80001818:	58448493          	addi	s1,s1,1412 # 8000fd98 <proc>
    initlock(&p->lock, "proc");
    8000181c:	00006b17          	auipc	s6,0x6
    80001820:	95cb0b13          	addi	s6,s6,-1700 # 80007178 <etext+0x178>
    p->state = UNUSED;
    p->kstack = KSTACK((int)(p - proc));
    80001824:	8aa6                	mv	s5,s1
    80001826:	04fa5937          	lui	s2,0x4fa5
    8000182a:	fa590913          	addi	s2,s2,-91 # 4fa4fa5 <_entry-0x7b05b05b>
    8000182e:	0932                	slli	s2,s2,0xc
    80001830:	fa590913          	addi	s2,s2,-91
    80001834:	0932                	slli	s2,s2,0xc
    80001836:	fa590913          	addi	s2,s2,-91
    8000183a:	0932                	slli	s2,s2,0xc
    8000183c:	fa590913          	addi	s2,s2,-91
    80001840:	040009b7          	lui	s3,0x4000
    80001844:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001846:	09b2                	slli	s3,s3,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    80001848:	00014a17          	auipc	s4,0x14
    8000184c:	f50a0a13          	addi	s4,s4,-176 # 80015798 <tickslock>
    initlock(&p->lock, "proc");
    80001850:	85da                	mv	a1,s6
    80001852:	8526                	mv	a0,s1
    80001854:	af6ff0ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>
    p->state = UNUSED;
    80001858:	0004ac23          	sw	zero,24(s1)
    p->kstack = KSTACK((int)(p - proc));
    8000185c:	415487b3          	sub	a5,s1,s5
    80001860:	878d                	srai	a5,a5,0x3
    80001862:	032787b3          	mul	a5,a5,s2
    80001866:	2785                	addiw	a5,a5,1 # fffffffffffff001 <end+0xffffffff7ffde489>
    80001868:	00d7979b          	slliw	a5,a5,0xd
    8000186c:	40f987b3          	sub	a5,s3,a5
    80001870:	e0bc                	sd	a5,64(s1)
  for (p = proc; p < &proc[NPROC]; p++) {
    80001872:	16848493          	addi	s1,s1,360
    80001876:	fd449de3          	bne	s1,s4,80001850 <_Z8procinitv+0x78>
  }
}
    8000187a:	70e2                	ld	ra,56(sp)
    8000187c:	7442                	ld	s0,48(sp)
    8000187e:	74a2                	ld	s1,40(sp)
    80001880:	7902                	ld	s2,32(sp)
    80001882:	69e2                	ld	s3,24(sp)
    80001884:	6a42                	ld	s4,16(sp)
    80001886:	6aa2                	ld	s5,8(sp)
    80001888:	6b02                	ld	s6,0(sp)
    8000188a:	6121                	addi	sp,sp,64
    8000188c:	8082                	ret

000000008000188e <_Z5cpuidv>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    8000188e:	1141                	addi	sp,sp,-16
    80001890:	e422                	sd	s0,8(sp)
    80001892:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r"(x));
    80001894:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001896:	2501                	sext.w	a0,a0
    80001898:	6422                	ld	s0,8(sp)
    8000189a:	0141                	addi	sp,sp,16
    8000189c:	8082                	ret

000000008000189e <_Z5mycpuv>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu *
mycpu(void)
{
    8000189e:	1141                	addi	sp,sp,-16
    800018a0:	e422                	sd	s0,8(sp)
    800018a2:	0800                	addi	s0,sp,16
    800018a4:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    800018a6:	2781                	sext.w	a5,a5
    800018a8:	079e                	slli	a5,a5,0x7
  return c;
}
    800018aa:	0000e517          	auipc	a0,0xe
    800018ae:	0ee50513          	addi	a0,a0,238 # 8000f998 <cpus>
    800018b2:	953e                	add	a0,a0,a5
    800018b4:	6422                	ld	s0,8(sp)
    800018b6:	0141                	addi	sp,sp,16
    800018b8:	8082                	ret

00000000800018ba <_Z6myprocv>:

// Return the current struct proc *, or zero if none.
struct proc *
myproc(void)
{
    800018ba:	1101                	addi	sp,sp,-32
    800018bc:	ec06                	sd	ra,24(sp)
    800018be:	e822                	sd	s0,16(sp)
    800018c0:	e426                	sd	s1,8(sp)
    800018c2:	1000                	addi	s0,sp,32
  push_off();
    800018c4:	ac6ff0ef          	jal	80000b8a <_Z8push_offv>
    800018c8:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    800018ca:	2781                	sext.w	a5,a5
    800018cc:	079e                	slli	a5,a5,0x7
    800018ce:	0000e717          	auipc	a4,0xe
    800018d2:	09a70713          	addi	a4,a4,154 # 8000f968 <pid_lock>
    800018d6:	97ba                	add	a5,a5,a4
    800018d8:	7b84                	ld	s1,48(a5)
  pop_off();
    800018da:	b26ff0ef          	jal	80000c00 <_Z7pop_offv>
  return p;
}
    800018de:	8526                	mv	a0,s1
    800018e0:	60e2                	ld	ra,24(sp)
    800018e2:	6442                	ld	s0,16(sp)
    800018e4:	64a2                	ld	s1,8(sp)
    800018e6:	6105                	addi	sp,sp,32
    800018e8:	8082                	ret

00000000800018ea <_Z7forkretv>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    800018ea:	7179                	addi	sp,sp,-48
    800018ec:	f406                	sd	ra,40(sp)
    800018ee:	f022                	sd	s0,32(sp)
    800018f0:	ec26                	sd	s1,24(sp)
    800018f2:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    800018f4:	fc7ff0ef          	jal	800018ba <_Z6myprocv>
    800018f8:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    800018fa:	b52ff0ef          	jal	80000c4c <_Z7releaseP8spinlock>

  if (__atomic_load_n(&first, __ATOMIC_ACQUIRE)) {
    800018fe:	00006797          	auipc	a5,0x6
    80001902:	f327a783          	lw	a5,-206(a5) # 80007830 <_ZZ7forkretvE5first>
    80001906:	0ff0000f          	fence
    8000190a:	2781                	sext.w	a5,a5
    8000190c:	cf9d                	beqz	a5,8000194a <_Z7forkretv+0x60>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    8000190e:	4505                	li	a0,1
    80001910:	379010ef          	jal	80003488 <_Z6fsiniti>

    // ensure other cores see first=0.
    __atomic_store_n(&first, 0, __ATOMIC_RELEASE);
    80001914:	00006797          	auipc	a5,0x6
    80001918:	f1c78793          	addi	a5,a5,-228 # 80007830 <_ZZ7forkretvE5first>
    8000191c:	0f50000f          	fence	iorw,ow
    80001920:	0807a02f          	amoswap.w	zero,zero,(a5)

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    const char *argv[] = {"/init", nullptr};
    80001924:	00006517          	auipc	a0,0x6
    80001928:	85c50513          	addi	a0,a0,-1956 # 80007180 <etext+0x180>
    8000192c:	fca43823          	sd	a0,-48(s0)
    80001930:	fc043c23          	sd	zero,-40(s0)
    p->trapframe->a0 = kexec("/init", argv);
    80001934:	fd040593          	addi	a1,s0,-48
    80001938:	4df020ef          	jal	80004616 <_Z5kexecPKcPKS0_>
    8000193c:	6cbc                	ld	a5,88(s1)
    8000193e:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == static_cast<uint64>(-1)) {
    80001940:	6cbc                	ld	a5,88(s1)
    80001942:	7bb8                	ld	a4,112(a5)
    80001944:	57fd                	li	a5,-1
    80001946:	02f70d63          	beq	a4,a5,80001980 <_Z7forkretv+0x96>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    8000194a:	2ab000ef          	jal	800023f4 <_Z14prepare_returnv>
  uint64 satp = MAKE_SATP(p->pagetable);
    8000194e:	68a8                	ld	a0,80(s1)
    80001950:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001952:	04000737          	lui	a4,0x4000
    80001956:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80001958:	0732                	slli	a4,a4,0xc
    8000195a:	00004797          	auipc	a5,0x4
    8000195e:	74278793          	addi	a5,a5,1858 # 8000609c <userret>
    80001962:	00004697          	auipc	a3,0x4
    80001966:	69e68693          	addi	a3,a3,1694 # 80006000 <_trampoline>
    8000196a:	8f95                	sub	a5,a5,a3
    8000196c:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    8000196e:	577d                	li	a4,-1
    80001970:	177e                	slli	a4,a4,0x3f
    80001972:	8d59                	or	a0,a0,a4
    80001974:	9782                	jalr	a5
}
    80001976:	70a2                	ld	ra,40(sp)
    80001978:	7402                	ld	s0,32(sp)
    8000197a:	64e2                	ld	s1,24(sp)
    8000197c:	6145                	addi	sp,sp,48
    8000197e:	8082                	ret
      panic("exec");
    80001980:	00006517          	auipc	a0,0x6
    80001984:	80850513          	addi	a0,a0,-2040 # 80007188 <etext+0x188>
    80001988:	e6bfe0ef          	jal	800007f2 <_Z5panicPKc>

000000008000198c <_Z8allocpidv>:
{
    8000198c:	1101                	addi	sp,sp,-32
    8000198e:	ec06                	sd	ra,24(sp)
    80001990:	e822                	sd	s0,16(sp)
    80001992:	e426                	sd	s1,8(sp)
    80001994:	e04a                	sd	s2,0(sp)
    80001996:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001998:	0000e917          	auipc	s2,0xe
    8000199c:	fd090913          	addi	s2,s2,-48 # 8000f968 <pid_lock>
    800019a0:	854a                	mv	a0,s2
    800019a2:	a1eff0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  pid = nextpid;
    800019a6:	00006797          	auipc	a5,0x6
    800019aa:	e8e78793          	addi	a5,a5,-370 # 80007834 <nextpid>
    800019ae:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    800019b0:	0014871b          	addiw	a4,s1,1
    800019b4:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    800019b6:	854a                	mv	a0,s2
    800019b8:	a94ff0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    800019bc:	8526                	mv	a0,s1
    800019be:	60e2                	ld	ra,24(sp)
    800019c0:	6442                	ld	s0,16(sp)
    800019c2:	64a2                	ld	s1,8(sp)
    800019c4:	6902                	ld	s2,0(sp)
    800019c6:	6105                	addi	sp,sp,32
    800019c8:	8082                	ret

00000000800019ca <_Z14proc_pagetableP4proc>:
{
    800019ca:	1101                	addi	sp,sp,-32
    800019cc:	ec06                	sd	ra,24(sp)
    800019ce:	e822                	sd	s0,16(sp)
    800019d0:	e426                	sd	s1,8(sp)
    800019d2:	e04a                	sd	s2,0(sp)
    800019d4:	1000                	addi	s0,sp,32
    800019d6:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    800019d8:	fa8ff0ef          	jal	80001180 <_Z9uvmcreatev>
    800019dc:	84aa                	mv	s1,a0
  if (pagetable == 0)
    800019de:	cd05                	beqz	a0,80001a16 <_Z14proc_pagetableP4proc+0x4c>
  if (mappages(pagetable, TRAMPOLINE, PGSIZE, (uint64)trampoline,
    800019e0:	4729                	li	a4,10
    800019e2:	00004697          	auipc	a3,0x4
    800019e6:	61e68693          	addi	a3,a3,1566 # 80006000 <_trampoline>
    800019ea:	6605                	lui	a2,0x1
    800019ec:	040005b7          	lui	a1,0x4000
    800019f0:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800019f2:	05b2                	slli	a1,a1,0xc
    800019f4:	de6ff0ef          	jal	80000fda <_Z8mappagesPmmmmi>
    800019f8:	02054663          	bltz	a0,80001a24 <_Z14proc_pagetableP4proc+0x5a>
  if (mappages(pagetable, TRAPFRAME, PGSIZE, (uint64)(p->trapframe),
    800019fc:	4719                	li	a4,6
    800019fe:	05893683          	ld	a3,88(s2)
    80001a02:	6605                	lui	a2,0x1
    80001a04:	020005b7          	lui	a1,0x2000
    80001a08:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a0a:	05b6                	slli	a1,a1,0xd
    80001a0c:	8526                	mv	a0,s1
    80001a0e:	dccff0ef          	jal	80000fda <_Z8mappagesPmmmmi>
    80001a12:	00054f63          	bltz	a0,80001a30 <_Z14proc_pagetableP4proc+0x66>
}
    80001a16:	8526                	mv	a0,s1
    80001a18:	60e2                	ld	ra,24(sp)
    80001a1a:	6442                	ld	s0,16(sp)
    80001a1c:	64a2                	ld	s1,8(sp)
    80001a1e:	6902                	ld	s2,0(sp)
    80001a20:	6105                	addi	sp,sp,32
    80001a22:	8082                	ret
    uvmfree(pagetable, 0);
    80001a24:	4581                	li	a1,0
    80001a26:	8526                	mv	a0,s1
    80001a28:	953ff0ef          	jal	8000137a <_Z7uvmfreePmm>
    return 0;
    80001a2c:	4481                	li	s1,0
    80001a2e:	b7e5                	j	80001a16 <_Z14proc_pagetableP4proc+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a30:	4681                	li	a3,0
    80001a32:	4605                	li	a2,1
    80001a34:	040005b7          	lui	a1,0x4000
    80001a38:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a3a:	05b2                	slli	a1,a1,0xc
    80001a3c:	8526                	mv	a0,s1
    80001a3e:	f68ff0ef          	jal	800011a6 <_Z8uvmunmapPmmmi>
    uvmfree(pagetable, 0);
    80001a42:	4581                	li	a1,0
    80001a44:	8526                	mv	a0,s1
    80001a46:	935ff0ef          	jal	8000137a <_Z7uvmfreePmm>
    return 0;
    80001a4a:	4481                	li	s1,0
    80001a4c:	b7e9                	j	80001a16 <_Z14proc_pagetableP4proc+0x4c>

0000000080001a4e <_Z18proc_freepagetablePmm>:
{
    80001a4e:	1101                	addi	sp,sp,-32
    80001a50:	ec06                	sd	ra,24(sp)
    80001a52:	e822                	sd	s0,16(sp)
    80001a54:	e426                	sd	s1,8(sp)
    80001a56:	e04a                	sd	s2,0(sp)
    80001a58:	1000                	addi	s0,sp,32
    80001a5a:	84aa                	mv	s1,a0
    80001a5c:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a5e:	4681                	li	a3,0
    80001a60:	4605                	li	a2,1
    80001a62:	040005b7          	lui	a1,0x4000
    80001a66:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a68:	05b2                	slli	a1,a1,0xc
    80001a6a:	f3cff0ef          	jal	800011a6 <_Z8uvmunmapPmmmi>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a6e:	4681                	li	a3,0
    80001a70:	4605                	li	a2,1
    80001a72:	020005b7          	lui	a1,0x2000
    80001a76:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a78:	05b6                	slli	a1,a1,0xd
    80001a7a:	8526                	mv	a0,s1
    80001a7c:	f2aff0ef          	jal	800011a6 <_Z8uvmunmapPmmmi>
  uvmfree(pagetable, sz);
    80001a80:	85ca                	mv	a1,s2
    80001a82:	8526                	mv	a0,s1
    80001a84:	8f7ff0ef          	jal	8000137a <_Z7uvmfreePmm>
}
    80001a88:	60e2                	ld	ra,24(sp)
    80001a8a:	6442                	ld	s0,16(sp)
    80001a8c:	64a2                	ld	s1,8(sp)
    80001a8e:	6902                	ld	s2,0(sp)
    80001a90:	6105                	addi	sp,sp,32
    80001a92:	8082                	ret

0000000080001a94 <_ZL8freeprocP4proc>:
{
    80001a94:	1101                	addi	sp,sp,-32
    80001a96:	ec06                	sd	ra,24(sp)
    80001a98:	e822                	sd	s0,16(sp)
    80001a9a:	e426                	sd	s1,8(sp)
    80001a9c:	1000                	addi	s0,sp,32
    80001a9e:	84aa                	mv	s1,a0
  if (p->trapframe)
    80001aa0:	6d28                	ld	a0,88(a0)
    80001aa2:	c119                	beqz	a0,80001aa8 <_ZL8freeprocP4proc+0x14>
    kfree((void *)p->trapframe);
    80001aa4:	f75fe0ef          	jal	80000a18 <_Z5kfreePv>
  p->trapframe = 0;
    80001aa8:	0404bc23          	sd	zero,88(s1)
  if (p->pagetable)
    80001aac:	68a8                	ld	a0,80(s1)
    80001aae:	c501                	beqz	a0,80001ab6 <_ZL8freeprocP4proc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001ab0:	64ac                	ld	a1,72(s1)
    80001ab2:	f9dff0ef          	jal	80001a4e <_Z18proc_freepagetablePmm>
  p->pagetable = 0;
    80001ab6:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001aba:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001abe:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001ac2:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001ac6:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001aca:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001ace:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001ad2:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001ad6:	0004ac23          	sw	zero,24(s1)
}
    80001ada:	60e2                	ld	ra,24(sp)
    80001adc:	6442                	ld	s0,16(sp)
    80001ade:	64a2                	ld	s1,8(sp)
    80001ae0:	6105                	addi	sp,sp,32
    80001ae2:	8082                	ret

0000000080001ae4 <_ZL9allocprocv>:
{
    80001ae4:	1101                	addi	sp,sp,-32
    80001ae6:	ec06                	sd	ra,24(sp)
    80001ae8:	e822                	sd	s0,16(sp)
    80001aea:	e426                	sd	s1,8(sp)
    80001aec:	e04a                	sd	s2,0(sp)
    80001aee:	1000                	addi	s0,sp,32
  for (p = proc; p < &proc[NPROC]; p++) {
    80001af0:	0000e497          	auipc	s1,0xe
    80001af4:	2a848493          	addi	s1,s1,680 # 8000fd98 <proc>
    80001af8:	00014917          	auipc	s2,0x14
    80001afc:	ca090913          	addi	s2,s2,-864 # 80015798 <tickslock>
    acquire(&p->lock);
    80001b00:	8526                	mv	a0,s1
    80001b02:	8beff0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
    if (p->state == UNUSED) {
    80001b06:	4c9c                	lw	a5,24(s1)
    80001b08:	cb91                	beqz	a5,80001b1c <_ZL9allocprocv+0x38>
      release(&p->lock);
    80001b0a:	8526                	mv	a0,s1
    80001b0c:	940ff0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001b10:	16848493          	addi	s1,s1,360
    80001b14:	ff2496e3          	bne	s1,s2,80001b00 <_ZL9allocprocv+0x1c>
  return 0;
    80001b18:	4481                	li	s1,0
    80001b1a:	a089                	j	80001b5c <_ZL9allocprocv+0x78>
  p->pid = allocpid();
    80001b1c:	e71ff0ef          	jal	8000198c <_Z8allocpidv>
    80001b20:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b22:	4785                	li	a5,1
    80001b24:	cc9c                	sw	a5,24(s1)
  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    80001b26:	fd5fe0ef          	jal	80000afa <_Z6kallocv>
    80001b2a:	892a                	mv	s2,a0
    80001b2c:	eca8                	sd	a0,88(s1)
    80001b2e:	cd15                	beqz	a0,80001b6a <_ZL9allocprocv+0x86>
  p->pagetable = proc_pagetable(p);
    80001b30:	8526                	mv	a0,s1
    80001b32:	e99ff0ef          	jal	800019ca <_Z14proc_pagetableP4proc>
    80001b36:	892a                	mv	s2,a0
    80001b38:	e8a8                	sd	a0,80(s1)
  if (p->pagetable == 0) {
    80001b3a:	c121                	beqz	a0,80001b7a <_ZL9allocprocv+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001b3c:	07000613          	li	a2,112
    80001b40:	4581                	li	a1,0
    80001b42:	06048513          	addi	a0,s1,96
    80001b46:	93eff0ef          	jal	80000c84 <_Z6memsetPvij>
  p->context.ra = (uint64)forkret;
    80001b4a:	00000797          	auipc	a5,0x0
    80001b4e:	da078793          	addi	a5,a5,-608 # 800018ea <_Z7forkretv>
    80001b52:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b54:	60bc                	ld	a5,64(s1)
    80001b56:	6705                	lui	a4,0x1
    80001b58:	97ba                	add	a5,a5,a4
    80001b5a:	f4bc                	sd	a5,104(s1)
}
    80001b5c:	8526                	mv	a0,s1
    80001b5e:	60e2                	ld	ra,24(sp)
    80001b60:	6442                	ld	s0,16(sp)
    80001b62:	64a2                	ld	s1,8(sp)
    80001b64:	6902                	ld	s2,0(sp)
    80001b66:	6105                	addi	sp,sp,32
    80001b68:	8082                	ret
    freeproc(p);
    80001b6a:	8526                	mv	a0,s1
    80001b6c:	f29ff0ef          	jal	80001a94 <_ZL8freeprocP4proc>
    release(&p->lock);
    80001b70:	8526                	mv	a0,s1
    80001b72:	8daff0ef          	jal	80000c4c <_Z7releaseP8spinlock>
    return 0;
    80001b76:	84ca                	mv	s1,s2
    80001b78:	b7d5                	j	80001b5c <_ZL9allocprocv+0x78>
    freeproc(p);
    80001b7a:	8526                	mv	a0,s1
    80001b7c:	f19ff0ef          	jal	80001a94 <_ZL8freeprocP4proc>
    release(&p->lock);
    80001b80:	8526                	mv	a0,s1
    80001b82:	8caff0ef          	jal	80000c4c <_Z7releaseP8spinlock>
    return 0;
    80001b86:	84ca                	mv	s1,s2
    80001b88:	bfd1                	j	80001b5c <_ZL9allocprocv+0x78>

0000000080001b8a <_Z8userinitv>:
{
    80001b8a:	1101                	addi	sp,sp,-32
    80001b8c:	ec06                	sd	ra,24(sp)
    80001b8e:	e822                	sd	s0,16(sp)
    80001b90:	e426                	sd	s1,8(sp)
    80001b92:	1000                	addi	s0,sp,32
  p = allocproc();
    80001b94:	f51ff0ef          	jal	80001ae4 <_ZL9allocprocv>
    80001b98:	84aa                	mv	s1,a0
  initproc = p;
    80001b9a:	00006797          	auipc	a5,0x6
    80001b9e:	cca7b323          	sd	a0,-826(a5) # 80007860 <initproc>
  p->cwd = namei("/");
    80001ba2:	00005517          	auipc	a0,0x5
    80001ba6:	5ee50513          	addi	a0,a0,1518 # 80007190 <etext+0x190>
    80001baa:	611010ef          	jal	800039ba <_Z5nameiPKc>
    80001bae:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001bb2:	478d                	li	a5,3
    80001bb4:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001bb6:	8526                	mv	a0,s1
    80001bb8:	894ff0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80001bbc:	60e2                	ld	ra,24(sp)
    80001bbe:	6442                	ld	s0,16(sp)
    80001bc0:	64a2                	ld	s1,8(sp)
    80001bc2:	6105                	addi	sp,sp,32
    80001bc4:	8082                	ret

0000000080001bc6 <_Z8growproci>:
{
    80001bc6:	1101                	addi	sp,sp,-32
    80001bc8:	ec06                	sd	ra,24(sp)
    80001bca:	e822                	sd	s0,16(sp)
    80001bcc:	e426                	sd	s1,8(sp)
    80001bce:	e04a                	sd	s2,0(sp)
    80001bd0:	1000                	addi	s0,sp,32
    80001bd2:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001bd4:	ce7ff0ef          	jal	800018ba <_Z6myprocv>
    80001bd8:	892a                	mv	s2,a0
  sz = p->sz;
    80001bda:	652c                	ld	a1,72(a0)
  if (n > 0) {
    80001bdc:	02905963          	blez	s1,80001c0e <_Z8growproci+0x48>
    if (sz + n > TRAPFRAME) {
    80001be0:	00b48633          	add	a2,s1,a1
    80001be4:	020007b7          	lui	a5,0x2000
    80001be8:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001bea:	07b6                	slli	a5,a5,0xd
    80001bec:	02c7ea63          	bltu	a5,a2,80001c20 <_Z8growproci+0x5a>
    if ((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001bf0:	4691                	li	a3,4
    80001bf2:	6928                	ld	a0,80(a0)
    80001bf4:	e80ff0ef          	jal	80001274 <_Z8uvmallocPmmmi>
    80001bf8:	85aa                	mv	a1,a0
    80001bfa:	c50d                	beqz	a0,80001c24 <_Z8growproci+0x5e>
  p->sz = sz;
    80001bfc:	04b93423          	sd	a1,72(s2)
  return 0;
    80001c00:	4501                	li	a0,0
}
    80001c02:	60e2                	ld	ra,24(sp)
    80001c04:	6442                	ld	s0,16(sp)
    80001c06:	64a2                	ld	s1,8(sp)
    80001c08:	6902                	ld	s2,0(sp)
    80001c0a:	6105                	addi	sp,sp,32
    80001c0c:	8082                	ret
  } else if (n < 0) {
    80001c0e:	fe04d7e3          	bgez	s1,80001bfc <_Z8growproci+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c12:	00b48633          	add	a2,s1,a1
    80001c16:	6928                	ld	a0,80(a0)
    80001c18:	e18ff0ef          	jal	80001230 <_Z10uvmdeallocPmmm>
    80001c1c:	85aa                	mv	a1,a0
    80001c1e:	bff9                	j	80001bfc <_Z8growproci+0x36>
      return -1;
    80001c20:	557d                	li	a0,-1
    80001c22:	b7c5                	j	80001c02 <_Z8growproci+0x3c>
      return -1;
    80001c24:	557d                	li	a0,-1
    80001c26:	bff1                	j	80001c02 <_Z8growproci+0x3c>

0000000080001c28 <_Z5kforkv>:
{
    80001c28:	7139                	addi	sp,sp,-64
    80001c2a:	fc06                	sd	ra,56(sp)
    80001c2c:	f822                	sd	s0,48(sp)
    80001c2e:	f04a                	sd	s2,32(sp)
    80001c30:	e456                	sd	s5,8(sp)
    80001c32:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c34:	c87ff0ef          	jal	800018ba <_Z6myprocv>
    80001c38:	8aaa                	mv	s5,a0
  if ((np = allocproc()) == 0) {
    80001c3a:	eabff0ef          	jal	80001ae4 <_ZL9allocprocv>
    80001c3e:	0e050a63          	beqz	a0,80001d32 <_Z5kforkv+0x10a>
    80001c42:	e852                	sd	s4,16(sp)
    80001c44:	8a2a                	mv	s4,a0
  if (uvmcopy(p->pagetable, np->pagetable, p->sz) < 0) {
    80001c46:	048ab603          	ld	a2,72(s5)
    80001c4a:	692c                	ld	a1,80(a0)
    80001c4c:	050ab503          	ld	a0,80(s5)
    80001c50:	f5cff0ef          	jal	800013ac <_Z7uvmcopyPmS_m>
    80001c54:	04054a63          	bltz	a0,80001ca8 <_Z5kforkv+0x80>
    80001c58:	f426                	sd	s1,40(sp)
    80001c5a:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001c5c:	048ab783          	ld	a5,72(s5)
    80001c60:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001c64:	058ab683          	ld	a3,88(s5)
    80001c68:	87b6                	mv	a5,a3
    80001c6a:	058a3703          	ld	a4,88(s4)
    80001c6e:	12068693          	addi	a3,a3,288
    80001c72:	0007b803          	ld	a6,0(a5)
    80001c76:	6788                	ld	a0,8(a5)
    80001c78:	6b8c                	ld	a1,16(a5)
    80001c7a:	6f90                	ld	a2,24(a5)
    80001c7c:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001c80:	e708                	sd	a0,8(a4)
    80001c82:	eb0c                	sd	a1,16(a4)
    80001c84:	ef10                	sd	a2,24(a4)
    80001c86:	02078793          	addi	a5,a5,32
    80001c8a:	02070713          	addi	a4,a4,32
    80001c8e:	fed792e3          	bne	a5,a3,80001c72 <_Z5kforkv+0x4a>
  np->trapframe->a0 = 0;
    80001c92:	058a3783          	ld	a5,88(s4)
    80001c96:	0607b823          	sd	zero,112(a5)
  for (i = 0; i < NOFILE; i++)
    80001c9a:	0d0a8493          	addi	s1,s5,208
    80001c9e:	0d0a0913          	addi	s2,s4,208
    80001ca2:	150a8993          	addi	s3,s5,336
    80001ca6:	a831                	j	80001cc2 <_Z5kforkv+0x9a>
    freeproc(np);
    80001ca8:	8552                	mv	a0,s4
    80001caa:	debff0ef          	jal	80001a94 <_ZL8freeprocP4proc>
    release(&np->lock);
    80001cae:	8552                	mv	a0,s4
    80001cb0:	f9dfe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
    return -1;
    80001cb4:	597d                	li	s2,-1
    80001cb6:	6a42                	ld	s4,16(sp)
    80001cb8:	a0b5                	j	80001d24 <_Z5kforkv+0xfc>
  for (i = 0; i < NOFILE; i++)
    80001cba:	04a1                	addi	s1,s1,8
    80001cbc:	0921                	addi	s2,s2,8
    80001cbe:	01348963          	beq	s1,s3,80001cd0 <_Z5kforkv+0xa8>
    if (p->ofile[i])
    80001cc2:	6088                	ld	a0,0(s1)
    80001cc4:	d97d                	beqz	a0,80001cba <_Z5kforkv+0x92>
      np->ofile[i] = filedup(p->ofile[i]);
    80001cc6:	328020ef          	jal	80003fee <_Z7filedupP4file>
    80001cca:	00a93023          	sd	a0,0(s2)
    80001cce:	b7f5                	j	80001cba <_Z5kforkv+0x92>
  np->cwd = idup(p->cwd);
    80001cd0:	150ab503          	ld	a0,336(s5)
    80001cd4:	494010ef          	jal	80003168 <_Z4idupP5inode>
    80001cd8:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001cdc:	4641                	li	a2,16
    80001cde:	158a8593          	addi	a1,s5,344
    80001ce2:	158a0513          	addi	a0,s4,344
    80001ce6:	8e0ff0ef          	jal	80000dc6 <_Z10safestrcpyPcPKci>
  pid = np->pid;
    80001cea:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001cee:	8552                	mv	a0,s4
    80001cf0:	f5dfe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  acquire(&wait_lock);
    80001cf4:	0000e497          	auipc	s1,0xe
    80001cf8:	c8c48493          	addi	s1,s1,-884 # 8000f980 <wait_lock>
    80001cfc:	8526                	mv	a0,s1
    80001cfe:	ec3fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  np->parent = p;
    80001d02:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d06:	8526                	mv	a0,s1
    80001d08:	f45fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  acquire(&np->lock);
    80001d0c:	8552                	mv	a0,s4
    80001d0e:	eb3fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  np->state = RUNNABLE;
    80001d12:	478d                	li	a5,3
    80001d14:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d18:	8552                	mv	a0,s4
    80001d1a:	f33fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  return pid;
    80001d1e:	74a2                	ld	s1,40(sp)
    80001d20:	69e2                	ld	s3,24(sp)
    80001d22:	6a42                	ld	s4,16(sp)
}
    80001d24:	854a                	mv	a0,s2
    80001d26:	70e2                	ld	ra,56(sp)
    80001d28:	7442                	ld	s0,48(sp)
    80001d2a:	7902                	ld	s2,32(sp)
    80001d2c:	6aa2                	ld	s5,8(sp)
    80001d2e:	6121                	addi	sp,sp,64
    80001d30:	8082                	ret
    return -1;
    80001d32:	597d                	li	s2,-1
    80001d34:	bfc5                	j	80001d24 <_Z5kforkv+0xfc>

0000000080001d36 <_Z9schedulerv>:
{
    80001d36:	715d                	addi	sp,sp,-80
    80001d38:	e486                	sd	ra,72(sp)
    80001d3a:	e0a2                	sd	s0,64(sp)
    80001d3c:	fc26                	sd	s1,56(sp)
    80001d3e:	f84a                	sd	s2,48(sp)
    80001d40:	f44e                	sd	s3,40(sp)
    80001d42:	f052                	sd	s4,32(sp)
    80001d44:	ec56                	sd	s5,24(sp)
    80001d46:	e85a                	sd	s6,16(sp)
    80001d48:	e45e                	sd	s7,8(sp)
    80001d4a:	e062                	sd	s8,0(sp)
    80001d4c:	0880                	addi	s0,sp,80
    80001d4e:	8792                	mv	a5,tp
  int id = r_tp();
    80001d50:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d52:	00779b13          	slli	s6,a5,0x7
    80001d56:	0000e717          	auipc	a4,0xe
    80001d5a:	c1270713          	addi	a4,a4,-1006 # 8000f968 <pid_lock>
    80001d5e:	975a                	add	a4,a4,s6
    80001d60:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001d64:	0000e717          	auipc	a4,0xe
    80001d68:	c3c70713          	addi	a4,a4,-964 # 8000f9a0 <cpus+0x8>
    80001d6c:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    80001d6e:	4c11                	li	s8,4
        c->proc = p;
    80001d70:	079e                	slli	a5,a5,0x7
    80001d72:	0000ea17          	auipc	s4,0xe
    80001d76:	bf6a0a13          	addi	s4,s4,-1034 # 8000f968 <pid_lock>
    80001d7a:	9a3e                	add	s4,s4,a5
        found = 1;
    80001d7c:	4b85                	li	s7,1
    for (p = proc; p < &proc[NPROC]; p++) {
    80001d7e:	00014997          	auipc	s3,0x14
    80001d82:	a1a98993          	addi	s3,s3,-1510 # 80015798 <tickslock>
    80001d86:	a83d                	j	80001dc4 <_Z9schedulerv+0x8e>
      release(&p->lock);
    80001d88:	8526                	mv	a0,s1
    80001d8a:	ec3fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
    for (p = proc; p < &proc[NPROC]; p++) {
    80001d8e:	16848493          	addi	s1,s1,360
    80001d92:	03348563          	beq	s1,s3,80001dbc <_Z9schedulerv+0x86>
      acquire(&p->lock);
    80001d96:	8526                	mv	a0,s1
    80001d98:	e29fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
      if (p->state == RUNNABLE) {
    80001d9c:	4c9c                	lw	a5,24(s1)
    80001d9e:	ff2795e3          	bne	a5,s2,80001d88 <_Z9schedulerv+0x52>
        p->state = RUNNING;
    80001da2:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001da6:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001daa:	06048593          	addi	a1,s1,96
    80001dae:	855a                	mv	a0,s6
    80001db0:	59e000ef          	jal	8000234e <swtch>
        c->proc = 0;
    80001db4:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001db8:	8ade                	mv	s5,s7
    80001dba:	b7f9                	j	80001d88 <_Z9schedulerv+0x52>
    if (found == 0) {
    80001dbc:	000a9463          	bnez	s5,80001dc4 <_Z9schedulerv+0x8e>
      asm volatile("wfi");
    80001dc0:	10500073          	wfi
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80001dc4:	10016073          	csrsi	sstatus,2
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80001dc8:	10017073          	csrci	sstatus,2
    int found = 0;
    80001dcc:	4a81                	li	s5,0
    for (p = proc; p < &proc[NPROC]; p++) {
    80001dce:	0000e497          	auipc	s1,0xe
    80001dd2:	fca48493          	addi	s1,s1,-54 # 8000fd98 <proc>
      if (p->state == RUNNABLE) {
    80001dd6:	490d                	li	s2,3
    80001dd8:	bf7d                	j	80001d96 <_Z9schedulerv+0x60>

0000000080001dda <_Z5schedv>:
{
    80001dda:	7179                	addi	sp,sp,-48
    80001ddc:	f406                	sd	ra,40(sp)
    80001dde:	f022                	sd	s0,32(sp)
    80001de0:	ec26                	sd	s1,24(sp)
    80001de2:	e84a                	sd	s2,16(sp)
    80001de4:	e44e                	sd	s3,8(sp)
    80001de6:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001de8:	ad3ff0ef          	jal	800018ba <_Z6myprocv>
    80001dec:	84aa                	mv	s1,a0
  if (!holding(&p->lock))
    80001dee:	d73fe0ef          	jal	80000b60 <_Z7holdingPK8spinlock>
    80001df2:	c92d                	beqz	a0,80001e64 <_Z5schedv+0x8a>
  asm volatile("mv %0, tp" : "=r"(x));
    80001df4:	8792                	mv	a5,tp
  if (mycpu()->noff != 1)
    80001df6:	2781                	sext.w	a5,a5
    80001df8:	079e                	slli	a5,a5,0x7
    80001dfa:	0000e717          	auipc	a4,0xe
    80001dfe:	b6e70713          	addi	a4,a4,-1170 # 8000f968 <pid_lock>
    80001e02:	97ba                	add	a5,a5,a4
    80001e04:	0a87a703          	lw	a4,168(a5)
    80001e08:	4785                	li	a5,1
    80001e0a:	06f71363          	bne	a4,a5,80001e70 <_Z5schedv+0x96>
  if (p->state == RUNNING)
    80001e0e:	4c98                	lw	a4,24(s1)
    80001e10:	4791                	li	a5,4
    80001e12:	06f70563          	beq	a4,a5,80001e7c <_Z5schedv+0xa2>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80001e16:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e1a:	8b89                	andi	a5,a5,2
  if (intr_get())
    80001e1c:	e7b5                	bnez	a5,80001e88 <_Z5schedv+0xae>
  asm volatile("mv %0, tp" : "=r"(x));
    80001e1e:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e20:	0000e917          	auipc	s2,0xe
    80001e24:	b4890913          	addi	s2,s2,-1208 # 8000f968 <pid_lock>
    80001e28:	2781                	sext.w	a5,a5
    80001e2a:	079e                	slli	a5,a5,0x7
    80001e2c:	97ca                	add	a5,a5,s2
    80001e2e:	0ac7a983          	lw	s3,172(a5)
    80001e32:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e34:	2781                	sext.w	a5,a5
    80001e36:	079e                	slli	a5,a5,0x7
    80001e38:	0000e597          	auipc	a1,0xe
    80001e3c:	b6858593          	addi	a1,a1,-1176 # 8000f9a0 <cpus+0x8>
    80001e40:	95be                	add	a1,a1,a5
    80001e42:	06048513          	addi	a0,s1,96
    80001e46:	508000ef          	jal	8000234e <swtch>
    80001e4a:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001e4c:	2781                	sext.w	a5,a5
    80001e4e:	079e                	slli	a5,a5,0x7
    80001e50:	993e                	add	s2,s2,a5
    80001e52:	0b392623          	sw	s3,172(s2)
}
    80001e56:	70a2                	ld	ra,40(sp)
    80001e58:	7402                	ld	s0,32(sp)
    80001e5a:	64e2                	ld	s1,24(sp)
    80001e5c:	6942                	ld	s2,16(sp)
    80001e5e:	69a2                	ld	s3,8(sp)
    80001e60:	6145                	addi	sp,sp,48
    80001e62:	8082                	ret
    panic("sched p->lock");
    80001e64:	00005517          	auipc	a0,0x5
    80001e68:	33450513          	addi	a0,a0,820 # 80007198 <etext+0x198>
    80001e6c:	987fe0ef          	jal	800007f2 <_Z5panicPKc>
    panic("sched locks");
    80001e70:	00005517          	auipc	a0,0x5
    80001e74:	33850513          	addi	a0,a0,824 # 800071a8 <etext+0x1a8>
    80001e78:	97bfe0ef          	jal	800007f2 <_Z5panicPKc>
    panic("sched RUNNING");
    80001e7c:	00005517          	auipc	a0,0x5
    80001e80:	33c50513          	addi	a0,a0,828 # 800071b8 <etext+0x1b8>
    80001e84:	96ffe0ef          	jal	800007f2 <_Z5panicPKc>
    panic("sched interruptible");
    80001e88:	00005517          	auipc	a0,0x5
    80001e8c:	34050513          	addi	a0,a0,832 # 800071c8 <etext+0x1c8>
    80001e90:	963fe0ef          	jal	800007f2 <_Z5panicPKc>

0000000080001e94 <_Z5yieldv>:
{
    80001e94:	1101                	addi	sp,sp,-32
    80001e96:	ec06                	sd	ra,24(sp)
    80001e98:	e822                	sd	s0,16(sp)
    80001e9a:	e426                	sd	s1,8(sp)
    80001e9c:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001e9e:	a1dff0ef          	jal	800018ba <_Z6myprocv>
    80001ea2:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001ea4:	d1dfe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  p->state = RUNNABLE;
    80001ea8:	478d                	li	a5,3
    80001eaa:	cc9c                	sw	a5,24(s1)
  sched();
    80001eac:	f2fff0ef          	jal	80001dda <_Z5schedv>
  release(&p->lock);
    80001eb0:	8526                	mv	a0,s1
    80001eb2:	d9bfe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80001eb6:	60e2                	ld	ra,24(sp)
    80001eb8:	6442                	ld	s0,16(sp)
    80001eba:	64a2                	ld	s1,8(sp)
    80001ebc:	6105                	addi	sp,sp,32
    80001ebe:	8082                	ret

0000000080001ec0 <_Z5sleepPvP8spinlock>:

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001ec0:	7179                	addi	sp,sp,-48
    80001ec2:	f406                	sd	ra,40(sp)
    80001ec4:	f022                	sd	s0,32(sp)
    80001ec6:	ec26                	sd	s1,24(sp)
    80001ec8:	e84a                	sd	s2,16(sp)
    80001eca:	e44e                	sd	s3,8(sp)
    80001ecc:	1800                	addi	s0,sp,48
    80001ece:	89aa                	mv	s3,a0
    80001ed0:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001ed2:	9e9ff0ef          	jal	800018ba <_Z6myprocv>
    80001ed6:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock); //DOC: sleeplock1
    80001ed8:	ce9fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  release(lk);
    80001edc:	854a                	mv	a0,s2
    80001ede:	d6ffe0ef          	jal	80000c4c <_Z7releaseP8spinlock>

  // Go to sleep.
  p->chan = chan;
    80001ee2:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001ee6:	4789                	li	a5,2
    80001ee8:	cc9c                	sw	a5,24(s1)

  sched();
    80001eea:	ef1ff0ef          	jal	80001dda <_Z5schedv>

  // Tidy up.
  p->chan = 0;
    80001eee:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001ef2:	8526                	mv	a0,s1
    80001ef4:	d59fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  acquire(lk);
    80001ef8:	854a                	mv	a0,s2
    80001efa:	cc7fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
}
    80001efe:	70a2                	ld	ra,40(sp)
    80001f00:	7402                	ld	s0,32(sp)
    80001f02:	64e2                	ld	s1,24(sp)
    80001f04:	6942                	ld	s2,16(sp)
    80001f06:	69a2                	ld	s3,8(sp)
    80001f08:	6145                	addi	sp,sp,48
    80001f0a:	8082                	ret

0000000080001f0c <_Z6wakeupPv>:

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80001f0c:	7139                	addi	sp,sp,-64
    80001f0e:	fc06                	sd	ra,56(sp)
    80001f10:	f822                	sd	s0,48(sp)
    80001f12:	f426                	sd	s1,40(sp)
    80001f14:	f04a                	sd	s2,32(sp)
    80001f16:	ec4e                	sd	s3,24(sp)
    80001f18:	e852                	sd	s4,16(sp)
    80001f1a:	e456                	sd	s5,8(sp)
    80001f1c:	0080                	addi	s0,sp,64
    80001f1e:	8a2a                	mv	s4,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80001f20:	0000e497          	auipc	s1,0xe
    80001f24:	e7848493          	addi	s1,s1,-392 # 8000fd98 <proc>
    if (p != myproc()) {
      acquire(&p->lock);
      if (p->state == SLEEPING && p->chan == chan) {
    80001f28:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001f2a:	4a8d                	li	s5,3
  for (p = proc; p < &proc[NPROC]; p++) {
    80001f2c:	00014917          	auipc	s2,0x14
    80001f30:	86c90913          	addi	s2,s2,-1940 # 80015798 <tickslock>
    80001f34:	a801                	j	80001f44 <_Z6wakeupPv+0x38>
      }
      release(&p->lock);
    80001f36:	8526                	mv	a0,s1
    80001f38:	d15fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001f3c:	16848493          	addi	s1,s1,360
    80001f40:	03248263          	beq	s1,s2,80001f64 <_Z6wakeupPv+0x58>
    if (p != myproc()) {
    80001f44:	977ff0ef          	jal	800018ba <_Z6myprocv>
    80001f48:	fea48ae3          	beq	s1,a0,80001f3c <_Z6wakeupPv+0x30>
      acquire(&p->lock);
    80001f4c:	8526                	mv	a0,s1
    80001f4e:	c73fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
      if (p->state == SLEEPING && p->chan == chan) {
    80001f52:	4c9c                	lw	a5,24(s1)
    80001f54:	ff3791e3          	bne	a5,s3,80001f36 <_Z6wakeupPv+0x2a>
    80001f58:	709c                	ld	a5,32(s1)
    80001f5a:	fd479ee3          	bne	a5,s4,80001f36 <_Z6wakeupPv+0x2a>
        p->state = RUNNABLE;
    80001f5e:	0154ac23          	sw	s5,24(s1)
    80001f62:	bfd1                	j	80001f36 <_Z6wakeupPv+0x2a>
    }
  }
}
    80001f64:	70e2                	ld	ra,56(sp)
    80001f66:	7442                	ld	s0,48(sp)
    80001f68:	74a2                	ld	s1,40(sp)
    80001f6a:	7902                	ld	s2,32(sp)
    80001f6c:	69e2                	ld	s3,24(sp)
    80001f6e:	6a42                	ld	s4,16(sp)
    80001f70:	6aa2                	ld	s5,8(sp)
    80001f72:	6121                	addi	sp,sp,64
    80001f74:	8082                	ret

0000000080001f76 <_Z8reparentP4proc>:
{
    80001f76:	7179                	addi	sp,sp,-48
    80001f78:	f406                	sd	ra,40(sp)
    80001f7a:	f022                	sd	s0,32(sp)
    80001f7c:	ec26                	sd	s1,24(sp)
    80001f7e:	e84a                	sd	s2,16(sp)
    80001f80:	e44e                	sd	s3,8(sp)
    80001f82:	e052                	sd	s4,0(sp)
    80001f84:	1800                	addi	s0,sp,48
    80001f86:	892a                	mv	s2,a0
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    80001f88:	0000e497          	auipc	s1,0xe
    80001f8c:	e1048493          	addi	s1,s1,-496 # 8000fd98 <proc>
      pp->parent = initproc;
    80001f90:	00006a17          	auipc	s4,0x6
    80001f94:	8d0a0a13          	addi	s4,s4,-1840 # 80007860 <initproc>
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    80001f98:	00014997          	auipc	s3,0x14
    80001f9c:	80098993          	addi	s3,s3,-2048 # 80015798 <tickslock>
    80001fa0:	a029                	j	80001faa <_Z8reparentP4proc+0x34>
    80001fa2:	16848493          	addi	s1,s1,360
    80001fa6:	01348b63          	beq	s1,s3,80001fbc <_Z8reparentP4proc+0x46>
    if (pp->parent == p) {
    80001faa:	7c9c                	ld	a5,56(s1)
    80001fac:	ff279be3          	bne	a5,s2,80001fa2 <_Z8reparentP4proc+0x2c>
      pp->parent = initproc;
    80001fb0:	000a3503          	ld	a0,0(s4)
    80001fb4:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001fb6:	f57ff0ef          	jal	80001f0c <_Z6wakeupPv>
    80001fba:	b7e5                	j	80001fa2 <_Z8reparentP4proc+0x2c>
}
    80001fbc:	70a2                	ld	ra,40(sp)
    80001fbe:	7402                	ld	s0,32(sp)
    80001fc0:	64e2                	ld	s1,24(sp)
    80001fc2:	6942                	ld	s2,16(sp)
    80001fc4:	69a2                	ld	s3,8(sp)
    80001fc6:	6a02                	ld	s4,0(sp)
    80001fc8:	6145                	addi	sp,sp,48
    80001fca:	8082                	ret

0000000080001fcc <_Z5kexiti>:
{
    80001fcc:	7179                	addi	sp,sp,-48
    80001fce:	f406                	sd	ra,40(sp)
    80001fd0:	f022                	sd	s0,32(sp)
    80001fd2:	ec26                	sd	s1,24(sp)
    80001fd4:	e84a                	sd	s2,16(sp)
    80001fd6:	e44e                	sd	s3,8(sp)
    80001fd8:	e052                	sd	s4,0(sp)
    80001fda:	1800                	addi	s0,sp,48
    80001fdc:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80001fde:	8ddff0ef          	jal	800018ba <_Z6myprocv>
    80001fe2:	89aa                	mv	s3,a0
  if (p == initproc)
    80001fe4:	00006797          	auipc	a5,0x6
    80001fe8:	87c7b783          	ld	a5,-1924(a5) # 80007860 <initproc>
    80001fec:	0d050493          	addi	s1,a0,208
    80001ff0:	15050913          	addi	s2,a0,336
    80001ff4:	00a79f63          	bne	a5,a0,80002012 <_Z5kexiti+0x46>
    panic("init exiting");
    80001ff8:	00005517          	auipc	a0,0x5
    80001ffc:	1e850513          	addi	a0,a0,488 # 800071e0 <etext+0x1e0>
    80002000:	ff2fe0ef          	jal	800007f2 <_Z5panicPKc>
      fileclose(f);
    80002004:	030020ef          	jal	80004034 <_Z9filecloseP4file>
      p->ofile[fd] = 0;
    80002008:	0004b023          	sd	zero,0(s1)
  for (int fd = 0; fd < NOFILE; fd++) {
    8000200c:	04a1                	addi	s1,s1,8
    8000200e:	01248563          	beq	s1,s2,80002018 <_Z5kexiti+0x4c>
    if (p->ofile[fd]) {
    80002012:	6088                	ld	a0,0(s1)
    80002014:	f965                	bnez	a0,80002004 <_Z5kexiti+0x38>
    80002016:	bfdd                	j	8000200c <_Z5kexiti+0x40>
  begin_op();
    80002018:	3a9010ef          	jal	80003bc0 <_Z8begin_opv>
  iput(p->cwd);
    8000201c:	1509b503          	ld	a0,336(s3)
    80002020:	300010ef          	jal	80003320 <_Z4iputP5inode>
  end_op();
    80002024:	407010ef          	jal	80003c2a <_Z6end_opv>
  p->cwd = 0;
    80002028:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000202c:	0000e497          	auipc	s1,0xe
    80002030:	95448493          	addi	s1,s1,-1708 # 8000f980 <wait_lock>
    80002034:	8526                	mv	a0,s1
    80002036:	b8bfe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  reparent(p);
    8000203a:	854e                	mv	a0,s3
    8000203c:	f3bff0ef          	jal	80001f76 <_Z8reparentP4proc>
  wakeup(p->parent);
    80002040:	0389b503          	ld	a0,56(s3)
    80002044:	ec9ff0ef          	jal	80001f0c <_Z6wakeupPv>
  acquire(&p->lock);
    80002048:	854e                	mv	a0,s3
    8000204a:	b77fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  p->xstate = status;
    8000204e:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80002052:	4795                	li	a5,5
    80002054:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80002058:	8526                	mv	a0,s1
    8000205a:	bf3fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  sched();
    8000205e:	d7dff0ef          	jal	80001dda <_Z5schedv>
  panic("zombie exit");
    80002062:	00005517          	auipc	a0,0x5
    80002066:	18e50513          	addi	a0,a0,398 # 800071f0 <etext+0x1f0>
    8000206a:	f88fe0ef          	jal	800007f2 <_Z5panicPKc>

000000008000206e <_Z5kkilli>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    8000206e:	7179                	addi	sp,sp,-48
    80002070:	f406                	sd	ra,40(sp)
    80002072:	f022                	sd	s0,32(sp)
    80002074:	ec26                	sd	s1,24(sp)
    80002076:	e84a                	sd	s2,16(sp)
    80002078:	e44e                	sd	s3,8(sp)
    8000207a:	1800                	addi	s0,sp,48
    8000207c:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    8000207e:	0000e497          	auipc	s1,0xe
    80002082:	d1a48493          	addi	s1,s1,-742 # 8000fd98 <proc>
    80002086:	00013997          	auipc	s3,0x13
    8000208a:	71298993          	addi	s3,s3,1810 # 80015798 <tickslock>
    acquire(&p->lock);
    8000208e:	8526                	mv	a0,s1
    80002090:	b31fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
    if (p->pid == pid) {
    80002094:	589c                	lw	a5,48(s1)
    80002096:	01278b63          	beq	a5,s2,800020ac <_Z5kkilli+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    8000209a:	8526                	mv	a0,s1
    8000209c:	bb1fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  for (p = proc; p < &proc[NPROC]; p++) {
    800020a0:	16848493          	addi	s1,s1,360
    800020a4:	ff3495e3          	bne	s1,s3,8000208e <_Z5kkilli+0x20>
  }
  return -1;
    800020a8:	557d                	li	a0,-1
    800020aa:	a819                	j	800020c0 <_Z5kkilli+0x52>
      p->killed = 1;
    800020ac:	4785                	li	a5,1
    800020ae:	d49c                	sw	a5,40(s1)
      if (p->state == SLEEPING) {
    800020b0:	4c98                	lw	a4,24(s1)
    800020b2:	4789                	li	a5,2
    800020b4:	00f70d63          	beq	a4,a5,800020ce <_Z5kkilli+0x60>
      release(&p->lock);
    800020b8:	8526                	mv	a0,s1
    800020ba:	b93fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
      return 0;
    800020be:	4501                	li	a0,0
}
    800020c0:	70a2                	ld	ra,40(sp)
    800020c2:	7402                	ld	s0,32(sp)
    800020c4:	64e2                	ld	s1,24(sp)
    800020c6:	6942                	ld	s2,16(sp)
    800020c8:	69a2                	ld	s3,8(sp)
    800020ca:	6145                	addi	sp,sp,48
    800020cc:	8082                	ret
        p->state = RUNNABLE;
    800020ce:	478d                	li	a5,3
    800020d0:	cc9c                	sw	a5,24(s1)
    800020d2:	b7dd                	j	800020b8 <_Z5kkilli+0x4a>

00000000800020d4 <_Z9setkilledP4proc>:

void
setkilled(struct proc *p)
{
    800020d4:	1101                	addi	sp,sp,-32
    800020d6:	ec06                	sd	ra,24(sp)
    800020d8:	e822                	sd	s0,16(sp)
    800020da:	e426                	sd	s1,8(sp)
    800020dc:	1000                	addi	s0,sp,32
    800020de:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800020e0:	ae1fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  p->killed = 1;
    800020e4:	4785                	li	a5,1
    800020e6:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800020e8:	8526                	mv	a0,s1
    800020ea:	b63fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    800020ee:	60e2                	ld	ra,24(sp)
    800020f0:	6442                	ld	s0,16(sp)
    800020f2:	64a2                	ld	s1,8(sp)
    800020f4:	6105                	addi	sp,sp,32
    800020f6:	8082                	ret

00000000800020f8 <_Z6killedP4proc>:

int
killed(struct proc *p)
{
    800020f8:	1101                	addi	sp,sp,-32
    800020fa:	ec06                	sd	ra,24(sp)
    800020fc:	e822                	sd	s0,16(sp)
    800020fe:	e426                	sd	s1,8(sp)
    80002100:	e04a                	sd	s2,0(sp)
    80002102:	1000                	addi	s0,sp,32
    80002104:	84aa                	mv	s1,a0
  int k;

  acquire(&p->lock);
    80002106:	abbfe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  k = p->killed;
    8000210a:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    8000210e:	8526                	mv	a0,s1
    80002110:	b3dfe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  return k;
}
    80002114:	854a                	mv	a0,s2
    80002116:	60e2                	ld	ra,24(sp)
    80002118:	6442                	ld	s0,16(sp)
    8000211a:	64a2                	ld	s1,8(sp)
    8000211c:	6902                	ld	s2,0(sp)
    8000211e:	6105                	addi	sp,sp,32
    80002120:	8082                	ret

0000000080002122 <_Z5kwaitm>:
{
    80002122:	715d                	addi	sp,sp,-80
    80002124:	e486                	sd	ra,72(sp)
    80002126:	e0a2                	sd	s0,64(sp)
    80002128:	fc26                	sd	s1,56(sp)
    8000212a:	f84a                	sd	s2,48(sp)
    8000212c:	f44e                	sd	s3,40(sp)
    8000212e:	f052                	sd	s4,32(sp)
    80002130:	ec56                	sd	s5,24(sp)
    80002132:	e85a                	sd	s6,16(sp)
    80002134:	e45e                	sd	s7,8(sp)
    80002136:	e062                	sd	s8,0(sp)
    80002138:	0880                	addi	s0,sp,80
    8000213a:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    8000213c:	f7eff0ef          	jal	800018ba <_Z6myprocv>
    80002140:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002142:	0000e517          	auipc	a0,0xe
    80002146:	83e50513          	addi	a0,a0,-1986 # 8000f980 <wait_lock>
    8000214a:	a77fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
    havekids = 0;
    8000214e:	4b81                	li	s7,0
        if (pp->state == ZOMBIE) {
    80002150:	4a15                	li	s4,5
        havekids = 1;
    80002152:	4a85                	li	s5,1
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002154:	00013997          	auipc	s3,0x13
    80002158:	64498993          	addi	s3,s3,1604 # 80015798 <tickslock>
    sleep(p, &wait_lock); //DOC: wait-sleep
    8000215c:	0000ec17          	auipc	s8,0xe
    80002160:	824c0c13          	addi	s8,s8,-2012 # 8000f980 <wait_lock>
    80002164:	a871                	j	80002200 <_Z5kwaitm+0xde>
          pid = pp->pid;
    80002166:	0304a983          	lw	s3,48(s1)
          if (addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    8000216a:	000b0c63          	beqz	s6,80002182 <_Z5kwaitm+0x60>
    8000216e:	4691                	li	a3,4
    80002170:	02c48613          	addi	a2,s1,44
    80002174:	85da                	mv	a1,s6
    80002176:	05093503          	ld	a0,80(s2)
    8000217a:	c54ff0ef          	jal	800015ce <_Z7copyoutPmmPKcm>
    8000217e:	02054b63          	bltz	a0,800021b4 <_Z5kwaitm+0x92>
          freeproc(pp);
    80002182:	8526                	mv	a0,s1
    80002184:	911ff0ef          	jal	80001a94 <_ZL8freeprocP4proc>
          release(&pp->lock);
    80002188:	8526                	mv	a0,s1
    8000218a:	ac3fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
          release(&wait_lock);
    8000218e:	0000d517          	auipc	a0,0xd
    80002192:	7f250513          	addi	a0,a0,2034 # 8000f980 <wait_lock>
    80002196:	ab7fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    8000219a:	854e                	mv	a0,s3
    8000219c:	60a6                	ld	ra,72(sp)
    8000219e:	6406                	ld	s0,64(sp)
    800021a0:	74e2                	ld	s1,56(sp)
    800021a2:	7942                	ld	s2,48(sp)
    800021a4:	79a2                	ld	s3,40(sp)
    800021a6:	7a02                	ld	s4,32(sp)
    800021a8:	6ae2                	ld	s5,24(sp)
    800021aa:	6b42                	ld	s6,16(sp)
    800021ac:	6ba2                	ld	s7,8(sp)
    800021ae:	6c02                	ld	s8,0(sp)
    800021b0:	6161                	addi	sp,sp,80
    800021b2:	8082                	ret
            release(&pp->lock);
    800021b4:	8526                	mv	a0,s1
    800021b6:	a97fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
            release(&wait_lock);
    800021ba:	0000d517          	auipc	a0,0xd
    800021be:	7c650513          	addi	a0,a0,1990 # 8000f980 <wait_lock>
    800021c2:	a8bfe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
            return -1;
    800021c6:	59fd                	li	s3,-1
    800021c8:	bfc9                	j	8000219a <_Z5kwaitm+0x78>
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    800021ca:	16848493          	addi	s1,s1,360
    800021ce:	03348063          	beq	s1,s3,800021ee <_Z5kwaitm+0xcc>
      if (pp->parent == p) {
    800021d2:	7c9c                	ld	a5,56(s1)
    800021d4:	ff279be3          	bne	a5,s2,800021ca <_Z5kwaitm+0xa8>
        acquire(&pp->lock);
    800021d8:	8526                	mv	a0,s1
    800021da:	9e7fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
        if (pp->state == ZOMBIE) {
    800021de:	4c9c                	lw	a5,24(s1)
    800021e0:	f94783e3          	beq	a5,s4,80002166 <_Z5kwaitm+0x44>
        release(&pp->lock);
    800021e4:	8526                	mv	a0,s1
    800021e6:	a67fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
        havekids = 1;
    800021ea:	8756                	mv	a4,s5
    800021ec:	bff9                	j	800021ca <_Z5kwaitm+0xa8>
    if (!havekids || killed(p)) {
    800021ee:	cf19                	beqz	a4,8000220c <_Z5kwaitm+0xea>
    800021f0:	854a                	mv	a0,s2
    800021f2:	f07ff0ef          	jal	800020f8 <_Z6killedP4proc>
    800021f6:	e919                	bnez	a0,8000220c <_Z5kwaitm+0xea>
    sleep(p, &wait_lock); //DOC: wait-sleep
    800021f8:	85e2                	mv	a1,s8
    800021fa:	854a                	mv	a0,s2
    800021fc:	cc5ff0ef          	jal	80001ec0 <_Z5sleepPvP8spinlock>
    havekids = 0;
    80002200:	875e                	mv	a4,s7
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002202:	0000e497          	auipc	s1,0xe
    80002206:	b9648493          	addi	s1,s1,-1130 # 8000fd98 <proc>
    8000220a:	b7e1                	j	800021d2 <_Z5kwaitm+0xb0>
      release(&wait_lock);
    8000220c:	0000d517          	auipc	a0,0xd
    80002210:	77450513          	addi	a0,a0,1908 # 8000f980 <wait_lock>
    80002214:	a39fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
      return -1;
    80002218:	59fd                	li	s3,-1
    8000221a:	b741                	j	8000219a <_Z5kwaitm+0x78>

000000008000221c <_Z14either_copyoutimPKvm>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, const void *src, uint64 len)
{
    8000221c:	7179                	addi	sp,sp,-48
    8000221e:	f406                	sd	ra,40(sp)
    80002220:	f022                	sd	s0,32(sp)
    80002222:	ec26                	sd	s1,24(sp)
    80002224:	e84a                	sd	s2,16(sp)
    80002226:	e44e                	sd	s3,8(sp)
    80002228:	e052                	sd	s4,0(sp)
    8000222a:	1800                	addi	s0,sp,48
    8000222c:	84aa                	mv	s1,a0
    8000222e:	892e                	mv	s2,a1
    80002230:	89b2                	mv	s3,a2
    80002232:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002234:	e86ff0ef          	jal	800018ba <_Z6myprocv>
  if (user_dst) {
    80002238:	cc99                	beqz	s1,80002256 <_Z14either_copyoutimPKvm+0x3a>
    return copyout(p->pagetable, dst, static_cast<const char*>(src), len);
    8000223a:	86d2                	mv	a3,s4
    8000223c:	864e                	mv	a2,s3
    8000223e:	85ca                	mv	a1,s2
    80002240:	6928                	ld	a0,80(a0)
    80002242:	b8cff0ef          	jal	800015ce <_Z7copyoutPmmPKcm>
  } else {
    memmove(reinterpret_cast<char*>(dst), static_cast<const char*>(src), len);
    return 0;
  }
}
    80002246:	70a2                	ld	ra,40(sp)
    80002248:	7402                	ld	s0,32(sp)
    8000224a:	64e2                	ld	s1,24(sp)
    8000224c:	6942                	ld	s2,16(sp)
    8000224e:	69a2                	ld	s3,8(sp)
    80002250:	6a02                	ld	s4,0(sp)
    80002252:	6145                	addi	sp,sp,48
    80002254:	8082                	ret
    memmove(reinterpret_cast<char*>(dst), static_cast<const char*>(src), len);
    80002256:	000a061b          	sext.w	a2,s4
    8000225a:	85ce                	mv	a1,s3
    8000225c:	854a                	mv	a0,s2
    8000225e:	a83fe0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
    return 0;
    80002262:	8526                	mv	a0,s1
    80002264:	b7cd                	j	80002246 <_Z14either_copyoutimPKvm+0x2a>

0000000080002266 <_Z13either_copyinPvimm>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80002266:	7179                	addi	sp,sp,-48
    80002268:	f406                	sd	ra,40(sp)
    8000226a:	f022                	sd	s0,32(sp)
    8000226c:	ec26                	sd	s1,24(sp)
    8000226e:	e84a                	sd	s2,16(sp)
    80002270:	e44e                	sd	s3,8(sp)
    80002272:	e052                	sd	s4,0(sp)
    80002274:	1800                	addi	s0,sp,48
    80002276:	892a                	mv	s2,a0
    80002278:	84ae                	mv	s1,a1
    8000227a:	89b2                	mv	s3,a2
    8000227c:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    8000227e:	e3cff0ef          	jal	800018ba <_Z6myprocv>
  if (user_src) {
    80002282:	cc99                	beqz	s1,800022a0 <_Z13either_copyinPvimm+0x3a>
    return copyin(p->pagetable, static_cast<char*>(dst), src, len);
    80002284:	86d2                	mv	a3,s4
    80002286:	864e                	mv	a2,s3
    80002288:	85ca                	mv	a1,s2
    8000228a:	6928                	ld	a0,80(a0)
    8000228c:	c26ff0ef          	jal	800016b2 <_Z6copyinPmPcmm>
  } else {
    memmove(dst, reinterpret_cast<const void*>(src), len);
    return 0;
  }
}
    80002290:	70a2                	ld	ra,40(sp)
    80002292:	7402                	ld	s0,32(sp)
    80002294:	64e2                	ld	s1,24(sp)
    80002296:	6942                	ld	s2,16(sp)
    80002298:	69a2                	ld	s3,8(sp)
    8000229a:	6a02                	ld	s4,0(sp)
    8000229c:	6145                	addi	sp,sp,48
    8000229e:	8082                	ret
    memmove(dst, reinterpret_cast<const void*>(src), len);
    800022a0:	000a061b          	sext.w	a2,s4
    800022a4:	85ce                	mv	a1,s3
    800022a6:	854a                	mv	a0,s2
    800022a8:	a39fe0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
    return 0;
    800022ac:	8526                	mv	a0,s1
    800022ae:	b7cd                	j	80002290 <_Z13either_copyinPvimm+0x2a>

00000000800022b0 <_Z8procdumpv>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800022b0:	715d                	addi	sp,sp,-80
    800022b2:	e486                	sd	ra,72(sp)
    800022b4:	e0a2                	sd	s0,64(sp)
    800022b6:	fc26                	sd	s1,56(sp)
    800022b8:	f84a                	sd	s2,48(sp)
    800022ba:	f44e                	sd	s3,40(sp)
    800022bc:	f052                	sd	s4,32(sp)
    800022be:	ec56                	sd	s5,24(sp)
    800022c0:	e85a                	sd	s6,16(sp)
    800022c2:	e45e                	sd	s7,8(sp)
    800022c4:	0880                	addi	s0,sp,80
    // clang-format on
  };
  struct proc *p;
  const char *state;

  printk("\n");
    800022c6:	00005517          	auipc	a0,0x5
    800022ca:	db250513          	addi	a0,a0,-590 # 80007078 <etext+0x78>
    800022ce:	a24fe0ef          	jal	800004f2 <_Z6printkPKcz>
  for (p = proc; p < &proc[NPROC]; p++) {
    800022d2:	0000e497          	auipc	s1,0xe
    800022d6:	c1e48493          	addi	s1,s1,-994 # 8000fef0 <proc+0x158>
    800022da:	00013917          	auipc	s2,0x13
    800022de:	61690913          	addi	s2,s2,1558 # 800158f0 <bcache+0x140>
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800022e2:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800022e4:	00005997          	auipc	s3,0x5
    800022e8:	f1c98993          	addi	s3,s3,-228 # 80007200 <etext+0x200>
    printk("%d %s %s", p->pid, state, p->name);
    800022ec:	00005a97          	auipc	s5,0x5
    800022f0:	f1ca8a93          	addi	s5,s5,-228 # 80007208 <etext+0x208>
    printk("\n");
    800022f4:	00005a17          	auipc	s4,0x5
    800022f8:	d84a0a13          	addi	s4,s4,-636 # 80007078 <etext+0x78>
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800022fc:	00005b97          	auipc	s7,0x5
    80002300:	42cb8b93          	addi	s7,s7,1068 # 80007728 <_ZZ8procdumpvE6states>
    80002304:	a829                	j	8000231e <_Z8procdumpv+0x6e>
    printk("%d %s %s", p->pid, state, p->name);
    80002306:	ed86a583          	lw	a1,-296(a3)
    8000230a:	8556                	mv	a0,s5
    8000230c:	9e6fe0ef          	jal	800004f2 <_Z6printkPKcz>
    printk("\n");
    80002310:	8552                	mv	a0,s4
    80002312:	9e0fe0ef          	jal	800004f2 <_Z6printkPKcz>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002316:	16848493          	addi	s1,s1,360
    8000231a:	01248f63          	beq	s1,s2,80002338 <_Z8procdumpv+0x88>
    if (p->state == UNUSED)
    8000231e:	86a6                	mv	a3,s1
    80002320:	ec04a783          	lw	a5,-320(s1)
    80002324:	dbed                	beqz	a5,80002316 <_Z8procdumpv+0x66>
      state = "???";
    80002326:	864e                	mv	a2,s3
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002328:	fcfb6fe3          	bltu	s6,a5,80002306 <_Z8procdumpv+0x56>
    8000232c:	078e                	slli	a5,a5,0x3
    8000232e:	97de                	add	a5,a5,s7
    80002330:	6390                	ld	a2,0(a5)
    80002332:	fa71                	bnez	a2,80002306 <_Z8procdumpv+0x56>
      state = "???";
    80002334:	864e                	mv	a2,s3
    80002336:	bfc1                	j	80002306 <_Z8procdumpv+0x56>
  }
}
    80002338:	60a6                	ld	ra,72(sp)
    8000233a:	6406                	ld	s0,64(sp)
    8000233c:	74e2                	ld	s1,56(sp)
    8000233e:	7942                	ld	s2,48(sp)
    80002340:	79a2                	ld	s3,40(sp)
    80002342:	7a02                	ld	s4,32(sp)
    80002344:	6ae2                	ld	s5,24(sp)
    80002346:	6b42                	ld	s6,16(sp)
    80002348:	6ba2                	ld	s7,8(sp)
    8000234a:	6161                	addi	sp,sp,80
    8000234c:	8082                	ret

000000008000234e <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    8000234e:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    80002352:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    80002356:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    80002358:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    8000235a:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    8000235e:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    80002362:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    80002366:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    8000236a:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    8000236e:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    80002372:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    80002376:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    8000237a:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    8000237e:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    80002382:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    80002386:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    8000238a:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    8000238c:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    8000238e:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    80002392:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    80002396:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    8000239a:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    8000239e:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    800023a2:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    800023a6:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    800023aa:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    800023ae:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    800023b2:	0685bd83          	ld	s11,104(a1)
        
        ret
    800023b6:	8082                	ret

00000000800023b8 <_Z8trapinitv>:

extern int devintr();

void
trapinit(void)
{
    800023b8:	1141                	addi	sp,sp,-16
    800023ba:	e406                	sd	ra,8(sp)
    800023bc:	e022                	sd	s0,0(sp)
    800023be:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800023c0:	00005597          	auipc	a1,0x5
    800023c4:	e8858593          	addi	a1,a1,-376 # 80007248 <etext+0x248>
    800023c8:	00013517          	auipc	a0,0x13
    800023cc:	3d050513          	addi	a0,a0,976 # 80015798 <tickslock>
    800023d0:	f7afe0ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>
}
    800023d4:	60a2                	ld	ra,8(sp)
    800023d6:	6402                	ld	s0,0(sp)
    800023d8:	0141                	addi	sp,sp,16
    800023da:	8082                	ret

00000000800023dc <_Z12trapinithartv>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    800023dc:	1141                	addi	sp,sp,-16
    800023de:	e422                	sd	s0,8(sp)
    800023e0:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r"(x));
    800023e2:	00003797          	auipc	a5,0x3
    800023e6:	f6e78793          	addi	a5,a5,-146 # 80005350 <kernelvec>
    800023ea:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800023ee:	6422                	ld	s0,8(sp)
    800023f0:	0141                	addi	sp,sp,16
    800023f2:	8082                	ret

00000000800023f4 <_Z14prepare_returnv>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    800023f4:	1141                	addi	sp,sp,-16
    800023f6:	e406                	sd	ra,8(sp)
    800023f8:	e022                	sd	s0,0(sp)
    800023fa:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    800023fc:	cbeff0ef          	jal	800018ba <_Z6myprocv>
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80002400:	10017073          	csrci	sstatus,2
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002404:	04000737          	lui	a4,0x4000
    80002408:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    8000240a:	0732                	slli	a4,a4,0xc
    8000240c:	00004797          	auipc	a5,0x4
    80002410:	bf478793          	addi	a5,a5,-1036 # 80006000 <_trampoline>
    80002414:	00004697          	auipc	a3,0x4
    80002418:	bec68693          	addi	a3,a3,-1044 # 80006000 <_trampoline>
    8000241c:	8f95                	sub	a5,a5,a3
    8000241e:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002420:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002424:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r"(x));
    80002426:	18002773          	csrr	a4,satp
    8000242a:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    8000242c:	6d38                	ld	a4,88(a0)
    8000242e:	613c                	ld	a5,64(a0)
    80002430:	6685                	lui	a3,0x1
    80002432:	97b6                	add	a5,a5,a3
    80002434:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002436:	6d3c                	ld	a5,88(a0)
    80002438:	00000717          	auipc	a4,0x0
    8000243c:	0f870713          	addi	a4,a4,248 # 80002530 <usertrap>
    80002440:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp(); // hartid for cpuid()
    80002442:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r"(x));
    80002444:	8712                	mv	a4,tp
    80002446:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002448:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.

  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000244c:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002450:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002454:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002458:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r"(x));
    8000245a:	6f9c                	ld	a5,24(a5)
    8000245c:	14179073          	csrw	sepc,a5
}
    80002460:	60a2                	ld	ra,8(sp)
    80002462:	6402                	ld	s0,0(sp)
    80002464:	0141                	addi	sp,sp,16
    80002466:	8082                	ret

0000000080002468 <_Z9clockintrv>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80002468:	1101                	addi	sp,sp,-32
    8000246a:	ec06                	sd	ra,24(sp)
    8000246c:	e822                	sd	s0,16(sp)
    8000246e:	1000                	addi	s0,sp,32
  if (cpuid() == 0) {
    80002470:	c1eff0ef          	jal	8000188e <_Z5cpuidv>
    80002474:	cd11                	beqz	a0,80002490 <_Z9clockintrv+0x28>
  asm volatile("csrr %0, time" : "=r"(x));
    80002476:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    8000247a:	000f4737          	lui	a4,0xf4
    8000247e:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80002482:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    80002484:	14d79073          	csrw	stimecmp,a5
}
    80002488:	60e2                	ld	ra,24(sp)
    8000248a:	6442                	ld	s0,16(sp)
    8000248c:	6105                	addi	sp,sp,32
    8000248e:	8082                	ret
    80002490:	e426                	sd	s1,8(sp)
    acquire(&tickslock);
    80002492:	00013497          	auipc	s1,0x13
    80002496:	30648493          	addi	s1,s1,774 # 80015798 <tickslock>
    8000249a:	8526                	mv	a0,s1
    8000249c:	f24fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
    ticks++;
    800024a0:	00005517          	auipc	a0,0x5
    800024a4:	3c850513          	addi	a0,a0,968 # 80007868 <ticks>
    800024a8:	411c                	lw	a5,0(a0)
    800024aa:	2785                	addiw	a5,a5,1
    800024ac:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    800024ae:	a5fff0ef          	jal	80001f0c <_Z6wakeupPv>
    release(&tickslock);
    800024b2:	8526                	mv	a0,s1
    800024b4:	f98fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
    800024b8:	64a2                	ld	s1,8(sp)
    800024ba:	bf75                	j	80002476 <_Z9clockintrv+0xe>

00000000800024bc <_Z7devintrv>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    800024bc:	1101                	addi	sp,sp,-32
    800024be:	ec06                	sd	ra,24(sp)
    800024c0:	e822                	sd	s0,16(sp)
    800024c2:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r"(x));
    800024c4:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if (scause == 0x8000000000000009L) {
    800024c8:	57fd                	li	a5,-1
    800024ca:	17fe                	slli	a5,a5,0x3f
    800024cc:	07a5                	addi	a5,a5,9
    800024ce:	00f70c63          	beq	a4,a5,800024e6 <_Z7devintrv+0x2a>
    // now allowed to interrupt again.
    if (irq)
      plic_complete(irq);

    return 1;
  } else if (scause == 0x8000000000000005L) {
    800024d2:	57fd                	li	a5,-1
    800024d4:	17fe                	slli	a5,a5,0x3f
    800024d6:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    800024d8:	4501                	li	a0,0
  } else if (scause == 0x8000000000000005L) {
    800024da:	04f70763          	beq	a4,a5,80002528 <_Z7devintrv+0x6c>
  }
}
    800024de:	60e2                	ld	ra,24(sp)
    800024e0:	6442                	ld	s0,16(sp)
    800024e2:	6105                	addi	sp,sp,32
    800024e4:	8082                	ret
    800024e6:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    800024e8:	715020ef          	jal	800053fc <_Z10plic_claimv>
    800024ec:	84aa                	mv	s1,a0
    if (irq == UART0_IRQ) {
    800024ee:	47a9                	li	a5,10
    800024f0:	00f50963          	beq	a0,a5,80002502 <_Z7devintrv+0x46>
    } else if (irq == VIRTIO0_IRQ) {
    800024f4:	4785                	li	a5,1
    800024f6:	00f50963          	beq	a0,a5,80002508 <_Z7devintrv+0x4c>
    return 1;
    800024fa:	4505                	li	a0,1
    } else if (irq) {
    800024fc:	e889                	bnez	s1,8000250e <_Z7devintrv+0x52>
    800024fe:	64a2                	ld	s1,8(sp)
    80002500:	bff9                	j	800024de <_Z7devintrv+0x22>
      uartintr();
    80002502:	c9afe0ef          	jal	8000099c <_Z8uartintrv>
    if (irq)
    80002506:	a819                	j	8000251c <_Z7devintrv+0x60>
      virtio_disk_intr();
    80002508:	3ba030ef          	jal	800058c2 <_Z16virtio_disk_intrv>
    if (irq)
    8000250c:	a801                	j	8000251c <_Z7devintrv+0x60>
      printk("unexpected interrupt irq=%d\n", irq);
    8000250e:	85a6                	mv	a1,s1
    80002510:	00005517          	auipc	a0,0x5
    80002514:	d4050513          	addi	a0,a0,-704 # 80007250 <etext+0x250>
    80002518:	fdbfd0ef          	jal	800004f2 <_Z6printkPKcz>
      plic_complete(irq);
    8000251c:	8526                	mv	a0,s1
    8000251e:	6ff020ef          	jal	8000541c <_Z13plic_completei>
    return 1;
    80002522:	4505                	li	a0,1
    80002524:	64a2                	ld	s1,8(sp)
    80002526:	bf65                	j	800024de <_Z7devintrv+0x22>
    clockintr();
    80002528:	f41ff0ef          	jal	80002468 <_Z9clockintrv>
    return 2;
    8000252c:	4509                	li	a0,2
    8000252e:	bf45                	j	800024de <_Z7devintrv+0x22>

0000000080002530 <usertrap>:
{
    80002530:	1101                	addi	sp,sp,-32
    80002532:	ec06                	sd	ra,24(sp)
    80002534:	e822                	sd	s0,16(sp)
    80002536:	e426                	sd	s1,8(sp)
    80002538:	e04a                	sd	s2,0(sp)
    8000253a:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r"(x));
    8000253c:	100027f3          	csrr	a5,sstatus
  if ((r_sstatus() & SSTATUS_SPP) != 0)
    80002540:	1007f793          	andi	a5,a5,256
    80002544:	eba5                	bnez	a5,800025b4 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002546:	00003797          	auipc	a5,0x3
    8000254a:	e0a78793          	addi	a5,a5,-502 # 80005350 <kernelvec>
    8000254e:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80002552:	b68ff0ef          	jal	800018ba <_Z6myprocv>
    80002556:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002558:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r"(x));
    8000255a:	14102773          	csrr	a4,sepc
    8000255e:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r"(x));
    80002560:	14202773          	csrr	a4,scause
  if (r_scause() == 8) {
    80002564:	47a1                	li	a5,8
    80002566:	04f70d63          	beq	a4,a5,800025c0 <usertrap+0x90>
  } else if ((which_dev = devintr()) != 0) {
    8000256a:	f53ff0ef          	jal	800024bc <_Z7devintrv>
    8000256e:	892a                	mv	s2,a0
    80002570:	e545                	bnez	a0,80002618 <usertrap+0xe8>
    80002572:	14202773          	csrr	a4,scause
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    80002576:	47bd                	li	a5,15
    80002578:	08f70463          	beq	a4,a5,80002600 <usertrap+0xd0>
    8000257c:	14202773          	csrr	a4,scause
    80002580:	47b5                	li	a5,13
    80002582:	06f70f63          	beq	a4,a5,80002600 <usertrap+0xd0>
    80002586:	142025f3          	csrr	a1,scause
    printk("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    8000258a:	5890                	lw	a2,48(s1)
    8000258c:	00005517          	auipc	a0,0x5
    80002590:	d0450513          	addi	a0,a0,-764 # 80007290 <etext+0x290>
    80002594:	f5ffd0ef          	jal	800004f2 <_Z6printkPKcz>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002598:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    8000259c:	14302673          	csrr	a2,stval
    printk("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    800025a0:	00005517          	auipc	a0,0x5
    800025a4:	d2050513          	addi	a0,a0,-736 # 800072c0 <etext+0x2c0>
    800025a8:	f4bfd0ef          	jal	800004f2 <_Z6printkPKcz>
    setkilled(p);
    800025ac:	8526                	mv	a0,s1
    800025ae:	b27ff0ef          	jal	800020d4 <_Z9setkilledP4proc>
    800025b2:	a015                	j	800025d6 <usertrap+0xa6>
    panic("usertrap: not from user mode");
    800025b4:	00005517          	auipc	a0,0x5
    800025b8:	cbc50513          	addi	a0,a0,-836 # 80007270 <etext+0x270>
    800025bc:	a36fe0ef          	jal	800007f2 <_Z5panicPKc>
    if (killed(p))
    800025c0:	b39ff0ef          	jal	800020f8 <_Z6killedP4proc>
    800025c4:	e915                	bnez	a0,800025f8 <usertrap+0xc8>
    p->trapframe->epc += 4;
    800025c6:	6cb8                	ld	a4,88(s1)
    800025c8:	6f1c                	ld	a5,24(a4)
    800025ca:	0791                	addi	a5,a5,4
    800025cc:	ef1c                	sd	a5,24(a4)
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    800025ce:	10016073          	csrsi	sstatus,2
    syscall();
    800025d2:	246000ef          	jal	80002818 <_Z7syscallv>
  if (killed(p))
    800025d6:	8526                	mv	a0,s1
    800025d8:	b21ff0ef          	jal	800020f8 <_Z6killedP4proc>
    800025dc:	e139                	bnez	a0,80002622 <usertrap+0xf2>
  prepare_return();
    800025de:	e17ff0ef          	jal	800023f4 <_Z14prepare_returnv>
  uint64 satp = MAKE_SATP(p->pagetable);
    800025e2:	68a8                	ld	a0,80(s1)
    800025e4:	8131                	srli	a0,a0,0xc
    800025e6:	57fd                	li	a5,-1
    800025e8:	17fe                	slli	a5,a5,0x3f
    800025ea:	8d5d                	or	a0,a0,a5
}
    800025ec:	60e2                	ld	ra,24(sp)
    800025ee:	6442                	ld	s0,16(sp)
    800025f0:	64a2                	ld	s1,8(sp)
    800025f2:	6902                	ld	s2,0(sp)
    800025f4:	6105                	addi	sp,sp,32
    800025f6:	8082                	ret
      kexit(-1);
    800025f8:	557d                	li	a0,-1
    800025fa:	9d3ff0ef          	jal	80001fcc <_Z5kexiti>
    800025fe:	b7e1                	j	800025c6 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r"(x));
    80002600:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r"(x));
    80002604:	14202673          	csrr	a2,scause
             vmfault(p->pagetable, r_stval(), (r_scause() == 13) ? 1 : 0) !=
    80002608:	164d                	addi	a2,a2,-13 # ff3 <_entry-0x7ffff00d>
    8000260a:	00163613          	seqz	a2,a2
    8000260e:	68a8                	ld	a0,80(s1)
    80002610:	f3dfe0ef          	jal	8000154c <_Z7vmfaultPmmi>
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    80002614:	f169                	bnez	a0,800025d6 <usertrap+0xa6>
    80002616:	bf85                	j	80002586 <usertrap+0x56>
  if (killed(p))
    80002618:	8526                	mv	a0,s1
    8000261a:	adfff0ef          	jal	800020f8 <_Z6killedP4proc>
    8000261e:	c511                	beqz	a0,8000262a <usertrap+0xfa>
    80002620:	a011                	j	80002624 <usertrap+0xf4>
    80002622:	4901                	li	s2,0
    kexit(-1);
    80002624:	557d                	li	a0,-1
    80002626:	9a7ff0ef          	jal	80001fcc <_Z5kexiti>
  if (which_dev == 2)
    8000262a:	4789                	li	a5,2
    8000262c:	faf919e3          	bne	s2,a5,800025de <usertrap+0xae>
    yield();
    80002630:	865ff0ef          	jal	80001e94 <_Z5yieldv>
    80002634:	b76d                	j	800025de <usertrap+0xae>

0000000080002636 <kerneltrap>:
{
    80002636:	7179                	addi	sp,sp,-48
    80002638:	f406                	sd	ra,40(sp)
    8000263a:	f022                	sd	s0,32(sp)
    8000263c:	ec26                	sd	s1,24(sp)
    8000263e:	e84a                	sd	s2,16(sp)
    80002640:	e44e                	sd	s3,8(sp)
    80002642:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002644:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002648:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r"(x));
    8000264c:	142029f3          	csrr	s3,scause
  if ((sstatus & SSTATUS_SPP) == 0)
    80002650:	1004f793          	andi	a5,s1,256
    80002654:	c795                	beqz	a5,80002680 <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002656:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000265a:	8b89                	andi	a5,a5,2
  if (intr_get() != 0)
    8000265c:	eb85                	bnez	a5,8000268c <kerneltrap+0x56>
  if ((which_dev = devintr()) == 0) {
    8000265e:	e5fff0ef          	jal	800024bc <_Z7devintrv>
    80002662:	c91d                	beqz	a0,80002698 <kerneltrap+0x62>
  if (which_dev == 2 && myproc() != 0)
    80002664:	4789                	li	a5,2
    80002666:	04f50a63          	beq	a0,a5,800026ba <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r"(x));
    8000266a:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    8000266e:	10049073          	csrw	sstatus,s1
}
    80002672:	70a2                	ld	ra,40(sp)
    80002674:	7402                	ld	s0,32(sp)
    80002676:	64e2                	ld	s1,24(sp)
    80002678:	6942                	ld	s2,16(sp)
    8000267a:	69a2                	ld	s3,8(sp)
    8000267c:	6145                	addi	sp,sp,48
    8000267e:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002680:	00005517          	auipc	a0,0x5
    80002684:	c6850513          	addi	a0,a0,-920 # 800072e8 <etext+0x2e8>
    80002688:	96afe0ef          	jal	800007f2 <_Z5panicPKc>
    panic("kerneltrap: interrupts enabled");
    8000268c:	00005517          	auipc	a0,0x5
    80002690:	c8450513          	addi	a0,a0,-892 # 80007310 <etext+0x310>
    80002694:	95efe0ef          	jal	800007f2 <_Z5panicPKc>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002698:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    8000269c:	143026f3          	csrr	a3,stval
    printk("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(),
    800026a0:	85ce                	mv	a1,s3
    800026a2:	00005517          	auipc	a0,0x5
    800026a6:	c8e50513          	addi	a0,a0,-882 # 80007330 <etext+0x330>
    800026aa:	e49fd0ef          	jal	800004f2 <_Z6printkPKcz>
    panic("kerneltrap");
    800026ae:	00005517          	auipc	a0,0x5
    800026b2:	caa50513          	addi	a0,a0,-854 # 80007358 <etext+0x358>
    800026b6:	93cfe0ef          	jal	800007f2 <_Z5panicPKc>
  if (which_dev == 2 && myproc() != 0)
    800026ba:	a00ff0ef          	jal	800018ba <_Z6myprocv>
    800026be:	d555                	beqz	a0,8000266a <kerneltrap+0x34>
    yield();
    800026c0:	fd4ff0ef          	jal	80001e94 <_Z5yieldv>
    800026c4:	b75d                	j	8000266a <kerneltrap+0x34>

00000000800026c6 <_ZL6argrawi>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    800026c6:	1101                	addi	sp,sp,-32
    800026c8:	ec06                	sd	ra,24(sp)
    800026ca:	e822                	sd	s0,16(sp)
    800026cc:	e426                	sd	s1,8(sp)
    800026ce:	1000                	addi	s0,sp,32
    800026d0:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    800026d2:	9e8ff0ef          	jal	800018ba <_Z6myprocv>
  switch (n) {
    800026d6:	4795                	li	a5,5
    800026d8:	0497e163          	bltu	a5,s1,8000271a <_ZL6argrawi+0x54>
    800026dc:	048a                	slli	s1,s1,0x2
    800026de:	00005717          	auipc	a4,0x5
    800026e2:	07a70713          	addi	a4,a4,122 # 80007758 <_ZZ8procdumpvE6states+0x30>
    800026e6:	94ba                	add	s1,s1,a4
    800026e8:	409c                	lw	a5,0(s1)
    800026ea:	97ba                	add	a5,a5,a4
    800026ec:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    800026ee:	6d3c                	ld	a5,88(a0)
    800026f0:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    800026f2:	60e2                	ld	ra,24(sp)
    800026f4:	6442                	ld	s0,16(sp)
    800026f6:	64a2                	ld	s1,8(sp)
    800026f8:	6105                	addi	sp,sp,32
    800026fa:	8082                	ret
    return p->trapframe->a1;
    800026fc:	6d3c                	ld	a5,88(a0)
    800026fe:	7fa8                	ld	a0,120(a5)
    80002700:	bfcd                	j	800026f2 <_ZL6argrawi+0x2c>
    return p->trapframe->a2;
    80002702:	6d3c                	ld	a5,88(a0)
    80002704:	63c8                	ld	a0,128(a5)
    80002706:	b7f5                	j	800026f2 <_ZL6argrawi+0x2c>
    return p->trapframe->a3;
    80002708:	6d3c                	ld	a5,88(a0)
    8000270a:	67c8                	ld	a0,136(a5)
    8000270c:	b7dd                	j	800026f2 <_ZL6argrawi+0x2c>
    return p->trapframe->a4;
    8000270e:	6d3c                	ld	a5,88(a0)
    80002710:	6bc8                	ld	a0,144(a5)
    80002712:	b7c5                	j	800026f2 <_ZL6argrawi+0x2c>
    return p->trapframe->a5;
    80002714:	6d3c                	ld	a5,88(a0)
    80002716:	6fc8                	ld	a0,152(a5)
    80002718:	bfe9                	j	800026f2 <_ZL6argrawi+0x2c>
  panic("argraw");
    8000271a:	00005517          	auipc	a0,0x5
    8000271e:	c4e50513          	addi	a0,a0,-946 # 80007368 <etext+0x368>
    80002722:	8d0fe0ef          	jal	800007f2 <_Z5panicPKc>

0000000080002726 <_Z9fetchaddrmPm>:
{
    80002726:	1101                	addi	sp,sp,-32
    80002728:	ec06                	sd	ra,24(sp)
    8000272a:	e822                	sd	s0,16(sp)
    8000272c:	e426                	sd	s1,8(sp)
    8000272e:	e04a                	sd	s2,0(sp)
    80002730:	1000                	addi	s0,sp,32
    80002732:	84aa                	mv	s1,a0
    80002734:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002736:	984ff0ef          	jal	800018ba <_Z6myprocv>
  if (addr >= p->sz ||
    8000273a:	653c                	ld	a5,72(a0)
    8000273c:	02f4f663          	bgeu	s1,a5,80002768 <_Z9fetchaddrmPm+0x42>
      addr + sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002740:	00848713          	addi	a4,s1,8
  if (addr >= p->sz ||
    80002744:	02e7e463          	bltu	a5,a4,8000276c <_Z9fetchaddrmPm+0x46>
  if (copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80002748:	46a1                	li	a3,8
    8000274a:	8626                	mv	a2,s1
    8000274c:	85ca                	mv	a1,s2
    8000274e:	6928                	ld	a0,80(a0)
    80002750:	f63fe0ef          	jal	800016b2 <_Z6copyinPmPcmm>
    80002754:	00a03533          	snez	a0,a0
    80002758:	40a00533          	neg	a0,a0
}
    8000275c:	60e2                	ld	ra,24(sp)
    8000275e:	6442                	ld	s0,16(sp)
    80002760:	64a2                	ld	s1,8(sp)
    80002762:	6902                	ld	s2,0(sp)
    80002764:	6105                	addi	sp,sp,32
    80002766:	8082                	ret
    return -1;
    80002768:	557d                	li	a0,-1
    8000276a:	bfcd                	j	8000275c <_Z9fetchaddrmPm+0x36>
    8000276c:	557d                	li	a0,-1
    8000276e:	b7fd                	j	8000275c <_Z9fetchaddrmPm+0x36>

0000000080002770 <_Z8fetchstrmPci>:
{
    80002770:	7179                	addi	sp,sp,-48
    80002772:	f406                	sd	ra,40(sp)
    80002774:	f022                	sd	s0,32(sp)
    80002776:	ec26                	sd	s1,24(sp)
    80002778:	e84a                	sd	s2,16(sp)
    8000277a:	e44e                	sd	s3,8(sp)
    8000277c:	1800                	addi	s0,sp,48
    8000277e:	892a                	mv	s2,a0
    80002780:	84ae                	mv	s1,a1
    80002782:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80002784:	936ff0ef          	jal	800018ba <_Z6myprocv>
  if (copyinstr(p->pagetable, buf, addr, max) < 0)
    80002788:	86ce                	mv	a3,s3
    8000278a:	864a                	mv	a2,s2
    8000278c:	85a6                	mv	a1,s1
    8000278e:	6928                	ld	a0,80(a0)
    80002790:	ce5fe0ef          	jal	80001474 <_Z9copyinstrPmPcmm>
    80002794:	00054c63          	bltz	a0,800027ac <_Z8fetchstrmPci+0x3c>
  return strlen(buf);
    80002798:	8526                	mv	a0,s1
    8000279a:	e60fe0ef          	jal	80000dfa <_Z6strlenPKc>
}
    8000279e:	70a2                	ld	ra,40(sp)
    800027a0:	7402                	ld	s0,32(sp)
    800027a2:	64e2                	ld	s1,24(sp)
    800027a4:	6942                	ld	s2,16(sp)
    800027a6:	69a2                	ld	s3,8(sp)
    800027a8:	6145                	addi	sp,sp,48
    800027aa:	8082                	ret
    return -1;
    800027ac:	557d                	li	a0,-1
    800027ae:	bfc5                	j	8000279e <_Z8fetchstrmPci+0x2e>

00000000800027b0 <_Z6argintiPi>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    800027b0:	1101                	addi	sp,sp,-32
    800027b2:	ec06                	sd	ra,24(sp)
    800027b4:	e822                	sd	s0,16(sp)
    800027b6:	e426                	sd	s1,8(sp)
    800027b8:	1000                	addi	s0,sp,32
    800027ba:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800027bc:	f0bff0ef          	jal	800026c6 <_ZL6argrawi>
    800027c0:	c088                	sw	a0,0(s1)
}
    800027c2:	60e2                	ld	ra,24(sp)
    800027c4:	6442                	ld	s0,16(sp)
    800027c6:	64a2                	ld	s1,8(sp)
    800027c8:	6105                	addi	sp,sp,32
    800027ca:	8082                	ret

00000000800027cc <_Z7argaddriPm>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    800027cc:	1101                	addi	sp,sp,-32
    800027ce:	ec06                	sd	ra,24(sp)
    800027d0:	e822                	sd	s0,16(sp)
    800027d2:	e426                	sd	s1,8(sp)
    800027d4:	1000                	addi	s0,sp,32
    800027d6:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800027d8:	eefff0ef          	jal	800026c6 <_ZL6argrawi>
    800027dc:	e088                	sd	a0,0(s1)
}
    800027de:	60e2                	ld	ra,24(sp)
    800027e0:	6442                	ld	s0,16(sp)
    800027e2:	64a2                	ld	s1,8(sp)
    800027e4:	6105                	addi	sp,sp,32
    800027e6:	8082                	ret

00000000800027e8 <_Z6argstriPci>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (not including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    800027e8:	7179                	addi	sp,sp,-48
    800027ea:	f406                	sd	ra,40(sp)
    800027ec:	f022                	sd	s0,32(sp)
    800027ee:	ec26                	sd	s1,24(sp)
    800027f0:	e84a                	sd	s2,16(sp)
    800027f2:	1800                	addi	s0,sp,48
    800027f4:	84ae                	mv	s1,a1
    800027f6:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    800027f8:	fd840593          	addi	a1,s0,-40
    800027fc:	fd1ff0ef          	jal	800027cc <_Z7argaddriPm>
  return fetchstr(addr, buf, max);
    80002800:	864a                	mv	a2,s2
    80002802:	85a6                	mv	a1,s1
    80002804:	fd843503          	ld	a0,-40(s0)
    80002808:	f69ff0ef          	jal	80002770 <_Z8fetchstrmPci>
}
    8000280c:	70a2                	ld	ra,40(sp)
    8000280e:	7402                	ld	s0,32(sp)
    80002810:	64e2                	ld	s1,24(sp)
    80002812:	6942                	ld	s2,16(sp)
    80002814:	6145                	addi	sp,sp,48
    80002816:	8082                	ret

0000000080002818 <_Z7syscallv>:
  // clang-format on
};

void
syscall(void)
{
    80002818:	1101                	addi	sp,sp,-32
    8000281a:	ec06                	sd	ra,24(sp)
    8000281c:	e822                	sd	s0,16(sp)
    8000281e:	e426                	sd	s1,8(sp)
    80002820:	e04a                	sd	s2,0(sp)
    80002822:	1000                	addi	s0,sp,32
  uint num;
  struct proc *p = myproc();
    80002824:	896ff0ef          	jal	800018ba <_Z6myprocv>
    80002828:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    8000282a:	05853903          	ld	s2,88(a0)
    8000282e:	0a892683          	lw	a3,168(s2)
  if (num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002832:	fff6871b          	addiw	a4,a3,-1 # fff <_entry-0x7ffff001>
    80002836:	47d5                	li	a5,21
    80002838:	02e7e163          	bltu	a5,a4,8000285a <_Z7syscallv+0x42>
    8000283c:	02069793          	slli	a5,a3,0x20
    80002840:	01d7d713          	srli	a4,a5,0x1d
    80002844:	00005797          	auipc	a5,0x5
    80002848:	f2c78793          	addi	a5,a5,-212 # 80007770 <_ZL8syscalls>
    8000284c:	97ba                	add	a5,a5,a4
    8000284e:	639c                	ld	a5,0(a5)
    80002850:	c789                	beqz	a5,8000285a <_Z7syscallv+0x42>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002852:	9782                	jalr	a5
    80002854:	06a93823          	sd	a0,112(s2)
    80002858:	a829                	j	80002872 <_Z7syscallv+0x5a>
  } else {
    printk("%d %s: unknown sys call %d\n", p->pid, p->name, num);
    8000285a:	15848613          	addi	a2,s1,344
    8000285e:	588c                	lw	a1,48(s1)
    80002860:	00005517          	auipc	a0,0x5
    80002864:	b1050513          	addi	a0,a0,-1264 # 80007370 <etext+0x370>
    80002868:	c8bfd0ef          	jal	800004f2 <_Z6printkPKcz>
    p->trapframe->a0 = -1;
    8000286c:	6cbc                	ld	a5,88(s1)
    8000286e:	577d                	li	a4,-1
    80002870:	fbb8                	sd	a4,112(a5)
  }
}
    80002872:	60e2                	ld	ra,24(sp)
    80002874:	6442                	ld	s0,16(sp)
    80002876:	64a2                	ld	s1,8(sp)
    80002878:	6902                	ld	s2,0(sp)
    8000287a:	6105                	addi	sp,sp,32
    8000287c:	8082                	ret

000000008000287e <_Z8sys_exitv>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    8000287e:	1101                	addi	sp,sp,-32
    80002880:	ec06                	sd	ra,24(sp)
    80002882:	e822                	sd	s0,16(sp)
    80002884:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002886:	fec40593          	addi	a1,s0,-20
    8000288a:	4501                	li	a0,0
    8000288c:	f25ff0ef          	jal	800027b0 <_Z6argintiPi>
  kexit(n);
    80002890:	fec42503          	lw	a0,-20(s0)
    80002894:	f38ff0ef          	jal	80001fcc <_Z5kexiti>
  return 0; // not reached
}
    80002898:	4501                	li	a0,0
    8000289a:	60e2                	ld	ra,24(sp)
    8000289c:	6442                	ld	s0,16(sp)
    8000289e:	6105                	addi	sp,sp,32
    800028a0:	8082                	ret

00000000800028a2 <_Z10sys_getpidv>:

uint64
sys_getpid(void)
{
    800028a2:	1141                	addi	sp,sp,-16
    800028a4:	e406                	sd	ra,8(sp)
    800028a6:	e022                	sd	s0,0(sp)
    800028a8:	0800                	addi	s0,sp,16
  return myproc()->pid;
    800028aa:	810ff0ef          	jal	800018ba <_Z6myprocv>
}
    800028ae:	5908                	lw	a0,48(a0)
    800028b0:	60a2                	ld	ra,8(sp)
    800028b2:	6402                	ld	s0,0(sp)
    800028b4:	0141                	addi	sp,sp,16
    800028b6:	8082                	ret

00000000800028b8 <_Z8sys_forkv>:

uint64
sys_fork(void)
{
    800028b8:	1141                	addi	sp,sp,-16
    800028ba:	e406                	sd	ra,8(sp)
    800028bc:	e022                	sd	s0,0(sp)
    800028be:	0800                	addi	s0,sp,16
  return kfork();
    800028c0:	b68ff0ef          	jal	80001c28 <_Z5kforkv>
}
    800028c4:	60a2                	ld	ra,8(sp)
    800028c6:	6402                	ld	s0,0(sp)
    800028c8:	0141                	addi	sp,sp,16
    800028ca:	8082                	ret

00000000800028cc <_Z8sys_waitv>:

uint64
sys_wait(void)
{
    800028cc:	1101                	addi	sp,sp,-32
    800028ce:	ec06                	sd	ra,24(sp)
    800028d0:	e822                	sd	s0,16(sp)
    800028d2:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    800028d4:	fe840593          	addi	a1,s0,-24
    800028d8:	4501                	li	a0,0
    800028da:	ef3ff0ef          	jal	800027cc <_Z7argaddriPm>
  return kwait(p);
    800028de:	fe843503          	ld	a0,-24(s0)
    800028e2:	841ff0ef          	jal	80002122 <_Z5kwaitm>
}
    800028e6:	60e2                	ld	ra,24(sp)
    800028e8:	6442                	ld	s0,16(sp)
    800028ea:	6105                	addi	sp,sp,32
    800028ec:	8082                	ret

00000000800028ee <_Z8sys_sbrkv>:

uint64
sys_sbrk(void)
{
    800028ee:	7179                	addi	sp,sp,-48
    800028f0:	f406                	sd	ra,40(sp)
    800028f2:	f022                	sd	s0,32(sp)
    800028f4:	ec26                	sd	s1,24(sp)
    800028f6:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    800028f8:	fd840593          	addi	a1,s0,-40
    800028fc:	4501                	li	a0,0
    800028fe:	eb3ff0ef          	jal	800027b0 <_Z6argintiPi>
  argint(1, &t);
    80002902:	fdc40593          	addi	a1,s0,-36
    80002906:	4505                	li	a0,1
    80002908:	ea9ff0ef          	jal	800027b0 <_Z6argintiPi>
  addr = myproc()->sz;
    8000290c:	faffe0ef          	jal	800018ba <_Z6myprocv>
    80002910:	6524                	ld	s1,72(a0)

  if (t == SBRK_EAGER || n < 0) {
    80002912:	fdc42703          	lw	a4,-36(s0)
    80002916:	4785                	li	a5,1
    80002918:	02f70763          	beq	a4,a5,80002946 <_Z8sys_sbrkv+0x58>
    8000291c:	fd842783          	lw	a5,-40(s0)
    80002920:	0207c363          	bltz	a5,80002946 <_Z8sys_sbrkv+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
    80002924:	97a6                	add	a5,a5,s1
    80002926:	0297ee63          	bltu	a5,s1,80002962 <_Z8sys_sbrkv+0x74>
      return -1;
    if (addr + n > TRAPFRAME)
    8000292a:	02000737          	lui	a4,0x2000
    8000292e:	177d                	addi	a4,a4,-1 # 1ffffff <_entry-0x7e000001>
    80002930:	0736                	slli	a4,a4,0xd
    80002932:	02f76a63          	bltu	a4,a5,80002966 <_Z8sys_sbrkv+0x78>
      return -1;
    myproc()->sz += n;
    80002936:	f85fe0ef          	jal	800018ba <_Z6myprocv>
    8000293a:	fd842703          	lw	a4,-40(s0)
    8000293e:	653c                	ld	a5,72(a0)
    80002940:	97ba                	add	a5,a5,a4
    80002942:	e53c                	sd	a5,72(a0)
    80002944:	a039                	j	80002952 <_Z8sys_sbrkv+0x64>
    if (growproc(n) < 0) {
    80002946:	fd842503          	lw	a0,-40(s0)
    8000294a:	a7cff0ef          	jal	80001bc6 <_Z8growproci>
    8000294e:	00054863          	bltz	a0,8000295e <_Z8sys_sbrkv+0x70>
  }
  return addr;
}
    80002952:	8526                	mv	a0,s1
    80002954:	70a2                	ld	ra,40(sp)
    80002956:	7402                	ld	s0,32(sp)
    80002958:	64e2                	ld	s1,24(sp)
    8000295a:	6145                	addi	sp,sp,48
    8000295c:	8082                	ret
      return -1;
    8000295e:	54fd                	li	s1,-1
    80002960:	bfcd                	j	80002952 <_Z8sys_sbrkv+0x64>
      return -1;
    80002962:	54fd                	li	s1,-1
    80002964:	b7fd                	j	80002952 <_Z8sys_sbrkv+0x64>
      return -1;
    80002966:	54fd                	li	s1,-1
    80002968:	b7ed                	j	80002952 <_Z8sys_sbrkv+0x64>

000000008000296a <_Z9sys_pausev>:

uint64
sys_pause(void)
{
    8000296a:	7139                	addi	sp,sp,-64
    8000296c:	fc06                	sd	ra,56(sp)
    8000296e:	f822                	sd	s0,48(sp)
    80002970:	f04a                	sd	s2,32(sp)
    80002972:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002974:	fcc40593          	addi	a1,s0,-52
    80002978:	4501                	li	a0,0
    8000297a:	e37ff0ef          	jal	800027b0 <_Z6argintiPi>
  if (n < 0)
    8000297e:	fcc42783          	lw	a5,-52(s0)
    80002982:	0607c763          	bltz	a5,800029f0 <_Z9sys_pausev+0x86>
    n = 0;
  acquire(&tickslock);
    80002986:	00013517          	auipc	a0,0x13
    8000298a:	e1250513          	addi	a0,a0,-494 # 80015798 <tickslock>
    8000298e:	a32fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  ticks0 = ticks;
    80002992:	00005917          	auipc	s2,0x5
    80002996:	ed692903          	lw	s2,-298(s2) # 80007868 <ticks>
  while (ticks - ticks0 < static_cast<uint>(n)) {
    8000299a:	fcc42783          	lw	a5,-52(s0)
    8000299e:	cf8d                	beqz	a5,800029d8 <_Z9sys_pausev+0x6e>
    800029a0:	f426                	sd	s1,40(sp)
    800029a2:	ec4e                	sd	s3,24(sp)
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    800029a4:	00013997          	auipc	s3,0x13
    800029a8:	df498993          	addi	s3,s3,-524 # 80015798 <tickslock>
    800029ac:	00005497          	auipc	s1,0x5
    800029b0:	ebc48493          	addi	s1,s1,-324 # 80007868 <ticks>
    if (killed(myproc())) {
    800029b4:	f07fe0ef          	jal	800018ba <_Z6myprocv>
    800029b8:	f40ff0ef          	jal	800020f8 <_Z6killedP4proc>
    800029bc:	ed0d                	bnez	a0,800029f6 <_Z9sys_pausev+0x8c>
    sleep(&ticks, &tickslock);
    800029be:	85ce                	mv	a1,s3
    800029c0:	8526                	mv	a0,s1
    800029c2:	cfeff0ef          	jal	80001ec0 <_Z5sleepPvP8spinlock>
  while (ticks - ticks0 < static_cast<uint>(n)) {
    800029c6:	409c                	lw	a5,0(s1)
    800029c8:	412787bb          	subw	a5,a5,s2
    800029cc:	fcc42703          	lw	a4,-52(s0)
    800029d0:	fee7e2e3          	bltu	a5,a4,800029b4 <_Z9sys_pausev+0x4a>
    800029d4:	74a2                	ld	s1,40(sp)
    800029d6:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    800029d8:	00013517          	auipc	a0,0x13
    800029dc:	dc050513          	addi	a0,a0,-576 # 80015798 <tickslock>
    800029e0:	a6cfe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  return 0;
    800029e4:	4501                	li	a0,0
}
    800029e6:	70e2                	ld	ra,56(sp)
    800029e8:	7442                	ld	s0,48(sp)
    800029ea:	7902                	ld	s2,32(sp)
    800029ec:	6121                	addi	sp,sp,64
    800029ee:	8082                	ret
    n = 0;
    800029f0:	fc042623          	sw	zero,-52(s0)
    800029f4:	bf49                	j	80002986 <_Z9sys_pausev+0x1c>
      release(&tickslock);
    800029f6:	00013517          	auipc	a0,0x13
    800029fa:	da250513          	addi	a0,a0,-606 # 80015798 <tickslock>
    800029fe:	a4efe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
      return -1;
    80002a02:	557d                	li	a0,-1
    80002a04:	74a2                	ld	s1,40(sp)
    80002a06:	69e2                	ld	s3,24(sp)
    80002a08:	bff9                	j	800029e6 <_Z9sys_pausev+0x7c>

0000000080002a0a <_Z8sys_killv>:

uint64
sys_kill(void)
{
    80002a0a:	1101                	addi	sp,sp,-32
    80002a0c:	ec06                	sd	ra,24(sp)
    80002a0e:	e822                	sd	s0,16(sp)
    80002a10:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002a12:	fec40593          	addi	a1,s0,-20
    80002a16:	4501                	li	a0,0
    80002a18:	d99ff0ef          	jal	800027b0 <_Z6argintiPi>
  return kkill(pid);
    80002a1c:	fec42503          	lw	a0,-20(s0)
    80002a20:	e4eff0ef          	jal	8000206e <_Z5kkilli>
}
    80002a24:	60e2                	ld	ra,24(sp)
    80002a26:	6442                	ld	s0,16(sp)
    80002a28:	6105                	addi	sp,sp,32
    80002a2a:	8082                	ret

0000000080002a2c <_Z10sys_uptimev>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002a2c:	1101                	addi	sp,sp,-32
    80002a2e:	ec06                	sd	ra,24(sp)
    80002a30:	e822                	sd	s0,16(sp)
    80002a32:	e426                	sd	s1,8(sp)
    80002a34:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002a36:	00013517          	auipc	a0,0x13
    80002a3a:	d6250513          	addi	a0,a0,-670 # 80015798 <tickslock>
    80002a3e:	982fe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  xticks = ticks;
    80002a42:	00005497          	auipc	s1,0x5
    80002a46:	e264a483          	lw	s1,-474(s1) # 80007868 <ticks>
  release(&tickslock);
    80002a4a:	00013517          	auipc	a0,0x13
    80002a4e:	d4e50513          	addi	a0,a0,-690 # 80015798 <tickslock>
    80002a52:	9fafe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  return xticks;
}
    80002a56:	02049513          	slli	a0,s1,0x20
    80002a5a:	9101                	srli	a0,a0,0x20
    80002a5c:	60e2                	ld	ra,24(sp)
    80002a5e:	6442                	ld	s0,16(sp)
    80002a60:	64a2                	ld	s1,8(sp)
    80002a62:	6105                	addi	sp,sp,32
    80002a64:	8082                	ret

0000000080002a66 <_Z5binitv>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002a66:	7179                	addi	sp,sp,-48
    80002a68:	f406                	sd	ra,40(sp)
    80002a6a:	f022                	sd	s0,32(sp)
    80002a6c:	ec26                	sd	s1,24(sp)
    80002a6e:	e84a                	sd	s2,16(sp)
    80002a70:	e44e                	sd	s3,8(sp)
    80002a72:	e052                	sd	s4,0(sp)
    80002a74:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002a76:	00005597          	auipc	a1,0x5
    80002a7a:	91a58593          	addi	a1,a1,-1766 # 80007390 <etext+0x390>
    80002a7e:	00013517          	auipc	a0,0x13
    80002a82:	d3250513          	addi	a0,a0,-718 # 800157b0 <bcache>
    80002a86:	8c4fe0ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002a8a:	0001b797          	auipc	a5,0x1b
    80002a8e:	d2678793          	addi	a5,a5,-730 # 8001d7b0 <bcache+0x8000>
    80002a92:	0001b717          	auipc	a4,0x1b
    80002a96:	f8670713          	addi	a4,a4,-122 # 8001da18 <bcache+0x8268>
    80002a9a:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002a9e:	2ae7bc23          	sd	a4,696(a5)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002aa2:	00013497          	auipc	s1,0x13
    80002aa6:	d2648493          	addi	s1,s1,-730 # 800157c8 <bcache+0x18>
    b->next = bcache.head.next;
    80002aaa:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002aac:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002aae:	00005a17          	auipc	s4,0x5
    80002ab2:	8eaa0a13          	addi	s4,s4,-1814 # 80007398 <etext+0x398>
    b->next = bcache.head.next;
    80002ab6:	2b893783          	ld	a5,696(s2)
    80002aba:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002abc:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002ac0:	85d2                	mv	a1,s4
    80002ac2:	01048513          	addi	a0,s1,16
    80002ac6:	3a8010ef          	jal	80003e6e <_Z13initsleeplockP9sleeplockPKc>
    bcache.head.next->prev = b;
    80002aca:	2b893783          	ld	a5,696(s2)
    80002ace:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002ad0:	2a993c23          	sd	s1,696(s2)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002ad4:	45848493          	addi	s1,s1,1112
    80002ad8:	fd349fe3          	bne	s1,s3,80002ab6 <_Z5binitv+0x50>
  }
}
    80002adc:	70a2                	ld	ra,40(sp)
    80002ade:	7402                	ld	s0,32(sp)
    80002ae0:	64e2                	ld	s1,24(sp)
    80002ae2:	6942                	ld	s2,16(sp)
    80002ae4:	69a2                	ld	s3,8(sp)
    80002ae6:	6a02                	ld	s4,0(sp)
    80002ae8:	6145                	addi	sp,sp,48
    80002aea:	8082                	ret

0000000080002aec <_Z5breadjj>:
}

// Return a locked buf with the contents of the indicated block.
struct buf *
bread(uint dev, uint blockno)
{
    80002aec:	7179                	addi	sp,sp,-48
    80002aee:	f406                	sd	ra,40(sp)
    80002af0:	f022                	sd	s0,32(sp)
    80002af2:	ec26                	sd	s1,24(sp)
    80002af4:	e84a                	sd	s2,16(sp)
    80002af6:	e44e                	sd	s3,8(sp)
    80002af8:	1800                	addi	s0,sp,48
    80002afa:	892a                	mv	s2,a0
    80002afc:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002afe:	00013517          	auipc	a0,0x13
    80002b02:	cb250513          	addi	a0,a0,-846 # 800157b0 <bcache>
    80002b06:	8bafe0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  for (b = bcache.head.next; b != &bcache.head; b = b->next) {
    80002b0a:	0001b497          	auipc	s1,0x1b
    80002b0e:	f5e4b483          	ld	s1,-162(s1) # 8001da68 <bcache+0x82b8>
    80002b12:	0001b797          	auipc	a5,0x1b
    80002b16:	f0678793          	addi	a5,a5,-250 # 8001da18 <bcache+0x8268>
    80002b1a:	02f48b63          	beq	s1,a5,80002b50 <_Z5breadjj+0x64>
    80002b1e:	873e                	mv	a4,a5
    80002b20:	a021                	j	80002b28 <_Z5breadjj+0x3c>
    80002b22:	68a4                	ld	s1,80(s1)
    80002b24:	02e48663          	beq	s1,a4,80002b50 <_Z5breadjj+0x64>
    if (b->dev == dev && b->blockno == blockno) {
    80002b28:	449c                	lw	a5,8(s1)
    80002b2a:	ff279ce3          	bne	a5,s2,80002b22 <_Z5breadjj+0x36>
    80002b2e:	44dc                	lw	a5,12(s1)
    80002b30:	ff3799e3          	bne	a5,s3,80002b22 <_Z5breadjj+0x36>
      b->refcnt++;
    80002b34:	40bc                	lw	a5,64(s1)
    80002b36:	2785                	addiw	a5,a5,1
    80002b38:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002b3a:	00013517          	auipc	a0,0x13
    80002b3e:	c7650513          	addi	a0,a0,-906 # 800157b0 <bcache>
    80002b42:	90afe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
      acquiresleep(&b->lock);
    80002b46:	01048513          	addi	a0,s1,16
    80002b4a:	35a010ef          	jal	80003ea4 <_Z12acquiresleepP9sleeplock>
      return b;
    80002b4e:	a889                	j	80002ba0 <_Z5breadjj+0xb4>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002b50:	0001b497          	auipc	s1,0x1b
    80002b54:	f104b483          	ld	s1,-240(s1) # 8001da60 <bcache+0x82b0>
    80002b58:	0001b797          	auipc	a5,0x1b
    80002b5c:	ec078793          	addi	a5,a5,-320 # 8001da18 <bcache+0x8268>
    80002b60:	00f48863          	beq	s1,a5,80002b70 <_Z5breadjj+0x84>
    80002b64:	873e                	mv	a4,a5
    if (b->refcnt == 0) {
    80002b66:	40bc                	lw	a5,64(s1)
    80002b68:	cb91                	beqz	a5,80002b7c <_Z5breadjj+0x90>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002b6a:	64a4                	ld	s1,72(s1)
    80002b6c:	fee49de3          	bne	s1,a4,80002b66 <_Z5breadjj+0x7a>
  panic("bget: no buffers");
    80002b70:	00005517          	auipc	a0,0x5
    80002b74:	83050513          	addi	a0,a0,-2000 # 800073a0 <etext+0x3a0>
    80002b78:	c7bfd0ef          	jal	800007f2 <_Z5panicPKc>
      b->dev = dev;
    80002b7c:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002b80:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002b84:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002b88:	4785                	li	a5,1
    80002b8a:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002b8c:	00013517          	auipc	a0,0x13
    80002b90:	c2450513          	addi	a0,a0,-988 # 800157b0 <bcache>
    80002b94:	8b8fe0ef          	jal	80000c4c <_Z7releaseP8spinlock>
      acquiresleep(&b->lock);
    80002b98:	01048513          	addi	a0,s1,16
    80002b9c:	308010ef          	jal	80003ea4 <_Z12acquiresleepP9sleeplock>
  struct buf *b;

  b = bget(dev, blockno);
  if (!b->valid) {
    80002ba0:	409c                	lw	a5,0(s1)
    80002ba2:	cb89                	beqz	a5,80002bb4 <_Z5breadjj+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002ba4:	8526                	mv	a0,s1
    80002ba6:	70a2                	ld	ra,40(sp)
    80002ba8:	7402                	ld	s0,32(sp)
    80002baa:	64e2                	ld	s1,24(sp)
    80002bac:	6942                	ld	s2,16(sp)
    80002bae:	69a2                	ld	s3,8(sp)
    80002bb0:	6145                	addi	sp,sp,48
    80002bb2:	8082                	ret
    virtio_disk_rw(b, 0);
    80002bb4:	4581                	li	a1,0
    80002bb6:	8526                	mv	a0,s1
    80002bb8:	2f9020ef          	jal	800056b0 <_Z14virtio_disk_rwP3bufi>
    b->valid = 1;
    80002bbc:	4785                	li	a5,1
    80002bbe:	c09c                	sw	a5,0(s1)
  return b;
    80002bc0:	b7d5                	j	80002ba4 <_Z5breadjj+0xb8>

0000000080002bc2 <_Z6bwriteP3buf>:

// Write b's contents to disk.  Must be locked.
// Only the log calls bwrite.
void
bwrite(struct buf *b)
{
    80002bc2:	1101                	addi	sp,sp,-32
    80002bc4:	ec06                	sd	ra,24(sp)
    80002bc6:	e822                	sd	s0,16(sp)
    80002bc8:	e426                	sd	s1,8(sp)
    80002bca:	1000                	addi	s0,sp,32
    80002bcc:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002bce:	0541                	addi	a0,a0,16
    80002bd0:	352010ef          	jal	80003f22 <_Z12holdingsleepPK9sleeplock>
    80002bd4:	c911                	beqz	a0,80002be8 <_Z6bwriteP3buf+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002bd6:	4585                	li	a1,1
    80002bd8:	8526                	mv	a0,s1
    80002bda:	2d7020ef          	jal	800056b0 <_Z14virtio_disk_rwP3bufi>
}
    80002bde:	60e2                	ld	ra,24(sp)
    80002be0:	6442                	ld	s0,16(sp)
    80002be2:	64a2                	ld	s1,8(sp)
    80002be4:	6105                	addi	sp,sp,32
    80002be6:	8082                	ret
    panic("bwrite");
    80002be8:	00004517          	auipc	a0,0x4
    80002bec:	7d050513          	addi	a0,a0,2000 # 800073b8 <etext+0x3b8>
    80002bf0:	c03fd0ef          	jal	800007f2 <_Z5panicPKc>

0000000080002bf4 <_Z6brelseP3buf>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002bf4:	1101                	addi	sp,sp,-32
    80002bf6:	ec06                	sd	ra,24(sp)
    80002bf8:	e822                	sd	s0,16(sp)
    80002bfa:	e426                	sd	s1,8(sp)
    80002bfc:	e04a                	sd	s2,0(sp)
    80002bfe:	1000                	addi	s0,sp,32
    80002c00:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002c02:	01050913          	addi	s2,a0,16
    80002c06:	854a                	mv	a0,s2
    80002c08:	31a010ef          	jal	80003f22 <_Z12holdingsleepPK9sleeplock>
    80002c0c:	c135                	beqz	a0,80002c70 <_Z6brelseP3buf+0x7c>
    panic("brelse");

  releasesleep(&b->lock);
    80002c0e:	854a                	mv	a0,s2
    80002c10:	2da010ef          	jal	80003eea <_Z12releasesleepP9sleeplock>

  acquire(&bcache.lock);
    80002c14:	00013517          	auipc	a0,0x13
    80002c18:	b9c50513          	addi	a0,a0,-1124 # 800157b0 <bcache>
    80002c1c:	fa5fd0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  b->refcnt--;
    80002c20:	40bc                	lw	a5,64(s1)
    80002c22:	37fd                	addiw	a5,a5,-1
    80002c24:	0007871b          	sext.w	a4,a5
    80002c28:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002c2a:	e71d                	bnez	a4,80002c58 <_Z6brelseP3buf+0x64>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002c2c:	68b8                	ld	a4,80(s1)
    80002c2e:	64bc                	ld	a5,72(s1)
    80002c30:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002c32:	68b8                	ld	a4,80(s1)
    80002c34:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002c36:	0001b797          	auipc	a5,0x1b
    80002c3a:	b7a78793          	addi	a5,a5,-1158 # 8001d7b0 <bcache+0x8000>
    80002c3e:	2b87b703          	ld	a4,696(a5)
    80002c42:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002c44:	0001b717          	auipc	a4,0x1b
    80002c48:	dd470713          	addi	a4,a4,-556 # 8001da18 <bcache+0x8268>
    80002c4c:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002c4e:	2b87b703          	ld	a4,696(a5)
    80002c52:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002c54:	2a97bc23          	sd	s1,696(a5)
  }

  release(&bcache.lock);
    80002c58:	00013517          	auipc	a0,0x13
    80002c5c:	b5850513          	addi	a0,a0,-1192 # 800157b0 <bcache>
    80002c60:	fedfd0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80002c64:	60e2                	ld	ra,24(sp)
    80002c66:	6442                	ld	s0,16(sp)
    80002c68:	64a2                	ld	s1,8(sp)
    80002c6a:	6902                	ld	s2,0(sp)
    80002c6c:	6105                	addi	sp,sp,32
    80002c6e:	8082                	ret
    panic("brelse");
    80002c70:	00004517          	auipc	a0,0x4
    80002c74:	75050513          	addi	a0,a0,1872 # 800073c0 <etext+0x3c0>
    80002c78:	b7bfd0ef          	jal	800007f2 <_Z5panicPKc>

0000000080002c7c <_Z4bpinP3buf>:

void
bpin(struct buf *b)
{
    80002c7c:	1101                	addi	sp,sp,-32
    80002c7e:	ec06                	sd	ra,24(sp)
    80002c80:	e822                	sd	s0,16(sp)
    80002c82:	e426                	sd	s1,8(sp)
    80002c84:	1000                	addi	s0,sp,32
    80002c86:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002c88:	00013517          	auipc	a0,0x13
    80002c8c:	b2850513          	addi	a0,a0,-1240 # 800157b0 <bcache>
    80002c90:	f31fd0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  b->refcnt++;
    80002c94:	40bc                	lw	a5,64(s1)
    80002c96:	2785                	addiw	a5,a5,1
    80002c98:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002c9a:	00013517          	auipc	a0,0x13
    80002c9e:	b1650513          	addi	a0,a0,-1258 # 800157b0 <bcache>
    80002ca2:	fabfd0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80002ca6:	60e2                	ld	ra,24(sp)
    80002ca8:	6442                	ld	s0,16(sp)
    80002caa:	64a2                	ld	s1,8(sp)
    80002cac:	6105                	addi	sp,sp,32
    80002cae:	8082                	ret

0000000080002cb0 <_Z6bunpinP3buf>:

void
bunpin(struct buf *b)
{
    80002cb0:	1101                	addi	sp,sp,-32
    80002cb2:	ec06                	sd	ra,24(sp)
    80002cb4:	e822                	sd	s0,16(sp)
    80002cb6:	e426                	sd	s1,8(sp)
    80002cb8:	1000                	addi	s0,sp,32
    80002cba:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002cbc:	00013517          	auipc	a0,0x13
    80002cc0:	af450513          	addi	a0,a0,-1292 # 800157b0 <bcache>
    80002cc4:	efdfd0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  b->refcnt--;
    80002cc8:	40bc                	lw	a5,64(s1)
    80002cca:	37fd                	addiw	a5,a5,-1
    80002ccc:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002cce:	00013517          	auipc	a0,0x13
    80002cd2:	ae250513          	addi	a0,a0,-1310 # 800157b0 <bcache>
    80002cd6:	f77fd0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80002cda:	60e2                	ld	ra,24(sp)
    80002cdc:	6442                	ld	s0,16(sp)
    80002cde:	64a2                	ld	s1,8(sp)
    80002ce0:	6105                	addi	sp,sp,32
    80002ce2:	8082                	ret

0000000080002ce4 <_ZL5bfreeij>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002ce4:	1101                	addi	sp,sp,-32
    80002ce6:	ec06                	sd	ra,24(sp)
    80002ce8:	e822                	sd	s0,16(sp)
    80002cea:	e426                	sd	s1,8(sp)
    80002cec:	e04a                	sd	s2,0(sp)
    80002cee:	1000                	addi	s0,sp,32
    80002cf0:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002cf2:	00d5d59b          	srliw	a1,a1,0xd
    80002cf6:	0001b797          	auipc	a5,0x1b
    80002cfa:	1967a783          	lw	a5,406(a5) # 8001de8c <sb+0x1c>
    80002cfe:	9dbd                	addw	a1,a1,a5
    80002d00:	dedff0ef          	jal	80002aec <_Z5breadjj>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002d04:	0074f713          	andi	a4,s1,7
    80002d08:	4785                	li	a5,1
    80002d0a:	00e797bb          	sllw	a5,a5,a4
  if ((bp->data[bi / 8] & m) == 0)
    80002d0e:	14ce                	slli	s1,s1,0x33
    80002d10:	90d9                	srli	s1,s1,0x36
    80002d12:	00950733          	add	a4,a0,s1
    80002d16:	05874703          	lbu	a4,88(a4)
    80002d1a:	00e7f6b3          	and	a3,a5,a4
    80002d1e:	c29d                	beqz	a3,80002d44 <_ZL5bfreeij+0x60>
    80002d20:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi / 8] &= ~m;
    80002d22:	94aa                	add	s1,s1,a0
    80002d24:	fff7c793          	not	a5,a5
    80002d28:	8f7d                	and	a4,a4,a5
    80002d2a:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002d2e:	01c010ef          	jal	80003d4a <_Z9log_writeP3buf>
  brelse(bp);
    80002d32:	854a                	mv	a0,s2
    80002d34:	ec1ff0ef          	jal	80002bf4 <_Z6brelseP3buf>
}
    80002d38:	60e2                	ld	ra,24(sp)
    80002d3a:	6442                	ld	s0,16(sp)
    80002d3c:	64a2                	ld	s1,8(sp)
    80002d3e:	6902                	ld	s2,0(sp)
    80002d40:	6105                	addi	sp,sp,32
    80002d42:	8082                	ret
    panic("freeing free block");
    80002d44:	00004517          	auipc	a0,0x4
    80002d48:	68450513          	addi	a0,a0,1668 # 800073c8 <etext+0x3c8>
    80002d4c:	aa7fd0ef          	jal	800007f2 <_Z5panicPKc>

0000000080002d50 <_ZL6ballocj>:
{
    80002d50:	711d                	addi	sp,sp,-96
    80002d52:	ec86                	sd	ra,88(sp)
    80002d54:	e8a2                	sd	s0,80(sp)
    80002d56:	e4a6                	sd	s1,72(sp)
    80002d58:	1080                	addi	s0,sp,96
  for (b = 0; b < sb.size; b += BPB) {
    80002d5a:	0001b797          	auipc	a5,0x1b
    80002d5e:	11a7a783          	lw	a5,282(a5) # 8001de74 <sb+0x4>
    80002d62:	0e078563          	beqz	a5,80002e4c <_ZL6ballocj+0xfc>
    80002d66:	e0ca                	sd	s2,64(sp)
    80002d68:	fc4e                	sd	s3,56(sp)
    80002d6a:	f852                	sd	s4,48(sp)
    80002d6c:	f456                	sd	s5,40(sp)
    80002d6e:	f05a                	sd	s6,32(sp)
    80002d70:	ec5e                	sd	s7,24(sp)
    80002d72:	e862                	sd	s8,16(sp)
    80002d74:	e466                	sd	s9,8(sp)
    80002d76:	8baa                	mv	s7,a0
    80002d78:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002d7a:	0001bb17          	auipc	s6,0x1b
    80002d7e:	0f6b0b13          	addi	s6,s6,246 # 8001de70 <sb>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002d82:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    80002d84:	4985                	li	s3,1
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002d86:	6a09                	lui	s4,0x2
  for (b = 0; b < sb.size; b += BPB) {
    80002d88:	6c89                	lui	s9,0x2
    80002d8a:	a0b5                	j	80002df6 <_ZL6ballocj+0xa6>
        bp->data[bi / 8] |= m;           // Mark block in use.
    80002d8c:	1602                	slli	a2,a2,0x20
    80002d8e:	9201                	srli	a2,a2,0x20
    80002d90:	964a                	add	a2,a2,s2
    80002d92:	8ec9                	or	a3,a3,a0
    80002d94:	04d60c23          	sb	a3,88(a2)
        log_write(bp);
    80002d98:	854a                	mv	a0,s2
    80002d9a:	7b1000ef          	jal	80003d4a <_Z9log_writeP3buf>
        brelse(bp);
    80002d9e:	854a                	mv	a0,s2
    80002da0:	e55ff0ef          	jal	80002bf4 <_Z6brelseP3buf>
  bp = bread(dev, bno);
    80002da4:	85a6                	mv	a1,s1
    80002da6:	855e                	mv	a0,s7
    80002da8:	d45ff0ef          	jal	80002aec <_Z5breadjj>
    80002dac:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002dae:	40000613          	li	a2,1024
    80002db2:	4581                	li	a1,0
    80002db4:	05850513          	addi	a0,a0,88
    80002db8:	ecdfd0ef          	jal	80000c84 <_Z6memsetPvij>
  log_write(bp);
    80002dbc:	854a                	mv	a0,s2
    80002dbe:	78d000ef          	jal	80003d4a <_Z9log_writeP3buf>
  brelse(bp);
    80002dc2:	854a                	mv	a0,s2
    80002dc4:	e31ff0ef          	jal	80002bf4 <_Z6brelseP3buf>
}
    80002dc8:	6906                	ld	s2,64(sp)
    80002dca:	79e2                	ld	s3,56(sp)
    80002dcc:	7a42                	ld	s4,48(sp)
    80002dce:	7aa2                	ld	s5,40(sp)
    80002dd0:	7b02                	ld	s6,32(sp)
    80002dd2:	6be2                	ld	s7,24(sp)
    80002dd4:	6c42                	ld	s8,16(sp)
    80002dd6:	6ca2                	ld	s9,8(sp)
}
    80002dd8:	8526                	mv	a0,s1
    80002dda:	60e6                	ld	ra,88(sp)
    80002ddc:	6446                	ld	s0,80(sp)
    80002dde:	64a6                	ld	s1,72(sp)
    80002de0:	6125                	addi	sp,sp,96
    80002de2:	8082                	ret
    brelse(bp);
    80002de4:	854a                	mv	a0,s2
    80002de6:	e0fff0ef          	jal	80002bf4 <_Z6brelseP3buf>
  for (b = 0; b < sb.size; b += BPB) {
    80002dea:	015c8abb          	addw	s5,s9,s5
    80002dee:	004b2783          	lw	a5,4(s6)
    80002df2:	04faf563          	bgeu	s5,a5,80002e3c <_ZL6ballocj+0xec>
    bp = bread(dev, BBLOCK(b, sb));
    80002df6:	00dad59b          	srliw	a1,s5,0xd
    80002dfa:	01cb2783          	lw	a5,28(s6)
    80002dfe:	9dbd                	addw	a1,a1,a5
    80002e00:	855e                	mv	a0,s7
    80002e02:	cebff0ef          	jal	80002aec <_Z5breadjj>
    80002e06:	892a                	mv	s2,a0
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002e08:	004b2583          	lw	a1,4(s6)
    80002e0c:	84d6                	mv	s1,s5
    80002e0e:	8762                	mv	a4,s8
    80002e10:	fcb4fae3          	bgeu	s1,a1,80002de4 <_ZL6ballocj+0x94>
      m = 1 << (bi % 8);
    80002e14:	00777793          	andi	a5,a4,7
    80002e18:	00f997bb          	sllw	a5,s3,a5
    80002e1c:	0007851b          	sext.w	a0,a5
      if ((bp->data[bi / 8] & m) == 0) { // Is block free?
    80002e20:	0037561b          	srliw	a2,a4,0x3
    80002e24:	0037569b          	srliw	a3,a4,0x3
    80002e28:	96ca                	add	a3,a3,s2
    80002e2a:	0586c683          	lbu	a3,88(a3)
    80002e2e:	8ff5                	and	a5,a5,a3
    80002e30:	dfb1                	beqz	a5,80002d8c <_ZL6ballocj+0x3c>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002e32:	2705                	addiw	a4,a4,1
    80002e34:	2485                	addiw	s1,s1,1
    80002e36:	fd471de3          	bne	a4,s4,80002e10 <_ZL6ballocj+0xc0>
    80002e3a:	b76d                	j	80002de4 <_ZL6ballocj+0x94>
    80002e3c:	6906                	ld	s2,64(sp)
    80002e3e:	79e2                	ld	s3,56(sp)
    80002e40:	7a42                	ld	s4,48(sp)
    80002e42:	7aa2                	ld	s5,40(sp)
    80002e44:	7b02                	ld	s6,32(sp)
    80002e46:	6be2                	ld	s7,24(sp)
    80002e48:	6c42                	ld	s8,16(sp)
    80002e4a:	6ca2                	ld	s9,8(sp)
  printk("balloc: out of blocks\n");
    80002e4c:	00004517          	auipc	a0,0x4
    80002e50:	59450513          	addi	a0,a0,1428 # 800073e0 <etext+0x3e0>
    80002e54:	e9efd0ef          	jal	800004f2 <_Z6printkPKcz>
  return 0;
    80002e58:	4481                	li	s1,0
    80002e5a:	bfbd                	j	80002dd8 <_ZL6ballocj+0x88>

0000000080002e5c <_ZL4bmapP5inodej>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002e5c:	7179                	addi	sp,sp,-48
    80002e5e:	f406                	sd	ra,40(sp)
    80002e60:	f022                	sd	s0,32(sp)
    80002e62:	ec26                	sd	s1,24(sp)
    80002e64:	e84a                	sd	s2,16(sp)
    80002e66:	e44e                	sd	s3,8(sp)
    80002e68:	1800                	addi	s0,sp,48
    80002e6a:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if (bn < NDIRECT) {
    80002e6c:	47ad                	li	a5,11
    80002e6e:	02b7e663          	bltu	a5,a1,80002e9a <_ZL4bmapP5inodej+0x3e>
    if ((addr = ip->addrs[bn]) == 0) {
    80002e72:	02059793          	slli	a5,a1,0x20
    80002e76:	01e7d593          	srli	a1,a5,0x1e
    80002e7a:	00b504b3          	add	s1,a0,a1
    80002e7e:	0504a903          	lw	s2,80(s1)
    80002e82:	06091a63          	bnez	s2,80002ef6 <_ZL4bmapP5inodej+0x9a>
      addr = balloc(ip->dev);
    80002e86:	4108                	lw	a0,0(a0)
    80002e88:	ec9ff0ef          	jal	80002d50 <_ZL6ballocj>
    80002e8c:	0005091b          	sext.w	s2,a0
      if (addr == 0)
    80002e90:	06090363          	beqz	s2,80002ef6 <_ZL4bmapP5inodej+0x9a>
        return 0;
      ip->addrs[bn] = addr;
    80002e94:	0524a823          	sw	s2,80(s1)
    80002e98:	a8b9                	j	80002ef6 <_ZL4bmapP5inodej+0x9a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002e9a:	ff45849b          	addiw	s1,a1,-12
    80002e9e:	0004871b          	sext.w	a4,s1

  if (bn < NINDIRECT) {
    80002ea2:	0ff00793          	li	a5,255
    80002ea6:	06e7ee63          	bltu	a5,a4,80002f22 <_ZL4bmapP5inodej+0xc6>
    // Load indirect block, allocating if necessary.
    if ((addr = ip->addrs[NDIRECT]) == 0) {
    80002eaa:	08052903          	lw	s2,128(a0)
    80002eae:	00091d63          	bnez	s2,80002ec8 <_ZL4bmapP5inodej+0x6c>
      addr = balloc(ip->dev);
    80002eb2:	4108                	lw	a0,0(a0)
    80002eb4:	e9dff0ef          	jal	80002d50 <_ZL6ballocj>
    80002eb8:	0005091b          	sext.w	s2,a0
      if (addr == 0)
    80002ebc:	02090d63          	beqz	s2,80002ef6 <_ZL4bmapP5inodej+0x9a>
    80002ec0:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002ec2:	0929a023          	sw	s2,128(s3)
    80002ec6:	a011                	j	80002eca <_ZL4bmapP5inodej+0x6e>
    80002ec8:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80002eca:	85ca                	mv	a1,s2
    80002ecc:	0009a503          	lw	a0,0(s3)
    80002ed0:	c1dff0ef          	jal	80002aec <_Z5breadjj>
    80002ed4:	8a2a                	mv	s4,a0
    a = (uint *)bp->data;
    80002ed6:	05850793          	addi	a5,a0,88
    if ((addr = a[bn]) == 0) {
    80002eda:	02049713          	slli	a4,s1,0x20
    80002ede:	01e75593          	srli	a1,a4,0x1e
    80002ee2:	00b784b3          	add	s1,a5,a1
    80002ee6:	0004a903          	lw	s2,0(s1)
    80002eea:	00090e63          	beqz	s2,80002f06 <_ZL4bmapP5inodej+0xaa>
      if (addr) {
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80002eee:	8552                	mv	a0,s4
    80002ef0:	d05ff0ef          	jal	80002bf4 <_Z6brelseP3buf>
    return addr;
    80002ef4:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002ef6:	854a                	mv	a0,s2
    80002ef8:	70a2                	ld	ra,40(sp)
    80002efa:	7402                	ld	s0,32(sp)
    80002efc:	64e2                	ld	s1,24(sp)
    80002efe:	6942                	ld	s2,16(sp)
    80002f00:	69a2                	ld	s3,8(sp)
    80002f02:	6145                	addi	sp,sp,48
    80002f04:	8082                	ret
      addr = balloc(ip->dev);
    80002f06:	0009a503          	lw	a0,0(s3)
    80002f0a:	e47ff0ef          	jal	80002d50 <_ZL6ballocj>
    80002f0e:	0005091b          	sext.w	s2,a0
      if (addr) {
    80002f12:	fc090ee3          	beqz	s2,80002eee <_ZL4bmapP5inodej+0x92>
        a[bn] = addr;
    80002f16:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    80002f1a:	8552                	mv	a0,s4
    80002f1c:	62f000ef          	jal	80003d4a <_Z9log_writeP3buf>
    80002f20:	b7f9                	j	80002eee <_ZL4bmapP5inodej+0x92>
    80002f22:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80002f24:	00004517          	auipc	a0,0x4
    80002f28:	4d450513          	addi	a0,a0,1236 # 800073f8 <etext+0x3f8>
    80002f2c:	8c7fd0ef          	jal	800007f2 <_Z5panicPKc>

0000000080002f30 <_ZL4igetjj>:
{
    80002f30:	7179                	addi	sp,sp,-48
    80002f32:	f406                	sd	ra,40(sp)
    80002f34:	f022                	sd	s0,32(sp)
    80002f36:	ec26                	sd	s1,24(sp)
    80002f38:	e84a                	sd	s2,16(sp)
    80002f3a:	e44e                	sd	s3,8(sp)
    80002f3c:	e052                	sd	s4,0(sp)
    80002f3e:	1800                	addi	s0,sp,48
    80002f40:	89aa                	mv	s3,a0
    80002f42:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80002f44:	0001b517          	auipc	a0,0x1b
    80002f48:	f4c50513          	addi	a0,a0,-180 # 8001de90 <itable>
    80002f4c:	c75fd0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  empty = 0;
    80002f50:	4901                	li	s2,0
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    80002f52:	0001b497          	auipc	s1,0x1b
    80002f56:	f5648493          	addi	s1,s1,-170 # 8001dea8 <itable+0x18>
    80002f5a:	0001d697          	auipc	a3,0x1d
    80002f5e:	9de68693          	addi	a3,a3,-1570 # 8001f938 <log>
    80002f62:	a039                	j	80002f70 <_ZL4igetjj+0x40>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    80002f64:	02090963          	beqz	s2,80002f96 <_ZL4igetjj+0x66>
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    80002f68:	08848493          	addi	s1,s1,136
    80002f6c:	02d48863          	beq	s1,a3,80002f9c <_ZL4igetjj+0x6c>
    if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    80002f70:	449c                	lw	a5,8(s1)
    80002f72:	fef059e3          	blez	a5,80002f64 <_ZL4igetjj+0x34>
    80002f76:	4098                	lw	a4,0(s1)
    80002f78:	ff3716e3          	bne	a4,s3,80002f64 <_ZL4igetjj+0x34>
    80002f7c:	40d8                	lw	a4,4(s1)
    80002f7e:	ff4713e3          	bne	a4,s4,80002f64 <_ZL4igetjj+0x34>
      ip->ref++;
    80002f82:	2785                	addiw	a5,a5,1
    80002f84:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80002f86:	0001b517          	auipc	a0,0x1b
    80002f8a:	f0a50513          	addi	a0,a0,-246 # 8001de90 <itable>
    80002f8e:	cbffd0ef          	jal	80000c4c <_Z7releaseP8spinlock>
      return ip;
    80002f92:	8926                	mv	s2,s1
    80002f94:	a02d                	j	80002fbe <_ZL4igetjj+0x8e>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    80002f96:	fbe9                	bnez	a5,80002f68 <_ZL4igetjj+0x38>
      empty = ip;
    80002f98:	8926                	mv	s2,s1
    80002f9a:	b7f9                	j	80002f68 <_ZL4igetjj+0x38>
  if (empty == 0)
    80002f9c:	02090a63          	beqz	s2,80002fd0 <_ZL4igetjj+0xa0>
  ip->dev = dev;
    80002fa0:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80002fa4:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80002fa8:	4785                	li	a5,1
    80002faa:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80002fae:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    80002fb2:	0001b517          	auipc	a0,0x1b
    80002fb6:	ede50513          	addi	a0,a0,-290 # 8001de90 <itable>
    80002fba:	c93fd0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80002fbe:	854a                	mv	a0,s2
    80002fc0:	70a2                	ld	ra,40(sp)
    80002fc2:	7402                	ld	s0,32(sp)
    80002fc4:	64e2                	ld	s1,24(sp)
    80002fc6:	6942                	ld	s2,16(sp)
    80002fc8:	69a2                	ld	s3,8(sp)
    80002fca:	6a02                	ld	s4,0(sp)
    80002fcc:	6145                	addi	sp,sp,48
    80002fce:	8082                	ret
    panic("iget: no inodes");
    80002fd0:	00004517          	auipc	a0,0x4
    80002fd4:	44050513          	addi	a0,a0,1088 # 80007410 <etext+0x410>
    80002fd8:	81bfd0ef          	jal	800007f2 <_Z5panicPKc>

0000000080002fdc <_Z5iinitv>:
{
    80002fdc:	7179                	addi	sp,sp,-48
    80002fde:	f406                	sd	ra,40(sp)
    80002fe0:	f022                	sd	s0,32(sp)
    80002fe2:	ec26                	sd	s1,24(sp)
    80002fe4:	e84a                	sd	s2,16(sp)
    80002fe6:	e44e                	sd	s3,8(sp)
    80002fe8:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80002fea:	00004597          	auipc	a1,0x4
    80002fee:	43658593          	addi	a1,a1,1078 # 80007420 <etext+0x420>
    80002ff2:	0001b517          	auipc	a0,0x1b
    80002ff6:	e9e50513          	addi	a0,a0,-354 # 8001de90 <itable>
    80002ffa:	b51fd0ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>
  for (i = 0; i < NINODE; i++) {
    80002ffe:	0001b497          	auipc	s1,0x1b
    80003002:	eba48493          	addi	s1,s1,-326 # 8001deb8 <itable+0x28>
    80003006:	0001d997          	auipc	s3,0x1d
    8000300a:	94298993          	addi	s3,s3,-1726 # 8001f948 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    8000300e:	00004917          	auipc	s2,0x4
    80003012:	41a90913          	addi	s2,s2,1050 # 80007428 <etext+0x428>
    80003016:	85ca                	mv	a1,s2
    80003018:	8526                	mv	a0,s1
    8000301a:	655000ef          	jal	80003e6e <_Z13initsleeplockP9sleeplockPKc>
  for (i = 0; i < NINODE; i++) {
    8000301e:	08848493          	addi	s1,s1,136
    80003022:	ff349ae3          	bne	s1,s3,80003016 <_Z5iinitv+0x3a>
}
    80003026:	70a2                	ld	ra,40(sp)
    80003028:	7402                	ld	s0,32(sp)
    8000302a:	64e2                	ld	s1,24(sp)
    8000302c:	6942                	ld	s2,16(sp)
    8000302e:	69a2                	ld	s3,8(sp)
    80003030:	6145                	addi	sp,sp,48
    80003032:	8082                	ret

0000000080003034 <_Z6iallocjs>:
{
    80003034:	7139                	addi	sp,sp,-64
    80003036:	fc06                	sd	ra,56(sp)
    80003038:	f822                	sd	s0,48(sp)
    8000303a:	0080                	addi	s0,sp,64
  for (inum = 1; inum < sb.ninodes; inum++) {
    8000303c:	0001b717          	auipc	a4,0x1b
    80003040:	e4072703          	lw	a4,-448(a4) # 8001de7c <sb+0xc>
    80003044:	4785                	li	a5,1
    80003046:	04e7fe63          	bgeu	a5,a4,800030a2 <_Z6iallocjs+0x6e>
    8000304a:	f426                	sd	s1,40(sp)
    8000304c:	f04a                	sd	s2,32(sp)
    8000304e:	ec4e                	sd	s3,24(sp)
    80003050:	e852                	sd	s4,16(sp)
    80003052:	e456                	sd	s5,8(sp)
    80003054:	e05a                	sd	s6,0(sp)
    80003056:	8aaa                	mv	s5,a0
    80003058:	8b2e                	mv	s6,a1
    8000305a:	4905                	li	s2,1
    bp = bread(dev, IBLOCK(inum, sb));
    8000305c:	0001ba17          	auipc	s4,0x1b
    80003060:	e14a0a13          	addi	s4,s4,-492 # 8001de70 <sb>
    80003064:	0049559b          	srliw	a1,s2,0x4
    80003068:	018a2783          	lw	a5,24(s4)
    8000306c:	9dbd                	addw	a1,a1,a5
    8000306e:	8556                	mv	a0,s5
    80003070:	a7dff0ef          	jal	80002aec <_Z5breadjj>
    80003074:	84aa                	mv	s1,a0
    dip = (struct dinode *)bp->data + inum % IPB;
    80003076:	05850993          	addi	s3,a0,88
    8000307a:	00f97793          	andi	a5,s2,15
    8000307e:	079a                	slli	a5,a5,0x6
    80003080:	99be                	add	s3,s3,a5
    if (dip->type == 0) { // a free inode
    80003082:	00099783          	lh	a5,0(s3)
    80003086:	cb8d                	beqz	a5,800030b8 <_Z6iallocjs+0x84>
    brelse(bp);
    80003088:	b6dff0ef          	jal	80002bf4 <_Z6brelseP3buf>
  for (inum = 1; inum < sb.ninodes; inum++) {
    8000308c:	2905                	addiw	s2,s2,1
    8000308e:	00ca2783          	lw	a5,12(s4)
    80003092:	fcf969e3          	bltu	s2,a5,80003064 <_Z6iallocjs+0x30>
    80003096:	74a2                	ld	s1,40(sp)
    80003098:	7902                	ld	s2,32(sp)
    8000309a:	69e2                	ld	s3,24(sp)
    8000309c:	6a42                	ld	s4,16(sp)
    8000309e:	6aa2                	ld	s5,8(sp)
    800030a0:	6b02                	ld	s6,0(sp)
  printk("ialloc: no inodes\n");
    800030a2:	00004517          	auipc	a0,0x4
    800030a6:	38e50513          	addi	a0,a0,910 # 80007430 <etext+0x430>
    800030aa:	c48fd0ef          	jal	800004f2 <_Z6printkPKcz>
  return 0;
    800030ae:	4501                	li	a0,0
}
    800030b0:	70e2                	ld	ra,56(sp)
    800030b2:	7442                	ld	s0,48(sp)
    800030b4:	6121                	addi	sp,sp,64
    800030b6:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800030b8:	04000613          	li	a2,64
    800030bc:	4581                	li	a1,0
    800030be:	854e                	mv	a0,s3
    800030c0:	bc5fd0ef          	jal	80000c84 <_Z6memsetPvij>
      dip->type = type;
    800030c4:	01699023          	sh	s6,0(s3)
      log_write(bp); // mark it allocated on the disk
    800030c8:	8526                	mv	a0,s1
    800030ca:	481000ef          	jal	80003d4a <_Z9log_writeP3buf>
      brelse(bp);
    800030ce:	8526                	mv	a0,s1
    800030d0:	b25ff0ef          	jal	80002bf4 <_Z6brelseP3buf>
      return iget(dev, inum);
    800030d4:	85ca                	mv	a1,s2
    800030d6:	8556                	mv	a0,s5
    800030d8:	e59ff0ef          	jal	80002f30 <_ZL4igetjj>
    800030dc:	74a2                	ld	s1,40(sp)
    800030de:	7902                	ld	s2,32(sp)
    800030e0:	69e2                	ld	s3,24(sp)
    800030e2:	6a42                	ld	s4,16(sp)
    800030e4:	6aa2                	ld	s5,8(sp)
    800030e6:	6b02                	ld	s6,0(sp)
    800030e8:	b7e1                	j	800030b0 <_Z6iallocjs+0x7c>

00000000800030ea <_Z7iupdateP5inode>:
{
    800030ea:	1101                	addi	sp,sp,-32
    800030ec:	ec06                	sd	ra,24(sp)
    800030ee:	e822                	sd	s0,16(sp)
    800030f0:	e426                	sd	s1,8(sp)
    800030f2:	e04a                	sd	s2,0(sp)
    800030f4:	1000                	addi	s0,sp,32
    800030f6:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800030f8:	415c                	lw	a5,4(a0)
    800030fa:	0047d79b          	srliw	a5,a5,0x4
    800030fe:	0001b597          	auipc	a1,0x1b
    80003102:	d8a5a583          	lw	a1,-630(a1) # 8001de88 <sb+0x18>
    80003106:	9dbd                	addw	a1,a1,a5
    80003108:	4108                	lw	a0,0(a0)
    8000310a:	9e3ff0ef          	jal	80002aec <_Z5breadjj>
    8000310e:	892a                	mv	s2,a0
  dip = (struct dinode *)bp->data + ip->inum % IPB;
    80003110:	05850793          	addi	a5,a0,88
    80003114:	40d8                	lw	a4,4(s1)
    80003116:	8b3d                	andi	a4,a4,15
    80003118:	071a                	slli	a4,a4,0x6
    8000311a:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    8000311c:	04449703          	lh	a4,68(s1)
    80003120:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80003124:	04649703          	lh	a4,70(s1)
    80003128:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    8000312c:	04849703          	lh	a4,72(s1)
    80003130:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80003134:	04a49703          	lh	a4,74(s1)
    80003138:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    8000313c:	44f8                	lw	a4,76(s1)
    8000313e:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80003140:	03400613          	li	a2,52
    80003144:	05048593          	addi	a1,s1,80
    80003148:	00c78513          	addi	a0,a5,12
    8000314c:	b95fd0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
  log_write(bp);
    80003150:	854a                	mv	a0,s2
    80003152:	3f9000ef          	jal	80003d4a <_Z9log_writeP3buf>
  brelse(bp);
    80003156:	854a                	mv	a0,s2
    80003158:	a9dff0ef          	jal	80002bf4 <_Z6brelseP3buf>
}
    8000315c:	60e2                	ld	ra,24(sp)
    8000315e:	6442                	ld	s0,16(sp)
    80003160:	64a2                	ld	s1,8(sp)
    80003162:	6902                	ld	s2,0(sp)
    80003164:	6105                	addi	sp,sp,32
    80003166:	8082                	ret

0000000080003168 <_Z4idupP5inode>:
{
    80003168:	1101                	addi	sp,sp,-32
    8000316a:	ec06                	sd	ra,24(sp)
    8000316c:	e822                	sd	s0,16(sp)
    8000316e:	e426                	sd	s1,8(sp)
    80003170:	1000                	addi	s0,sp,32
    80003172:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003174:	0001b517          	auipc	a0,0x1b
    80003178:	d1c50513          	addi	a0,a0,-740 # 8001de90 <itable>
    8000317c:	a45fd0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  ip->ref++;
    80003180:	449c                	lw	a5,8(s1)
    80003182:	2785                	addiw	a5,a5,1
    80003184:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003186:	0001b517          	auipc	a0,0x1b
    8000318a:	d0a50513          	addi	a0,a0,-758 # 8001de90 <itable>
    8000318e:	abffd0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80003192:	8526                	mv	a0,s1
    80003194:	60e2                	ld	ra,24(sp)
    80003196:	6442                	ld	s0,16(sp)
    80003198:	64a2                	ld	s1,8(sp)
    8000319a:	6105                	addi	sp,sp,32
    8000319c:	8082                	ret

000000008000319e <_Z5ilockP5inode>:
{
    8000319e:	1101                	addi	sp,sp,-32
    800031a0:	ec06                	sd	ra,24(sp)
    800031a2:	e822                	sd	s0,16(sp)
    800031a4:	e426                	sd	s1,8(sp)
    800031a6:	1000                	addi	s0,sp,32
  if (ip == 0 || ip->ref < 1)
    800031a8:	cd19                	beqz	a0,800031c6 <_Z5ilockP5inode+0x28>
    800031aa:	84aa                	mv	s1,a0
    800031ac:	451c                	lw	a5,8(a0)
    800031ae:	00f05c63          	blez	a5,800031c6 <_Z5ilockP5inode+0x28>
  acquiresleep(&ip->lock);
    800031b2:	0541                	addi	a0,a0,16
    800031b4:	4f1000ef          	jal	80003ea4 <_Z12acquiresleepP9sleeplock>
  if (ip->valid == 0) {
    800031b8:	40bc                	lw	a5,64(s1)
    800031ba:	cf89                	beqz	a5,800031d4 <_Z5ilockP5inode+0x36>
}
    800031bc:	60e2                	ld	ra,24(sp)
    800031be:	6442                	ld	s0,16(sp)
    800031c0:	64a2                	ld	s1,8(sp)
    800031c2:	6105                	addi	sp,sp,32
    800031c4:	8082                	ret
    800031c6:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800031c8:	00004517          	auipc	a0,0x4
    800031cc:	28050513          	addi	a0,a0,640 # 80007448 <etext+0x448>
    800031d0:	e22fd0ef          	jal	800007f2 <_Z5panicPKc>
    800031d4:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800031d6:	40dc                	lw	a5,4(s1)
    800031d8:	0047d79b          	srliw	a5,a5,0x4
    800031dc:	0001b597          	auipc	a1,0x1b
    800031e0:	cac5a583          	lw	a1,-852(a1) # 8001de88 <sb+0x18>
    800031e4:	9dbd                	addw	a1,a1,a5
    800031e6:	4088                	lw	a0,0(s1)
    800031e8:	905ff0ef          	jal	80002aec <_Z5breadjj>
    800031ec:	892a                	mv	s2,a0
    dip = (struct dinode *)bp->data + ip->inum % IPB;
    800031ee:	05850593          	addi	a1,a0,88
    800031f2:	40dc                	lw	a5,4(s1)
    800031f4:	8bbd                	andi	a5,a5,15
    800031f6:	079a                	slli	a5,a5,0x6
    800031f8:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800031fa:	00059783          	lh	a5,0(a1)
    800031fe:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80003202:	00259783          	lh	a5,2(a1)
    80003206:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    8000320a:	00459783          	lh	a5,4(a1)
    8000320e:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80003212:	00659783          	lh	a5,6(a1)
    80003216:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    8000321a:	459c                	lw	a5,8(a1)
    8000321c:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    8000321e:	03400613          	li	a2,52
    80003222:	05b1                	addi	a1,a1,12
    80003224:	05048513          	addi	a0,s1,80
    80003228:	ab9fd0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
    brelse(bp);
    8000322c:	854a                	mv	a0,s2
    8000322e:	9c7ff0ef          	jal	80002bf4 <_Z6brelseP3buf>
    ip->valid = 1;
    80003232:	4785                	li	a5,1
    80003234:	c0bc                	sw	a5,64(s1)
    if (ip->type == 0)
    80003236:	04449783          	lh	a5,68(s1)
    8000323a:	c399                	beqz	a5,80003240 <_Z5ilockP5inode+0xa2>
    8000323c:	6902                	ld	s2,0(sp)
    8000323e:	bfbd                	j	800031bc <_Z5ilockP5inode+0x1e>
      panic("ilock: no type");
    80003240:	00004517          	auipc	a0,0x4
    80003244:	21050513          	addi	a0,a0,528 # 80007450 <etext+0x450>
    80003248:	daafd0ef          	jal	800007f2 <_Z5panicPKc>

000000008000324c <_Z7iunlockP5inode>:
{
    8000324c:	1101                	addi	sp,sp,-32
    8000324e:	ec06                	sd	ra,24(sp)
    80003250:	e822                	sd	s0,16(sp)
    80003252:	e426                	sd	s1,8(sp)
    80003254:	e04a                	sd	s2,0(sp)
    80003256:	1000                	addi	s0,sp,32
  if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003258:	c505                	beqz	a0,80003280 <_Z7iunlockP5inode+0x34>
    8000325a:	84aa                	mv	s1,a0
    8000325c:	01050913          	addi	s2,a0,16
    80003260:	854a                	mv	a0,s2
    80003262:	4c1000ef          	jal	80003f22 <_Z12holdingsleepPK9sleeplock>
    80003266:	cd09                	beqz	a0,80003280 <_Z7iunlockP5inode+0x34>
    80003268:	449c                	lw	a5,8(s1)
    8000326a:	00f05b63          	blez	a5,80003280 <_Z7iunlockP5inode+0x34>
  releasesleep(&ip->lock);
    8000326e:	854a                	mv	a0,s2
    80003270:	47b000ef          	jal	80003eea <_Z12releasesleepP9sleeplock>
}
    80003274:	60e2                	ld	ra,24(sp)
    80003276:	6442                	ld	s0,16(sp)
    80003278:	64a2                	ld	s1,8(sp)
    8000327a:	6902                	ld	s2,0(sp)
    8000327c:	6105                	addi	sp,sp,32
    8000327e:	8082                	ret
    panic("iunlock");
    80003280:	00004517          	auipc	a0,0x4
    80003284:	1e050513          	addi	a0,a0,480 # 80007460 <etext+0x460>
    80003288:	d6afd0ef          	jal	800007f2 <_Z5panicPKc>

000000008000328c <_Z6itruncP5inode>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    8000328c:	7179                	addi	sp,sp,-48
    8000328e:	f406                	sd	ra,40(sp)
    80003290:	f022                	sd	s0,32(sp)
    80003292:	ec26                	sd	s1,24(sp)
    80003294:	e84a                	sd	s2,16(sp)
    80003296:	e44e                	sd	s3,8(sp)
    80003298:	1800                	addi	s0,sp,48
    8000329a:	89aa                	mv	s3,a0
  uint i, j;
  struct buf *bp;
  uint *a;

  for (i = 0; i < NDIRECT; i++) {
    8000329c:	05050493          	addi	s1,a0,80
    800032a0:	08050913          	addi	s2,a0,128
    800032a4:	a021                	j	800032ac <_Z6itruncP5inode+0x20>
    800032a6:	0491                	addi	s1,s1,4
    800032a8:	01248b63          	beq	s1,s2,800032be <_Z6itruncP5inode+0x32>
    if (ip->addrs[i]) {
    800032ac:	408c                	lw	a1,0(s1)
    800032ae:	dde5                	beqz	a1,800032a6 <_Z6itruncP5inode+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    800032b0:	0009a503          	lw	a0,0(s3)
    800032b4:	a31ff0ef          	jal	80002ce4 <_ZL5bfreeij>
      ip->addrs[i] = 0;
    800032b8:	0004a023          	sw	zero,0(s1)
    800032bc:	b7ed                	j	800032a6 <_Z6itruncP5inode+0x1a>
    }
  }

  if (ip->addrs[NDIRECT]) {
    800032be:	0809a583          	lw	a1,128(s3)
    800032c2:	ed89                	bnez	a1,800032dc <_Z6itruncP5inode+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800032c4:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800032c8:	854e                	mv	a0,s3
    800032ca:	e21ff0ef          	jal	800030ea <_Z7iupdateP5inode>
}
    800032ce:	70a2                	ld	ra,40(sp)
    800032d0:	7402                	ld	s0,32(sp)
    800032d2:	64e2                	ld	s1,24(sp)
    800032d4:	6942                	ld	s2,16(sp)
    800032d6:	69a2                	ld	s3,8(sp)
    800032d8:	6145                	addi	sp,sp,48
    800032da:	8082                	ret
    800032dc:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800032de:	0009a503          	lw	a0,0(s3)
    800032e2:	80bff0ef          	jal	80002aec <_Z5breadjj>
    800032e6:	8a2a                	mv	s4,a0
    for (j = 0; j < NINDIRECT; j++) {
    800032e8:	05850493          	addi	s1,a0,88
    800032ec:	45850913          	addi	s2,a0,1112
    800032f0:	a021                	j	800032f8 <_Z6itruncP5inode+0x6c>
    800032f2:	0491                	addi	s1,s1,4
    800032f4:	01248963          	beq	s1,s2,80003306 <_Z6itruncP5inode+0x7a>
      if (a[j])
    800032f8:	408c                	lw	a1,0(s1)
    800032fa:	dde5                	beqz	a1,800032f2 <_Z6itruncP5inode+0x66>
        bfree(ip->dev, a[j]);
    800032fc:	0009a503          	lw	a0,0(s3)
    80003300:	9e5ff0ef          	jal	80002ce4 <_ZL5bfreeij>
    80003304:	b7fd                	j	800032f2 <_Z6itruncP5inode+0x66>
    brelse(bp);
    80003306:	8552                	mv	a0,s4
    80003308:	8edff0ef          	jal	80002bf4 <_Z6brelseP3buf>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    8000330c:	0809a583          	lw	a1,128(s3)
    80003310:	0009a503          	lw	a0,0(s3)
    80003314:	9d1ff0ef          	jal	80002ce4 <_ZL5bfreeij>
    ip->addrs[NDIRECT] = 0;
    80003318:	0809a023          	sw	zero,128(s3)
    8000331c:	6a02                	ld	s4,0(sp)
    8000331e:	b75d                	j	800032c4 <_Z6itruncP5inode+0x38>

0000000080003320 <_Z4iputP5inode>:
{
    80003320:	1101                	addi	sp,sp,-32
    80003322:	ec06                	sd	ra,24(sp)
    80003324:	e822                	sd	s0,16(sp)
    80003326:	e426                	sd	s1,8(sp)
    80003328:	1000                	addi	s0,sp,32
    8000332a:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000332c:	0001b517          	auipc	a0,0x1b
    80003330:	b6450513          	addi	a0,a0,-1180 # 8001de90 <itable>
    80003334:	88dfd0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  if (ip->ref == 1 && ip->valid && ip->nlink == 0) {
    80003338:	4498                	lw	a4,8(s1)
    8000333a:	4785                	li	a5,1
    8000333c:	02f70063          	beq	a4,a5,8000335c <_Z4iputP5inode+0x3c>
  ip->ref--;
    80003340:	449c                	lw	a5,8(s1)
    80003342:	37fd                	addiw	a5,a5,-1
    80003344:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003346:	0001b517          	auipc	a0,0x1b
    8000334a:	b4a50513          	addi	a0,a0,-1206 # 8001de90 <itable>
    8000334e:	8fffd0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80003352:	60e2                	ld	ra,24(sp)
    80003354:	6442                	ld	s0,16(sp)
    80003356:	64a2                	ld	s1,8(sp)
    80003358:	6105                	addi	sp,sp,32
    8000335a:	8082                	ret
  if (ip->ref == 1 && ip->valid && ip->nlink == 0) {
    8000335c:	40bc                	lw	a5,64(s1)
    8000335e:	d3ed                	beqz	a5,80003340 <_Z4iputP5inode+0x20>
    80003360:	04a49783          	lh	a5,74(s1)
    80003364:	fff1                	bnez	a5,80003340 <_Z4iputP5inode+0x20>
    80003366:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80003368:	01048913          	addi	s2,s1,16
    8000336c:	854a                	mv	a0,s2
    8000336e:	337000ef          	jal	80003ea4 <_Z12acquiresleepP9sleeplock>
    release(&itable.lock);
    80003372:	0001b517          	auipc	a0,0x1b
    80003376:	b1e50513          	addi	a0,a0,-1250 # 8001de90 <itable>
    8000337a:	8d3fd0ef          	jal	80000c4c <_Z7releaseP8spinlock>
    itrunc(ip);
    8000337e:	8526                	mv	a0,s1
    80003380:	f0dff0ef          	jal	8000328c <_Z6itruncP5inode>
    ip->type = 0;
    80003384:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80003388:	8526                	mv	a0,s1
    8000338a:	d61ff0ef          	jal	800030ea <_Z7iupdateP5inode>
    ip->valid = 0;
    8000338e:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80003392:	854a                	mv	a0,s2
    80003394:	357000ef          	jal	80003eea <_Z12releasesleepP9sleeplock>
    acquire(&itable.lock);
    80003398:	0001b517          	auipc	a0,0x1b
    8000339c:	af850513          	addi	a0,a0,-1288 # 8001de90 <itable>
    800033a0:	821fd0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
    800033a4:	6902                	ld	s2,0(sp)
    800033a6:	bf69                	j	80003340 <_Z4iputP5inode+0x20>

00000000800033a8 <_Z10iunlockputP5inode>:
{
    800033a8:	1101                	addi	sp,sp,-32
    800033aa:	ec06                	sd	ra,24(sp)
    800033ac:	e822                	sd	s0,16(sp)
    800033ae:	e426                	sd	s1,8(sp)
    800033b0:	1000                	addi	s0,sp,32
    800033b2:	84aa                	mv	s1,a0
  iunlock(ip);
    800033b4:	e99ff0ef          	jal	8000324c <_Z7iunlockP5inode>
  iput(ip);
    800033b8:	8526                	mv	a0,s1
    800033ba:	f67ff0ef          	jal	80003320 <_Z4iputP5inode>
}
    800033be:	60e2                	ld	ra,24(sp)
    800033c0:	6442                	ld	s0,16(sp)
    800033c2:	64a2                	ld	s1,8(sp)
    800033c4:	6105                	addi	sp,sp,32
    800033c6:	8082                	ret

00000000800033c8 <_Z8ireclaimj>:
  for (uint inum = 1; inum < sb.ninodes; inum++) {
    800033c8:	0001b717          	auipc	a4,0x1b
    800033cc:	ab472703          	lw	a4,-1356(a4) # 8001de7c <sb+0xc>
    800033d0:	4785                	li	a5,1
    800033d2:	0ae7fa63          	bgeu	a5,a4,80003486 <_Z8ireclaimj+0xbe>
{
    800033d6:	7139                	addi	sp,sp,-64
    800033d8:	fc06                	sd	ra,56(sp)
    800033da:	f822                	sd	s0,48(sp)
    800033dc:	f426                	sd	s1,40(sp)
    800033de:	f04a                	sd	s2,32(sp)
    800033e0:	ec4e                	sd	s3,24(sp)
    800033e2:	e852                	sd	s4,16(sp)
    800033e4:	e456                	sd	s5,8(sp)
    800033e6:	e05a                	sd	s6,0(sp)
    800033e8:	0080                	addi	s0,sp,64
    800033ea:	8a2a                	mv	s4,a0
  for (uint inum = 1; inum < sb.ninodes; inum++) {
    800033ec:	4485                	li	s1,1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800033ee:	0001b997          	auipc	s3,0x1b
    800033f2:	a8298993          	addi	s3,s3,-1406 # 8001de70 <sb>
      printk("ireclaim: orphaned inode %d\n", inum);
    800033f6:	00004a97          	auipc	s5,0x4
    800033fa:	072a8a93          	addi	s5,s5,114 # 80007468 <etext+0x468>
    800033fe:	a089                	j	80003440 <_Z8ireclaimj+0x78>
    80003400:	85a6                	mv	a1,s1
    80003402:	8556                	mv	a0,s5
    80003404:	8eefd0ef          	jal	800004f2 <_Z6printkPKcz>
      ip = iget(dev, inum);
    80003408:	85a6                	mv	a1,s1
    8000340a:	8552                	mv	a0,s4
    8000340c:	b25ff0ef          	jal	80002f30 <_ZL4igetjj>
    80003410:	8b2a                	mv	s6,a0
    brelse(bp);
    80003412:	854a                	mv	a0,s2
    80003414:	fe0ff0ef          	jal	80002bf4 <_Z6brelseP3buf>
    if (ip) {
    80003418:	000b0f63          	beqz	s6,80003436 <_Z8ireclaimj+0x6e>
      begin_op();
    8000341c:	7a4000ef          	jal	80003bc0 <_Z8begin_opv>
      ilock(ip);
    80003420:	855a                	mv	a0,s6
    80003422:	d7dff0ef          	jal	8000319e <_Z5ilockP5inode>
      iunlock(ip);
    80003426:	855a                	mv	a0,s6
    80003428:	e25ff0ef          	jal	8000324c <_Z7iunlockP5inode>
      iput(ip);
    8000342c:	855a                	mv	a0,s6
    8000342e:	ef3ff0ef          	jal	80003320 <_Z4iputP5inode>
      end_op();
    80003432:	7f8000ef          	jal	80003c2a <_Z6end_opv>
  for (uint inum = 1; inum < sb.ninodes; inum++) {
    80003436:	2485                	addiw	s1,s1,1
    80003438:	00c9a783          	lw	a5,12(s3)
    8000343c:	02f4fb63          	bgeu	s1,a5,80003472 <_Z8ireclaimj+0xaa>
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003440:	0044d59b          	srliw	a1,s1,0x4
    80003444:	0189a783          	lw	a5,24(s3)
    80003448:	9dbd                	addw	a1,a1,a5
    8000344a:	8552                	mv	a0,s4
    8000344c:	ea0ff0ef          	jal	80002aec <_Z5breadjj>
    80003450:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    80003452:	05850793          	addi	a5,a0,88
    80003456:	00f4f713          	andi	a4,s1,15
    8000345a:	071a                	slli	a4,a4,0x6
    8000345c:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) { // is an orphaned inode
    8000345e:	00079703          	lh	a4,0(a5)
    80003462:	c701                	beqz	a4,8000346a <_Z8ireclaimj+0xa2>
    80003464:	00679783          	lh	a5,6(a5)
    80003468:	dfc1                	beqz	a5,80003400 <_Z8ireclaimj+0x38>
    brelse(bp);
    8000346a:	854a                	mv	a0,s2
    8000346c:	f88ff0ef          	jal	80002bf4 <_Z6brelseP3buf>
    if (ip) {
    80003470:	b7d9                	j	80003436 <_Z8ireclaimj+0x6e>
}
    80003472:	70e2                	ld	ra,56(sp)
    80003474:	7442                	ld	s0,48(sp)
    80003476:	74a2                	ld	s1,40(sp)
    80003478:	7902                	ld	s2,32(sp)
    8000347a:	69e2                	ld	s3,24(sp)
    8000347c:	6a42                	ld	s4,16(sp)
    8000347e:	6aa2                	ld	s5,8(sp)
    80003480:	6b02                	ld	s6,0(sp)
    80003482:	6121                	addi	sp,sp,64
    80003484:	8082                	ret
    80003486:	8082                	ret

0000000080003488 <_Z6fsiniti>:
{
    80003488:	7179                	addi	sp,sp,-48
    8000348a:	f406                	sd	ra,40(sp)
    8000348c:	f022                	sd	s0,32(sp)
    8000348e:	ec26                	sd	s1,24(sp)
    80003490:	e84a                	sd	s2,16(sp)
    80003492:	e44e                	sd	s3,8(sp)
    80003494:	e052                	sd	s4,0(sp)
    80003496:	1800                	addi	s0,sp,48
    80003498:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    8000349a:	00050a1b          	sext.w	s4,a0
    8000349e:	4585                	li	a1,1
    800034a0:	8552                	mv	a0,s4
    800034a2:	e4aff0ef          	jal	80002aec <_Z5breadjj>
    800034a6:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    800034a8:	0001b997          	auipc	s3,0x1b
    800034ac:	9c898993          	addi	s3,s3,-1592 # 8001de70 <sb>
    800034b0:	02000613          	li	a2,32
    800034b4:	05850593          	addi	a1,a0,88
    800034b8:	854e                	mv	a0,s3
    800034ba:	827fd0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
  brelse(bp);
    800034be:	8526                	mv	a0,s1
    800034c0:	f34ff0ef          	jal	80002bf4 <_Z6brelseP3buf>
  if (sb.magic != FSMAGIC)
    800034c4:	0009a703          	lw	a4,0(s3)
    800034c8:	102037b7          	lui	a5,0x10203
    800034cc:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    800034d0:	02f71463          	bne	a4,a5,800034f8 <_Z6fsiniti+0x70>
  initlog(dev, &sb);
    800034d4:	0001b597          	auipc	a1,0x1b
    800034d8:	99c58593          	addi	a1,a1,-1636 # 8001de70 <sb>
    800034dc:	854a                	mv	a0,s2
    800034de:	664000ef          	jal	80003b42 <_Z7initlogiP10superblock>
  ireclaim(dev);
    800034e2:	8552                	mv	a0,s4
    800034e4:	ee5ff0ef          	jal	800033c8 <_Z8ireclaimj>
}
    800034e8:	70a2                	ld	ra,40(sp)
    800034ea:	7402                	ld	s0,32(sp)
    800034ec:	64e2                	ld	s1,24(sp)
    800034ee:	6942                	ld	s2,16(sp)
    800034f0:	69a2                	ld	s3,8(sp)
    800034f2:	6a02                	ld	s4,0(sp)
    800034f4:	6145                	addi	sp,sp,48
    800034f6:	8082                	ret
    panic("invalid file system");
    800034f8:	00004517          	auipc	a0,0x4
    800034fc:	f9050513          	addi	a0,a0,-112 # 80007488 <etext+0x488>
    80003500:	af2fd0ef          	jal	800007f2 <_Z5panicPKc>

0000000080003504 <_Z5statiP5inodeP4stat>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003504:	1141                	addi	sp,sp,-16
    80003506:	e422                	sd	s0,8(sp)
    80003508:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    8000350a:	411c                	lw	a5,0(a0)
    8000350c:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    8000350e:	415c                	lw	a5,4(a0)
    80003510:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003512:	04451783          	lh	a5,68(a0)
    80003516:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    8000351a:	04a51783          	lh	a5,74(a0)
    8000351e:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003522:	04c56783          	lwu	a5,76(a0)
    80003526:	e99c                	sd	a5,16(a1)
}
    80003528:	6422                	ld	s0,8(sp)
    8000352a:	0141                	addi	sp,sp,16
    8000352c:	8082                	ret

000000008000352e <_Z5readiP5inodeimjj>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    8000352e:	457c                	lw	a5,76(a0)
    80003530:	0ed7eb63          	bltu	a5,a3,80003626 <_Z5readiP5inodeimjj+0xf8>
{
    80003534:	7159                	addi	sp,sp,-112
    80003536:	f486                	sd	ra,104(sp)
    80003538:	f0a2                	sd	s0,96(sp)
    8000353a:	eca6                	sd	s1,88(sp)
    8000353c:	e0d2                	sd	s4,64(sp)
    8000353e:	fc56                	sd	s5,56(sp)
    80003540:	f85a                	sd	s6,48(sp)
    80003542:	f45e                	sd	s7,40(sp)
    80003544:	1880                	addi	s0,sp,112
    80003546:	8b2a                	mv	s6,a0
    80003548:	8bae                	mv	s7,a1
    8000354a:	8a32                	mv	s4,a2
    8000354c:	84b6                	mv	s1,a3
    8000354e:	8aba                	mv	s5,a4
  if (off > ip->size || off + n < off)
    80003550:	9f35                	addw	a4,a4,a3
    return 0;
    80003552:	4501                	li	a0,0
  if (off > ip->size || off + n < off)
    80003554:	0cd76063          	bltu	a4,a3,80003614 <_Z5readiP5inodeimjj+0xe6>
    80003558:	e4ce                	sd	s3,72(sp)
  if (off + n > ip->size)
    8000355a:	00e7f463          	bgeu	a5,a4,80003562 <_Z5readiP5inodeimjj+0x34>
    n = ip->size - off;
    8000355e:	40d78abb          	subw	s5,a5,a3

  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003562:	080a8f63          	beqz	s5,80003600 <_Z5readiP5inodeimjj+0xd2>
    80003566:	e8ca                	sd	s2,80(sp)
    80003568:	f062                	sd	s8,32(sp)
    8000356a:	ec66                	sd	s9,24(sp)
    8000356c:	e86a                	sd	s10,16(sp)
    8000356e:	e46e                	sd	s11,8(sp)
    80003570:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    80003572:	40000c93          	li	s9,1024
    if (either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003576:	5c7d                	li	s8,-1
    80003578:	a80d                	j	800035aa <_Z5readiP5inodeimjj+0x7c>
    8000357a:	020d1d93          	slli	s11,s10,0x20
    8000357e:	020ddd93          	srli	s11,s11,0x20
    80003582:	05890613          	addi	a2,s2,88
    80003586:	86ee                	mv	a3,s11
    80003588:	963a                	add	a2,a2,a4
    8000358a:	85d2                	mv	a1,s4
    8000358c:	855e                	mv	a0,s7
    8000358e:	c8ffe0ef          	jal	8000221c <_Z14either_copyoutimPKvm>
    80003592:	05850763          	beq	a0,s8,800035e0 <_Z5readiP5inodeimjj+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003596:	854a                	mv	a0,s2
    80003598:	e5cff0ef          	jal	80002bf4 <_Z6brelseP3buf>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    8000359c:	013d09bb          	addw	s3,s10,s3
    800035a0:	009d04bb          	addw	s1,s10,s1
    800035a4:	9a6e                	add	s4,s4,s11
    800035a6:	0559f763          	bgeu	s3,s5,800035f4 <_Z5readiP5inodeimjj+0xc6>
    uint addr = bmap(ip, off / BSIZE);
    800035aa:	00a4d59b          	srliw	a1,s1,0xa
    800035ae:	855a                	mv	a0,s6
    800035b0:	8adff0ef          	jal	80002e5c <_ZL4bmapP5inodej>
    800035b4:	0005059b          	sext.w	a1,a0
    if (addr == 0)
    800035b8:	c5b1                	beqz	a1,80003604 <_Z5readiP5inodeimjj+0xd6>
    bp = bread(ip->dev, addr);
    800035ba:	000b2503          	lw	a0,0(s6)
    800035be:	d2eff0ef          	jal	80002aec <_Z5breadjj>
    800035c2:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    800035c4:	3ff4f713          	andi	a4,s1,1023
    800035c8:	40ec87bb          	subw	a5,s9,a4
    800035cc:	413a86bb          	subw	a3,s5,s3
    800035d0:	8d3e                	mv	s10,a5
    800035d2:	2781                	sext.w	a5,a5
    800035d4:	0006861b          	sext.w	a2,a3
    800035d8:	faf671e3          	bgeu	a2,a5,8000357a <_Z5readiP5inodeimjj+0x4c>
    800035dc:	8d36                	mv	s10,a3
    800035de:	bf71                	j	8000357a <_Z5readiP5inodeimjj+0x4c>
      brelse(bp);
    800035e0:	854a                	mv	a0,s2
    800035e2:	e12ff0ef          	jal	80002bf4 <_Z6brelseP3buf>
      tot = -1;
    800035e6:	59fd                	li	s3,-1
      break;
    800035e8:	6946                	ld	s2,80(sp)
    800035ea:	7c02                	ld	s8,32(sp)
    800035ec:	6ce2                	ld	s9,24(sp)
    800035ee:	6d42                	ld	s10,16(sp)
    800035f0:	6da2                	ld	s11,8(sp)
    800035f2:	a831                	j	8000360e <_Z5readiP5inodeimjj+0xe0>
    800035f4:	6946                	ld	s2,80(sp)
    800035f6:	7c02                	ld	s8,32(sp)
    800035f8:	6ce2                	ld	s9,24(sp)
    800035fa:	6d42                	ld	s10,16(sp)
    800035fc:	6da2                	ld	s11,8(sp)
    800035fe:	a801                	j	8000360e <_Z5readiP5inodeimjj+0xe0>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003600:	89d6                	mv	s3,s5
    80003602:	a031                	j	8000360e <_Z5readiP5inodeimjj+0xe0>
    80003604:	6946                	ld	s2,80(sp)
    80003606:	7c02                	ld	s8,32(sp)
    80003608:	6ce2                	ld	s9,24(sp)
    8000360a:	6d42                	ld	s10,16(sp)
    8000360c:	6da2                	ld	s11,8(sp)
  }
  return tot;
    8000360e:	0009851b          	sext.w	a0,s3
    80003612:	69a6                	ld	s3,72(sp)
}
    80003614:	70a6                	ld	ra,104(sp)
    80003616:	7406                	ld	s0,96(sp)
    80003618:	64e6                	ld	s1,88(sp)
    8000361a:	6a06                	ld	s4,64(sp)
    8000361c:	7ae2                	ld	s5,56(sp)
    8000361e:	7b42                	ld	s6,48(sp)
    80003620:	7ba2                	ld	s7,40(sp)
    80003622:	6165                	addi	sp,sp,112
    80003624:	8082                	ret
    return 0;
    80003626:	4501                	li	a0,0
}
    80003628:	8082                	ret

000000008000362a <_Z6writeiP5inodeimjj>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    8000362a:	457c                	lw	a5,76(a0)
    8000362c:	10d7e363          	bltu	a5,a3,80003732 <_Z6writeiP5inodeimjj+0x108>
{
    80003630:	7159                	addi	sp,sp,-112
    80003632:	f486                	sd	ra,104(sp)
    80003634:	f0a2                	sd	s0,96(sp)
    80003636:	e8ca                	sd	s2,80(sp)
    80003638:	e0d2                	sd	s4,64(sp)
    8000363a:	fc56                	sd	s5,56(sp)
    8000363c:	f85a                	sd	s6,48(sp)
    8000363e:	f45e                	sd	s7,40(sp)
    80003640:	1880                	addi	s0,sp,112
    80003642:	8aaa                	mv	s5,a0
    80003644:	8bae                	mv	s7,a1
    80003646:	8a32                	mv	s4,a2
    80003648:	8936                	mv	s2,a3
    8000364a:	8b3a                	mv	s6,a4
  if (off > ip->size || off + n < off)
    8000364c:	00e687bb          	addw	a5,a3,a4
    80003650:	0ed7e363          	bltu	a5,a3,80003736 <_Z6writeiP5inodeimjj+0x10c>
    return -1;
  if (off + n > MAXFILE * BSIZE)
    80003654:	00043737          	lui	a4,0x43
    80003658:	0ef76163          	bltu	a4,a5,8000373a <_Z6writeiP5inodeimjj+0x110>
    8000365c:	e4ce                	sd	s3,72(sp)
    return -1;

  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    8000365e:	0c0b0263          	beqz	s6,80003722 <_Z6writeiP5inodeimjj+0xf8>
    80003662:	eca6                	sd	s1,88(sp)
    80003664:	f062                	sd	s8,32(sp)
    80003666:	ec66                	sd	s9,24(sp)
    80003668:	e86a                	sd	s10,16(sp)
    8000366a:	e46e                	sd	s11,8(sp)
    8000366c:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    8000366e:	40000c93          	li	s9,1024
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003672:	5c7d                	li	s8,-1
    80003674:	a825                	j	800036ac <_Z6writeiP5inodeimjj+0x82>
    80003676:	020d1d93          	slli	s11,s10,0x20
    8000367a:	020ddd93          	srli	s11,s11,0x20
    8000367e:	05848513          	addi	a0,s1,88
    80003682:	86ee                	mv	a3,s11
    80003684:	8652                	mv	a2,s4
    80003686:	85de                	mv	a1,s7
    80003688:	953a                	add	a0,a0,a4
    8000368a:	bddfe0ef          	jal	80002266 <_Z13either_copyinPvimm>
    8000368e:	05850a63          	beq	a0,s8,800036e2 <_Z6writeiP5inodeimjj+0xb8>
      // Might have partially updated the block, so we need to log it.
      log_write(bp);
      brelse(bp);
      break;
    }
    log_write(bp);
    80003692:	8526                	mv	a0,s1
    80003694:	6b6000ef          	jal	80003d4a <_Z9log_writeP3buf>
    brelse(bp);
    80003698:	8526                	mv	a0,s1
    8000369a:	d5aff0ef          	jal	80002bf4 <_Z6brelseP3buf>
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    8000369e:	013d09bb          	addw	s3,s10,s3
    800036a2:	012d093b          	addw	s2,s10,s2
    800036a6:	9a6e                	add	s4,s4,s11
    800036a8:	0569f363          	bgeu	s3,s6,800036ee <_Z6writeiP5inodeimjj+0xc4>
    uint addr = bmap(ip, off / BSIZE);
    800036ac:	00a9559b          	srliw	a1,s2,0xa
    800036b0:	8556                	mv	a0,s5
    800036b2:	faaff0ef          	jal	80002e5c <_ZL4bmapP5inodej>
    800036b6:	0005059b          	sext.w	a1,a0
    if (addr == 0)
    800036ba:	c995                	beqz	a1,800036ee <_Z6writeiP5inodeimjj+0xc4>
    bp = bread(ip->dev, addr);
    800036bc:	000aa503          	lw	a0,0(s5)
    800036c0:	c2cff0ef          	jal	80002aec <_Z5breadjj>
    800036c4:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    800036c6:	3ff97713          	andi	a4,s2,1023
    800036ca:	40ec87bb          	subw	a5,s9,a4
    800036ce:	413b06bb          	subw	a3,s6,s3
    800036d2:	8d3e                	mv	s10,a5
    800036d4:	2781                	sext.w	a5,a5
    800036d6:	0006861b          	sext.w	a2,a3
    800036da:	f8f67ee3          	bgeu	a2,a5,80003676 <_Z6writeiP5inodeimjj+0x4c>
    800036de:	8d36                	mv	s10,a3
    800036e0:	bf59                	j	80003676 <_Z6writeiP5inodeimjj+0x4c>
      log_write(bp);
    800036e2:	8526                	mv	a0,s1
    800036e4:	666000ef          	jal	80003d4a <_Z9log_writeP3buf>
      brelse(bp);
    800036e8:	8526                	mv	a0,s1
    800036ea:	d0aff0ef          	jal	80002bf4 <_Z6brelseP3buf>
  }

  if (off > ip->size)
    800036ee:	04caa783          	lw	a5,76(s5)
    800036f2:	0327fa63          	bgeu	a5,s2,80003726 <_Z6writeiP5inodeimjj+0xfc>
    ip->size = off;
    800036f6:	052aa623          	sw	s2,76(s5)
    800036fa:	64e6                	ld	s1,88(sp)
    800036fc:	7c02                	ld	s8,32(sp)
    800036fe:	6ce2                	ld	s9,24(sp)
    80003700:	6d42                	ld	s10,16(sp)
    80003702:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003704:	8556                	mv	a0,s5
    80003706:	9e5ff0ef          	jal	800030ea <_Z7iupdateP5inode>

  return tot;
    8000370a:	0009851b          	sext.w	a0,s3
    8000370e:	69a6                	ld	s3,72(sp)
}
    80003710:	70a6                	ld	ra,104(sp)
    80003712:	7406                	ld	s0,96(sp)
    80003714:	6946                	ld	s2,80(sp)
    80003716:	6a06                	ld	s4,64(sp)
    80003718:	7ae2                	ld	s5,56(sp)
    8000371a:	7b42                	ld	s6,48(sp)
    8000371c:	7ba2                	ld	s7,40(sp)
    8000371e:	6165                	addi	sp,sp,112
    80003720:	8082                	ret
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003722:	89da                	mv	s3,s6
    80003724:	b7c5                	j	80003704 <_Z6writeiP5inodeimjj+0xda>
    80003726:	64e6                	ld	s1,88(sp)
    80003728:	7c02                	ld	s8,32(sp)
    8000372a:	6ce2                	ld	s9,24(sp)
    8000372c:	6d42                	ld	s10,16(sp)
    8000372e:	6da2                	ld	s11,8(sp)
    80003730:	bfd1                	j	80003704 <_Z6writeiP5inodeimjj+0xda>
    return -1;
    80003732:	557d                	li	a0,-1
}
    80003734:	8082                	ret
    return -1;
    80003736:	557d                	li	a0,-1
    80003738:	bfe1                	j	80003710 <_Z6writeiP5inodeimjj+0xe6>
    return -1;
    8000373a:	557d                	li	a0,-1
    8000373c:	bfd1                	j	80003710 <_Z6writeiP5inodeimjj+0xe6>

000000008000373e <_Z7namecmpPKcS0_>:

// Directories

int
namecmp(const char *s, const char *t)
{
    8000373e:	1141                	addi	sp,sp,-16
    80003740:	e406                	sd	ra,8(sp)
    80003742:	e022                	sd	s0,0(sp)
    80003744:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003746:	4639                	li	a2,14
    80003748:	e08fd0ef          	jal	80000d50 <_Z7strncmpPKcS0_j>
}
    8000374c:	60a2                	ld	ra,8(sp)
    8000374e:	6402                	ld	s0,0(sp)
    80003750:	0141                	addi	sp,sp,16
    80003752:	8082                	ret

0000000080003754 <_Z9dirlookupP5inodePKcPj>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode *
dirlookup(struct inode *dp, const char *name, uint *poff)
{
    80003754:	7139                	addi	sp,sp,-64
    80003756:	fc06                	sd	ra,56(sp)
    80003758:	f822                	sd	s0,48(sp)
    8000375a:	f426                	sd	s1,40(sp)
    8000375c:	f04a                	sd	s2,32(sp)
    8000375e:	ec4e                	sd	s3,24(sp)
    80003760:	e852                	sd	s4,16(sp)
    80003762:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if (dp->type != T_DIR)
    80003764:	04451703          	lh	a4,68(a0)
    80003768:	4785                	li	a5,1
    8000376a:	00f71a63          	bne	a4,a5,8000377e <_Z9dirlookupP5inodePKcPj+0x2a>
    8000376e:	892a                	mv	s2,a0
    80003770:	89ae                	mv	s3,a1
    80003772:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003774:	457c                	lw	a5,76(a0)
    80003776:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003778:	4501                	li	a0,0
  for (off = 0; off < dp->size; off += sizeof(de)) {
    8000377a:	e39d                	bnez	a5,800037a0 <_Z9dirlookupP5inodePKcPj+0x4c>
    8000377c:	a095                	j	800037e0 <_Z9dirlookupP5inodePKcPj+0x8c>
    panic("dirlookup not DIR");
    8000377e:	00004517          	auipc	a0,0x4
    80003782:	d2250513          	addi	a0,a0,-734 # 800074a0 <etext+0x4a0>
    80003786:	86cfd0ef          	jal	800007f2 <_Z5panicPKc>
      panic("dirlookup read");
    8000378a:	00004517          	auipc	a0,0x4
    8000378e:	d2e50513          	addi	a0,a0,-722 # 800074b8 <etext+0x4b8>
    80003792:	860fd0ef          	jal	800007f2 <_Z5panicPKc>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003796:	24c1                	addiw	s1,s1,16
    80003798:	04c92783          	lw	a5,76(s2)
    8000379c:	04f4f163          	bgeu	s1,a5,800037de <_Z9dirlookupP5inodePKcPj+0x8a>
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800037a0:	4741                	li	a4,16
    800037a2:	86a6                	mv	a3,s1
    800037a4:	fc040613          	addi	a2,s0,-64
    800037a8:	4581                	li	a1,0
    800037aa:	854a                	mv	a0,s2
    800037ac:	d83ff0ef          	jal	8000352e <_Z5readiP5inodeimjj>
    800037b0:	47c1                	li	a5,16
    800037b2:	fcf51ce3          	bne	a0,a5,8000378a <_Z9dirlookupP5inodePKcPj+0x36>
    if (de.inum == 0)
    800037b6:	fc045783          	lhu	a5,-64(s0)
    800037ba:	dff1                	beqz	a5,80003796 <_Z9dirlookupP5inodePKcPj+0x42>
    if (namecmp(name, de.name) == 0) {
    800037bc:	fc240593          	addi	a1,s0,-62
    800037c0:	854e                	mv	a0,s3
    800037c2:	f7dff0ef          	jal	8000373e <_Z7namecmpPKcS0_>
    800037c6:	f961                	bnez	a0,80003796 <_Z9dirlookupP5inodePKcPj+0x42>
      if (poff)
    800037c8:	000a0463          	beqz	s4,800037d0 <_Z9dirlookupP5inodePKcPj+0x7c>
        *poff = off;
    800037cc:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    800037d0:	fc045583          	lhu	a1,-64(s0)
    800037d4:	00092503          	lw	a0,0(s2)
    800037d8:	f58ff0ef          	jal	80002f30 <_ZL4igetjj>
    800037dc:	a011                	j	800037e0 <_Z9dirlookupP5inodePKcPj+0x8c>
  return 0;
    800037de:	4501                	li	a0,0
}
    800037e0:	70e2                	ld	ra,56(sp)
    800037e2:	7442                	ld	s0,48(sp)
    800037e4:	74a2                	ld	s1,40(sp)
    800037e6:	7902                	ld	s2,32(sp)
    800037e8:	69e2                	ld	s3,24(sp)
    800037ea:	6a42                	ld	s4,16(sp)
    800037ec:	6121                	addi	sp,sp,64
    800037ee:	8082                	ret

00000000800037f0 <_ZL5namexPKciPc>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode *
namex(const char *path, int nameiparent, char *name)
{
    800037f0:	711d                	addi	sp,sp,-96
    800037f2:	ec86                	sd	ra,88(sp)
    800037f4:	e8a2                	sd	s0,80(sp)
    800037f6:	e4a6                	sd	s1,72(sp)
    800037f8:	e0ca                	sd	s2,64(sp)
    800037fa:	fc4e                	sd	s3,56(sp)
    800037fc:	f852                	sd	s4,48(sp)
    800037fe:	f456                	sd	s5,40(sp)
    80003800:	f05a                	sd	s6,32(sp)
    80003802:	ec5e                	sd	s7,24(sp)
    80003804:	e862                	sd	s8,16(sp)
    80003806:	e466                	sd	s9,8(sp)
    80003808:	1080                	addi	s0,sp,96
    8000380a:	84aa                	mv	s1,a0
    8000380c:	8b2e                	mv	s6,a1
    8000380e:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if (*path == '/')
    80003810:	00054703          	lbu	a4,0(a0)
    80003814:	02f00793          	li	a5,47
    80003818:	00f70e63          	beq	a4,a5,80003834 <_ZL5namexPKciPc+0x44>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    8000381c:	89efe0ef          	jal	800018ba <_Z6myprocv>
    80003820:	15053503          	ld	a0,336(a0)
    80003824:	945ff0ef          	jal	80003168 <_Z4idupP5inode>
    80003828:	8a2a                	mv	s4,a0
  while (*path == '/')
    8000382a:	02f00913          	li	s2,47
  if (len >= DIRSIZ)
    8000382e:	4c35                	li	s8,13

  while ((path = skipelem(path, name)) != 0) {
    ilock(ip);
    if (ip->type != T_DIR) {
    80003830:	4b85                	li	s7,1
    80003832:	a871                	j	800038ce <_ZL5namexPKciPc+0xde>
    ip = iget(ROOTDEV, ROOTINO);
    80003834:	4585                	li	a1,1
    80003836:	4505                	li	a0,1
    80003838:	ef8ff0ef          	jal	80002f30 <_ZL4igetjj>
    8000383c:	8a2a                	mv	s4,a0
    8000383e:	b7f5                	j	8000382a <_ZL5namexPKciPc+0x3a>
      iunlockput(ip);
    80003840:	8552                	mv	a0,s4
    80003842:	b67ff0ef          	jal	800033a8 <_Z10iunlockputP5inode>
      return 0;
    80003846:	4a01                	li	s4,0
  if (nameiparent) {
    iput(ip);
    return 0;
  }
  return ip;
}
    80003848:	8552                	mv	a0,s4
    8000384a:	60e6                	ld	ra,88(sp)
    8000384c:	6446                	ld	s0,80(sp)
    8000384e:	64a6                	ld	s1,72(sp)
    80003850:	6906                	ld	s2,64(sp)
    80003852:	79e2                	ld	s3,56(sp)
    80003854:	7a42                	ld	s4,48(sp)
    80003856:	7aa2                	ld	s5,40(sp)
    80003858:	7b02                	ld	s6,32(sp)
    8000385a:	6be2                	ld	s7,24(sp)
    8000385c:	6c42                	ld	s8,16(sp)
    8000385e:	6ca2                	ld	s9,8(sp)
    80003860:	6125                	addi	sp,sp,96
    80003862:	8082                	ret
      iunlock(ip);
    80003864:	8552                	mv	a0,s4
    80003866:	9e7ff0ef          	jal	8000324c <_Z7iunlockP5inode>
      return ip;
    8000386a:	bff9                	j	80003848 <_ZL5namexPKciPc+0x58>
      iunlockput(ip);
    8000386c:	8552                	mv	a0,s4
    8000386e:	b3bff0ef          	jal	800033a8 <_Z10iunlockputP5inode>
      return 0;
    80003872:	8a4e                	mv	s4,s3
    80003874:	bfd1                	j	80003848 <_ZL5namexPKciPc+0x58>
  len = path - s;
    80003876:	40998633          	sub	a2,s3,s1
    8000387a:	00060c9b          	sext.w	s9,a2
  if (len >= DIRSIZ)
    8000387e:	099c5063          	bge	s8,s9,800038fe <_ZL5namexPKciPc+0x10e>
    memmove(name, s, DIRSIZ);
    80003882:	4639                	li	a2,14
    80003884:	85a6                	mv	a1,s1
    80003886:	8556                	mv	a0,s5
    80003888:	c58fd0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
    8000388c:	84ce                	mv	s1,s3
  while (*path == '/')
    8000388e:	0004c783          	lbu	a5,0(s1)
    80003892:	01279763          	bne	a5,s2,800038a0 <_ZL5namexPKciPc+0xb0>
    path++;
    80003896:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003898:	0004c783          	lbu	a5,0(s1)
    8000389c:	ff278de3          	beq	a5,s2,80003896 <_ZL5namexPKciPc+0xa6>
    ilock(ip);
    800038a0:	8552                	mv	a0,s4
    800038a2:	8fdff0ef          	jal	8000319e <_Z5ilockP5inode>
    if (ip->type != T_DIR) {
    800038a6:	044a1783          	lh	a5,68(s4)
    800038aa:	f9779be3          	bne	a5,s7,80003840 <_ZL5namexPKciPc+0x50>
    if (nameiparent && *path == '\0') {
    800038ae:	000b0563          	beqz	s6,800038b8 <_ZL5namexPKciPc+0xc8>
    800038b2:	0004c783          	lbu	a5,0(s1)
    800038b6:	d7dd                	beqz	a5,80003864 <_ZL5namexPKciPc+0x74>
    if ((next = dirlookup(ip, name, 0)) == 0) {
    800038b8:	4601                	li	a2,0
    800038ba:	85d6                	mv	a1,s5
    800038bc:	8552                	mv	a0,s4
    800038be:	e97ff0ef          	jal	80003754 <_Z9dirlookupP5inodePKcPj>
    800038c2:	89aa                	mv	s3,a0
    800038c4:	d545                	beqz	a0,8000386c <_ZL5namexPKciPc+0x7c>
    iunlockput(ip);
    800038c6:	8552                	mv	a0,s4
    800038c8:	ae1ff0ef          	jal	800033a8 <_Z10iunlockputP5inode>
    ip = next;
    800038cc:	8a4e                	mv	s4,s3
  while (*path == '/')
    800038ce:	0004c783          	lbu	a5,0(s1)
    800038d2:	01279763          	bne	a5,s2,800038e0 <_ZL5namexPKciPc+0xf0>
    path++;
    800038d6:	0485                	addi	s1,s1,1
  while (*path == '/')
    800038d8:	0004c783          	lbu	a5,0(s1)
    800038dc:	ff278de3          	beq	a5,s2,800038d6 <_ZL5namexPKciPc+0xe6>
  if (*path == 0)
    800038e0:	cb8d                	beqz	a5,80003912 <_ZL5namexPKciPc+0x122>
  while (*path != '/' && *path != 0)
    800038e2:	0004c783          	lbu	a5,0(s1)
    800038e6:	89a6                	mv	s3,s1
  len = path - s;
    800038e8:	4c81                	li	s9,0
    800038ea:	4601                	li	a2,0
  while (*path != '/' && *path != 0)
    800038ec:	01278963          	beq	a5,s2,800038fe <_ZL5namexPKciPc+0x10e>
    800038f0:	d3d9                	beqz	a5,80003876 <_ZL5namexPKciPc+0x86>
    path++;
    800038f2:	0985                	addi	s3,s3,1
  while (*path != '/' && *path != 0)
    800038f4:	0009c783          	lbu	a5,0(s3)
    800038f8:	ff279ce3          	bne	a5,s2,800038f0 <_ZL5namexPKciPc+0x100>
    800038fc:	bfad                	j	80003876 <_ZL5namexPKciPc+0x86>
    memmove(name, s, len);
    800038fe:	2601                	sext.w	a2,a2
    80003900:	85a6                	mv	a1,s1
    80003902:	8556                	mv	a0,s5
    80003904:	bdcfd0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
    name[len] = 0;
    80003908:	9cd6                	add	s9,s9,s5
    8000390a:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    8000390e:	84ce                	mv	s1,s3
    80003910:	bfbd                	j	8000388e <_ZL5namexPKciPc+0x9e>
  if (nameiparent) {
    80003912:	f20b0be3          	beqz	s6,80003848 <_ZL5namexPKciPc+0x58>
    iput(ip);
    80003916:	8552                	mv	a0,s4
    80003918:	a09ff0ef          	jal	80003320 <_Z4iputP5inode>
    return 0;
    8000391c:	4a01                	li	s4,0
    8000391e:	b72d                	j	80003848 <_ZL5namexPKciPc+0x58>

0000000080003920 <_Z7dirlinkP5inodePKcj>:
{
    80003920:	7139                	addi	sp,sp,-64
    80003922:	fc06                	sd	ra,56(sp)
    80003924:	f822                	sd	s0,48(sp)
    80003926:	f04a                	sd	s2,32(sp)
    80003928:	ec4e                	sd	s3,24(sp)
    8000392a:	e852                	sd	s4,16(sp)
    8000392c:	0080                	addi	s0,sp,64
    8000392e:	892a                	mv	s2,a0
    80003930:	8a2e                	mv	s4,a1
    80003932:	89b2                	mv	s3,a2
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80003934:	4601                	li	a2,0
    80003936:	e1fff0ef          	jal	80003754 <_Z9dirlookupP5inodePKcPj>
    8000393a:	e535                	bnez	a0,800039a6 <_Z7dirlinkP5inodePKcj+0x86>
    8000393c:	f426                	sd	s1,40(sp)
  for (off = 0; off < dp->size; off += sizeof(de)) {
    8000393e:	04c92483          	lw	s1,76(s2)
    80003942:	c48d                	beqz	s1,8000396c <_Z7dirlinkP5inodePKcj+0x4c>
    80003944:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003946:	4741                	li	a4,16
    80003948:	86a6                	mv	a3,s1
    8000394a:	fc040613          	addi	a2,s0,-64
    8000394e:	4581                	li	a1,0
    80003950:	854a                	mv	a0,s2
    80003952:	bddff0ef          	jal	8000352e <_Z5readiP5inodeimjj>
    80003956:	47c1                	li	a5,16
    80003958:	04f51b63          	bne	a0,a5,800039ae <_Z7dirlinkP5inodePKcj+0x8e>
    if (de.inum == 0)
    8000395c:	fc045783          	lhu	a5,-64(s0)
    80003960:	c791                	beqz	a5,8000396c <_Z7dirlinkP5inodePKcj+0x4c>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003962:	24c1                	addiw	s1,s1,16
    80003964:	04c92783          	lw	a5,76(s2)
    80003968:	fcf4efe3          	bltu	s1,a5,80003946 <_Z7dirlinkP5inodePKcj+0x26>
  strncpy(de.name, name, DIRSIZ);
    8000396c:	4639                	li	a2,14
    8000396e:	85d2                	mv	a1,s4
    80003970:	fc240513          	addi	a0,s0,-62
    80003974:	c12fd0ef          	jal	80000d86 <_Z7strncpyPcPKci>
  de.inum = inum;
    80003978:	fd341023          	sh	s3,-64(s0)
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000397c:	4741                	li	a4,16
    8000397e:	86a6                	mv	a3,s1
    80003980:	fc040613          	addi	a2,s0,-64
    80003984:	4581                	li	a1,0
    80003986:	854a                	mv	a0,s2
    80003988:	ca3ff0ef          	jal	8000362a <_Z6writeiP5inodeimjj>
    8000398c:	1541                	addi	a0,a0,-16
    8000398e:	00a03533          	snez	a0,a0
    80003992:	40a00533          	neg	a0,a0
    80003996:	74a2                	ld	s1,40(sp)
}
    80003998:	70e2                	ld	ra,56(sp)
    8000399a:	7442                	ld	s0,48(sp)
    8000399c:	7902                	ld	s2,32(sp)
    8000399e:	69e2                	ld	s3,24(sp)
    800039a0:	6a42                	ld	s4,16(sp)
    800039a2:	6121                	addi	sp,sp,64
    800039a4:	8082                	ret
    iput(ip);
    800039a6:	97bff0ef          	jal	80003320 <_Z4iputP5inode>
    return -1;
    800039aa:	557d                	li	a0,-1
    800039ac:	b7f5                	j	80003998 <_Z7dirlinkP5inodePKcj+0x78>
      panic("dirlink read");
    800039ae:	00004517          	auipc	a0,0x4
    800039b2:	b1a50513          	addi	a0,a0,-1254 # 800074c8 <etext+0x4c8>
    800039b6:	e3dfc0ef          	jal	800007f2 <_Z5panicPKc>

00000000800039ba <_Z5nameiPKc>:

struct inode *
namei(const char *path)
{
    800039ba:	1101                	addi	sp,sp,-32
    800039bc:	ec06                	sd	ra,24(sp)
    800039be:	e822                	sd	s0,16(sp)
    800039c0:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    800039c2:	fe040613          	addi	a2,s0,-32
    800039c6:	4581                	li	a1,0
    800039c8:	e29ff0ef          	jal	800037f0 <_ZL5namexPKciPc>
}
    800039cc:	60e2                	ld	ra,24(sp)
    800039ce:	6442                	ld	s0,16(sp)
    800039d0:	6105                	addi	sp,sp,32
    800039d2:	8082                	ret

00000000800039d4 <_Z11nameiparentPKcPc>:

struct inode *
nameiparent(const char *path, char *name)
{
    800039d4:	1141                	addi	sp,sp,-16
    800039d6:	e406                	sd	ra,8(sp)
    800039d8:	e022                	sd	s0,0(sp)
    800039da:	0800                	addi	s0,sp,16
    800039dc:	862e                	mv	a2,a1
  return namex(path, 1, name);
    800039de:	4585                	li	a1,1
    800039e0:	e11ff0ef          	jal	800037f0 <_ZL5namexPKciPc>
}
    800039e4:	60a2                	ld	ra,8(sp)
    800039e6:	6402                	ld	s0,0(sp)
    800039e8:	0141                	addi	sp,sp,16
    800039ea:	8082                	ret

00000000800039ec <_ZL10write_headv>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    800039ec:	1101                	addi	sp,sp,-32
    800039ee:	ec06                	sd	ra,24(sp)
    800039f0:	e822                	sd	s0,16(sp)
    800039f2:	e426                	sd	s1,8(sp)
    800039f4:	e04a                	sd	s2,0(sp)
    800039f6:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    800039f8:	0001c917          	auipc	s2,0x1c
    800039fc:	f4090913          	addi	s2,s2,-192 # 8001f938 <log>
    80003a00:	01892583          	lw	a1,24(s2)
    80003a04:	02492503          	lw	a0,36(s2)
    80003a08:	8e4ff0ef          	jal	80002aec <_Z5breadjj>
    80003a0c:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *)(buf->data);
  int i;
  hb->n = log.lh.n;
    80003a0e:	02c92603          	lw	a2,44(s2)
    80003a12:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003a14:	00c05f63          	blez	a2,80003a32 <_ZL10write_headv+0x46>
    80003a18:	0001c717          	auipc	a4,0x1c
    80003a1c:	f5070713          	addi	a4,a4,-176 # 8001f968 <log+0x30>
    80003a20:	87aa                	mv	a5,a0
    80003a22:	060a                	slli	a2,a2,0x2
    80003a24:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003a26:	4314                	lw	a3,0(a4)
    80003a28:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003a2a:	0711                	addi	a4,a4,4
    80003a2c:	0791                	addi	a5,a5,4
    80003a2e:	fec79ce3          	bne	a5,a2,80003a26 <_ZL10write_headv+0x3a>
  }
  bwrite(buf);
    80003a32:	8526                	mv	a0,s1
    80003a34:	98eff0ef          	jal	80002bc2 <_Z6bwriteP3buf>
  brelse(buf);
    80003a38:	8526                	mv	a0,s1
    80003a3a:	9baff0ef          	jal	80002bf4 <_Z6brelseP3buf>
}
    80003a3e:	60e2                	ld	ra,24(sp)
    80003a40:	6442                	ld	s0,16(sp)
    80003a42:	64a2                	ld	s1,8(sp)
    80003a44:	6902                	ld	s2,0(sp)
    80003a46:	6105                	addi	sp,sp,32
    80003a48:	8082                	ret

0000000080003a4a <_ZL13install_transi>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003a4a:	0001c797          	auipc	a5,0x1c
    80003a4e:	f1a7a783          	lw	a5,-230(a5) # 8001f964 <log+0x2c>
    80003a52:	0ef05763          	blez	a5,80003b40 <_ZL13install_transi+0xf6>
{
    80003a56:	715d                	addi	sp,sp,-80
    80003a58:	e486                	sd	ra,72(sp)
    80003a5a:	e0a2                	sd	s0,64(sp)
    80003a5c:	fc26                	sd	s1,56(sp)
    80003a5e:	f84a                	sd	s2,48(sp)
    80003a60:	f44e                	sd	s3,40(sp)
    80003a62:	f052                	sd	s4,32(sp)
    80003a64:	ec56                	sd	s5,24(sp)
    80003a66:	e85a                	sd	s6,16(sp)
    80003a68:	e45e                	sd	s7,8(sp)
    80003a6a:	0880                	addi	s0,sp,80
    80003a6c:	8b2a                	mv	s6,a0
    80003a6e:	0001ca17          	auipc	s4,0x1c
    80003a72:	efaa0a13          	addi	s4,s4,-262 # 8001f968 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003a76:	4901                	li	s2,0
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003a78:	0001ca97          	auipc	s5,0x1c
    80003a7c:	ec0a8a93          	addi	s5,s5,-320 # 8001f938 <log>
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003a80:	00004b97          	auipc	s7,0x4
    80003a84:	a58b8b93          	addi	s7,s7,-1448 # 800074d8 <etext+0x4d8>
    80003a88:	a8b9                	j	80003ae6 <_ZL13install_transi+0x9c>
    80003a8a:	000a2603          	lw	a2,0(s4)
    80003a8e:	85ca                	mv	a1,s2
    80003a90:	855e                	mv	a0,s7
    80003a92:	a61fc0ef          	jal	800004f2 <_Z6printkPKcz>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003a96:	018aa583          	lw	a1,24(s5)
    80003a9a:	012585bb          	addw	a1,a1,s2
    80003a9e:	2585                	addiw	a1,a1,1
    80003aa0:	024aa503          	lw	a0,36(s5)
    80003aa4:	848ff0ef          	jal	80002aec <_Z5breadjj>
    80003aa8:	89aa                	mv	s3,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]);   // read dst
    80003aaa:	000a2583          	lw	a1,0(s4)
    80003aae:	024aa503          	lw	a0,36(s5)
    80003ab2:	83aff0ef          	jal	80002aec <_Z5breadjj>
    80003ab6:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003ab8:	40000613          	li	a2,1024
    80003abc:	05898593          	addi	a1,s3,88
    80003ac0:	05850513          	addi	a0,a0,88
    80003ac4:	a1cfd0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
    bwrite(dbuf);                           // write dst to disk
    80003ac8:	8526                	mv	a0,s1
    80003aca:	8f8ff0ef          	jal	80002bc2 <_Z6bwriteP3buf>
    brelse(lbuf);
    80003ace:	854e                	mv	a0,s3
    80003ad0:	924ff0ef          	jal	80002bf4 <_Z6brelseP3buf>
    brelse(dbuf);
    80003ad4:	8526                	mv	a0,s1
    80003ad6:	91eff0ef          	jal	80002bf4 <_Z6brelseP3buf>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003ada:	2905                	addiw	s2,s2,1
    80003adc:	0a11                	addi	s4,s4,4
    80003ade:	02caa783          	lw	a5,44(s5)
    80003ae2:	04f95463          	bge	s2,a5,80003b2a <_ZL13install_transi+0xe0>
    if (recovering) {
    80003ae6:	fa0b12e3          	bnez	s6,80003a8a <_ZL13install_transi+0x40>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003aea:	018aa583          	lw	a1,24(s5)
    80003aee:	012585bb          	addw	a1,a1,s2
    80003af2:	2585                	addiw	a1,a1,1
    80003af4:	024aa503          	lw	a0,36(s5)
    80003af8:	ff5fe0ef          	jal	80002aec <_Z5breadjj>
    80003afc:	89aa                	mv	s3,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]);   // read dst
    80003afe:	000a2583          	lw	a1,0(s4)
    80003b02:	024aa503          	lw	a0,36(s5)
    80003b06:	fe7fe0ef          	jal	80002aec <_Z5breadjj>
    80003b0a:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003b0c:	40000613          	li	a2,1024
    80003b10:	05898593          	addi	a1,s3,88
    80003b14:	05850513          	addi	a0,a0,88
    80003b18:	9c8fd0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
    bwrite(dbuf);                           // write dst to disk
    80003b1c:	8526                	mv	a0,s1
    80003b1e:	8a4ff0ef          	jal	80002bc2 <_Z6bwriteP3buf>
      bunpin(dbuf);
    80003b22:	8526                	mv	a0,s1
    80003b24:	98cff0ef          	jal	80002cb0 <_Z6bunpinP3buf>
    80003b28:	b75d                	j	80003ace <_ZL13install_transi+0x84>
}
    80003b2a:	60a6                	ld	ra,72(sp)
    80003b2c:	6406                	ld	s0,64(sp)
    80003b2e:	74e2                	ld	s1,56(sp)
    80003b30:	7942                	ld	s2,48(sp)
    80003b32:	79a2                	ld	s3,40(sp)
    80003b34:	7a02                	ld	s4,32(sp)
    80003b36:	6ae2                	ld	s5,24(sp)
    80003b38:	6b42                	ld	s6,16(sp)
    80003b3a:	6ba2                	ld	s7,8(sp)
    80003b3c:	6161                	addi	sp,sp,80
    80003b3e:	8082                	ret
    80003b40:	8082                	ret

0000000080003b42 <_Z7initlogiP10superblock>:
{
    80003b42:	7179                	addi	sp,sp,-48
    80003b44:	f406                	sd	ra,40(sp)
    80003b46:	f022                	sd	s0,32(sp)
    80003b48:	ec26                	sd	s1,24(sp)
    80003b4a:	e84a                	sd	s2,16(sp)
    80003b4c:	e44e                	sd	s3,8(sp)
    80003b4e:	1800                	addi	s0,sp,48
    80003b50:	892a                	mv	s2,a0
    80003b52:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003b54:	0001c497          	auipc	s1,0x1c
    80003b58:	de448493          	addi	s1,s1,-540 # 8001f938 <log>
    80003b5c:	00004597          	auipc	a1,0x4
    80003b60:	99c58593          	addi	a1,a1,-1636 # 800074f8 <etext+0x4f8>
    80003b64:	8526                	mv	a0,s1
    80003b66:	fe5fc0ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>
  log.start = sb->logstart;
    80003b6a:	0149a583          	lw	a1,20(s3)
    80003b6e:	cc8c                	sw	a1,24(s1)
  log.dev = dev;
    80003b70:	0324a223          	sw	s2,36(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003b74:	854a                	mv	a0,s2
    80003b76:	f77fe0ef          	jal	80002aec <_Z5breadjj>
  log.lh.n = lh->n;
    80003b7a:	4d30                	lw	a2,88(a0)
    80003b7c:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003b7e:	00c05f63          	blez	a2,80003b9c <_Z7initlogiP10superblock+0x5a>
    80003b82:	87aa                	mv	a5,a0
    80003b84:	0001c717          	auipc	a4,0x1c
    80003b88:	de470713          	addi	a4,a4,-540 # 8001f968 <log+0x30>
    80003b8c:	060a                	slli	a2,a2,0x2
    80003b8e:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003b90:	4ff4                	lw	a3,92(a5)
    80003b92:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003b94:	0791                	addi	a5,a5,4
    80003b96:	0711                	addi	a4,a4,4
    80003b98:	fec79ce3          	bne	a5,a2,80003b90 <_Z7initlogiP10superblock+0x4e>
  brelse(buf);
    80003b9c:	858ff0ef          	jal	80002bf4 <_Z6brelseP3buf>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003ba0:	4505                	li	a0,1
    80003ba2:	ea9ff0ef          	jal	80003a4a <_ZL13install_transi>
  log.lh.n = 0;
    80003ba6:	0001c797          	auipc	a5,0x1c
    80003baa:	da07af23          	sw	zero,-578(a5) # 8001f964 <log+0x2c>
  write_head(); // clear the log
    80003bae:	e3fff0ef          	jal	800039ec <_ZL10write_headv>
}
    80003bb2:	70a2                	ld	ra,40(sp)
    80003bb4:	7402                	ld	s0,32(sp)
    80003bb6:	64e2                	ld	s1,24(sp)
    80003bb8:	6942                	ld	s2,16(sp)
    80003bba:	69a2                	ld	s3,8(sp)
    80003bbc:	6145                	addi	sp,sp,48
    80003bbe:	8082                	ret

0000000080003bc0 <_Z8begin_opv>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003bc0:	1101                	addi	sp,sp,-32
    80003bc2:	ec06                	sd	ra,24(sp)
    80003bc4:	e822                	sd	s0,16(sp)
    80003bc6:	e426                	sd	s1,8(sp)
    80003bc8:	e04a                	sd	s2,0(sp)
    80003bca:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003bcc:	0001c517          	auipc	a0,0x1c
    80003bd0:	d6c50513          	addi	a0,a0,-660 # 8001f938 <log>
    80003bd4:	fedfc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  while (1) {
    if (log.committing) {
    80003bd8:	0001c497          	auipc	s1,0x1c
    80003bdc:	d6048493          	addi	s1,s1,-672 # 8001f938 <log>
      sleep(&log, &log.lock);
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003be0:	4979                	li	s2,30
    80003be2:	a029                	j	80003bec <_Z8begin_opv+0x2c>
      sleep(&log, &log.lock);
    80003be4:	85a6                	mv	a1,s1
    80003be6:	8526                	mv	a0,s1
    80003be8:	ad8fe0ef          	jal	80001ec0 <_Z5sleepPvP8spinlock>
    if (log.committing) {
    80003bec:	509c                	lw	a5,32(s1)
    80003bee:	fbfd                	bnez	a5,80003be4 <_Z8begin_opv+0x24>
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003bf0:	4cd8                	lw	a4,28(s1)
    80003bf2:	2705                	addiw	a4,a4,1
    80003bf4:	0027179b          	slliw	a5,a4,0x2
    80003bf8:	9fb9                	addw	a5,a5,a4
    80003bfa:	0017979b          	slliw	a5,a5,0x1
    80003bfe:	54d4                	lw	a3,44(s1)
    80003c00:	9fb5                	addw	a5,a5,a3
    80003c02:	00f95763          	bge	s2,a5,80003c10 <_Z8begin_opv+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003c06:	85a6                	mv	a1,s1
    80003c08:	8526                	mv	a0,s1
    80003c0a:	ab6fe0ef          	jal	80001ec0 <_Z5sleepPvP8spinlock>
    80003c0e:	bff9                	j	80003bec <_Z8begin_opv+0x2c>
    } else {
      log.outstanding += 1;
    80003c10:	0001c517          	auipc	a0,0x1c
    80003c14:	d2850513          	addi	a0,a0,-728 # 8001f938 <log>
    80003c18:	cd58                	sw	a4,28(a0)
      release(&log.lock);
    80003c1a:	832fd0ef          	jal	80000c4c <_Z7releaseP8spinlock>
      break;
    }
  }
}
    80003c1e:	60e2                	ld	ra,24(sp)
    80003c20:	6442                	ld	s0,16(sp)
    80003c22:	64a2                	ld	s1,8(sp)
    80003c24:	6902                	ld	s2,0(sp)
    80003c26:	6105                	addi	sp,sp,32
    80003c28:	8082                	ret

0000000080003c2a <_Z6end_opv>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003c2a:	7139                	addi	sp,sp,-64
    80003c2c:	fc06                	sd	ra,56(sp)
    80003c2e:	f822                	sd	s0,48(sp)
    80003c30:	f426                	sd	s1,40(sp)
    80003c32:	f04a                	sd	s2,32(sp)
    80003c34:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003c36:	0001c497          	auipc	s1,0x1c
    80003c3a:	d0248493          	addi	s1,s1,-766 # 8001f938 <log>
    80003c3e:	8526                	mv	a0,s1
    80003c40:	f81fc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  log.outstanding -= 1;
    80003c44:	4cdc                	lw	a5,28(s1)
    80003c46:	37fd                	addiw	a5,a5,-1
    80003c48:	0007891b          	sext.w	s2,a5
    80003c4c:	ccdc                	sw	a5,28(s1)
  if (log.committing)
    80003c4e:	509c                	lw	a5,32(s1)
    80003c50:	e3b1                	bnez	a5,80003c94 <_Z6end_opv+0x6a>
    panic("log.committing");
  if (log.outstanding == 0) {
    80003c52:	04091a63          	bnez	s2,80003ca6 <_Z6end_opv+0x7c>
    do_commit = 1;
    log.committing = 1;
    80003c56:	0001c497          	auipc	s1,0x1c
    80003c5a:	ce248493          	addi	s1,s1,-798 # 8001f938 <log>
    80003c5e:	4785                	li	a5,1
    80003c60:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003c62:	8526                	mv	a0,s1
    80003c64:	fe9fc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003c68:	54dc                	lw	a5,44(s1)
    80003c6a:	04f04e63          	bgtz	a5,80003cc6 <_Z6end_opv+0x9c>
    acquire(&log.lock);
    80003c6e:	0001c497          	auipc	s1,0x1c
    80003c72:	cca48493          	addi	s1,s1,-822 # 8001f938 <log>
    80003c76:	8526                	mv	a0,s1
    80003c78:	f49fc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
    log.committing = 0;
    80003c7c:	0204a023          	sw	zero,32(s1)
    log.ncommit += 1;
    80003c80:	549c                	lw	a5,40(s1)
    80003c82:	2785                	addiw	a5,a5,1
    80003c84:	d49c                	sw	a5,40(s1)
    wakeup(&log);
    80003c86:	8526                	mv	a0,s1
    80003c88:	a84fe0ef          	jal	80001f0c <_Z6wakeupPv>
    release(&log.lock);
    80003c8c:	8526                	mv	a0,s1
    80003c8e:	fbffc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80003c92:	a025                	j	80003cba <_Z6end_opv+0x90>
    80003c94:	ec4e                	sd	s3,24(sp)
    80003c96:	e852                	sd	s4,16(sp)
    80003c98:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003c9a:	00004517          	auipc	a0,0x4
    80003c9e:	86650513          	addi	a0,a0,-1946 # 80007500 <etext+0x500>
    80003ca2:	b51fc0ef          	jal	800007f2 <_Z5panicPKc>
    wakeup(&log);
    80003ca6:	0001c497          	auipc	s1,0x1c
    80003caa:	c9248493          	addi	s1,s1,-878 # 8001f938 <log>
    80003cae:	8526                	mv	a0,s1
    80003cb0:	a5cfe0ef          	jal	80001f0c <_Z6wakeupPv>
  release(&log.lock);
    80003cb4:	8526                	mv	a0,s1
    80003cb6:	f97fc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80003cba:	70e2                	ld	ra,56(sp)
    80003cbc:	7442                	ld	s0,48(sp)
    80003cbe:	74a2                	ld	s1,40(sp)
    80003cc0:	7902                	ld	s2,32(sp)
    80003cc2:	6121                	addi	sp,sp,64
    80003cc4:	8082                	ret
    80003cc6:	ec4e                	sd	s3,24(sp)
    80003cc8:	e852                	sd	s4,16(sp)
    80003cca:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003ccc:	0001ca97          	auipc	s5,0x1c
    80003cd0:	c9ca8a93          	addi	s5,s5,-868 # 8001f968 <log+0x30>
    struct buf *to = bread(log.dev, log.start + tail + 1); // log block
    80003cd4:	0001ca17          	auipc	s4,0x1c
    80003cd8:	c64a0a13          	addi	s4,s4,-924 # 8001f938 <log>
    80003cdc:	018a2583          	lw	a1,24(s4)
    80003ce0:	012585bb          	addw	a1,a1,s2
    80003ce4:	2585                	addiw	a1,a1,1
    80003ce6:	024a2503          	lw	a0,36(s4)
    80003cea:	e03fe0ef          	jal	80002aec <_Z5breadjj>
    80003cee:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003cf0:	000aa583          	lw	a1,0(s5)
    80003cf4:	024a2503          	lw	a0,36(s4)
    80003cf8:	df5fe0ef          	jal	80002aec <_Z5breadjj>
    80003cfc:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003cfe:	40000613          	li	a2,1024
    80003d02:	05850593          	addi	a1,a0,88
    80003d06:	05848513          	addi	a0,s1,88
    80003d0a:	fd7fc0ef          	jal	80000ce0 <_Z7memmovePvPKvj>
    bwrite(to); // write the log
    80003d0e:	8526                	mv	a0,s1
    80003d10:	eb3fe0ef          	jal	80002bc2 <_Z6bwriteP3buf>
    brelse(from);
    80003d14:	854e                	mv	a0,s3
    80003d16:	edffe0ef          	jal	80002bf4 <_Z6brelseP3buf>
    brelse(to);
    80003d1a:	8526                	mv	a0,s1
    80003d1c:	ed9fe0ef          	jal	80002bf4 <_Z6brelseP3buf>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d20:	2905                	addiw	s2,s2,1
    80003d22:	0a91                	addi	s5,s5,4
    80003d24:	02ca2783          	lw	a5,44(s4)
    80003d28:	faf94ae3          	blt	s2,a5,80003cdc <_Z6end_opv+0xb2>
    write_log();      // Write modified blocks from cache to log
    write_head();     // Write header to disk -- the real commit
    80003d2c:	cc1ff0ef          	jal	800039ec <_ZL10write_headv>
    install_trans(0); // Now install writes to home locations
    80003d30:	4501                	li	a0,0
    80003d32:	d19ff0ef          	jal	80003a4a <_ZL13install_transi>
    log.lh.n = 0;
    80003d36:	0001c797          	auipc	a5,0x1c
    80003d3a:	c207a723          	sw	zero,-978(a5) # 8001f964 <log+0x2c>
    write_head(); // Erase the transaction from the log
    80003d3e:	cafff0ef          	jal	800039ec <_ZL10write_headv>
    80003d42:	69e2                	ld	s3,24(sp)
    80003d44:	6a42                	ld	s4,16(sp)
    80003d46:	6aa2                	ld	s5,8(sp)
    80003d48:	b71d                	j	80003c6e <_Z6end_opv+0x44>

0000000080003d4a <_Z9log_writeP3buf>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003d4a:	1101                	addi	sp,sp,-32
    80003d4c:	ec06                	sd	ra,24(sp)
    80003d4e:	e822                	sd	s0,16(sp)
    80003d50:	e426                	sd	s1,8(sp)
    80003d52:	e04a                	sd	s2,0(sp)
    80003d54:	1000                	addi	s0,sp,32
    80003d56:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003d58:	0001c917          	auipc	s2,0x1c
    80003d5c:	be090913          	addi	s2,s2,-1056 # 8001f938 <log>
    80003d60:	854a                	mv	a0,s2
    80003d62:	e5ffc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  if (log.lh.n >= LOGBLOCKS)
    80003d66:	02c92603          	lw	a2,44(s2)
    80003d6a:	47f5                	li	a5,29
    80003d6c:	04c7cc63          	blt	a5,a2,80003dc4 <_Z9log_writeP3buf+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003d70:	0001c797          	auipc	a5,0x1c
    80003d74:	be47a783          	lw	a5,-1052(a5) # 8001f954 <log+0x1c>
    80003d78:	04f05c63          	blez	a5,80003dd0 <_Z9log_writeP3buf+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003d7c:	4781                	li	a5,0
    80003d7e:	04c05f63          	blez	a2,80003ddc <_Z9log_writeP3buf+0x92>
    if (log.lh.block[i] == b->blockno) // log absorption
    80003d82:	44cc                	lw	a1,12(s1)
    80003d84:	0001c717          	auipc	a4,0x1c
    80003d88:	be470713          	addi	a4,a4,-1052 # 8001f968 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003d8c:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno) // log absorption
    80003d8e:	4314                	lw	a3,0(a4)
    80003d90:	04b68663          	beq	a3,a1,80003ddc <_Z9log_writeP3buf+0x92>
  for (i = 0; i < log.lh.n; i++) {
    80003d94:	2785                	addiw	a5,a5,1
    80003d96:	0711                	addi	a4,a4,4
    80003d98:	fef61be3          	bne	a2,a5,80003d8e <_Z9log_writeP3buf+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003d9c:	44d8                	lw	a4,12(s1)
    80003d9e:	0621                	addi	a2,a2,8
    80003da0:	060a                	slli	a2,a2,0x2
    80003da2:	0001c797          	auipc	a5,0x1c
    80003da6:	b9678793          	addi	a5,a5,-1130 # 8001f938 <log>
    80003daa:	97b2                	add	a5,a5,a2
    80003dac:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) { // Add new block to log?
    bpin(b);
    80003dae:	8526                	mv	a0,s1
    80003db0:	ecdfe0ef          	jal	80002c7c <_Z4bpinP3buf>
    log.lh.n++;
    80003db4:	0001c717          	auipc	a4,0x1c
    80003db8:	b8470713          	addi	a4,a4,-1148 # 8001f938 <log>
    80003dbc:	575c                	lw	a5,44(a4)
    80003dbe:	2785                	addiw	a5,a5,1
    80003dc0:	d75c                	sw	a5,44(a4)
    80003dc2:	a80d                	j	80003df4 <_Z9log_writeP3buf+0xaa>
    panic("too big a transaction");
    80003dc4:	00003517          	auipc	a0,0x3
    80003dc8:	74c50513          	addi	a0,a0,1868 # 80007510 <etext+0x510>
    80003dcc:	a27fc0ef          	jal	800007f2 <_Z5panicPKc>
    panic("log_write outside of trans");
    80003dd0:	00003517          	auipc	a0,0x3
    80003dd4:	75850513          	addi	a0,a0,1880 # 80007528 <etext+0x528>
    80003dd8:	a1bfc0ef          	jal	800007f2 <_Z5panicPKc>
  log.lh.block[i] = b->blockno;
    80003ddc:	44cc                	lw	a1,12(s1)
    80003dde:	00878693          	addi	a3,a5,8
    80003de2:	068a                	slli	a3,a3,0x2
    80003de4:	0001c717          	auipc	a4,0x1c
    80003de8:	b5470713          	addi	a4,a4,-1196 # 8001f938 <log>
    80003dec:	9736                	add	a4,a4,a3
    80003dee:	cb0c                	sw	a1,16(a4)
  if (i == log.lh.n) { // Add new block to log?
    80003df0:	faf60fe3          	beq	a2,a5,80003dae <_Z9log_writeP3buf+0x64>
  }
  release(&log.lock);
    80003df4:	0001c517          	auipc	a0,0x1c
    80003df8:	b4450513          	addi	a0,a0,-1212 # 8001f938 <log>
    80003dfc:	e51fc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80003e00:	60e2                	ld	ra,24(sp)
    80003e02:	6442                	ld	s0,16(sp)
    80003e04:	64a2                	ld	s1,8(sp)
    80003e06:	6902                	ld	s2,0(sp)
    80003e08:	6105                	addi	sp,sp,32
    80003e0a:	8082                	ret

0000000080003e0c <_Z8sys_syncv>:

uint64
sys_sync(void)
{
    80003e0c:	1101                	addi	sp,sp,-32
    80003e0e:	ec06                	sd	ra,24(sp)
    80003e10:	e822                	sd	s0,16(sp)
    80003e12:	e426                	sd	s1,8(sp)
    80003e14:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003e16:	0001c497          	auipc	s1,0x1c
    80003e1a:	b2248493          	addi	s1,s1,-1246 # 8001f938 <log>
    80003e1e:	8526                	mv	a0,s1
    80003e20:	da1fc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  if (log.committing || log.outstanding > 0) {
    80003e24:	509c                	lw	a5,32(s1)
    80003e26:	e799                	bnez	a5,80003e34 <_Z8sys_syncv+0x28>
    80003e28:	0001c797          	auipc	a5,0x1c
    80003e2c:	b2c7a783          	lw	a5,-1236(a5) # 8001f954 <log+0x1c>
    80003e30:	02f05363          	blez	a5,80003e56 <_Z8sys_syncv+0x4a>
    80003e34:	e04a                	sd	s2,0(sp)
    int n = log.ncommit + 1;
    80003e36:	0001c917          	auipc	s2,0x1c
    80003e3a:	b2a92903          	lw	s2,-1238(s2) # 8001f960 <log+0x28>
    while (log.ncommit < n) {
      sleep(&log, &log.lock);
    80003e3e:	0001c497          	auipc	s1,0x1c
    80003e42:	afa48493          	addi	s1,s1,-1286 # 8001f938 <log>
    80003e46:	85a6                	mv	a1,s1
    80003e48:	8526                	mv	a0,s1
    80003e4a:	876fe0ef          	jal	80001ec0 <_Z5sleepPvP8spinlock>
    while (log.ncommit < n) {
    80003e4e:	549c                	lw	a5,40(s1)
    80003e50:	fef95be3          	bge	s2,a5,80003e46 <_Z8sys_syncv+0x3a>
    80003e54:	6902                	ld	s2,0(sp)
    }
  }
  release(&log.lock);
    80003e56:	0001c517          	auipc	a0,0x1c
    80003e5a:	ae250513          	addi	a0,a0,-1310 # 8001f938 <log>
    80003e5e:	deffc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  return 0;
}
    80003e62:	4501                	li	a0,0
    80003e64:	60e2                	ld	ra,24(sp)
    80003e66:	6442                	ld	s0,16(sp)
    80003e68:	64a2                	ld	s1,8(sp)
    80003e6a:	6105                	addi	sp,sp,32
    80003e6c:	8082                	ret

0000000080003e6e <_Z13initsleeplockP9sleeplockPKc>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, const char *name)
{
    80003e6e:	1101                	addi	sp,sp,-32
    80003e70:	ec06                	sd	ra,24(sp)
    80003e72:	e822                	sd	s0,16(sp)
    80003e74:	e426                	sd	s1,8(sp)
    80003e76:	e04a                	sd	s2,0(sp)
    80003e78:	1000                	addi	s0,sp,32
    80003e7a:	84aa                	mv	s1,a0
    80003e7c:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003e7e:	00003597          	auipc	a1,0x3
    80003e82:	6ca58593          	addi	a1,a1,1738 # 80007548 <etext+0x548>
    80003e86:	0521                	addi	a0,a0,8
    80003e88:	cc3fc0ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>
  lk->name = name;
    80003e8c:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80003e90:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003e94:	0204a423          	sw	zero,40(s1)
}
    80003e98:	60e2                	ld	ra,24(sp)
    80003e9a:	6442                	ld	s0,16(sp)
    80003e9c:	64a2                	ld	s1,8(sp)
    80003e9e:	6902                	ld	s2,0(sp)
    80003ea0:	6105                	addi	sp,sp,32
    80003ea2:	8082                	ret

0000000080003ea4 <_Z12acquiresleepP9sleeplock>:

void
acquiresleep(struct sleeplock *lk)
{
    80003ea4:	1101                	addi	sp,sp,-32
    80003ea6:	ec06                	sd	ra,24(sp)
    80003ea8:	e822                	sd	s0,16(sp)
    80003eaa:	e426                	sd	s1,8(sp)
    80003eac:	e04a                	sd	s2,0(sp)
    80003eae:	1000                	addi	s0,sp,32
    80003eb0:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003eb2:	00850913          	addi	s2,a0,8
    80003eb6:	854a                	mv	a0,s2
    80003eb8:	d09fc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  while (lk->locked) {
    80003ebc:	409c                	lw	a5,0(s1)
    80003ebe:	c799                	beqz	a5,80003ecc <_Z12acquiresleepP9sleeplock+0x28>
    sleep(lk, &lk->lk);
    80003ec0:	85ca                	mv	a1,s2
    80003ec2:	8526                	mv	a0,s1
    80003ec4:	ffdfd0ef          	jal	80001ec0 <_Z5sleepPvP8spinlock>
  while (lk->locked) {
    80003ec8:	409c                	lw	a5,0(s1)
    80003eca:	fbfd                	bnez	a5,80003ec0 <_Z12acquiresleepP9sleeplock+0x1c>
  }
  lk->locked = 1;
    80003ecc:	4785                	li	a5,1
    80003ece:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80003ed0:	9ebfd0ef          	jal	800018ba <_Z6myprocv>
    80003ed4:	591c                	lw	a5,48(a0)
    80003ed6:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80003ed8:	854a                	mv	a0,s2
    80003eda:	d73fc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80003ede:	60e2                	ld	ra,24(sp)
    80003ee0:	6442                	ld	s0,16(sp)
    80003ee2:	64a2                	ld	s1,8(sp)
    80003ee4:	6902                	ld	s2,0(sp)
    80003ee6:	6105                	addi	sp,sp,32
    80003ee8:	8082                	ret

0000000080003eea <_Z12releasesleepP9sleeplock>:

void
releasesleep(struct sleeplock *lk)
{
    80003eea:	1101                	addi	sp,sp,-32
    80003eec:	ec06                	sd	ra,24(sp)
    80003eee:	e822                	sd	s0,16(sp)
    80003ef0:	e426                	sd	s1,8(sp)
    80003ef2:	e04a                	sd	s2,0(sp)
    80003ef4:	1000                	addi	s0,sp,32
    80003ef6:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003ef8:	00850913          	addi	s2,a0,8
    80003efc:	854a                	mv	a0,s2
    80003efe:	cc3fc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  lk->locked = 0;
    80003f02:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003f06:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003f0a:	8526                	mv	a0,s1
    80003f0c:	800fe0ef          	jal	80001f0c <_Z6wakeupPv>
  release(&lk->lk);
    80003f10:	854a                	mv	a0,s2
    80003f12:	d3bfc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80003f16:	60e2                	ld	ra,24(sp)
    80003f18:	6442                	ld	s0,16(sp)
    80003f1a:	64a2                	ld	s1,8(sp)
    80003f1c:	6902                	ld	s2,0(sp)
    80003f1e:	6105                	addi	sp,sp,32
    80003f20:	8082                	ret

0000000080003f22 <_Z12holdingsleepPK9sleeplock>:

int
holdingsleep(const struct sleeplock *lk)
{
    80003f22:	7179                	addi	sp,sp,-48
    80003f24:	f406                	sd	ra,40(sp)
    80003f26:	f022                	sd	s0,32(sp)
    80003f28:	ec26                	sd	s1,24(sp)
    80003f2a:	e84a                	sd	s2,16(sp)
    80003f2c:	1800                	addi	s0,sp,48
    80003f2e:	84aa                	mv	s1,a0
  int r;

  acquire(&lk->lk);
    80003f30:	00850913          	addi	s2,a0,8
    80003f34:	854a                	mv	a0,s2
    80003f36:	c8bfc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003f3a:	409c                	lw	a5,0(s1)
    80003f3c:	ef81                	bnez	a5,80003f54 <_Z12holdingsleepPK9sleeplock+0x32>
    80003f3e:	4481                	li	s1,0
  release(&lk->lk);
    80003f40:	854a                	mv	a0,s2
    80003f42:	d0bfc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  return r;
}
    80003f46:	8526                	mv	a0,s1
    80003f48:	70a2                	ld	ra,40(sp)
    80003f4a:	7402                	ld	s0,32(sp)
    80003f4c:	64e2                	ld	s1,24(sp)
    80003f4e:	6942                	ld	s2,16(sp)
    80003f50:	6145                	addi	sp,sp,48
    80003f52:	8082                	ret
    80003f54:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80003f56:	0284a983          	lw	s3,40(s1)
    80003f5a:	961fd0ef          	jal	800018ba <_Z6myprocv>
    80003f5e:	5904                	lw	s1,48(a0)
    80003f60:	413484b3          	sub	s1,s1,s3
    80003f64:	0014b493          	seqz	s1,s1
    80003f68:	69a2                	ld	s3,8(sp)
    80003f6a:	bfd9                	j	80003f40 <_Z12holdingsleepPK9sleeplock+0x1e>

0000000080003f6c <_Z8fileinitv>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003f6c:	1141                	addi	sp,sp,-16
    80003f6e:	e406                	sd	ra,8(sp)
    80003f70:	e022                	sd	s0,0(sp)
    80003f72:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80003f74:	00003597          	auipc	a1,0x3
    80003f78:	5e458593          	addi	a1,a1,1508 # 80007558 <etext+0x558>
    80003f7c:	0001c517          	auipc	a0,0x1c
    80003f80:	b0450513          	addi	a0,a0,-1276 # 8001fa80 <ftable>
    80003f84:	bc7fc0ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>
}
    80003f88:	60a2                	ld	ra,8(sp)
    80003f8a:	6402                	ld	s0,0(sp)
    80003f8c:	0141                	addi	sp,sp,16
    80003f8e:	8082                	ret

0000000080003f90 <_Z9fileallocv>:

// Allocate a file structure.
struct file *
filealloc(void)
{
    80003f90:	1101                	addi	sp,sp,-32
    80003f92:	ec06                	sd	ra,24(sp)
    80003f94:	e822                	sd	s0,16(sp)
    80003f96:	e426                	sd	s1,8(sp)
    80003f98:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003f9a:	0001c517          	auipc	a0,0x1c
    80003f9e:	ae650513          	addi	a0,a0,-1306 # 8001fa80 <ftable>
    80003fa2:	c1ffc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    80003fa6:	0001c497          	auipc	s1,0x1c
    80003faa:	af248493          	addi	s1,s1,-1294 # 8001fa98 <ftable+0x18>
    80003fae:	0001d717          	auipc	a4,0x1d
    80003fb2:	a8a70713          	addi	a4,a4,-1398 # 80020a38 <_ZL4disk>
    if (f->ref == 0) {
    80003fb6:	40dc                	lw	a5,4(s1)
    80003fb8:	cf89                	beqz	a5,80003fd2 <_Z9fileallocv+0x42>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    80003fba:	02848493          	addi	s1,s1,40
    80003fbe:	fee49ce3          	bne	s1,a4,80003fb6 <_Z9fileallocv+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80003fc2:	0001c517          	auipc	a0,0x1c
    80003fc6:	abe50513          	addi	a0,a0,-1346 # 8001fa80 <ftable>
    80003fca:	c83fc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  return 0;
    80003fce:	4481                	li	s1,0
    80003fd0:	a809                	j	80003fe2 <_Z9fileallocv+0x52>
      f->ref = 1;
    80003fd2:	4785                	li	a5,1
    80003fd4:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80003fd6:	0001c517          	auipc	a0,0x1c
    80003fda:	aaa50513          	addi	a0,a0,-1366 # 8001fa80 <ftable>
    80003fde:	c6ffc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80003fe2:	8526                	mv	a0,s1
    80003fe4:	60e2                	ld	ra,24(sp)
    80003fe6:	6442                	ld	s0,16(sp)
    80003fe8:	64a2                	ld	s1,8(sp)
    80003fea:	6105                	addi	sp,sp,32
    80003fec:	8082                	ret

0000000080003fee <_Z7filedupP4file>:

// Increment ref count for file f.
struct file *
filedup(struct file *f)
{
    80003fee:	1101                	addi	sp,sp,-32
    80003ff0:	ec06                	sd	ra,24(sp)
    80003ff2:	e822                	sd	s0,16(sp)
    80003ff4:	e426                	sd	s1,8(sp)
    80003ff6:	1000                	addi	s0,sp,32
    80003ff8:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80003ffa:	0001c517          	auipc	a0,0x1c
    80003ffe:	a8650513          	addi	a0,a0,-1402 # 8001fa80 <ftable>
    80004002:	bbffc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  if (f->ref < 1)
    80004006:	40dc                	lw	a5,4(s1)
    80004008:	02f05063          	blez	a5,80004028 <_Z7filedupP4file+0x3a>
    panic("filedup");
  f->ref++;
    8000400c:	2785                	addiw	a5,a5,1
    8000400e:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80004010:	0001c517          	auipc	a0,0x1c
    80004014:	a7050513          	addi	a0,a0,-1424 # 8001fa80 <ftable>
    80004018:	c35fc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  return f;
}
    8000401c:	8526                	mv	a0,s1
    8000401e:	60e2                	ld	ra,24(sp)
    80004020:	6442                	ld	s0,16(sp)
    80004022:	64a2                	ld	s1,8(sp)
    80004024:	6105                	addi	sp,sp,32
    80004026:	8082                	ret
    panic("filedup");
    80004028:	00003517          	auipc	a0,0x3
    8000402c:	53850513          	addi	a0,a0,1336 # 80007560 <etext+0x560>
    80004030:	fc2fc0ef          	jal	800007f2 <_Z5panicPKc>

0000000080004034 <_Z9filecloseP4file>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80004034:	7139                	addi	sp,sp,-64
    80004036:	fc06                	sd	ra,56(sp)
    80004038:	f822                	sd	s0,48(sp)
    8000403a:	f426                	sd	s1,40(sp)
    8000403c:	0080                	addi	s0,sp,64
    8000403e:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80004040:	0001c517          	auipc	a0,0x1c
    80004044:	a4050513          	addi	a0,a0,-1472 # 8001fa80 <ftable>
    80004048:	b79fc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  if (f->ref < 1)
    8000404c:	40dc                	lw	a5,4(s1)
    8000404e:	04f05a63          	blez	a5,800040a2 <_Z9filecloseP4file+0x6e>
    panic("fileclose");
  if (--f->ref > 0) {
    80004052:	37fd                	addiw	a5,a5,-1
    80004054:	0007871b          	sext.w	a4,a5
    80004058:	c0dc                	sw	a5,4(s1)
    8000405a:	04e04e63          	bgtz	a4,800040b6 <_Z9filecloseP4file+0x82>
    8000405e:	f04a                	sd	s2,32(sp)
    80004060:	ec4e                	sd	s3,24(sp)
    80004062:	e852                	sd	s4,16(sp)
    80004064:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80004066:	0004a903          	lw	s2,0(s1)
    8000406a:	0094ca83          	lbu	s5,9(s1)
    8000406e:	0104ba03          	ld	s4,16(s1)
    80004072:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    80004076:	0004a223          	sw	zero,4(s1)
  f->type = file::FD_NONE;
    8000407a:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    8000407e:	0001c517          	auipc	a0,0x1c
    80004082:	a0250513          	addi	a0,a0,-1534 # 8001fa80 <ftable>
    80004086:	bc7fc0ef          	jal	80000c4c <_Z7releaseP8spinlock>

  if (ff.type == file::FD_PIPE) {
    8000408a:	4785                	li	a5,1
    8000408c:	04f90063          	beq	s2,a5,800040cc <_Z9filecloseP4file+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if (ff.type == file::FD_INODE || ff.type == file::FD_DEVICE) {
    80004090:	3979                	addiw	s2,s2,-2
    80004092:	4785                	li	a5,1
    80004094:	0527f563          	bgeu	a5,s2,800040de <_Z9filecloseP4file+0xaa>
    80004098:	7902                	ld	s2,32(sp)
    8000409a:	69e2                	ld	s3,24(sp)
    8000409c:	6a42                	ld	s4,16(sp)
    8000409e:	6aa2                	ld	s5,8(sp)
    800040a0:	a00d                	j	800040c2 <_Z9filecloseP4file+0x8e>
    800040a2:	f04a                	sd	s2,32(sp)
    800040a4:	ec4e                	sd	s3,24(sp)
    800040a6:	e852                	sd	s4,16(sp)
    800040a8:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800040aa:	00003517          	auipc	a0,0x3
    800040ae:	4be50513          	addi	a0,a0,1214 # 80007568 <etext+0x568>
    800040b2:	f40fc0ef          	jal	800007f2 <_Z5panicPKc>
    release(&ftable.lock);
    800040b6:	0001c517          	auipc	a0,0x1c
    800040ba:	9ca50513          	addi	a0,a0,-1590 # 8001fa80 <ftable>
    800040be:	b8ffc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    800040c2:	70e2                	ld	ra,56(sp)
    800040c4:	7442                	ld	s0,48(sp)
    800040c6:	74a2                	ld	s1,40(sp)
    800040c8:	6121                	addi	sp,sp,64
    800040ca:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800040cc:	85d6                	mv	a1,s5
    800040ce:	8552                	mv	a0,s4
    800040d0:	32a000ef          	jal	800043fa <_Z9pipecloseP4pipei>
    800040d4:	7902                	ld	s2,32(sp)
    800040d6:	69e2                	ld	s3,24(sp)
    800040d8:	6a42                	ld	s4,16(sp)
    800040da:	6aa2                	ld	s5,8(sp)
    800040dc:	b7dd                	j	800040c2 <_Z9filecloseP4file+0x8e>
    begin_op();
    800040de:	ae3ff0ef          	jal	80003bc0 <_Z8begin_opv>
    iput(ff.ip);
    800040e2:	854e                	mv	a0,s3
    800040e4:	a3cff0ef          	jal	80003320 <_Z4iputP5inode>
    end_op();
    800040e8:	b43ff0ef          	jal	80003c2a <_Z6end_opv>
    800040ec:	7902                	ld	s2,32(sp)
    800040ee:	69e2                	ld	s3,24(sp)
    800040f0:	6a42                	ld	s4,16(sp)
    800040f2:	6aa2                	ld	s5,8(sp)
    800040f4:	b7f9                	j	800040c2 <_Z9filecloseP4file+0x8e>

00000000800040f6 <_Z8filestatP4filem>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800040f6:	715d                	addi	sp,sp,-80
    800040f8:	e486                	sd	ra,72(sp)
    800040fa:	e0a2                	sd	s0,64(sp)
    800040fc:	fc26                	sd	s1,56(sp)
    800040fe:	f44e                	sd	s3,40(sp)
    80004100:	0880                	addi	s0,sp,80
    80004102:	84aa                	mv	s1,a0
    80004104:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    80004106:	fb4fd0ef          	jal	800018ba <_Z6myprocv>
  struct stat st;

  if (f->type == file::FD_INODE || f->type == file::FD_DEVICE) {
    8000410a:	409c                	lw	a5,0(s1)
    8000410c:	37f9                	addiw	a5,a5,-2
    8000410e:	4705                	li	a4,1
    80004110:	04f76063          	bltu	a4,a5,80004150 <_Z8filestatP4filem+0x5a>
    80004114:	f84a                	sd	s2,48(sp)
    80004116:	892a                	mv	s2,a0
    ilock(f->ip);
    80004118:	6c88                	ld	a0,24(s1)
    8000411a:	884ff0ef          	jal	8000319e <_Z5ilockP5inode>
    stati(f->ip, &st);
    8000411e:	fb840593          	addi	a1,s0,-72
    80004122:	6c88                	ld	a0,24(s1)
    80004124:	be0ff0ef          	jal	80003504 <_Z5statiP5inodeP4stat>
    iunlock(f->ip);
    80004128:	6c88                	ld	a0,24(s1)
    8000412a:	922ff0ef          	jal	8000324c <_Z7iunlockP5inode>
    if (copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    8000412e:	46e1                	li	a3,24
    80004130:	fb840613          	addi	a2,s0,-72
    80004134:	85ce                	mv	a1,s3
    80004136:	05093503          	ld	a0,80(s2)
    8000413a:	c94fd0ef          	jal	800015ce <_Z7copyoutPmmPKcm>
    8000413e:	41f5551b          	sraiw	a0,a0,0x1f
    80004142:	7942                	ld	s2,48(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80004144:	60a6                	ld	ra,72(sp)
    80004146:	6406                	ld	s0,64(sp)
    80004148:	74e2                	ld	s1,56(sp)
    8000414a:	79a2                	ld	s3,40(sp)
    8000414c:	6161                	addi	sp,sp,80
    8000414e:	8082                	ret
  return -1;
    80004150:	557d                	li	a0,-1
    80004152:	bfcd                	j	80004144 <_Z8filestatP4filem+0x4e>

0000000080004154 <_Z8filereadP4filemi>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80004154:	7179                	addi	sp,sp,-48
    80004156:	f406                	sd	ra,40(sp)
    80004158:	f022                	sd	s0,32(sp)
    8000415a:	e84a                	sd	s2,16(sp)
    8000415c:	1800                	addi	s0,sp,48
  int r = 0;

  if (f->readable == 0)
    8000415e:	00854783          	lbu	a5,8(a0)
    80004162:	cfd1                	beqz	a5,800041fe <_Z8filereadP4filemi+0xaa>
    80004164:	ec26                	sd	s1,24(sp)
    80004166:	e44e                	sd	s3,8(sp)
    80004168:	84aa                	mv	s1,a0
    8000416a:	89ae                	mv	s3,a1
    8000416c:	8932                	mv	s2,a2
    return -1;

  if (f->type == file::FD_PIPE) {
    8000416e:	411c                	lw	a5,0(a0)
    80004170:	4705                	li	a4,1
    80004172:	04e78363          	beq	a5,a4,800041b8 <_Z8filereadP4filemi+0x64>
    r = piperead(f->pipe, addr, n);
  } else if (f->type == file::FD_DEVICE) {
    80004176:	470d                	li	a4,3
    80004178:	04e78763          	beq	a5,a4,800041c6 <_Z8filereadP4filemi+0x72>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if (f->type == file::FD_INODE) {
    8000417c:	4709                	li	a4,2
    8000417e:	06e79a63          	bne	a5,a4,800041f2 <_Z8filereadP4filemi+0x9e>
    ilock(f->ip);
    80004182:	6d08                	ld	a0,24(a0)
    80004184:	81aff0ef          	jal	8000319e <_Z5ilockP5inode>
    if ((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004188:	874a                	mv	a4,s2
    8000418a:	5094                	lw	a3,32(s1)
    8000418c:	864e                	mv	a2,s3
    8000418e:	4585                	li	a1,1
    80004190:	6c88                	ld	a0,24(s1)
    80004192:	b9cff0ef          	jal	8000352e <_Z5readiP5inodeimjj>
    80004196:	892a                	mv	s2,a0
    80004198:	00a05563          	blez	a0,800041a2 <_Z8filereadP4filemi+0x4e>
      f->off += r;
    8000419c:	509c                	lw	a5,32(s1)
    8000419e:	9fa9                	addw	a5,a5,a0
    800041a0:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800041a2:	6c88                	ld	a0,24(s1)
    800041a4:	8a8ff0ef          	jal	8000324c <_Z7iunlockP5inode>
    800041a8:	64e2                	ld	s1,24(sp)
    800041aa:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    800041ac:	854a                	mv	a0,s2
    800041ae:	70a2                	ld	ra,40(sp)
    800041b0:	7402                	ld	s0,32(sp)
    800041b2:	6942                	ld	s2,16(sp)
    800041b4:	6145                	addi	sp,sp,48
    800041b6:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800041b8:	6908                	ld	a0,16(a0)
    800041ba:	37c000ef          	jal	80004536 <_Z8pipereadP4pipemi>
    800041be:	892a                	mv	s2,a0
    800041c0:	64e2                	ld	s1,24(sp)
    800041c2:	69a2                	ld	s3,8(sp)
    800041c4:	b7e5                	j	800041ac <_Z8filereadP4filemi+0x58>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800041c6:	02451783          	lh	a5,36(a0)
    800041ca:	03079693          	slli	a3,a5,0x30
    800041ce:	92c1                	srli	a3,a3,0x30
    800041d0:	4725                	li	a4,9
    800041d2:	02d76863          	bltu	a4,a3,80004202 <_Z8filereadP4filemi+0xae>
    800041d6:	0792                	slli	a5,a5,0x4
    800041d8:	0001c717          	auipc	a4,0x1c
    800041dc:	80870713          	addi	a4,a4,-2040 # 8001f9e0 <devsw>
    800041e0:	97ba                	add	a5,a5,a4
    800041e2:	639c                	ld	a5,0(a5)
    800041e4:	c39d                	beqz	a5,8000420a <_Z8filereadP4filemi+0xb6>
    r = devsw[f->major].read(1, addr, n);
    800041e6:	4505                	li	a0,1
    800041e8:	9782                	jalr	a5
    800041ea:	892a                	mv	s2,a0
    800041ec:	64e2                	ld	s1,24(sp)
    800041ee:	69a2                	ld	s3,8(sp)
    800041f0:	bf75                	j	800041ac <_Z8filereadP4filemi+0x58>
    panic("fileread");
    800041f2:	00003517          	auipc	a0,0x3
    800041f6:	38650513          	addi	a0,a0,902 # 80007578 <etext+0x578>
    800041fa:	df8fc0ef          	jal	800007f2 <_Z5panicPKc>
    return -1;
    800041fe:	597d                	li	s2,-1
    80004200:	b775                	j	800041ac <_Z8filereadP4filemi+0x58>
      return -1;
    80004202:	597d                	li	s2,-1
    80004204:	64e2                	ld	s1,24(sp)
    80004206:	69a2                	ld	s3,8(sp)
    80004208:	b755                	j	800041ac <_Z8filereadP4filemi+0x58>
    8000420a:	597d                	li	s2,-1
    8000420c:	64e2                	ld	s1,24(sp)
    8000420e:	69a2                	ld	s3,8(sp)
    80004210:	bf71                	j	800041ac <_Z8filereadP4filemi+0x58>

0000000080004212 <_Z9filewriteP4filemi>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if (f->writable == 0)
    80004212:	00954783          	lbu	a5,9(a0)
    80004216:	10078563          	beqz	a5,80004320 <_Z9filewriteP4filemi+0x10e>
{
    8000421a:	715d                	addi	sp,sp,-80
    8000421c:	e486                	sd	ra,72(sp)
    8000421e:	e0a2                	sd	s0,64(sp)
    80004220:	fc26                	sd	s1,56(sp)
    80004222:	f052                	sd	s4,32(sp)
    80004224:	e85a                	sd	s6,16(sp)
    80004226:	0880                	addi	s0,sp,80
    80004228:	84aa                	mv	s1,a0
    8000422a:	8b2e                	mv	s6,a1
    8000422c:	8a32                	mv	s4,a2
    return -1;

  if (f->type == file::FD_PIPE) {
    8000422e:	411c                	lw	a5,0(a0)
    80004230:	4705                	li	a4,1
    80004232:	02e78763          	beq	a5,a4,80004260 <_Z9filewriteP4filemi+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if (f->type == file::FD_DEVICE) {
    80004236:	470d                	li	a4,3
    80004238:	02e78863          	beq	a5,a4,80004268 <_Z9filewriteP4filemi+0x56>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if (f->type == file::FD_INODE) {
    8000423c:	4709                	li	a4,2
    8000423e:	0ce79663          	bne	a5,a4,8000430a <_Z9filewriteP4filemi+0xf8>
    80004242:	f44e                	sd	s3,40(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS - 1 - 1 - 2) / 2) * BSIZE;
    int i = 0;
    while (i < n) {
    80004244:	0ac05263          	blez	a2,800042e8 <_Z9filewriteP4filemi+0xd6>
    80004248:	f84a                	sd	s2,48(sp)
    8000424a:	ec56                	sd	s5,24(sp)
    8000424c:	e45e                	sd	s7,8(sp)
    8000424e:	e062                	sd	s8,0(sp)
    int i = 0;
    80004250:	4981                	li	s3,0
      int n1 = n - i;
      if (n1 > max)
    80004252:	6b85                	lui	s7,0x1
    80004254:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80004258:	6c05                	lui	s8,0x1
    8000425a:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    8000425e:	a885                	j	800042ce <_Z9filewriteP4filemi+0xbc>
    ret = pipewrite(f->pipe, addr, n);
    80004260:	6908                	ld	a0,16(a0)
    80004262:	1f0000ef          	jal	80004452 <_Z9pipewriteP4pipemi>
    80004266:	a859                	j	800042fc <_Z9filewriteP4filemi+0xea>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004268:	02451783          	lh	a5,36(a0)
    8000426c:	03079693          	slli	a3,a5,0x30
    80004270:	92c1                	srli	a3,a3,0x30
    80004272:	4725                	li	a4,9
    80004274:	0ad76863          	bltu	a4,a3,80004324 <_Z9filewriteP4filemi+0x112>
    80004278:	0792                	slli	a5,a5,0x4
    8000427a:	0001b717          	auipc	a4,0x1b
    8000427e:	76670713          	addi	a4,a4,1894 # 8001f9e0 <devsw>
    80004282:	97ba                	add	a5,a5,a4
    80004284:	679c                	ld	a5,8(a5)
    80004286:	c3cd                	beqz	a5,80004328 <_Z9filewriteP4filemi+0x116>
    ret = devsw[f->major].write(1, addr, n);
    80004288:	4505                	li	a0,1
    8000428a:	9782                	jalr	a5
    8000428c:	a885                	j	800042fc <_Z9filewriteP4filemi+0xea>
      if (n1 > max)
    8000428e:	00090a9b          	sext.w	s5,s2
        n1 = max;

      begin_op();
    80004292:	92fff0ef          	jal	80003bc0 <_Z8begin_opv>
      ilock(f->ip);
    80004296:	6c88                	ld	a0,24(s1)
    80004298:	f07fe0ef          	jal	8000319e <_Z5ilockP5inode>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    8000429c:	8756                	mv	a4,s5
    8000429e:	5094                	lw	a3,32(s1)
    800042a0:	01698633          	add	a2,s3,s6
    800042a4:	4585                	li	a1,1
    800042a6:	6c88                	ld	a0,24(s1)
    800042a8:	b82ff0ef          	jal	8000362a <_Z6writeiP5inodeimjj>
    800042ac:	892a                	mv	s2,a0
    800042ae:	00a05563          	blez	a0,800042b8 <_Z9filewriteP4filemi+0xa6>
        f->off += r;
    800042b2:	509c                	lw	a5,32(s1)
    800042b4:	9fa9                	addw	a5,a5,a0
    800042b6:	d09c                	sw	a5,32(s1)
      iunlock(f->ip);
    800042b8:	6c88                	ld	a0,24(s1)
    800042ba:	f93fe0ef          	jal	8000324c <_Z7iunlockP5inode>
      end_op();
    800042be:	96dff0ef          	jal	80003c2a <_Z6end_opv>

      if (r != n1) {
    800042c2:	03591563          	bne	s2,s5,800042ec <_Z9filewriteP4filemi+0xda>
        // error from writei
        break;
      }
      i += r;
    800042c6:	013a89bb          	addw	s3,s5,s3
    while (i < n) {
    800042ca:	0149da63          	bge	s3,s4,800042de <_Z9filewriteP4filemi+0xcc>
      int n1 = n - i;
    800042ce:	413a093b          	subw	s2,s4,s3
      if (n1 > max)
    800042d2:	0009079b          	sext.w	a5,s2
    800042d6:	fafbdce3          	bge	s7,a5,8000428e <_Z9filewriteP4filemi+0x7c>
    800042da:	8962                	mv	s2,s8
    800042dc:	bf4d                	j	8000428e <_Z9filewriteP4filemi+0x7c>
    800042de:	7942                	ld	s2,48(sp)
    800042e0:	6ae2                	ld	s5,24(sp)
    800042e2:	6ba2                	ld	s7,8(sp)
    800042e4:	6c02                	ld	s8,0(sp)
    800042e6:	a039                	j	800042f4 <_Z9filewriteP4filemi+0xe2>
    int i = 0;
    800042e8:	4981                	li	s3,0
    800042ea:	a029                	j	800042f4 <_Z9filewriteP4filemi+0xe2>
    800042ec:	7942                	ld	s2,48(sp)
    800042ee:	6ae2                	ld	s5,24(sp)
    800042f0:	6ba2                	ld	s7,8(sp)
    800042f2:	6c02                	ld	s8,0(sp)
    }
    ret = (i == n ? n : -1);
    800042f4:	033a1c63          	bne	s4,s3,8000432c <_Z9filewriteP4filemi+0x11a>
    800042f8:	8552                	mv	a0,s4
    800042fa:	79a2                	ld	s3,40(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    800042fc:	60a6                	ld	ra,72(sp)
    800042fe:	6406                	ld	s0,64(sp)
    80004300:	74e2                	ld	s1,56(sp)
    80004302:	7a02                	ld	s4,32(sp)
    80004304:	6b42                	ld	s6,16(sp)
    80004306:	6161                	addi	sp,sp,80
    80004308:	8082                	ret
    8000430a:	f84a                	sd	s2,48(sp)
    8000430c:	f44e                	sd	s3,40(sp)
    8000430e:	ec56                	sd	s5,24(sp)
    80004310:	e45e                	sd	s7,8(sp)
    80004312:	e062                	sd	s8,0(sp)
    panic("filewrite");
    80004314:	00003517          	auipc	a0,0x3
    80004318:	27450513          	addi	a0,a0,628 # 80007588 <etext+0x588>
    8000431c:	cd6fc0ef          	jal	800007f2 <_Z5panicPKc>
    return -1;
    80004320:	557d                	li	a0,-1
}
    80004322:	8082                	ret
      return -1;
    80004324:	557d                	li	a0,-1
    80004326:	bfd9                	j	800042fc <_Z9filewriteP4filemi+0xea>
    80004328:	557d                	li	a0,-1
    8000432a:	bfc9                	j	800042fc <_Z9filewriteP4filemi+0xea>
    ret = (i == n ? n : -1);
    8000432c:	557d                	li	a0,-1
    8000432e:	79a2                	ld	s3,40(sp)
    80004330:	b7f1                	j	800042fc <_Z9filewriteP4filemi+0xea>

0000000080004332 <_Z9pipeallocPP4fileS1_>:
  int writeopen; // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004332:	7179                	addi	sp,sp,-48
    80004334:	f406                	sd	ra,40(sp)
    80004336:	f022                	sd	s0,32(sp)
    80004338:	ec26                	sd	s1,24(sp)
    8000433a:	e052                	sd	s4,0(sp)
    8000433c:	1800                	addi	s0,sp,48
    8000433e:	84aa                	mv	s1,a0
    80004340:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004342:	0005b023          	sd	zero,0(a1)
    80004346:	00053023          	sd	zero,0(a0)
  if ((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    8000434a:	c47ff0ef          	jal	80003f90 <_Z9fileallocv>
    8000434e:	e088                	sd	a0,0(s1)
    80004350:	c549                	beqz	a0,800043da <_Z9pipeallocPP4fileS1_+0xa8>
    80004352:	c3fff0ef          	jal	80003f90 <_Z9fileallocv>
    80004356:	00aa3023          	sd	a0,0(s4)
    8000435a:	cd25                	beqz	a0,800043d2 <_Z9pipeallocPP4fileS1_+0xa0>
    8000435c:	e84a                	sd	s2,16(sp)
    goto bad;
  if ((pi = (struct pipe *)kalloc()) == 0)
    8000435e:	f9cfc0ef          	jal	80000afa <_Z6kallocv>
    80004362:	892a                	mv	s2,a0
    80004364:	c12d                	beqz	a0,800043c6 <_Z9pipeallocPP4fileS1_+0x94>
    80004366:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80004368:	4985                	li	s3,1
    8000436a:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    8000436e:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004372:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004376:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    8000437a:	00003597          	auipc	a1,0x3
    8000437e:	21e58593          	addi	a1,a1,542 # 80007598 <etext+0x598>
    80004382:	fc8fc0ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>
  (*f0)->type = file::FD_PIPE;
    80004386:	609c                	ld	a5,0(s1)
    80004388:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    8000438c:	609c                	ld	a5,0(s1)
    8000438e:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004392:	609c                	ld	a5,0(s1)
    80004394:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004398:	609c                	ld	a5,0(s1)
    8000439a:	0127b823          	sd	s2,16(a5)
  (*f1)->type = file::FD_PIPE;
    8000439e:	000a3783          	ld	a5,0(s4)
    800043a2:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    800043a6:	000a3783          	ld	a5,0(s4)
    800043aa:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    800043ae:	000a3783          	ld	a5,0(s4)
    800043b2:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    800043b6:	000a3783          	ld	a5,0(s4)
    800043ba:	0127b823          	sd	s2,16(a5)
  return 0;
    800043be:	4501                	li	a0,0
    800043c0:	6942                	ld	s2,16(sp)
    800043c2:	69a2                	ld	s3,8(sp)
    800043c4:	a01d                	j	800043ea <_Z9pipeallocPP4fileS1_+0xb8>

bad:
  if (pi)
    kfree((char *)pi);
  if (*f0)
    800043c6:	6088                	ld	a0,0(s1)
    800043c8:	c119                	beqz	a0,800043ce <_Z9pipeallocPP4fileS1_+0x9c>
    800043ca:	6942                	ld	s2,16(sp)
    800043cc:	a029                	j	800043d6 <_Z9pipeallocPP4fileS1_+0xa4>
    800043ce:	6942                	ld	s2,16(sp)
    800043d0:	a029                	j	800043da <_Z9pipeallocPP4fileS1_+0xa8>
    800043d2:	6088                	ld	a0,0(s1)
    800043d4:	c10d                	beqz	a0,800043f6 <_Z9pipeallocPP4fileS1_+0xc4>
    fileclose(*f0);
    800043d6:	c5fff0ef          	jal	80004034 <_Z9filecloseP4file>
  if (*f1)
    800043da:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800043de:	557d                	li	a0,-1
  if (*f1)
    800043e0:	c789                	beqz	a5,800043ea <_Z9pipeallocPP4fileS1_+0xb8>
    fileclose(*f1);
    800043e2:	853e                	mv	a0,a5
    800043e4:	c51ff0ef          	jal	80004034 <_Z9filecloseP4file>
  return -1;
    800043e8:	557d                	li	a0,-1
}
    800043ea:	70a2                	ld	ra,40(sp)
    800043ec:	7402                	ld	s0,32(sp)
    800043ee:	64e2                	ld	s1,24(sp)
    800043f0:	6a02                	ld	s4,0(sp)
    800043f2:	6145                	addi	sp,sp,48
    800043f4:	8082                	ret
  return -1;
    800043f6:	557d                	li	a0,-1
    800043f8:	bfcd                	j	800043ea <_Z9pipeallocPP4fileS1_+0xb8>

00000000800043fa <_Z9pipecloseP4pipei>:

void
pipeclose(struct pipe *pi, int writable)
{
    800043fa:	1101                	addi	sp,sp,-32
    800043fc:	ec06                	sd	ra,24(sp)
    800043fe:	e822                	sd	s0,16(sp)
    80004400:	e426                	sd	s1,8(sp)
    80004402:	e04a                	sd	s2,0(sp)
    80004404:	1000                	addi	s0,sp,32
    80004406:	84aa                	mv	s1,a0
    80004408:	892e                	mv	s2,a1
  acquire(&pi->lock);
    8000440a:	fb6fc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  if (writable) {
    8000440e:	02090763          	beqz	s2,8000443c <_Z9pipecloseP4pipei+0x42>
    pi->writeopen = 0;
    80004412:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004416:	21848513          	addi	a0,s1,536
    8000441a:	af3fd0ef          	jal	80001f0c <_Z6wakeupPv>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if (pi->readopen == 0 && pi->writeopen == 0) {
    8000441e:	2204b783          	ld	a5,544(s1)
    80004422:	e785                	bnez	a5,8000444a <_Z9pipecloseP4pipei+0x50>
    release(&pi->lock);
    80004424:	8526                	mv	a0,s1
    80004426:	827fc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
    kfree((char *)pi);
    8000442a:	8526                	mv	a0,s1
    8000442c:	decfc0ef          	jal	80000a18 <_Z5kfreePv>
  } else
    release(&pi->lock);
}
    80004430:	60e2                	ld	ra,24(sp)
    80004432:	6442                	ld	s0,16(sp)
    80004434:	64a2                	ld	s1,8(sp)
    80004436:	6902                	ld	s2,0(sp)
    80004438:	6105                	addi	sp,sp,32
    8000443a:	8082                	ret
    pi->readopen = 0;
    8000443c:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004440:	21c48513          	addi	a0,s1,540
    80004444:	ac9fd0ef          	jal	80001f0c <_Z6wakeupPv>
    80004448:	bfd9                	j	8000441e <_Z9pipecloseP4pipei+0x24>
    release(&pi->lock);
    8000444a:	8526                	mv	a0,s1
    8000444c:	801fc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80004450:	b7c5                	j	80004430 <_Z9pipecloseP4pipei+0x36>

0000000080004452 <_Z9pipewriteP4pipemi>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004452:	711d                	addi	sp,sp,-96
    80004454:	ec86                	sd	ra,88(sp)
    80004456:	e8a2                	sd	s0,80(sp)
    80004458:	e4a6                	sd	s1,72(sp)
    8000445a:	e0ca                	sd	s2,64(sp)
    8000445c:	fc4e                	sd	s3,56(sp)
    8000445e:	f852                	sd	s4,48(sp)
    80004460:	f456                	sd	s5,40(sp)
    80004462:	1080                	addi	s0,sp,96
    80004464:	84aa                	mv	s1,a0
    80004466:	8aae                	mv	s5,a1
    80004468:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    8000446a:	c50fd0ef          	jal	800018ba <_Z6myprocv>
    8000446e:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004470:	8526                	mv	a0,s1
    80004472:	f4efc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  while (i < n) {
    80004476:	0b405a63          	blez	s4,8000452a <_Z9pipewriteP4pipemi+0xd8>
    8000447a:	f05a                	sd	s6,32(sp)
    8000447c:	ec5e                	sd	s7,24(sp)
    8000447e:	e862                	sd	s8,16(sp)
  int i = 0;
    80004480:	4901                	li	s2,0
    if (pi->nwrite == pi->nread + PIPESIZE) { //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if (copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004482:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004484:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004488:	21c48b93          	addi	s7,s1,540
    8000448c:	a81d                	j	800044c2 <_Z9pipewriteP4pipemi+0x70>
      release(&pi->lock);
    8000448e:	8526                	mv	a0,s1
    80004490:	fbcfc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
      return -1;
    80004494:	597d                	li	s2,-1
    80004496:	7b02                	ld	s6,32(sp)
    80004498:	6be2                	ld	s7,24(sp)
    8000449a:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    8000449c:	854a                	mv	a0,s2
    8000449e:	60e6                	ld	ra,88(sp)
    800044a0:	6446                	ld	s0,80(sp)
    800044a2:	64a6                	ld	s1,72(sp)
    800044a4:	6906                	ld	s2,64(sp)
    800044a6:	79e2                	ld	s3,56(sp)
    800044a8:	7a42                	ld	s4,48(sp)
    800044aa:	7aa2                	ld	s5,40(sp)
    800044ac:	6125                	addi	sp,sp,96
    800044ae:	8082                	ret
      wakeup(&pi->nread);
    800044b0:	8562                	mv	a0,s8
    800044b2:	a5bfd0ef          	jal	80001f0c <_Z6wakeupPv>
      sleep(&pi->nwrite, &pi->lock);
    800044b6:	85a6                	mv	a1,s1
    800044b8:	855e                	mv	a0,s7
    800044ba:	a07fd0ef          	jal	80001ec0 <_Z5sleepPvP8spinlock>
  while (i < n) {
    800044be:	05495b63          	bge	s2,s4,80004514 <_Z9pipewriteP4pipemi+0xc2>
    if (pi->readopen == 0 || killed(pr)) {
    800044c2:	2204a783          	lw	a5,544(s1)
    800044c6:	d7e1                	beqz	a5,8000448e <_Z9pipewriteP4pipemi+0x3c>
    800044c8:	854e                	mv	a0,s3
    800044ca:	c2ffd0ef          	jal	800020f8 <_Z6killedP4proc>
    800044ce:	f161                	bnez	a0,8000448e <_Z9pipewriteP4pipemi+0x3c>
    if (pi->nwrite == pi->nread + PIPESIZE) { //DOC: pipewrite-full
    800044d0:	2184a783          	lw	a5,536(s1)
    800044d4:	21c4a703          	lw	a4,540(s1)
    800044d8:	2007879b          	addiw	a5,a5,512
    800044dc:	fcf70ae3          	beq	a4,a5,800044b0 <_Z9pipewriteP4pipemi+0x5e>
      if (copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800044e0:	4685                	li	a3,1
    800044e2:	01590633          	add	a2,s2,s5
    800044e6:	faf40593          	addi	a1,s0,-81
    800044ea:	0509b503          	ld	a0,80(s3)
    800044ee:	9c4fd0ef          	jal	800016b2 <_Z6copyinPmPcmm>
    800044f2:	03650e63          	beq	a0,s6,8000452e <_Z9pipewriteP4pipemi+0xdc>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    800044f6:	faf44703          	lbu	a4,-81(s0)
    800044fa:	21c4a783          	lw	a5,540(s1)
    800044fe:	0017869b          	addiw	a3,a5,1
    80004502:	20d4ae23          	sw	a3,540(s1)
    80004506:	1ff7f793          	andi	a5,a5,511
    8000450a:	97a6                	add	a5,a5,s1
    8000450c:	00e78c23          	sb	a4,24(a5)
      i++;
    80004510:	2905                	addiw	s2,s2,1
    80004512:	b775                	j	800044be <_Z9pipewriteP4pipemi+0x6c>
    80004514:	7b02                	ld	s6,32(sp)
    80004516:	6be2                	ld	s7,24(sp)
    80004518:	6c42                	ld	s8,16(sp)
  wakeup(&pi->nread);
    8000451a:	21848513          	addi	a0,s1,536
    8000451e:	9effd0ef          	jal	80001f0c <_Z6wakeupPv>
  release(&pi->lock);
    80004522:	8526                	mv	a0,s1
    80004524:	f28fc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
  return i;
    80004528:	bf95                	j	8000449c <_Z9pipewriteP4pipemi+0x4a>
  int i = 0;
    8000452a:	4901                	li	s2,0
    8000452c:	b7fd                	j	8000451a <_Z9pipewriteP4pipemi+0xc8>
    8000452e:	7b02                	ld	s6,32(sp)
    80004530:	6be2                	ld	s7,24(sp)
    80004532:	6c42                	ld	s8,16(sp)
    80004534:	b7dd                	j	8000451a <_Z9pipewriteP4pipemi+0xc8>

0000000080004536 <_Z8pipereadP4pipemi>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004536:	715d                	addi	sp,sp,-80
    80004538:	e486                	sd	ra,72(sp)
    8000453a:	e0a2                	sd	s0,64(sp)
    8000453c:	fc26                	sd	s1,56(sp)
    8000453e:	f84a                	sd	s2,48(sp)
    80004540:	f44e                	sd	s3,40(sp)
    80004542:	f052                	sd	s4,32(sp)
    80004544:	ec56                	sd	s5,24(sp)
    80004546:	0880                	addi	s0,sp,80
    80004548:	84aa                	mv	s1,a0
    8000454a:	892e                	mv	s2,a1
    8000454c:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    8000454e:	b6cfd0ef          	jal	800018ba <_Z6myprocv>
    80004552:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80004554:	8526                	mv	a0,s1
    80004556:	e6afc0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    8000455a:	2184a703          	lw	a4,536(s1)
    8000455e:	21c4a783          	lw	a5,540(s1)
    if (killed(pr)) {
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004562:	21848993          	addi	s3,s1,536
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004566:	02f71563          	bne	a4,a5,80004590 <_Z8pipereadP4pipemi+0x5a>
    8000456a:	2244a783          	lw	a5,548(s1)
    8000456e:	cb85                	beqz	a5,8000459e <_Z8pipereadP4pipemi+0x68>
    if (killed(pr)) {
    80004570:	8552                	mv	a0,s4
    80004572:	b87fd0ef          	jal	800020f8 <_Z6killedP4proc>
    80004576:	ed19                	bnez	a0,80004594 <_Z8pipereadP4pipemi+0x5e>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004578:	85a6                	mv	a1,s1
    8000457a:	854e                	mv	a0,s3
    8000457c:	945fd0ef          	jal	80001ec0 <_Z5sleepPvP8spinlock>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004580:	2184a703          	lw	a4,536(s1)
    80004584:	21c4a783          	lw	a5,540(s1)
    80004588:	fef701e3          	beq	a4,a5,8000456a <_Z8pipereadP4pipemi+0x34>
    8000458c:	e85a                	sd	s6,16(sp)
    8000458e:	a809                	j	800045a0 <_Z8pipereadP4pipemi+0x6a>
    80004590:	e85a                	sd	s6,16(sp)
    80004592:	a039                	j	800045a0 <_Z8pipereadP4pipemi+0x6a>
      release(&pi->lock);
    80004594:	8526                	mv	a0,s1
    80004596:	eb6fc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
      return -1;
    8000459a:	59fd                	li	s3,-1
    8000459c:	a8b9                	j	800045fa <_Z8pipereadP4pipemi+0xc4>
    8000459e:	e85a                	sd	s6,16(sp)
  }
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    800045a0:	4981                	li	s3,0
    if (pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if (copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    800045a2:	5b7d                	li	s6,-1
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    800045a4:	05505363          	blez	s5,800045ea <_Z8pipereadP4pipemi+0xb4>
    if (pi->nread == pi->nwrite)
    800045a8:	2184a783          	lw	a5,536(s1)
    800045ac:	21c4a703          	lw	a4,540(s1)
    800045b0:	02f70d63          	beq	a4,a5,800045ea <_Z8pipereadP4pipemi+0xb4>
    ch = pi->data[pi->nread % PIPESIZE];
    800045b4:	1ff7f793          	andi	a5,a5,511
    800045b8:	97a6                	add	a5,a5,s1
    800045ba:	0187c783          	lbu	a5,24(a5)
    800045be:	faf40fa3          	sb	a5,-65(s0)
    if (copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    800045c2:	4685                	li	a3,1
    800045c4:	fbf40613          	addi	a2,s0,-65
    800045c8:	85ca                	mv	a1,s2
    800045ca:	050a3503          	ld	a0,80(s4)
    800045ce:	800fd0ef          	jal	800015ce <_Z7copyoutPmmPKcm>
    800045d2:	03650e63          	beq	a0,s6,8000460e <_Z8pipereadP4pipemi+0xd8>
      if (i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    800045d6:	2184a783          	lw	a5,536(s1)
    800045da:	2785                	addiw	a5,a5,1
    800045dc:	20f4ac23          	sw	a5,536(s1)
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    800045e0:	2985                	addiw	s3,s3,1
    800045e2:	0905                	addi	s2,s2,1
    800045e4:	fd3a92e3          	bne	s5,s3,800045a8 <_Z8pipereadP4pipemi+0x72>
    800045e8:	89d6                	mv	s3,s5
  }
  wakeup(&pi->nwrite); //DOC: piperead-wakeup
    800045ea:	21c48513          	addi	a0,s1,540
    800045ee:	91ffd0ef          	jal	80001f0c <_Z6wakeupPv>
  release(&pi->lock);
    800045f2:	8526                	mv	a0,s1
    800045f4:	e58fc0ef          	jal	80000c4c <_Z7releaseP8spinlock>
    800045f8:	6b42                	ld	s6,16(sp)
  return i;
}
    800045fa:	854e                	mv	a0,s3
    800045fc:	60a6                	ld	ra,72(sp)
    800045fe:	6406                	ld	s0,64(sp)
    80004600:	74e2                	ld	s1,56(sp)
    80004602:	7942                	ld	s2,48(sp)
    80004604:	79a2                	ld	s3,40(sp)
    80004606:	7a02                	ld	s4,32(sp)
    80004608:	6ae2                	ld	s5,24(sp)
    8000460a:	6161                	addi	sp,sp,80
    8000460c:	8082                	ret
      if (i == 0)
    8000460e:	fc099ee3          	bnez	s3,800045ea <_Z8pipereadP4pipemi+0xb4>
        i = -1;
    80004612:	89aa                	mv	s3,a0
    80004614:	bfd9                	j	800045ea <_Z8pipereadP4pipemi+0xb4>

0000000080004616 <_Z5kexecPKcPKS0_>:
//
// the implementation of the exec() system call
//
int
kexec(const char *path, const char *const *argv)
{
    80004616:	7105                	addi	sp,sp,-480
    80004618:	ef86                	sd	ra,472(sp)
    8000461a:	eba2                	sd	s0,464(sp)
    8000461c:	e7a6                	sd	s1,456(sp)
    8000461e:	e36a                	sd	s10,384(sp)
    80004620:	1380                	addi	s0,sp,480
    80004622:	84aa                	mv	s1,a0
    80004624:	e2a43c23          	sd	a0,-456(s0)
    80004628:	8d2e                	mv	s10,a1
  struct proc *p = myproc();
    8000462a:	a90fd0ef          	jal	800018ba <_Z6myprocv>
    8000462e:	e2a43823          	sd	a0,-464(s0)

  begin_op();
    80004632:	d8eff0ef          	jal	80003bc0 <_Z8begin_opv>
  struct inode *ip = namei(path);
    80004636:	8526                	mv	a0,s1
    80004638:	b82ff0ef          	jal	800039ba <_Z5nameiPKc>
  if (ip == nullptr) {
    8000463c:	c539                	beqz	a0,8000468a <_Z5kexecPKcPKS0_+0x74>
    8000463e:	fb52                	sd	s4,432(sp)
    80004640:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004642:	b5dfe0ef          	jal	8000319e <_Z5ilockP5inode>
  return readi(ip, 0, reinterpret_cast<uint64>(&obj), off, sizeof(T)) ==
    80004646:	04000713          	li	a4,64
    8000464a:	4681                	li	a3,0
    8000464c:	e8840613          	addi	a2,s0,-376
    80004650:	4581                	li	a1,0
    80004652:	8552                	mv	a0,s4
    80004654:	edbfe0ef          	jal	8000352e <_Z5readiP5inodeimjj>
  if (!read_obj(ip, 0, elf))
    80004658:	04000793          	li	a5,64
    8000465c:	00f51a63          	bne	a0,a5,80004670 <_Z5kexecPKcPKS0_+0x5a>
  if (elf.magic != ELF_MAGIC)
    80004660:	e8842703          	lw	a4,-376(s0)
    80004664:	464c47b7          	lui	a5,0x464c4
    80004668:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    8000466c:	02f70363          	beq	a4,a5,80004692 <_Z5kexecPKcPKS0_+0x7c>
      iunlockput(ip_);
    80004670:	8552                	mv	a0,s4
    80004672:	d37fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
      end_op();
    80004676:	db4ff0ef          	jal	80003c2a <_Z6end_opv>
      ip_ = nullptr;
    8000467a:	557d                	li	a0,-1
    8000467c:	7a5a                	ld	s4,432(sp)
  p->trapframe->epc = entry; // initial program counter = ulib.c:start()
  p->trapframe->sp = sp;     // initial stack pointer
  proc_freepagetable(oldpagetable, oldsz);

  return static_cast<int>(argc); // ends up in a0, the first argument to main
}
    8000467e:	60fe                	ld	ra,472(sp)
    80004680:	645e                	ld	s0,464(sp)
    80004682:	64be                	ld	s1,456(sp)
    80004684:	6d1a                	ld	s10,384(sp)
    80004686:	613d                	addi	sp,sp,480
    80004688:	8082                	ret
    end_op();
    8000468a:	da0ff0ef          	jal	80003c2a <_Z6end_opv>
    return -1;
    8000468e:	557d                	li	a0,-1
    80004690:	b7fd                	j	8000467e <_Z5kexecPKcPKS0_+0x68>
    80004692:	f35a                	sd	s6,416(sp)
  img.pagetable = proc_pagetable(p);
    80004694:	e3043503          	ld	a0,-464(s0)
    80004698:	b32fd0ef          	jal	800019ca <_Z14proc_pagetableP4proc>
    8000469c:	8b2a                	mv	s6,a0
  if (img.pagetable == nullptr)
    8000469e:	28050c63          	beqz	a0,80004936 <_Z5kexecPKcPKS0_+0x320>
    800046a2:	e3ca                	sd	s2,448(sp)
    800046a4:	ff4e                	sd	s3,440(sp)
    800046a6:	f756                	sd	s5,424(sp)
    800046a8:	ef5e                	sd	s7,408(sp)
    800046aa:	eb62                	sd	s8,400(sp)
  uint off = static_cast<uint>(elf.phoff);
    800046ac:	ea842783          	lw	a5,-344(s0)
    800046b0:	e4f43423          	sd	a5,-440(s0)
  for (int i = 0; i < elf.phnum; i++, off += sizeof(proghdr)) {
    800046b4:	ec045783          	lhu	a5,-320(s0)
    800046b8:	16078063          	beqz	a5,80004818 <_Z5kexecPKcPKS0_+0x202>
    800046bc:	e766                	sd	s9,392(sp)
    800046be:	feee                	sd	s11,376(sp)
  NewImage img;
    800046c0:	4481                	li	s1,0
  for (int i = 0; i < elf.phnum; i++, off += sizeof(proghdr)) {
    800046c2:	4d81                	li	s11,0
    if (ph.vaddr % PGSIZE != 0)
    800046c4:	6c85                	lui	s9,0x1
    800046c6:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    800046ca:	e2f43423          	sd	a5,-472(s0)
    uint n = (sz - i < PGSIZE) ? sz - i : PGSIZE;
    800046ce:	6a85                	lui	s5,0x1
    800046d0:	a0a5                	j	80004738 <_Z5kexecPKcPKS0_+0x122>
      panic("loadseg: address should exist");
    800046d2:	00003517          	auipc	a0,0x3
    800046d6:	ece50513          	addi	a0,a0,-306 # 800075a0 <etext+0x5a0>
    800046da:	918fc0ef          	jal	800007f2 <_Z5panicPKc>
    if (readi(ip, 0, pa, offset + i, n) != static_cast<int>(n))
    800046de:	0004871b          	sext.w	a4,s1
    800046e2:	012c06bb          	addw	a3,s8,s2
    800046e6:	4581                	li	a1,0
    800046e8:	8552                	mv	a0,s4
    800046ea:	e45fe0ef          	jal	8000352e <_Z5readiP5inodeimjj>
    800046ee:	2481                	sext.w	s1,s1
    800046f0:	22951263          	bne	a0,s1,80004914 <_Z5kexecPKcPKS0_+0x2fe>
  for (uint i = 0; i < sz; i += PGSIZE) {
    800046f4:	012a893b          	addw	s2,s5,s2
    800046f8:	03397363          	bgeu	s2,s3,8000471e <_Z5kexecPKcPKS0_+0x108>
    uint64 pa = walkaddr(pagetable, va + i);
    800046fc:	02091593          	slli	a1,s2,0x20
    80004700:	9181                	srli	a1,a1,0x20
    80004702:	95de                	add	a1,a1,s7
    80004704:	855a                	mv	a0,s6
    80004706:	897fc0ef          	jal	80000f9c <_Z8walkaddrPmm>
    8000470a:	862a                	mv	a2,a0
    if (pa == 0)
    8000470c:	d179                	beqz	a0,800046d2 <_Z5kexecPKcPKS0_+0xbc>
    uint n = (sz - i < PGSIZE) ? sz - i : PGSIZE;
    8000470e:	412984bb          	subw	s1,s3,s2
    80004712:	0004879b          	sext.w	a5,s1
    80004716:	fcfcf4e3          	bgeu	s9,a5,800046de <_Z5kexecPKcPKS0_+0xc8>
    8000471a:	84d6                	mv	s1,s5
    8000471c:	b7c9                	j	800046de <_Z5kexecPKcPKS0_+0xc8>
    img.sz = newsz;
    8000471e:	e4043483          	ld	s1,-448(s0)
  for (int i = 0; i < elf.phnum; i++, off += sizeof(proghdr)) {
    80004722:	2d85                	addiw	s11,s11,1
    80004724:	e4843783          	ld	a5,-440(s0)
    80004728:	0387879b          	addiw	a5,a5,56
    8000472c:	e4f43423          	sd	a5,-440(s0)
    80004730:	ec045783          	lhu	a5,-320(s0)
    80004734:	0afdd763          	bge	s11,a5,800047e2 <_Z5kexecPKcPKS0_+0x1cc>
  return readi(ip, 0, reinterpret_cast<uint64>(&obj), off, sizeof(T)) ==
    80004738:	03800713          	li	a4,56
    8000473c:	e4843683          	ld	a3,-440(s0)
    80004740:	e5040613          	addi	a2,s0,-432
    80004744:	4581                	li	a1,0
    80004746:	8552                	mv	a0,s4
    80004748:	de7fe0ef          	jal	8000352e <_Z5readiP5inodeimjj>
    if (!read_obj(ip, off, ph))
    8000474c:	03800793          	li	a5,56
    80004750:	06f51063          	bne	a0,a5,800047b0 <_Z5kexecPKcPKS0_+0x19a>
    if (ph.type != ELF_PROG_LOAD)
    80004754:	e5042783          	lw	a5,-432(s0)
    80004758:	4705                	li	a4,1
    8000475a:	fce794e3          	bne	a5,a4,80004722 <_Z5kexecPKcPKS0_+0x10c>
    if (ph.memsz < ph.filesz)
    8000475e:	e7843603          	ld	a2,-392(s0)
    80004762:	e7043783          	ld	a5,-400(s0)
    80004766:	04f66a63          	bltu	a2,a5,800047ba <_Z5kexecPKcPKS0_+0x1a4>
    if (ph.vaddr + ph.memsz < ph.vaddr)
    8000476a:	e6043783          	ld	a5,-416(s0)
    8000476e:	963e                	add	a2,a2,a5
    80004770:	04f66a63          	bltu	a2,a5,800047c4 <_Z5kexecPKcPKS0_+0x1ae>
    if (ph.vaddr % PGSIZE != 0)
    80004774:	e2843703          	ld	a4,-472(s0)
    80004778:	8ff9                	and	a5,a5,a4
    8000477a:	ebb1                	bnez	a5,800047ce <_Z5kexecPKcPKS0_+0x1b8>
    uint64 newsz = uvmalloc(img.pagetable, img.sz, ph.vaddr + ph.memsz,
    8000477c:	e5442783          	lw	a5,-428(s0)
  return ((flags & ELF_FLAG_EXEC) ? PTE_X : 0) |
    80004780:	0037969b          	slliw	a3,a5,0x3
    80004784:	8aa1                	andi	a3,a3,8
         ((flags & ELF_FLAG_WRITE) ? PTE_W : 0);
    80004786:	0017979b          	slliw	a5,a5,0x1
    8000478a:	8b91                	andi	a5,a5,4
    uint64 newsz = uvmalloc(img.pagetable, img.sz, ph.vaddr + ph.memsz,
    8000478c:	8edd                	or	a3,a3,a5
    8000478e:	85a6                	mv	a1,s1
    80004790:	855a                	mv	a0,s6
    80004792:	ae3fc0ef          	jal	80001274 <_Z8uvmallocPmmmi>
    80004796:	e4a43023          	sd	a0,-448(s0)
    if (newsz == 0)
    8000479a:	cd1d                	beqz	a0,800047d8 <_Z5kexecPKcPKS0_+0x1c2>
    if (!loadseg(img.pagetable, ph.vaddr, ip, ph.off, ph.filesz))
    8000479c:	e6043b83          	ld	s7,-416(s0)
    800047a0:	e5842c03          	lw	s8,-424(s0)
    800047a4:	e7042983          	lw	s3,-400(s0)
  for (uint i = 0; i < sz; i += PGSIZE) {
    800047a8:	f6098be3          	beqz	s3,8000471e <_Z5kexecPKcPKS0_+0x108>
    800047ac:	4901                	li	s2,0
    800047ae:	b7b9                	j	800046fc <_Z5kexecPKcPKS0_+0xe6>
    800047b0:	e4943023          	sd	s1,-448(s0)
    800047b4:	6cba                	ld	s9,392(sp)
    800047b6:	7df6                	ld	s11,376(sp)
    800047b8:	a285                	j	80004918 <_Z5kexecPKcPKS0_+0x302>
    800047ba:	e4943023          	sd	s1,-448(s0)
    800047be:	6cba                	ld	s9,392(sp)
    800047c0:	7df6                	ld	s11,376(sp)
    800047c2:	aa99                	j	80004918 <_Z5kexecPKcPKS0_+0x302>
    800047c4:	e4943023          	sd	s1,-448(s0)
    800047c8:	6cba                	ld	s9,392(sp)
    800047ca:	7df6                	ld	s11,376(sp)
    800047cc:	a2b1                	j	80004918 <_Z5kexecPKcPKS0_+0x302>
    800047ce:	e4943023          	sd	s1,-448(s0)
    800047d2:	6cba                	ld	s9,392(sp)
    800047d4:	7df6                	ld	s11,376(sp)
    800047d6:	a289                	j	80004918 <_Z5kexecPKcPKS0_+0x302>
    800047d8:	e4943023          	sd	s1,-448(s0)
    if (pagetable)
    800047dc:	6cba                	ld	s9,392(sp)
    800047de:	7df6                	ld	s11,376(sp)
    800047e0:	aa25                	j	80004918 <_Z5kexecPKcPKS0_+0x302>
    800047e2:	6cba                	ld	s9,392(sp)
    800047e4:	7df6                	ld	s11,376(sp)
  entry = elf.entry;
    800047e6:	ea043983          	ld	s3,-352(s0)
      iunlockput(ip_);
    800047ea:	8552                	mv	a0,s4
    800047ec:	bbdfe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
      end_op();
    800047f0:	c3aff0ef          	jal	80003c2a <_Z6end_opv>
  img.sz = PGROUNDUP(img.sz);
    800047f4:	6785                	lui	a5,0x1
    800047f6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800047f8:	94be                	add	s1,s1,a5
    800047fa:	77fd                	lui	a5,0xfffff
    800047fc:	8fe5                	and	a5,a5,s1
    800047fe:	e4f43023          	sd	a5,-448(s0)
    uvmalloc(img.pagetable, img.sz, img.sz + (USERSTACK + 1) * PGSIZE, PTE_W);
    80004802:	4691                	li	a3,4
    80004804:	6609                	lui	a2,0x2
    80004806:	963e                	add	a2,a2,a5
    80004808:	85be                	mv	a1,a5
    8000480a:	855a                	mv	a0,s6
    8000480c:	a69fc0ef          	jal	80001274 <_Z8uvmallocPmmmi>
    80004810:	8a2a                	mv	s4,a0
  if (newsz == 0)
    80004812:	e509                	bnez	a0,8000481c <_Z5kexecPKcPKS0_+0x206>
    if (pagetable)
    80004814:	4a01                	li	s4,0
    80004816:	a209                	j	80004918 <_Z5kexecPKcPKS0_+0x302>
  NewImage img;
    80004818:	4481                	li	s1,0
    8000481a:	b7f1                	j	800047e6 <_Z5kexecPKcPKS0_+0x1d0>
  uvmclear(img.pagetable, img.sz - (USERSTACK + 1) * PGSIZE);
    8000481c:	75f9                	lui	a1,0xffffe
    8000481e:	95aa                	add	a1,a1,a0
    80004820:	855a                	mv	a0,s6
    80004822:	c29fc0ef          	jal	8000144a <_Z8uvmclearPmm>
  const uint64 stackbase = sp - USERSTACK * PGSIZE;
    80004826:	7afd                	lui	s5,0xfffff
    80004828:	9ad2                	add	s5,s5,s4
  for (; argv[n]; n++) {
    8000482a:	000d3503          	ld	a0,0(s10) # 1000 <_entry-0x7ffff000>
    8000482e:	c521                	beqz	a0,80004876 <_Z5kexecPKcPKS0_+0x260>
    80004830:	e8840b93          	addi	s7,s0,-376
    80004834:	f8840c13          	addi	s8,s0,-120
  uint64 sp = img.sz;
    80004838:	84d2                	mv	s1,s4
  uint64 n = 0;
    8000483a:	4901                	li	s2,0
    const uint64 len = strlen(argv[n]) + 1;
    8000483c:	dbefc0ef          	jal	80000dfa <_Z6strlenPKc>
    80004840:	0015069b          	addiw	a3,a0,1
    sp -= len;
    80004844:	8c95                	sub	s1,s1,a3
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004846:	98c1                	andi	s1,s1,-16
    if (sp < stackbase)
    80004848:	0354e463          	bltu	s1,s5,80004870 <_Z5kexecPKcPKS0_+0x25a>
    if (copyout(img.pagetable, sp, argv[n], len) < 0)
    8000484c:	000d3603          	ld	a2,0(s10)
    80004850:	85a6                	mv	a1,s1
    80004852:	855a                	mv	a0,s6
    80004854:	d7bfc0ef          	jal	800015ce <_Z7copyoutPmmPKcm>
    80004858:	00054c63          	bltz	a0,80004870 <_Z5kexecPKcPKS0_+0x25a>
    ustack[n] = sp;
    8000485c:	009bb023          	sd	s1,0(s7)
  for (; argv[n]; n++) {
    80004860:	0905                	addi	s2,s2,1
    80004862:	0d21                	addi	s10,s10,8
    80004864:	000d3503          	ld	a0,0(s10)
    80004868:	c909                	beqz	a0,8000487a <_Z5kexecPKcPKS0_+0x264>
    if (n >= MAXARG)
    8000486a:	0ba1                	addi	s7,s7,8
    8000486c:	fd7c18e3          	bne	s8,s7,8000483c <_Z5kexecPKcPKS0_+0x226>
    80004870:	e5443023          	sd	s4,-448(s0)
    80004874:	b745                	j	80004814 <_Z5kexecPKcPKS0_+0x1fe>
  uint64 sp = img.sz;
    80004876:	84d2                	mv	s1,s4
  uint64 n = 0;
    80004878:	4901                	li	s2,0
  ustack[n] = 0;
    8000487a:	00391793          	slli	a5,s2,0x3
    8000487e:	f9078793          	addi	a5,a5,-112 # ffffffffffffef90 <end+0xffffffff7ffde418>
    80004882:	97a2                	add	a5,a5,s0
    80004884:	ee07bc23          	sd	zero,-264(a5)
  sp -= (n + 1) * sizeof(uint64);
    80004888:	00190693          	addi	a3,s2,1
    8000488c:	068e                	slli	a3,a3,0x3
    8000488e:	8c95                	sub	s1,s1,a3
  sp -= sp % 16;
    80004890:	98c1                	andi	s1,s1,-16
  img.sz = newsz;
    80004892:	e5443023          	sd	s4,-448(s0)
  if (sp < stackbase)
    80004896:	f754efe3          	bltu	s1,s5,80004814 <_Z5kexecPKcPKS0_+0x1fe>
  if (copyout(img.pagetable, sp, reinterpret_cast<const char *>(ustack),
    8000489a:	e8840613          	addi	a2,s0,-376
    8000489e:	85a6                	mv	a1,s1
    800048a0:	855a                	mv	a0,s6
    800048a2:	d2dfc0ef          	jal	800015ce <_Z7copyoutPmmPKcm>
    800048a6:	08054a63          	bltz	a0,8000493a <_Z5kexecPKcPKS0_+0x324>
  p->trapframe->a1 = sp;
    800048aa:	e3043703          	ld	a4,-464(s0)
    800048ae:	6f3c                	ld	a5,88(a4)
    800048b0:	ffa4                	sd	s1,120(a5)
  safestrcpy(p->name, basename_of(path), sizeof(p->name));
    800048b2:	15870513          	addi	a0,a4,344
  for (const char *s = path; *s; s++)
    800048b6:	e3843783          	ld	a5,-456(s0)
    800048ba:	0007c703          	lbu	a4,0(a5)
    800048be:	0785                	addi	a5,a5,1
    if (*s == '/')
    800048c0:	02f00693          	li	a3,47
  for (const char *s = path; *s; s++)
    800048c4:	e729                	bnez	a4,8000490e <_Z5kexecPKcPKS0_+0x2f8>
  safestrcpy(p->name, basename_of(path), sizeof(p->name));
    800048c6:	4641                	li	a2,16
    800048c8:	e3843583          	ld	a1,-456(s0)
    800048cc:	cfafc0ef          	jal	80000dc6 <_Z10safestrcpyPcPKci>
  pagetable_t oldpagetable = p->pagetable;
    800048d0:	e3043703          	ld	a4,-464(s0)
    800048d4:	6b28                	ld	a0,80(a4)
  uint64 oldsz = p->sz;
    800048d6:	672c                	ld	a1,72(a4)
  p->sz = img.sz;
    800048d8:	05473423          	sd	s4,72(a4)
  p->pagetable = img.release();
    800048dc:	05673823          	sd	s6,80(a4)
  p->trapframe->epc = entry; // initial program counter = ulib.c:start()
    800048e0:	6f3c                	ld	a5,88(a4)
    800048e2:	0137bc23          	sd	s3,24(a5)
  p->trapframe->sp = sp;     // initial stack pointer
    800048e6:	6f3c                	ld	a5,88(a4)
    800048e8:	fb84                	sd	s1,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    800048ea:	964fd0ef          	jal	80001a4e <_Z18proc_freepagetablePmm>
  return static_cast<int>(argc); // ends up in a0, the first argument to main
    800048ee:	0009051b          	sext.w	a0,s2
    if (ip_) {
    800048f2:	691e                	ld	s2,448(sp)
    800048f4:	79fa                	ld	s3,440(sp)
    800048f6:	7a5a                	ld	s4,432(sp)
    800048f8:	7aba                	ld	s5,424(sp)
    800048fa:	7b1a                	ld	s6,416(sp)
    800048fc:	6bfa                	ld	s7,408(sp)
    800048fe:	6c5a                	ld	s8,400(sp)
    80004900:	bbbd                	j	8000467e <_Z5kexecPKcPKS0_+0x68>
      last = s + 1;
    80004902:	e2f43c23          	sd	a5,-456(s0)
  for (const char *s = path; *s; s++)
    80004906:	0785                	addi	a5,a5,1
    80004908:	fff7c703          	lbu	a4,-1(a5)
    8000490c:	df4d                	beqz	a4,800048c6 <_Z5kexecPKcPKS0_+0x2b0>
    if (*s == '/')
    8000490e:	fed71ce3          	bne	a4,a3,80004906 <_Z5kexecPKcPKS0_+0x2f0>
    80004912:	bfc5                	j	80004902 <_Z5kexecPKcPKS0_+0x2ec>
    80004914:	6cba                	ld	s9,392(sp)
    80004916:	7df6                	ld	s11,376(sp)
      proc_freepagetable(pagetable, sz);
    80004918:	e4043583          	ld	a1,-448(s0)
    8000491c:	855a                	mv	a0,s6
    8000491e:	930fd0ef          	jal	80001a4e <_Z18proc_freepagetablePmm>
    if (ip_) {
    80004922:	557d                	li	a0,-1
    80004924:	000a0e63          	beqz	s4,80004940 <_Z5kexecPKcPKS0_+0x32a>
    80004928:	691e                	ld	s2,448(sp)
    8000492a:	79fa                	ld	s3,440(sp)
    8000492c:	7aba                	ld	s5,424(sp)
    8000492e:	7b1a                	ld	s6,416(sp)
    80004930:	6bfa                	ld	s7,408(sp)
    80004932:	6c5a                	ld	s8,400(sp)
    80004934:	bb35                	j	80004670 <_Z5kexecPKcPKS0_+0x5a>
    80004936:	7b1a                	ld	s6,416(sp)
    80004938:	bb25                	j	80004670 <_Z5kexecPKcPKS0_+0x5a>
  img.sz = newsz;
    8000493a:	e5443023          	sd	s4,-448(s0)
    8000493e:	bdd9                	j	80004814 <_Z5kexecPKcPKS0_+0x1fe>
    80004940:	691e                	ld	s2,448(sp)
    80004942:	79fa                	ld	s3,440(sp)
    80004944:	7a5a                	ld	s4,432(sp)
    80004946:	7aba                	ld	s5,424(sp)
    80004948:	7b1a                	ld	s6,416(sp)
    8000494a:	6bfa                	ld	s7,408(sp)
    8000494c:	6c5a                	ld	s8,400(sp)
    8000494e:	bb05                	j	8000467e <_Z5kexecPKcPKS0_+0x68>

0000000080004950 <_ZL5argfdiPiPP4file>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004950:	7179                	addi	sp,sp,-48
    80004952:	f406                	sd	ra,40(sp)
    80004954:	f022                	sd	s0,32(sp)
    80004956:	ec26                	sd	s1,24(sp)
    80004958:	e84a                	sd	s2,16(sp)
    8000495a:	1800                	addi	s0,sp,48
    8000495c:	892e                	mv	s2,a1
    8000495e:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004960:	fdc40593          	addi	a1,s0,-36
    80004964:	e4dfd0ef          	jal	800027b0 <_Z6argintiPi>
  if (fd < 0 || fd >= NOFILE || (f = myproc()->ofile[fd]) == 0)
    80004968:	fdc42703          	lw	a4,-36(s0)
    8000496c:	47bd                	li	a5,15
    8000496e:	02e7e963          	bltu	a5,a4,800049a0 <_ZL5argfdiPiPP4file+0x50>
    80004972:	f49fc0ef          	jal	800018ba <_Z6myprocv>
    80004976:	fdc42703          	lw	a4,-36(s0)
    8000497a:	01a70793          	addi	a5,a4,26
    8000497e:	078e                	slli	a5,a5,0x3
    80004980:	953e                	add	a0,a0,a5
    80004982:	611c                	ld	a5,0(a0)
    80004984:	c385                	beqz	a5,800049a4 <_ZL5argfdiPiPP4file+0x54>
    return -1;
  if (pfd)
    80004986:	00090463          	beqz	s2,8000498e <_ZL5argfdiPiPP4file+0x3e>
    *pfd = fd;
    8000498a:	00e92023          	sw	a4,0(s2)
  if (pf)
    *pf = f;
  return 0;
    8000498e:	4501                	li	a0,0
  if (pf)
    80004990:	c091                	beqz	s1,80004994 <_ZL5argfdiPiPP4file+0x44>
    *pf = f;
    80004992:	e09c                	sd	a5,0(s1)
}
    80004994:	70a2                	ld	ra,40(sp)
    80004996:	7402                	ld	s0,32(sp)
    80004998:	64e2                	ld	s1,24(sp)
    8000499a:	6942                	ld	s2,16(sp)
    8000499c:	6145                	addi	sp,sp,48
    8000499e:	8082                	ret
    return -1;
    800049a0:	557d                	li	a0,-1
    800049a2:	bfcd                	j	80004994 <_ZL5argfdiPiPP4file+0x44>
    800049a4:	557d                	li	a0,-1
    800049a6:	b7fd                	j	80004994 <_ZL5argfdiPiPP4file+0x44>

00000000800049a8 <_ZL7fdallocP4file>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    800049a8:	1101                	addi	sp,sp,-32
    800049aa:	ec06                	sd	ra,24(sp)
    800049ac:	e822                	sd	s0,16(sp)
    800049ae:	e426                	sd	s1,8(sp)
    800049b0:	1000                	addi	s0,sp,32
    800049b2:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    800049b4:	f07fc0ef          	jal	800018ba <_Z6myprocv>
    800049b8:	862a                	mv	a2,a0

  for (fd = 0; fd < NOFILE; fd++) {
    800049ba:	0d050793          	addi	a5,a0,208
    800049be:	4501                	li	a0,0
    800049c0:	46c1                	li	a3,16
    if (p->ofile[fd] == 0) {
    800049c2:	6398                	ld	a4,0(a5)
    800049c4:	cb19                	beqz	a4,800049da <_ZL7fdallocP4file+0x32>
  for (fd = 0; fd < NOFILE; fd++) {
    800049c6:	2505                	addiw	a0,a0,1
    800049c8:	07a1                	addi	a5,a5,8
    800049ca:	fed51ce3          	bne	a0,a3,800049c2 <_ZL7fdallocP4file+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    800049ce:	557d                	li	a0,-1
}
    800049d0:	60e2                	ld	ra,24(sp)
    800049d2:	6442                	ld	s0,16(sp)
    800049d4:	64a2                	ld	s1,8(sp)
    800049d6:	6105                	addi	sp,sp,32
    800049d8:	8082                	ret
      p->ofile[fd] = f;
    800049da:	01a50793          	addi	a5,a0,26
    800049de:	078e                	slli	a5,a5,0x3
    800049e0:	963e                	add	a2,a2,a5
    800049e2:	e204                	sd	s1,0(a2)
      return fd;
    800049e4:	b7f5                	j	800049d0 <_ZL7fdallocP4file+0x28>

00000000800049e6 <_ZL6createPcsss>:
  return -1;
}

static struct inode *
create(char *path, short type, short major, short minor)
{
    800049e6:	715d                	addi	sp,sp,-80
    800049e8:	e486                	sd	ra,72(sp)
    800049ea:	e0a2                	sd	s0,64(sp)
    800049ec:	fc26                	sd	s1,56(sp)
    800049ee:	f84a                	sd	s2,48(sp)
    800049f0:	f44e                	sd	s3,40(sp)
    800049f2:	ec56                	sd	s5,24(sp)
    800049f4:	e85a                	sd	s6,16(sp)
    800049f6:	0880                	addi	s0,sp,80
    800049f8:	8b2e                	mv	s6,a1
    800049fa:	89b2                	mv	s3,a2
    800049fc:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if ((dp = nameiparent(path, name)) == 0)
    800049fe:	fb040593          	addi	a1,s0,-80
    80004a02:	fd3fe0ef          	jal	800039d4 <_Z11nameiparentPKcPc>
    80004a06:	84aa                	mv	s1,a0
    80004a08:	10050a63          	beqz	a0,80004b1c <_ZL6createPcsss+0x136>
    return 0;

  ilock(dp);
    80004a0c:	f92fe0ef          	jal	8000319e <_Z5ilockP5inode>

  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80004a10:	4601                	li	a2,0
    80004a12:	fb040593          	addi	a1,s0,-80
    80004a16:	8526                	mv	a0,s1
    80004a18:	d3dfe0ef          	jal	80003754 <_Z9dirlookupP5inodePKcPj>
    80004a1c:	8aaa                	mv	s5,a0
    80004a1e:	c129                	beqz	a0,80004a60 <_ZL6createPcsss+0x7a>
    iunlockput(dp);
    80004a20:	8526                	mv	a0,s1
    80004a22:	987fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
    ilock(ip);
    80004a26:	8556                	mv	a0,s5
    80004a28:	f76fe0ef          	jal	8000319e <_Z5ilockP5inode>
    if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004a2c:	4789                	li	a5,2
    80004a2e:	02fb1463          	bne	s6,a5,80004a56 <_ZL6createPcsss+0x70>
    80004a32:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <end+0xffffffff7ffde4cc>
    80004a36:	37f9                	addiw	a5,a5,-2
    80004a38:	17c2                	slli	a5,a5,0x30
    80004a3a:	93c1                	srli	a5,a5,0x30
    80004a3c:	4705                	li	a4,1
    80004a3e:	00f76c63          	bltu	a4,a5,80004a56 <_ZL6createPcsss+0x70>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004a42:	8556                	mv	a0,s5
    80004a44:	60a6                	ld	ra,72(sp)
    80004a46:	6406                	ld	s0,64(sp)
    80004a48:	74e2                	ld	s1,56(sp)
    80004a4a:	7942                	ld	s2,48(sp)
    80004a4c:	79a2                	ld	s3,40(sp)
    80004a4e:	6ae2                	ld	s5,24(sp)
    80004a50:	6b42                	ld	s6,16(sp)
    80004a52:	6161                	addi	sp,sp,80
    80004a54:	8082                	ret
    iunlockput(ip);
    80004a56:	8556                	mv	a0,s5
    80004a58:	951fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
    return 0;
    80004a5c:	4a81                	li	s5,0
    80004a5e:	b7d5                	j	80004a42 <_ZL6createPcsss+0x5c>
    80004a60:	f052                	sd	s4,32(sp)
  if ((ip = ialloc(dp->dev, type)) == 0) {
    80004a62:	85da                	mv	a1,s6
    80004a64:	4088                	lw	a0,0(s1)
    80004a66:	dcefe0ef          	jal	80003034 <_Z6iallocjs>
    80004a6a:	8a2a                	mv	s4,a0
    80004a6c:	cd15                	beqz	a0,80004aa8 <_ZL6createPcsss+0xc2>
  ilock(ip);
    80004a6e:	f30fe0ef          	jal	8000319e <_Z5ilockP5inode>
  ip->major = major;
    80004a72:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80004a76:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    80004a7a:	4905                	li	s2,1
    80004a7c:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80004a80:	8552                	mv	a0,s4
    80004a82:	e68fe0ef          	jal	800030ea <_Z7iupdateP5inode>
  if (type == T_DIR) { // Create . and .. entries.
    80004a86:	032b0763          	beq	s6,s2,80004ab4 <_ZL6createPcsss+0xce>
  if (dirlink(dp, name, ip->inum) < 0)
    80004a8a:	004a2603          	lw	a2,4(s4)
    80004a8e:	fb040593          	addi	a1,s0,-80
    80004a92:	8526                	mv	a0,s1
    80004a94:	e8dfe0ef          	jal	80003920 <_Z7dirlinkP5inodePKcj>
    80004a98:	06054563          	bltz	a0,80004b02 <_ZL6createPcsss+0x11c>
  iunlockput(dp);
    80004a9c:	8526                	mv	a0,s1
    80004a9e:	90bfe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
  return ip;
    80004aa2:	8ad2                	mv	s5,s4
    80004aa4:	7a02                	ld	s4,32(sp)
    80004aa6:	bf71                	j	80004a42 <_ZL6createPcsss+0x5c>
    iunlockput(dp);
    80004aa8:	8526                	mv	a0,s1
    80004aaa:	8fffe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
    return 0;
    80004aae:	8ad2                	mv	s5,s4
    80004ab0:	7a02                	ld	s4,32(sp)
    80004ab2:	bf41                	j	80004a42 <_ZL6createPcsss+0x5c>
    if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004ab4:	004a2603          	lw	a2,4(s4)
    80004ab8:	00003597          	auipc	a1,0x3
    80004abc:	b0858593          	addi	a1,a1,-1272 # 800075c0 <etext+0x5c0>
    80004ac0:	8552                	mv	a0,s4
    80004ac2:	e5ffe0ef          	jal	80003920 <_Z7dirlinkP5inodePKcj>
    80004ac6:	02054e63          	bltz	a0,80004b02 <_ZL6createPcsss+0x11c>
    80004aca:	40d0                	lw	a2,4(s1)
    80004acc:	00003597          	auipc	a1,0x3
    80004ad0:	afc58593          	addi	a1,a1,-1284 # 800075c8 <etext+0x5c8>
    80004ad4:	8552                	mv	a0,s4
    80004ad6:	e4bfe0ef          	jal	80003920 <_Z7dirlinkP5inodePKcj>
    80004ada:	02054463          	bltz	a0,80004b02 <_ZL6createPcsss+0x11c>
  if (dirlink(dp, name, ip->inum) < 0)
    80004ade:	004a2603          	lw	a2,4(s4)
    80004ae2:	fb040593          	addi	a1,s0,-80
    80004ae6:	8526                	mv	a0,s1
    80004ae8:	e39fe0ef          	jal	80003920 <_Z7dirlinkP5inodePKcj>
    80004aec:	00054b63          	bltz	a0,80004b02 <_ZL6createPcsss+0x11c>
    dp->nlink++; // for ".."
    80004af0:	04a4d783          	lhu	a5,74(s1)
    80004af4:	2785                	addiw	a5,a5,1
    80004af6:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004afa:	8526                	mv	a0,s1
    80004afc:	deefe0ef          	jal	800030ea <_Z7iupdateP5inode>
    80004b00:	bf71                	j	80004a9c <_ZL6createPcsss+0xb6>
  ip->nlink = 0;
    80004b02:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80004b06:	8552                	mv	a0,s4
    80004b08:	de2fe0ef          	jal	800030ea <_Z7iupdateP5inode>
  iunlockput(ip);
    80004b0c:	8552                	mv	a0,s4
    80004b0e:	89bfe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
  iunlockput(dp);
    80004b12:	8526                	mv	a0,s1
    80004b14:	895fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
  return 0;
    80004b18:	7a02                	ld	s4,32(sp)
    80004b1a:	b725                	j	80004a42 <_ZL6createPcsss+0x5c>
    return 0;
    80004b1c:	8aaa                	mv	s5,a0
    80004b1e:	b715                	j	80004a42 <_ZL6createPcsss+0x5c>

0000000080004b20 <_Z7sys_dupv>:
{
    80004b20:	7179                	addi	sp,sp,-48
    80004b22:	f406                	sd	ra,40(sp)
    80004b24:	f022                	sd	s0,32(sp)
    80004b26:	1800                	addi	s0,sp,48
  if (argfd(0, 0, &f) < 0)
    80004b28:	fd840613          	addi	a2,s0,-40
    80004b2c:	4581                	li	a1,0
    80004b2e:	4501                	li	a0,0
    80004b30:	e21ff0ef          	jal	80004950 <_ZL5argfdiPiPP4file>
    return -1;
    80004b34:	57fd                	li	a5,-1
  if (argfd(0, 0, &f) < 0)
    80004b36:	02054363          	bltz	a0,80004b5c <_Z7sys_dupv+0x3c>
    80004b3a:	ec26                	sd	s1,24(sp)
    80004b3c:	e84a                	sd	s2,16(sp)
  if ((fd = fdalloc(f)) < 0)
    80004b3e:	fd843903          	ld	s2,-40(s0)
    80004b42:	854a                	mv	a0,s2
    80004b44:	e65ff0ef          	jal	800049a8 <_ZL7fdallocP4file>
    80004b48:	84aa                	mv	s1,a0
    return -1;
    80004b4a:	57fd                	li	a5,-1
  if ((fd = fdalloc(f)) < 0)
    80004b4c:	00054d63          	bltz	a0,80004b66 <_Z7sys_dupv+0x46>
  filedup(f);
    80004b50:	854a                	mv	a0,s2
    80004b52:	c9cff0ef          	jal	80003fee <_Z7filedupP4file>
  return fd;
    80004b56:	87a6                	mv	a5,s1
    80004b58:	64e2                	ld	s1,24(sp)
    80004b5a:	6942                	ld	s2,16(sp)
}
    80004b5c:	853e                	mv	a0,a5
    80004b5e:	70a2                	ld	ra,40(sp)
    80004b60:	7402                	ld	s0,32(sp)
    80004b62:	6145                	addi	sp,sp,48
    80004b64:	8082                	ret
    80004b66:	64e2                	ld	s1,24(sp)
    80004b68:	6942                	ld	s2,16(sp)
    80004b6a:	bfcd                	j	80004b5c <_Z7sys_dupv+0x3c>

0000000080004b6c <_Z8sys_readv>:
{
    80004b6c:	7179                	addi	sp,sp,-48
    80004b6e:	f406                	sd	ra,40(sp)
    80004b70:	f022                	sd	s0,32(sp)
    80004b72:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004b74:	fd840593          	addi	a1,s0,-40
    80004b78:	4505                	li	a0,1
    80004b7a:	c53fd0ef          	jal	800027cc <_Z7argaddriPm>
  argint(2, &n);
    80004b7e:	fe440593          	addi	a1,s0,-28
    80004b82:	4509                	li	a0,2
    80004b84:	c2dfd0ef          	jal	800027b0 <_Z6argintiPi>
  if (argfd(0, 0, &f) < 0)
    80004b88:	fe840613          	addi	a2,s0,-24
    80004b8c:	4581                	li	a1,0
    80004b8e:	4501                	li	a0,0
    80004b90:	dc1ff0ef          	jal	80004950 <_ZL5argfdiPiPP4file>
    80004b94:	87aa                	mv	a5,a0
    return -1;
    80004b96:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004b98:	0007ca63          	bltz	a5,80004bac <_Z8sys_readv+0x40>
  return fileread(f, p, n);
    80004b9c:	fe442603          	lw	a2,-28(s0)
    80004ba0:	fd843583          	ld	a1,-40(s0)
    80004ba4:	fe843503          	ld	a0,-24(s0)
    80004ba8:	dacff0ef          	jal	80004154 <_Z8filereadP4filemi>
}
    80004bac:	70a2                	ld	ra,40(sp)
    80004bae:	7402                	ld	s0,32(sp)
    80004bb0:	6145                	addi	sp,sp,48
    80004bb2:	8082                	ret

0000000080004bb4 <_Z9sys_writev>:
{
    80004bb4:	7179                	addi	sp,sp,-48
    80004bb6:	f406                	sd	ra,40(sp)
    80004bb8:	f022                	sd	s0,32(sp)
    80004bba:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004bbc:	fd840593          	addi	a1,s0,-40
    80004bc0:	4505                	li	a0,1
    80004bc2:	c0bfd0ef          	jal	800027cc <_Z7argaddriPm>
  argint(2, &n);
    80004bc6:	fe440593          	addi	a1,s0,-28
    80004bca:	4509                	li	a0,2
    80004bcc:	be5fd0ef          	jal	800027b0 <_Z6argintiPi>
  if (argfd(0, 0, &f) < 0)
    80004bd0:	fe840613          	addi	a2,s0,-24
    80004bd4:	4581                	li	a1,0
    80004bd6:	4501                	li	a0,0
    80004bd8:	d79ff0ef          	jal	80004950 <_ZL5argfdiPiPP4file>
    80004bdc:	87aa                	mv	a5,a0
    return -1;
    80004bde:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004be0:	0007ca63          	bltz	a5,80004bf4 <_Z9sys_writev+0x40>
  return filewrite(f, p, n);
    80004be4:	fe442603          	lw	a2,-28(s0)
    80004be8:	fd843583          	ld	a1,-40(s0)
    80004bec:	fe843503          	ld	a0,-24(s0)
    80004bf0:	e22ff0ef          	jal	80004212 <_Z9filewriteP4filemi>
}
    80004bf4:	70a2                	ld	ra,40(sp)
    80004bf6:	7402                	ld	s0,32(sp)
    80004bf8:	6145                	addi	sp,sp,48
    80004bfa:	8082                	ret

0000000080004bfc <_Z9sys_closev>:
{
    80004bfc:	1101                	addi	sp,sp,-32
    80004bfe:	ec06                	sd	ra,24(sp)
    80004c00:	e822                	sd	s0,16(sp)
    80004c02:	1000                	addi	s0,sp,32
  if (argfd(0, &fd, &f) < 0)
    80004c04:	fe040613          	addi	a2,s0,-32
    80004c08:	fec40593          	addi	a1,s0,-20
    80004c0c:	4501                	li	a0,0
    80004c0e:	d43ff0ef          	jal	80004950 <_ZL5argfdiPiPP4file>
    return -1;
    80004c12:	57fd                	li	a5,-1
  if (argfd(0, &fd, &f) < 0)
    80004c14:	02054063          	bltz	a0,80004c34 <_Z9sys_closev+0x38>
  myproc()->ofile[fd] = 0;
    80004c18:	ca3fc0ef          	jal	800018ba <_Z6myprocv>
    80004c1c:	fec42783          	lw	a5,-20(s0)
    80004c20:	07e9                	addi	a5,a5,26
    80004c22:	078e                	slli	a5,a5,0x3
    80004c24:	953e                	add	a0,a0,a5
    80004c26:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004c2a:	fe043503          	ld	a0,-32(s0)
    80004c2e:	c06ff0ef          	jal	80004034 <_Z9filecloseP4file>
  return 0;
    80004c32:	4781                	li	a5,0
}
    80004c34:	853e                	mv	a0,a5
    80004c36:	60e2                	ld	ra,24(sp)
    80004c38:	6442                	ld	s0,16(sp)
    80004c3a:	6105                	addi	sp,sp,32
    80004c3c:	8082                	ret

0000000080004c3e <_Z9sys_fstatv>:
{
    80004c3e:	1101                	addi	sp,sp,-32
    80004c40:	ec06                	sd	ra,24(sp)
    80004c42:	e822                	sd	s0,16(sp)
    80004c44:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004c46:	fe040593          	addi	a1,s0,-32
    80004c4a:	4505                	li	a0,1
    80004c4c:	b81fd0ef          	jal	800027cc <_Z7argaddriPm>
  if (argfd(0, 0, &f) < 0)
    80004c50:	fe840613          	addi	a2,s0,-24
    80004c54:	4581                	li	a1,0
    80004c56:	4501                	li	a0,0
    80004c58:	cf9ff0ef          	jal	80004950 <_ZL5argfdiPiPP4file>
    80004c5c:	87aa                	mv	a5,a0
    return -1;
    80004c5e:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004c60:	0007c863          	bltz	a5,80004c70 <_Z9sys_fstatv+0x32>
  return filestat(f, st);
    80004c64:	fe043583          	ld	a1,-32(s0)
    80004c68:	fe843503          	ld	a0,-24(s0)
    80004c6c:	c8aff0ef          	jal	800040f6 <_Z8filestatP4filem>
}
    80004c70:	60e2                	ld	ra,24(sp)
    80004c72:	6442                	ld	s0,16(sp)
    80004c74:	6105                	addi	sp,sp,32
    80004c76:	8082                	ret

0000000080004c78 <_Z8sys_linkv>:
{
    80004c78:	7169                	addi	sp,sp,-304
    80004c7a:	f606                	sd	ra,296(sp)
    80004c7c:	f222                	sd	s0,288(sp)
    80004c7e:	1a00                	addi	s0,sp,304
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new_path, MAXPATH) < 0)
    80004c80:	08000613          	li	a2,128
    80004c84:	ed040593          	addi	a1,s0,-304
    80004c88:	4501                	li	a0,0
    80004c8a:	b5ffd0ef          	jal	800027e8 <_Z6argstriPci>
    return -1;
    80004c8e:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new_path, MAXPATH) < 0)
    80004c90:	0c054e63          	bltz	a0,80004d6c <_Z8sys_linkv+0xf4>
    80004c94:	08000613          	li	a2,128
    80004c98:	f5040593          	addi	a1,s0,-176
    80004c9c:	4505                	li	a0,1
    80004c9e:	b4bfd0ef          	jal	800027e8 <_Z6argstriPci>
    return -1;
    80004ca2:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new_path, MAXPATH) < 0)
    80004ca4:	0c054463          	bltz	a0,80004d6c <_Z8sys_linkv+0xf4>
    80004ca8:	ee26                	sd	s1,280(sp)
  begin_op();
    80004caa:	f17fe0ef          	jal	80003bc0 <_Z8begin_opv>
  if ((ip = namei(old)) == 0) {
    80004cae:	ed040513          	addi	a0,s0,-304
    80004cb2:	d09fe0ef          	jal	800039ba <_Z5nameiPKc>
    80004cb6:	84aa                	mv	s1,a0
    80004cb8:	c53d                	beqz	a0,80004d26 <_Z8sys_linkv+0xae>
  ilock(ip);
    80004cba:	ce4fe0ef          	jal	8000319e <_Z5ilockP5inode>
  if (ip->type == T_DIR) {
    80004cbe:	04449703          	lh	a4,68(s1)
    80004cc2:	4785                	li	a5,1
    80004cc4:	06f70663          	beq	a4,a5,80004d30 <_Z8sys_linkv+0xb8>
    80004cc8:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004cca:	04a4d783          	lhu	a5,74(s1)
    80004cce:	2785                	addiw	a5,a5,1
    80004cd0:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004cd4:	8526                	mv	a0,s1
    80004cd6:	c14fe0ef          	jal	800030ea <_Z7iupdateP5inode>
  iunlock(ip);
    80004cda:	8526                	mv	a0,s1
    80004cdc:	d70fe0ef          	jal	8000324c <_Z7iunlockP5inode>
  if ((dp = nameiparent(new_path, name)) == 0)
    80004ce0:	fd040593          	addi	a1,s0,-48
    80004ce4:	f5040513          	addi	a0,s0,-176
    80004ce8:	cedfe0ef          	jal	800039d4 <_Z11nameiparentPKcPc>
    80004cec:	892a                	mv	s2,a0
    80004cee:	cd21                	beqz	a0,80004d46 <_Z8sys_linkv+0xce>
  ilock(dp);
    80004cf0:	caefe0ef          	jal	8000319e <_Z5ilockP5inode>
  if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    80004cf4:	00092703          	lw	a4,0(s2)
    80004cf8:	409c                	lw	a5,0(s1)
    80004cfa:	04f71363          	bne	a4,a5,80004d40 <_Z8sys_linkv+0xc8>
    80004cfe:	40d0                	lw	a2,4(s1)
    80004d00:	fd040593          	addi	a1,s0,-48
    80004d04:	854a                	mv	a0,s2
    80004d06:	c1bfe0ef          	jal	80003920 <_Z7dirlinkP5inodePKcj>
    80004d0a:	02054b63          	bltz	a0,80004d40 <_Z8sys_linkv+0xc8>
  iunlockput(dp);
    80004d0e:	854a                	mv	a0,s2
    80004d10:	e98fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
  iput(ip);
    80004d14:	8526                	mv	a0,s1
    80004d16:	e0afe0ef          	jal	80003320 <_Z4iputP5inode>
  end_op();
    80004d1a:	f11fe0ef          	jal	80003c2a <_Z6end_opv>
  return 0;
    80004d1e:	4781                	li	a5,0
    80004d20:	64f2                	ld	s1,280(sp)
    80004d22:	6952                	ld	s2,272(sp)
    80004d24:	a0a1                	j	80004d6c <_Z8sys_linkv+0xf4>
    end_op();
    80004d26:	f05fe0ef          	jal	80003c2a <_Z6end_opv>
    return -1;
    80004d2a:	57fd                	li	a5,-1
    80004d2c:	64f2                	ld	s1,280(sp)
    80004d2e:	a83d                	j	80004d6c <_Z8sys_linkv+0xf4>
    iunlockput(ip);
    80004d30:	8526                	mv	a0,s1
    80004d32:	e76fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
    end_op();
    80004d36:	ef5fe0ef          	jal	80003c2a <_Z6end_opv>
    return -1;
    80004d3a:	57fd                	li	a5,-1
    80004d3c:	64f2                	ld	s1,280(sp)
    80004d3e:	a03d                	j	80004d6c <_Z8sys_linkv+0xf4>
    iunlockput(dp);
    80004d40:	854a                	mv	a0,s2
    80004d42:	e66fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
  ilock(ip);
    80004d46:	8526                	mv	a0,s1
    80004d48:	c56fe0ef          	jal	8000319e <_Z5ilockP5inode>
  ip->nlink--;
    80004d4c:	04a4d783          	lhu	a5,74(s1)
    80004d50:	37fd                	addiw	a5,a5,-1
    80004d52:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004d56:	8526                	mv	a0,s1
    80004d58:	b92fe0ef          	jal	800030ea <_Z7iupdateP5inode>
  iunlockput(ip);
    80004d5c:	8526                	mv	a0,s1
    80004d5e:	e4afe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
  end_op();
    80004d62:	ec9fe0ef          	jal	80003c2a <_Z6end_opv>
  return -1;
    80004d66:	57fd                	li	a5,-1
    80004d68:	64f2                	ld	s1,280(sp)
    80004d6a:	6952                	ld	s2,272(sp)
}
    80004d6c:	853e                	mv	a0,a5
    80004d6e:	70b2                	ld	ra,296(sp)
    80004d70:	7412                	ld	s0,288(sp)
    80004d72:	6155                	addi	sp,sp,304
    80004d74:	8082                	ret

0000000080004d76 <_Z10sys_unlinkv>:
{
    80004d76:	7151                	addi	sp,sp,-240
    80004d78:	f586                	sd	ra,232(sp)
    80004d7a:	f1a2                	sd	s0,224(sp)
    80004d7c:	1980                	addi	s0,sp,240
  if (argstr(0, path, MAXPATH) < 0)
    80004d7e:	08000613          	li	a2,128
    80004d82:	f3040593          	addi	a1,s0,-208
    80004d86:	4501                	li	a0,0
    80004d88:	a61fd0ef          	jal	800027e8 <_Z6argstriPci>
    80004d8c:	16054063          	bltz	a0,80004eec <_Z10sys_unlinkv+0x176>
    80004d90:	eda6                	sd	s1,216(sp)
  begin_op();
    80004d92:	e2ffe0ef          	jal	80003bc0 <_Z8begin_opv>
  if ((dp = nameiparent(path, name)) == 0) {
    80004d96:	fb040593          	addi	a1,s0,-80
    80004d9a:	f3040513          	addi	a0,s0,-208
    80004d9e:	c37fe0ef          	jal	800039d4 <_Z11nameiparentPKcPc>
    80004da2:	84aa                	mv	s1,a0
    80004da4:	c945                	beqz	a0,80004e54 <_Z10sys_unlinkv+0xde>
  ilock(dp);
    80004da6:	bf8fe0ef          	jal	8000319e <_Z5ilockP5inode>
  if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004daa:	00003597          	auipc	a1,0x3
    80004dae:	81658593          	addi	a1,a1,-2026 # 800075c0 <etext+0x5c0>
    80004db2:	fb040513          	addi	a0,s0,-80
    80004db6:	989fe0ef          	jal	8000373e <_Z7namecmpPKcS0_>
    80004dba:	10050e63          	beqz	a0,80004ed6 <_Z10sys_unlinkv+0x160>
    80004dbe:	00003597          	auipc	a1,0x3
    80004dc2:	80a58593          	addi	a1,a1,-2038 # 800075c8 <etext+0x5c8>
    80004dc6:	fb040513          	addi	a0,s0,-80
    80004dca:	975fe0ef          	jal	8000373e <_Z7namecmpPKcS0_>
    80004dce:	10050463          	beqz	a0,80004ed6 <_Z10sys_unlinkv+0x160>
    80004dd2:	e9ca                	sd	s2,208(sp)
  if ((ip = dirlookup(dp, name, &off)) == 0)
    80004dd4:	f2c40613          	addi	a2,s0,-212
    80004dd8:	fb040593          	addi	a1,s0,-80
    80004ddc:	8526                	mv	a0,s1
    80004dde:	977fe0ef          	jal	80003754 <_Z9dirlookupP5inodePKcPj>
    80004de2:	892a                	mv	s2,a0
    80004de4:	0e050863          	beqz	a0,80004ed4 <_Z10sys_unlinkv+0x15e>
  ilock(ip);
    80004de8:	bb6fe0ef          	jal	8000319e <_Z5ilockP5inode>
  if (ip->nlink < 1)
    80004dec:	04a91783          	lh	a5,74(s2)
    80004df0:	06f05763          	blez	a5,80004e5e <_Z10sys_unlinkv+0xe8>
  if (ip->type == T_DIR && !isdirempty(ip)) {
    80004df4:	04491703          	lh	a4,68(s2)
    80004df8:	4785                	li	a5,1
    80004dfa:	06f70963          	beq	a4,a5,80004e6c <_Z10sys_unlinkv+0xf6>
  memset(&de, 0, sizeof(de));
    80004dfe:	4641                	li	a2,16
    80004e00:	4581                	li	a1,0
    80004e02:	fc040513          	addi	a0,s0,-64
    80004e06:	e7ffb0ef          	jal	80000c84 <_Z6memsetPvij>
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004e0a:	4741                	li	a4,16
    80004e0c:	f2c42683          	lw	a3,-212(s0)
    80004e10:	fc040613          	addi	a2,s0,-64
    80004e14:	4581                	li	a1,0
    80004e16:	8526                	mv	a0,s1
    80004e18:	813fe0ef          	jal	8000362a <_Z6writeiP5inodeimjj>
    80004e1c:	47c1                	li	a5,16
    80004e1e:	08f51b63          	bne	a0,a5,80004eb4 <_Z10sys_unlinkv+0x13e>
  if (ip->type == T_DIR) {
    80004e22:	04491703          	lh	a4,68(s2)
    80004e26:	4785                	li	a5,1
    80004e28:	08f70d63          	beq	a4,a5,80004ec2 <_Z10sys_unlinkv+0x14c>
  iunlockput(dp);
    80004e2c:	8526                	mv	a0,s1
    80004e2e:	d7afe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
  ip->nlink--;
    80004e32:	04a95783          	lhu	a5,74(s2)
    80004e36:	37fd                	addiw	a5,a5,-1
    80004e38:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004e3c:	854a                	mv	a0,s2
    80004e3e:	aacfe0ef          	jal	800030ea <_Z7iupdateP5inode>
  iunlockput(ip);
    80004e42:	854a                	mv	a0,s2
    80004e44:	d64fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
  end_op();
    80004e48:	de3fe0ef          	jal	80003c2a <_Z6end_opv>
  return 0;
    80004e4c:	4501                	li	a0,0
    80004e4e:	64ee                	ld	s1,216(sp)
    80004e50:	694e                	ld	s2,208(sp)
    80004e52:	a849                	j	80004ee4 <_Z10sys_unlinkv+0x16e>
    end_op();
    80004e54:	dd7fe0ef          	jal	80003c2a <_Z6end_opv>
    return -1;
    80004e58:	557d                	li	a0,-1
    80004e5a:	64ee                	ld	s1,216(sp)
    80004e5c:	a061                	j	80004ee4 <_Z10sys_unlinkv+0x16e>
    80004e5e:	e5ce                	sd	s3,200(sp)
    panic("unlink: nlink < 1");
    80004e60:	00002517          	auipc	a0,0x2
    80004e64:	77050513          	addi	a0,a0,1904 # 800075d0 <etext+0x5d0>
    80004e68:	98bfb0ef          	jal	800007f2 <_Z5panicPKc>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80004e6c:	04c92703          	lw	a4,76(s2)
    80004e70:	02000793          	li	a5,32
    80004e74:	f8e7f5e3          	bgeu	a5,a4,80004dfe <_Z10sys_unlinkv+0x88>
    80004e78:	e5ce                	sd	s3,200(sp)
    80004e7a:	02000993          	li	s3,32
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004e7e:	4741                	li	a4,16
    80004e80:	86ce                	mv	a3,s3
    80004e82:	f1840613          	addi	a2,s0,-232
    80004e86:	4581                	li	a1,0
    80004e88:	854a                	mv	a0,s2
    80004e8a:	ea4fe0ef          	jal	8000352e <_Z5readiP5inodeimjj>
    80004e8e:	47c1                	li	a5,16
    80004e90:	00f51c63          	bne	a0,a5,80004ea8 <_Z10sys_unlinkv+0x132>
    if (de.inum != 0)
    80004e94:	f1845783          	lhu	a5,-232(s0)
    80004e98:	efa1                	bnez	a5,80004ef0 <_Z10sys_unlinkv+0x17a>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80004e9a:	29c1                	addiw	s3,s3,16
    80004e9c:	04c92783          	lw	a5,76(s2)
    80004ea0:	fcf9efe3          	bltu	s3,a5,80004e7e <_Z10sys_unlinkv+0x108>
    80004ea4:	69ae                	ld	s3,200(sp)
    80004ea6:	bfa1                	j	80004dfe <_Z10sys_unlinkv+0x88>
      panic("isdirempty: readi");
    80004ea8:	00002517          	auipc	a0,0x2
    80004eac:	74050513          	addi	a0,a0,1856 # 800075e8 <etext+0x5e8>
    80004eb0:	943fb0ef          	jal	800007f2 <_Z5panicPKc>
    80004eb4:	e5ce                	sd	s3,200(sp)
    panic("unlink: writei");
    80004eb6:	00002517          	auipc	a0,0x2
    80004eba:	74a50513          	addi	a0,a0,1866 # 80007600 <etext+0x600>
    80004ebe:	935fb0ef          	jal	800007f2 <_Z5panicPKc>
    dp->nlink--;
    80004ec2:	04a4d783          	lhu	a5,74(s1)
    80004ec6:	37fd                	addiw	a5,a5,-1
    80004ec8:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004ecc:	8526                	mv	a0,s1
    80004ece:	a1cfe0ef          	jal	800030ea <_Z7iupdateP5inode>
    80004ed2:	bfa9                	j	80004e2c <_Z10sys_unlinkv+0xb6>
    80004ed4:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80004ed6:	8526                	mv	a0,s1
    80004ed8:	cd0fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
  end_op();
    80004edc:	d4ffe0ef          	jal	80003c2a <_Z6end_opv>
  return -1;
    80004ee0:	557d                	li	a0,-1
    80004ee2:	64ee                	ld	s1,216(sp)
}
    80004ee4:	70ae                	ld	ra,232(sp)
    80004ee6:	740e                	ld	s0,224(sp)
    80004ee8:	616d                	addi	sp,sp,240
    80004eea:	8082                	ret
    return -1;
    80004eec:	557d                	li	a0,-1
    80004eee:	bfdd                	j	80004ee4 <_Z10sys_unlinkv+0x16e>
    iunlockput(ip);
    80004ef0:	854a                	mv	a0,s2
    80004ef2:	cb6fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
    goto bad;
    80004ef6:	694e                	ld	s2,208(sp)
    80004ef8:	69ae                	ld	s3,200(sp)
    80004efa:	bff1                	j	80004ed6 <_Z10sys_unlinkv+0x160>

0000000080004efc <_Z8sys_openv>:

uint64
sys_open(void)
{
    80004efc:	7131                	addi	sp,sp,-192
    80004efe:	fd06                	sd	ra,184(sp)
    80004f00:	f922                	sd	s0,176(sp)
    80004f02:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80004f04:	f4c40593          	addi	a1,s0,-180
    80004f08:	4505                	li	a0,1
    80004f0a:	8a7fd0ef          	jal	800027b0 <_Z6argintiPi>
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80004f0e:	08000613          	li	a2,128
    80004f12:	f5040593          	addi	a1,s0,-176
    80004f16:	4501                	li	a0,0
    80004f18:	8d1fd0ef          	jal	800027e8 <_Z6argstriPci>
    80004f1c:	87aa                	mv	a5,a0
    return -1;
    80004f1e:	557d                	li	a0,-1
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80004f20:	0a07c363          	bltz	a5,80004fc6 <_Z8sys_openv+0xca>
    80004f24:	f526                	sd	s1,168(sp)

  begin_op();
    80004f26:	c9bfe0ef          	jal	80003bc0 <_Z8begin_opv>

  if (omode & O_CREATE) {
    80004f2a:	f4c42783          	lw	a5,-180(s0)
    80004f2e:	2007f793          	andi	a5,a5,512
    80004f32:	c3dd                	beqz	a5,80004fd8 <_Z8sys_openv+0xdc>
    ip = create(path, T_FILE, 0, 0);
    80004f34:	4681                	li	a3,0
    80004f36:	4601                	li	a2,0
    80004f38:	4589                	li	a1,2
    80004f3a:	f5040513          	addi	a0,s0,-176
    80004f3e:	aa9ff0ef          	jal	800049e6 <_ZL6createPcsss>
    80004f42:	84aa                	mv	s1,a0
    if (ip == 0) {
    80004f44:	c549                	beqz	a0,80004fce <_Z8sys_openv+0xd2>
      end_op();
      return -1;
    }
  }

  if (ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)) {
    80004f46:	04449703          	lh	a4,68(s1)
    80004f4a:	478d                	li	a5,3
    80004f4c:	00f71763          	bne	a4,a5,80004f5a <_Z8sys_openv+0x5e>
    80004f50:	0464d703          	lhu	a4,70(s1)
    80004f54:	47a5                	li	a5,9
    80004f56:	0ae7ee63          	bltu	a5,a4,80005012 <_Z8sys_openv+0x116>
    80004f5a:	ed4e                	sd	s3,152(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if ((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0) {
    80004f5c:	834ff0ef          	jal	80003f90 <_Z9fileallocv>
    80004f60:	89aa                	mv	s3,a0
    80004f62:	0e050063          	beqz	a0,80005042 <_Z8sys_openv+0x146>
    80004f66:	f14a                	sd	s2,160(sp)
    80004f68:	a41ff0ef          	jal	800049a8 <_ZL7fdallocP4file>
    80004f6c:	892a                	mv	s2,a0
    80004f6e:	0c054663          	bltz	a0,8000503a <_Z8sys_openv+0x13e>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if (ip->type == T_DEVICE) {
    80004f72:	04449703          	lh	a4,68(s1)
    80004f76:	478d                	li	a5,3
    80004f78:	0af70563          	beq	a4,a5,80005022 <_Z8sys_openv+0x126>
    f->type = file::FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = file::FD_INODE;
    80004f7c:	4789                	li	a5,2
    80004f7e:	00f9a023          	sw	a5,0(s3)
    f->off = 0;
    80004f82:	0209a023          	sw	zero,32(s3)
  }
  f->ip = ip;
    80004f86:	0099bc23          	sd	s1,24(s3)
  f->readable = !(omode & O_WRONLY);
    80004f8a:	f4c42783          	lw	a5,-180(s0)
    80004f8e:	0017c713          	xori	a4,a5,1
    80004f92:	8b05                	andi	a4,a4,1
    80004f94:	00e98423          	sb	a4,8(s3)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004f98:	0037f713          	andi	a4,a5,3
    80004f9c:	00e03733          	snez	a4,a4
    80004fa0:	00e984a3          	sb	a4,9(s3)

  if ((omode & O_TRUNC) && ip->type == T_FILE) {
    80004fa4:	4007f793          	andi	a5,a5,1024
    80004fa8:	c791                	beqz	a5,80004fb4 <_Z8sys_openv+0xb8>
    80004faa:	04449703          	lh	a4,68(s1)
    80004fae:	4789                	li	a5,2
    80004fb0:	08f70163          	beq	a4,a5,80005032 <_Z8sys_openv+0x136>
    itrunc(ip);
  }

  iunlock(ip);
    80004fb4:	8526                	mv	a0,s1
    80004fb6:	a96fe0ef          	jal	8000324c <_Z7iunlockP5inode>
  end_op();
    80004fba:	c71fe0ef          	jal	80003c2a <_Z6end_opv>

  return fd;
    80004fbe:	854a                	mv	a0,s2
    80004fc0:	74aa                	ld	s1,168(sp)
    80004fc2:	790a                	ld	s2,160(sp)
    80004fc4:	69ea                	ld	s3,152(sp)
}
    80004fc6:	70ea                	ld	ra,184(sp)
    80004fc8:	744a                	ld	s0,176(sp)
    80004fca:	6129                	addi	sp,sp,192
    80004fcc:	8082                	ret
      end_op();
    80004fce:	c5dfe0ef          	jal	80003c2a <_Z6end_opv>
      return -1;
    80004fd2:	557d                	li	a0,-1
    80004fd4:	74aa                	ld	s1,168(sp)
    80004fd6:	bfc5                	j	80004fc6 <_Z8sys_openv+0xca>
    if ((ip = namei(path)) == 0) {
    80004fd8:	f5040513          	addi	a0,s0,-176
    80004fdc:	9dffe0ef          	jal	800039ba <_Z5nameiPKc>
    80004fe0:	84aa                	mv	s1,a0
    80004fe2:	c11d                	beqz	a0,80005008 <_Z8sys_openv+0x10c>
    ilock(ip);
    80004fe4:	9bafe0ef          	jal	8000319e <_Z5ilockP5inode>
    if (ip->type == T_DIR && omode != O_RDONLY) {
    80004fe8:	04449703          	lh	a4,68(s1)
    80004fec:	4785                	li	a5,1
    80004fee:	f4f71ce3          	bne	a4,a5,80004f46 <_Z8sys_openv+0x4a>
    80004ff2:	f4c42783          	lw	a5,-180(s0)
    80004ff6:	d3b5                	beqz	a5,80004f5a <_Z8sys_openv+0x5e>
      iunlockput(ip);
    80004ff8:	8526                	mv	a0,s1
    80004ffa:	baefe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
      end_op();
    80004ffe:	c2dfe0ef          	jal	80003c2a <_Z6end_opv>
      return -1;
    80005002:	557d                	li	a0,-1
    80005004:	74aa                	ld	s1,168(sp)
    80005006:	b7c1                	j	80004fc6 <_Z8sys_openv+0xca>
      end_op();
    80005008:	c23fe0ef          	jal	80003c2a <_Z6end_opv>
      return -1;
    8000500c:	557d                	li	a0,-1
    8000500e:	74aa                	ld	s1,168(sp)
    80005010:	bf5d                	j	80004fc6 <_Z8sys_openv+0xca>
    iunlockput(ip);
    80005012:	8526                	mv	a0,s1
    80005014:	b94fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
    end_op();
    80005018:	c13fe0ef          	jal	80003c2a <_Z6end_opv>
    return -1;
    8000501c:	557d                	li	a0,-1
    8000501e:	74aa                	ld	s1,168(sp)
    80005020:	b75d                	j	80004fc6 <_Z8sys_openv+0xca>
    f->type = file::FD_DEVICE;
    80005022:	478d                	li	a5,3
    80005024:	00f9a023          	sw	a5,0(s3)
    f->major = ip->major;
    80005028:	04649783          	lh	a5,70(s1)
    8000502c:	02f99223          	sh	a5,36(s3)
    80005030:	bf99                	j	80004f86 <_Z8sys_openv+0x8a>
    itrunc(ip);
    80005032:	8526                	mv	a0,s1
    80005034:	a58fe0ef          	jal	8000328c <_Z6itruncP5inode>
    80005038:	bfb5                	j	80004fb4 <_Z8sys_openv+0xb8>
      fileclose(f);
    8000503a:	854e                	mv	a0,s3
    8000503c:	ff9fe0ef          	jal	80004034 <_Z9filecloseP4file>
    80005040:	790a                	ld	s2,160(sp)
    iunlockput(ip);
    80005042:	8526                	mv	a0,s1
    80005044:	b64fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
    end_op();
    80005048:	be3fe0ef          	jal	80003c2a <_Z6end_opv>
    return -1;
    8000504c:	557d                	li	a0,-1
    8000504e:	74aa                	ld	s1,168(sp)
    80005050:	69ea                	ld	s3,152(sp)
    80005052:	bf95                	j	80004fc6 <_Z8sys_openv+0xca>

0000000080005054 <_Z9sys_mkdirv>:

uint64
sys_mkdir(void)
{
    80005054:	7175                	addi	sp,sp,-144
    80005056:	e506                	sd	ra,136(sp)
    80005058:	e122                	sd	s0,128(sp)
    8000505a:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    8000505c:	b65fe0ef          	jal	80003bc0 <_Z8begin_opv>
  if (argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0) {
    80005060:	08000613          	li	a2,128
    80005064:	f7040593          	addi	a1,s0,-144
    80005068:	4501                	li	a0,0
    8000506a:	f7efd0ef          	jal	800027e8 <_Z6argstriPci>
    8000506e:	02054363          	bltz	a0,80005094 <_Z9sys_mkdirv+0x40>
    80005072:	4681                	li	a3,0
    80005074:	4601                	li	a2,0
    80005076:	4585                	li	a1,1
    80005078:	f7040513          	addi	a0,s0,-144
    8000507c:	96bff0ef          	jal	800049e6 <_ZL6createPcsss>
    80005080:	c911                	beqz	a0,80005094 <_Z9sys_mkdirv+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005082:	b26fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
  end_op();
    80005086:	ba5fe0ef          	jal	80003c2a <_Z6end_opv>
  return 0;
    8000508a:	4501                	li	a0,0
}
    8000508c:	60aa                	ld	ra,136(sp)
    8000508e:	640a                	ld	s0,128(sp)
    80005090:	6149                	addi	sp,sp,144
    80005092:	8082                	ret
    end_op();
    80005094:	b97fe0ef          	jal	80003c2a <_Z6end_opv>
    return -1;
    80005098:	557d                	li	a0,-1
    8000509a:	bfcd                	j	8000508c <_Z9sys_mkdirv+0x38>

000000008000509c <_Z9sys_mknodv>:

uint64
sys_mknod(void)
{
    8000509c:	7135                	addi	sp,sp,-160
    8000509e:	ed06                	sd	ra,152(sp)
    800050a0:	e922                	sd	s0,144(sp)
    800050a2:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    800050a4:	b1dfe0ef          	jal	80003bc0 <_Z8begin_opv>
  argint(1, &major);
    800050a8:	f6c40593          	addi	a1,s0,-148
    800050ac:	4505                	li	a0,1
    800050ae:	f02fd0ef          	jal	800027b0 <_Z6argintiPi>
  argint(2, &minor);
    800050b2:	f6840593          	addi	a1,s0,-152
    800050b6:	4509                	li	a0,2
    800050b8:	ef8fd0ef          	jal	800027b0 <_Z6argintiPi>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    800050bc:	08000613          	li	a2,128
    800050c0:	f7040593          	addi	a1,s0,-144
    800050c4:	4501                	li	a0,0
    800050c6:	f22fd0ef          	jal	800027e8 <_Z6argstriPci>
    800050ca:	02054563          	bltz	a0,800050f4 <_Z9sys_mknodv+0x58>
      (ip = create(path, T_DEVICE, major, minor)) == 0) {
    800050ce:	f6841683          	lh	a3,-152(s0)
    800050d2:	f6c41603          	lh	a2,-148(s0)
    800050d6:	458d                	li	a1,3
    800050d8:	f7040513          	addi	a0,s0,-144
    800050dc:	90bff0ef          	jal	800049e6 <_ZL6createPcsss>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    800050e0:	c911                	beqz	a0,800050f4 <_Z9sys_mknodv+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800050e2:	ac6fe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
  end_op();
    800050e6:	b45fe0ef          	jal	80003c2a <_Z6end_opv>
  return 0;
    800050ea:	4501                	li	a0,0
}
    800050ec:	60ea                	ld	ra,152(sp)
    800050ee:	644a                	ld	s0,144(sp)
    800050f0:	610d                	addi	sp,sp,160
    800050f2:	8082                	ret
    end_op();
    800050f4:	b37fe0ef          	jal	80003c2a <_Z6end_opv>
    return -1;
    800050f8:	557d                	li	a0,-1
    800050fa:	bfcd                	j	800050ec <_Z9sys_mknodv+0x50>

00000000800050fc <_Z9sys_chdirv>:

uint64
sys_chdir(void)
{
    800050fc:	7135                	addi	sp,sp,-160
    800050fe:	ed06                	sd	ra,152(sp)
    80005100:	e922                	sd	s0,144(sp)
    80005102:	e14a                	sd	s2,128(sp)
    80005104:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005106:	fb4fc0ef          	jal	800018ba <_Z6myprocv>
    8000510a:	892a                	mv	s2,a0

  begin_op();
    8000510c:	ab5fe0ef          	jal	80003bc0 <_Z8begin_opv>
  if (argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0) {
    80005110:	08000613          	li	a2,128
    80005114:	f6040593          	addi	a1,s0,-160
    80005118:	4501                	li	a0,0
    8000511a:	ecefd0ef          	jal	800027e8 <_Z6argstriPci>
    8000511e:	04054363          	bltz	a0,80005164 <_Z9sys_chdirv+0x68>
    80005122:	e526                	sd	s1,136(sp)
    80005124:	f6040513          	addi	a0,s0,-160
    80005128:	893fe0ef          	jal	800039ba <_Z5nameiPKc>
    8000512c:	84aa                	mv	s1,a0
    8000512e:	c915                	beqz	a0,80005162 <_Z9sys_chdirv+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80005130:	86efe0ef          	jal	8000319e <_Z5ilockP5inode>
  if (ip->type != T_DIR) {
    80005134:	04449703          	lh	a4,68(s1)
    80005138:	4785                	li	a5,1
    8000513a:	02f71963          	bne	a4,a5,8000516c <_Z9sys_chdirv+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    8000513e:	8526                	mv	a0,s1
    80005140:	90cfe0ef          	jal	8000324c <_Z7iunlockP5inode>
  iput(p->cwd);
    80005144:	15093503          	ld	a0,336(s2)
    80005148:	9d8fe0ef          	jal	80003320 <_Z4iputP5inode>
  end_op();
    8000514c:	adffe0ef          	jal	80003c2a <_Z6end_opv>
  p->cwd = ip;
    80005150:	14993823          	sd	s1,336(s2)
  return 0;
    80005154:	4501                	li	a0,0
    80005156:	64aa                	ld	s1,136(sp)
}
    80005158:	60ea                	ld	ra,152(sp)
    8000515a:	644a                	ld	s0,144(sp)
    8000515c:	690a                	ld	s2,128(sp)
    8000515e:	610d                	addi	sp,sp,160
    80005160:	8082                	ret
    80005162:	64aa                	ld	s1,136(sp)
    end_op();
    80005164:	ac7fe0ef          	jal	80003c2a <_Z6end_opv>
    return -1;
    80005168:	557d                	li	a0,-1
    8000516a:	b7fd                	j	80005158 <_Z9sys_chdirv+0x5c>
    iunlockput(ip);
    8000516c:	8526                	mv	a0,s1
    8000516e:	a3afe0ef          	jal	800033a8 <_Z10iunlockputP5inode>
    end_op();
    80005172:	ab9fe0ef          	jal	80003c2a <_Z6end_opv>
    return -1;
    80005176:	557d                	li	a0,-1
    80005178:	64aa                	ld	s1,136(sp)
    8000517a:	bff9                	j	80005158 <_Z9sys_chdirv+0x5c>

000000008000517c <_Z8sys_execv>:

uint64
sys_exec(void)
{
    8000517c:	7121                	addi	sp,sp,-448
    8000517e:	ff06                	sd	ra,440(sp)
    80005180:	fb22                	sd	s0,432(sp)
    80005182:	0380                	addi	s0,sp,448
  char path[MAXPATH], *argv[MAXARG];
  uint i;
  uint64 uargv, uarg;
  int ret;

  argaddr(1, &uargv);
    80005184:	e4840593          	addi	a1,s0,-440
    80005188:	4505                	li	a0,1
    8000518a:	e42fd0ef          	jal	800027cc <_Z7argaddriPm>
  if (argstr(0, path, MAXPATH) < 0) {
    8000518e:	08000613          	li	a2,128
    80005192:	f5040593          	addi	a1,s0,-176
    80005196:	4501                	li	a0,0
    80005198:	e50fd0ef          	jal	800027e8 <_Z6argstriPci>
    8000519c:	87aa                	mv	a5,a0
    return -1;
    8000519e:	557d                	li	a0,-1
  if (argstr(0, path, MAXPATH) < 0) {
    800051a0:	0c07c663          	bltz	a5,8000526c <_Z8sys_execv+0xf0>
    800051a4:	f726                	sd	s1,424(sp)
    800051a6:	f34a                	sd	s2,416(sp)
    800051a8:	ef4e                	sd	s3,408(sp)
    800051aa:	eb52                	sd	s4,400(sp)
  }
  memset(argv, 0, sizeof(argv));
    800051ac:	10000613          	li	a2,256
    800051b0:	4581                	li	a1,0
    800051b2:	e5040513          	addi	a0,s0,-432
    800051b6:	acffb0ef          	jal	80000c84 <_Z6memsetPvij>
  for (i = 0;; i++) {
    if (i >= NELEM(argv)) {
    800051ba:	e5040493          	addi	s1,s0,-432
  memset(argv, 0, sizeof(argv));
    800051be:	89a6                	mv	s3,s1
    800051c0:	4901                	li	s2,0
    if (i >= NELEM(argv)) {
    800051c2:	02000a13          	li	s4,32
      goto bad;
    }
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    800051c6:	00391513          	slli	a0,s2,0x3
    800051ca:	e4040593          	addi	a1,s0,-448
    800051ce:	e4843783          	ld	a5,-440(s0)
    800051d2:	953e                	add	a0,a0,a5
    800051d4:	d52fd0ef          	jal	80002726 <_Z9fetchaddrmPm>
    800051d8:	02054663          	bltz	a0,80005204 <_Z8sys_execv+0x88>
      goto bad;
    }
    if (uarg == 0) {
    800051dc:	e4043783          	ld	a5,-448(s0)
    800051e0:	c3a9                	beqz	a5,80005222 <_Z8sys_execv+0xa6>
      argv[i] = 0;
      break;
    }
    argv[i] = static_cast<char *>(kalloc());
    800051e2:	919fb0ef          	jal	80000afa <_Z6kallocv>
    800051e6:	85aa                	mv	a1,a0
    800051e8:	00a9b023          	sd	a0,0(s3)
    if (argv[i] == 0)
    800051ec:	cd01                	beqz	a0,80005204 <_Z8sys_execv+0x88>
      goto bad;
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    800051ee:	6605                	lui	a2,0x1
    800051f0:	e4043503          	ld	a0,-448(s0)
    800051f4:	d7cfd0ef          	jal	80002770 <_Z8fetchstrmPci>
    800051f8:	00054663          	bltz	a0,80005204 <_Z8sys_execv+0x88>
    if (i >= NELEM(argv)) {
    800051fc:	0905                	addi	s2,s2,1
    800051fe:	09a1                	addi	s3,s3,8
    80005200:	fd4913e3          	bne	s2,s4,800051c6 <_Z8sys_execv+0x4a>
    kfree(argv[i]);

  return ret;

bad:
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005204:	f5040913          	addi	s2,s0,-176
    80005208:	6088                	ld	a0,0(s1)
    8000520a:	cd21                	beqz	a0,80005262 <_Z8sys_execv+0xe6>
    kfree(argv[i]);
    8000520c:	80dfb0ef          	jal	80000a18 <_Z5kfreePv>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005210:	04a1                	addi	s1,s1,8
    80005212:	ff249be3          	bne	s1,s2,80005208 <_Z8sys_execv+0x8c>
  return -1;
    80005216:	557d                	li	a0,-1
    80005218:	74ba                	ld	s1,424(sp)
    8000521a:	791a                	ld	s2,416(sp)
    8000521c:	69fa                	ld	s3,408(sp)
    8000521e:	6a5a                	ld	s4,400(sp)
    80005220:	a0b1                	j	8000526c <_Z8sys_execv+0xf0>
      argv[i] = 0;
    80005222:	02091793          	slli	a5,s2,0x20
    80005226:	01d7d913          	srli	s2,a5,0x1d
    8000522a:	fd090793          	addi	a5,s2,-48
    8000522e:	00878933          	add	s2,a5,s0
    80005232:	e8093023          	sd	zero,-384(s2)
  ret = kexec(path, argv);
    80005236:	e5040593          	addi	a1,s0,-432
    8000523a:	f5040513          	addi	a0,s0,-176
    8000523e:	bd8ff0ef          	jal	80004616 <_Z5kexecPKcPKS0_>
    80005242:	892a                	mv	s2,a0
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005244:	f5040993          	addi	s3,s0,-176
    80005248:	6088                	ld	a0,0(s1)
    8000524a:	c511                	beqz	a0,80005256 <_Z8sys_execv+0xda>
    kfree(argv[i]);
    8000524c:	fccfb0ef          	jal	80000a18 <_Z5kfreePv>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005250:	04a1                	addi	s1,s1,8
    80005252:	ff349be3          	bne	s1,s3,80005248 <_Z8sys_execv+0xcc>
  return ret;
    80005256:	854a                	mv	a0,s2
    80005258:	74ba                	ld	s1,424(sp)
    8000525a:	791a                	ld	s2,416(sp)
    8000525c:	69fa                	ld	s3,408(sp)
    8000525e:	6a5a                	ld	s4,400(sp)
    80005260:	a031                	j	8000526c <_Z8sys_execv+0xf0>
  return -1;
    80005262:	557d                	li	a0,-1
    80005264:	74ba                	ld	s1,424(sp)
    80005266:	791a                	ld	s2,416(sp)
    80005268:	69fa                	ld	s3,408(sp)
    8000526a:	6a5a                	ld	s4,400(sp)
}
    8000526c:	70fa                	ld	ra,440(sp)
    8000526e:	745a                	ld	s0,432(sp)
    80005270:	6139                	addi	sp,sp,448
    80005272:	8082                	ret

0000000080005274 <_Z8sys_pipev>:

uint64
sys_pipe(void)
{
    80005274:	7139                	addi	sp,sp,-64
    80005276:	fc06                	sd	ra,56(sp)
    80005278:	f822                	sd	s0,48(sp)
    8000527a:	f426                	sd	s1,40(sp)
    8000527c:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    8000527e:	e3cfc0ef          	jal	800018ba <_Z6myprocv>
    80005282:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005284:	fd840593          	addi	a1,s0,-40
    80005288:	4501                	li	a0,0
    8000528a:	d42fd0ef          	jal	800027cc <_Z7argaddriPm>
  if (pipealloc(&rf, &wf) < 0)
    8000528e:	fc840593          	addi	a1,s0,-56
    80005292:	fd040513          	addi	a0,s0,-48
    80005296:	89cff0ef          	jal	80004332 <_Z9pipeallocPP4fileS1_>
    return -1;
    8000529a:	57fd                	li	a5,-1
  if (pipealloc(&rf, &wf) < 0)
    8000529c:	0a054463          	bltz	a0,80005344 <_Z8sys_pipev+0xd0>
  fd0 = -1;
    800052a0:	fcf42223          	sw	a5,-60(s0)
  if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    800052a4:	fd043503          	ld	a0,-48(s0)
    800052a8:	f00ff0ef          	jal	800049a8 <_ZL7fdallocP4file>
    800052ac:	fca42223          	sw	a0,-60(s0)
    800052b0:	08054163          	bltz	a0,80005332 <_Z8sys_pipev+0xbe>
    800052b4:	fc843503          	ld	a0,-56(s0)
    800052b8:	ef0ff0ef          	jal	800049a8 <_ZL7fdallocP4file>
    800052bc:	fca42023          	sw	a0,-64(s0)
    800052c0:	06054063          	bltz	a0,80005320 <_Z8sys_pipev+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if (copyout(p->pagetable, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    800052c4:	4691                	li	a3,4
    800052c6:	fc440613          	addi	a2,s0,-60
    800052ca:	fd843583          	ld	a1,-40(s0)
    800052ce:	68a8                	ld	a0,80(s1)
    800052d0:	afefc0ef          	jal	800015ce <_Z7copyoutPmmPKcm>
    800052d4:	00054e63          	bltz	a0,800052f0 <_Z8sys_pipev+0x7c>
      copyout(p->pagetable, fdarray + sizeof(fd0), (char *)&fd1, sizeof(fd1)) <
    800052d8:	4691                	li	a3,4
    800052da:	fc040613          	addi	a2,s0,-64
    800052de:	fd843583          	ld	a1,-40(s0)
    800052e2:	0591                	addi	a1,a1,4
    800052e4:	68a8                	ld	a0,80(s1)
    800052e6:	ae8fc0ef          	jal	800015ce <_Z7copyoutPmmPKcm>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800052ea:	4781                	li	a5,0
  if (copyout(p->pagetable, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    800052ec:	04055c63          	bgez	a0,80005344 <_Z8sys_pipev+0xd0>
    p->ofile[fd0] = 0;
    800052f0:	fc442783          	lw	a5,-60(s0)
    800052f4:	07e9                	addi	a5,a5,26
    800052f6:	078e                	slli	a5,a5,0x3
    800052f8:	97a6                	add	a5,a5,s1
    800052fa:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800052fe:	fc042783          	lw	a5,-64(s0)
    80005302:	07e9                	addi	a5,a5,26
    80005304:	078e                	slli	a5,a5,0x3
    80005306:	94be                	add	s1,s1,a5
    80005308:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    8000530c:	fd043503          	ld	a0,-48(s0)
    80005310:	d25fe0ef          	jal	80004034 <_Z9filecloseP4file>
    fileclose(wf);
    80005314:	fc843503          	ld	a0,-56(s0)
    80005318:	d1dfe0ef          	jal	80004034 <_Z9filecloseP4file>
    return -1;
    8000531c:	57fd                	li	a5,-1
    8000531e:	a01d                	j	80005344 <_Z8sys_pipev+0xd0>
    if (fd0 >= 0)
    80005320:	fc442783          	lw	a5,-60(s0)
    80005324:	0007c763          	bltz	a5,80005332 <_Z8sys_pipev+0xbe>
      p->ofile[fd0] = 0;
    80005328:	07e9                	addi	a5,a5,26
    8000532a:	078e                	slli	a5,a5,0x3
    8000532c:	97a6                	add	a5,a5,s1
    8000532e:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005332:	fd043503          	ld	a0,-48(s0)
    80005336:	cfffe0ef          	jal	80004034 <_Z9filecloseP4file>
    fileclose(wf);
    8000533a:	fc843503          	ld	a0,-56(s0)
    8000533e:	cf7fe0ef          	jal	80004034 <_Z9filecloseP4file>
    return -1;
    80005342:	57fd                	li	a5,-1
}
    80005344:	853e                	mv	a0,a5
    80005346:	70e2                	ld	ra,56(sp)
    80005348:	7442                	ld	s0,48(sp)
    8000534a:	74a2                	ld	s1,40(sp)
    8000534c:	6121                	addi	sp,sp,64
    8000534e:	8082                	ret

0000000080005350 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005350:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005352:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005354:	e80e                	sd	gp,16(sp)
        # sd tp, 24(sp)
        sd t0, 32(sp)
    80005356:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    80005358:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000535a:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000535c:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    8000535e:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005360:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005362:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005364:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005366:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    80005368:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000536a:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000536c:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    8000536e:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005370:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005372:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005374:	ac2fd0ef          	jal	80002636 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    80005378:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000537a:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000537c:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    8000537e:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005380:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005382:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005384:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005386:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    80005388:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    8000538a:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    8000538c:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    8000538e:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005390:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005392:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005394:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005396:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    80005398:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    8000539a:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    8000539c:	10200073          	sret
	...

00000000800053ae <_Z8plicinitv>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800053ae:	1141                	addi	sp,sp,-16
    800053b0:	e422                	sd	s0,8(sp)
    800053b2:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32 *)(PLIC + UART0_IRQ * 4) = 1;
    800053b4:	0c0007b7          	lui	a5,0xc000
    800053b8:	4705                	li	a4,1
    800053ba:	d798                	sw	a4,40(a5)
  *(uint32 *)(PLIC + VIRTIO0_IRQ * 4) = 1;
    800053bc:	0c0007b7          	lui	a5,0xc000
    800053c0:	c3d8                	sw	a4,4(a5)
}
    800053c2:	6422                	ld	s0,8(sp)
    800053c4:	0141                	addi	sp,sp,16
    800053c6:	8082                	ret

00000000800053c8 <_Z12plicinithartv>:

void
plicinithart(void)
{
    800053c8:	1141                	addi	sp,sp,-16
    800053ca:	e406                	sd	ra,8(sp)
    800053cc:	e022                	sd	s0,0(sp)
    800053ce:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800053d0:	cbefc0ef          	jal	8000188e <_Z5cpuidv>

  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32 *)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    800053d4:	0085171b          	slliw	a4,a0,0x8
    800053d8:	0c0027b7          	lui	a5,0xc002
    800053dc:	97ba                	add	a5,a5,a4
    800053de:	40200713          	li	a4,1026
    800053e2:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32 *)PLIC_SPRIORITY(hart) = 0;
    800053e6:	00d5151b          	slliw	a0,a0,0xd
    800053ea:	0c2017b7          	lui	a5,0xc201
    800053ee:	97aa                	add	a5,a5,a0
    800053f0:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    800053f4:	60a2                	ld	ra,8(sp)
    800053f6:	6402                	ld	s0,0(sp)
    800053f8:	0141                	addi	sp,sp,16
    800053fa:	8082                	ret

00000000800053fc <_Z10plic_claimv>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800053fc:	1141                	addi	sp,sp,-16
    800053fe:	e406                	sd	ra,8(sp)
    80005400:	e022                	sd	s0,0(sp)
    80005402:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005404:	c8afc0ef          	jal	8000188e <_Z5cpuidv>
  int irq = *(uint32 *)PLIC_SCLAIM(hart);
    80005408:	00d5151b          	slliw	a0,a0,0xd
    8000540c:	0c2017b7          	lui	a5,0xc201
    80005410:	97aa                	add	a5,a5,a0
  return irq;
}
    80005412:	43c8                	lw	a0,4(a5)
    80005414:	60a2                	ld	ra,8(sp)
    80005416:	6402                	ld	s0,0(sp)
    80005418:	0141                	addi	sp,sp,16
    8000541a:	8082                	ret

000000008000541c <_Z13plic_completei>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    8000541c:	1101                	addi	sp,sp,-32
    8000541e:	ec06                	sd	ra,24(sp)
    80005420:	e822                	sd	s0,16(sp)
    80005422:	e426                	sd	s1,8(sp)
    80005424:	1000                	addi	s0,sp,32
    80005426:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005428:	c66fc0ef          	jal	8000188e <_Z5cpuidv>
  *(uint32 *)PLIC_SCLAIM(hart) = irq;
    8000542c:	00d5151b          	slliw	a0,a0,0xd
    80005430:	0c2017b7          	lui	a5,0xc201
    80005434:	97aa                	add	a5,a5,a0
    80005436:	c3c4                	sw	s1,4(a5)
}
    80005438:	60e2                	ld	ra,24(sp)
    8000543a:	6442                	ld	s0,16(sp)
    8000543c:	64a2                	ld	s1,8(sp)
    8000543e:	6105                	addi	sp,sp,32
    80005440:	8082                	ret

0000000080005442 <_ZL9free_desci>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005442:	1141                	addi	sp,sp,-16
    80005444:	e406                	sd	ra,8(sp)
    80005446:	e022                	sd	s0,0(sp)
    80005448:	0800                	addi	s0,sp,16
  if (i >= NUM)
    8000544a:	479d                	li	a5,7
    8000544c:	04a7ca63          	blt	a5,a0,800054a0 <_ZL9free_desci+0x5e>
    panic("free_desc 1");
  if (disk.free[i])
    80005450:	0001b797          	auipc	a5,0x1b
    80005454:	5e878793          	addi	a5,a5,1512 # 80020a38 <_ZL4disk>
    80005458:	97aa                	add	a5,a5,a0
    8000545a:	0187c783          	lbu	a5,24(a5)
    8000545e:	e7b9                	bnez	a5,800054ac <_ZL9free_desci+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005460:	00451693          	slli	a3,a0,0x4
    80005464:	0001b797          	auipc	a5,0x1b
    80005468:	5d478793          	addi	a5,a5,1492 # 80020a38 <_ZL4disk>
    8000546c:	6398                	ld	a4,0(a5)
    8000546e:	9736                	add	a4,a4,a3
    80005470:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    80005474:	6398                	ld	a4,0(a5)
    80005476:	9736                	add	a4,a4,a3
    80005478:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000547c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005480:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005484:	97aa                	add	a5,a5,a0
    80005486:	4705                	li	a4,1
    80005488:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000548c:	0001b517          	auipc	a0,0x1b
    80005490:	5c450513          	addi	a0,a0,1476 # 80020a50 <_ZL4disk+0x18>
    80005494:	a79fc0ef          	jal	80001f0c <_Z6wakeupPv>
}
    80005498:	60a2                	ld	ra,8(sp)
    8000549a:	6402                	ld	s0,0(sp)
    8000549c:	0141                	addi	sp,sp,16
    8000549e:	8082                	ret
    panic("free_desc 1");
    800054a0:	00002517          	auipc	a0,0x2
    800054a4:	17050513          	addi	a0,a0,368 # 80007610 <etext+0x610>
    800054a8:	b4afb0ef          	jal	800007f2 <_Z5panicPKc>
    panic("free_desc 2");
    800054ac:	00002517          	auipc	a0,0x2
    800054b0:	17450513          	addi	a0,a0,372 # 80007620 <etext+0x620>
    800054b4:	b3efb0ef          	jal	800007f2 <_Z5panicPKc>

00000000800054b8 <_Z16virtio_disk_initv>:
{
    800054b8:	1101                	addi	sp,sp,-32
    800054ba:	ec06                	sd	ra,24(sp)
    800054bc:	e822                	sd	s0,16(sp)
    800054be:	e426                	sd	s1,8(sp)
    800054c0:	e04a                	sd	s2,0(sp)
    800054c2:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800054c4:	00002597          	auipc	a1,0x2
    800054c8:	16c58593          	addi	a1,a1,364 # 80007630 <etext+0x630>
    800054cc:	0001b517          	auipc	a0,0x1b
    800054d0:	69450513          	addi	a0,a0,1684 # 80020b60 <_ZL4disk+0x128>
    800054d4:	e76fb0ef          	jal	80000b4a <_Z8initlockP8spinlockPKc>
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800054d8:	100017b7          	lui	a5,0x10001
    800054dc:	4398                	lw	a4,0(a5)
    800054de:	2701                	sext.w	a4,a4
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800054e0:	747277b7          	lui	a5,0x74727
    800054e4:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800054e8:	18f71063          	bne	a4,a5,80005668 <_Z16virtio_disk_initv+0x1b0>
    800054ec:	100017b7          	lui	a5,0x10001
    800054f0:	0791                	addi	a5,a5,4 # 10001004 <_entry-0x6fffeffc>
    800054f2:	439c                	lw	a5,0(a5)
    800054f4:	2781                	sext.w	a5,a5
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800054f6:	4709                	li	a4,2
    800054f8:	16e79863          	bne	a5,a4,80005668 <_Z16virtio_disk_initv+0x1b0>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800054fc:	100017b7          	lui	a5,0x10001
    80005500:	07a1                	addi	a5,a5,8 # 10001008 <_entry-0x6fffeff8>
    80005502:	439c                	lw	a5,0(a5)
    80005504:	2781                	sext.w	a5,a5
    80005506:	16e79163          	bne	a5,a4,80005668 <_Z16virtio_disk_initv+0x1b0>
      *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551) {
    8000550a:	100017b7          	lui	a5,0x10001
    8000550e:	47d8                	lw	a4,12(a5)
    80005510:	2701                	sext.w	a4,a4
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005512:	554d47b7          	lui	a5,0x554d4
    80005516:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    8000551a:	14f71763          	bne	a4,a5,80005668 <_Z16virtio_disk_initv+0x1b0>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000551e:	100017b7          	lui	a5,0x10001
    80005522:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005526:	4705                	li	a4,1
    80005528:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000552a:	470d                	li	a4,3
    8000552c:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    8000552e:	10001737          	lui	a4,0x10001
    80005532:	4b14                	lw	a3,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005534:	c7ffe737          	lui	a4,0xc7ffe
    80005538:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fddbe7>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    8000553c:	8ef9                	and	a3,a3,a4
    8000553e:	10001737          	lui	a4,0x10001
    80005542:	d314                	sw	a3,32(a4)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005544:	472d                	li	a4,11
    80005546:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005548:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    8000554c:	439c                	lw	a5,0(a5)
    8000554e:	0007891b          	sext.w	s2,a5
  if (!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005552:	8ba1                	andi	a5,a5,8
    80005554:	12078063          	beqz	a5,80005674 <_Z16virtio_disk_initv+0x1bc>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005558:	100017b7          	lui	a5,0x10001
    8000555c:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if (*R(VIRTIO_MMIO_QUEUE_READY))
    80005560:	100017b7          	lui	a5,0x10001
    80005564:	04478793          	addi	a5,a5,68 # 10001044 <_entry-0x6fffefbc>
    80005568:	439c                	lw	a5,0(a5)
    8000556a:	2781                	sext.w	a5,a5
    8000556c:	10079a63          	bnez	a5,80005680 <_Z16virtio_disk_initv+0x1c8>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005570:	100017b7          	lui	a5,0x10001
    80005574:	03478793          	addi	a5,a5,52 # 10001034 <_entry-0x6fffefcc>
    80005578:	439c                	lw	a5,0(a5)
    8000557a:	2781                	sext.w	a5,a5
  if (max == 0)
    8000557c:	10078863          	beqz	a5,8000568c <_Z16virtio_disk_initv+0x1d4>
  if (max < NUM)
    80005580:	471d                	li	a4,7
    80005582:	10f77b63          	bgeu	a4,a5,80005698 <_Z16virtio_disk_initv+0x1e0>
  disk.desc = static_cast<struct virtq_desc *>(kalloc());
    80005586:	d74fb0ef          	jal	80000afa <_Z6kallocv>
    8000558a:	0001b497          	auipc	s1,0x1b
    8000558e:	4ae48493          	addi	s1,s1,1198 # 80020a38 <_ZL4disk>
    80005592:	e088                	sd	a0,0(s1)
  disk.avail = static_cast<struct virtq_avail *>(kalloc());
    80005594:	d66fb0ef          	jal	80000afa <_Z6kallocv>
    80005598:	e488                	sd	a0,8(s1)
  disk.used = static_cast<struct virtq_used *>(kalloc());
    8000559a:	d60fb0ef          	jal	80000afa <_Z6kallocv>
    8000559e:	87aa                	mv	a5,a0
    800055a0:	e888                	sd	a0,16(s1)
  if (!disk.desc || !disk.avail || !disk.used)
    800055a2:	6088                	ld	a0,0(s1)
    800055a4:	10050063          	beqz	a0,800056a4 <_Z16virtio_disk_initv+0x1ec>
    800055a8:	0001b717          	auipc	a4,0x1b
    800055ac:	49873703          	ld	a4,1176(a4) # 80020a40 <_ZL4disk+0x8>
    800055b0:	0e070a63          	beqz	a4,800056a4 <_Z16virtio_disk_initv+0x1ec>
    800055b4:	0e078863          	beqz	a5,800056a4 <_Z16virtio_disk_initv+0x1ec>
  memset(disk.desc, 0, PGSIZE);
    800055b8:	6605                	lui	a2,0x1
    800055ba:	4581                	li	a1,0
    800055bc:	ec8fb0ef          	jal	80000c84 <_Z6memsetPvij>
  memset(disk.avail, 0, PGSIZE);
    800055c0:	0001b497          	auipc	s1,0x1b
    800055c4:	47848493          	addi	s1,s1,1144 # 80020a38 <_ZL4disk>
    800055c8:	6605                	lui	a2,0x1
    800055ca:	4581                	li	a1,0
    800055cc:	6488                	ld	a0,8(s1)
    800055ce:	eb6fb0ef          	jal	80000c84 <_Z6memsetPvij>
  memset(disk.used, 0, PGSIZE);
    800055d2:	6605                	lui	a2,0x1
    800055d4:	4581                	li	a1,0
    800055d6:	6888                	ld	a0,16(s1)
    800055d8:	eacfb0ef          	jal	80000c84 <_Z6memsetPvij>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800055dc:	100017b7          	lui	a5,0x10001
    800055e0:	4721                	li	a4,8
    800055e2:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800055e4:	4098                	lw	a4,0(s1)
    800055e6:	100017b7          	lui	a5,0x10001
    800055ea:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800055ee:	40d8                	lw	a4,4(s1)
    800055f0:	100017b7          	lui	a5,0x10001
    800055f4:	08e7a223          	sw	a4,132(a5) # 10001084 <_entry-0x6fffef7c>
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    800055f8:	649c                	ld	a5,8(s1)
    800055fa:	0007869b          	sext.w	a3,a5
    800055fe:	10001737          	lui	a4,0x10001
    80005602:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005606:	9781                	srai	a5,a5,0x20
    80005608:	10001737          	lui	a4,0x10001
    8000560c:	08f72a23          	sw	a5,148(a4) # 10001094 <_entry-0x6fffef6c>
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005610:	689c                	ld	a5,16(s1)
    80005612:	0007869b          	sext.w	a3,a5
    80005616:	10001737          	lui	a4,0x10001
    8000561a:	0ad72023          	sw	a3,160(a4) # 100010a0 <_entry-0x6fffef60>
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    8000561e:	9781                	srai	a5,a5,0x20
    80005620:	10001737          	lui	a4,0x10001
    80005624:	0af72223          	sw	a5,164(a4) # 100010a4 <_entry-0x6fffef5c>
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005628:	10001737          	lui	a4,0x10001
    8000562c:	4785                	li	a5,1
    8000562e:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005630:	00f48c23          	sb	a5,24(s1)
    80005634:	00f48ca3          	sb	a5,25(s1)
    80005638:	00f48d23          	sb	a5,26(s1)
    8000563c:	00f48da3          	sb	a5,27(s1)
    80005640:	00f48e23          	sb	a5,28(s1)
    80005644:	00f48ea3          	sb	a5,29(s1)
    80005648:	00f48f23          	sb	a5,30(s1)
    8000564c:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005650:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005654:	100017b7          	lui	a5,0x10001
    80005658:	0727a823          	sw	s2,112(a5) # 10001070 <_entry-0x6fffef90>
}
    8000565c:	60e2                	ld	ra,24(sp)
    8000565e:	6442                	ld	s0,16(sp)
    80005660:	64a2                	ld	s1,8(sp)
    80005662:	6902                	ld	s2,0(sp)
    80005664:	6105                	addi	sp,sp,32
    80005666:	8082                	ret
    panic("could not find virtio disk");
    80005668:	00002517          	auipc	a0,0x2
    8000566c:	fd850513          	addi	a0,a0,-40 # 80007640 <etext+0x640>
    80005670:	982fb0ef          	jal	800007f2 <_Z5panicPKc>
    panic("virtio disk FEATURES_OK unset");
    80005674:	00002517          	auipc	a0,0x2
    80005678:	fec50513          	addi	a0,a0,-20 # 80007660 <etext+0x660>
    8000567c:	976fb0ef          	jal	800007f2 <_Z5panicPKc>
    panic("virtio disk should not be ready");
    80005680:	00002517          	auipc	a0,0x2
    80005684:	00050513          	mv	a0,a0
    80005688:	96afb0ef          	jal	800007f2 <_Z5panicPKc>
    panic("virtio disk has no queue 0");
    8000568c:	00002517          	auipc	a0,0x2
    80005690:	01450513          	addi	a0,a0,20 # 800076a0 <etext+0x6a0>
    80005694:	95efb0ef          	jal	800007f2 <_Z5panicPKc>
    panic("virtio disk max queue too short");
    80005698:	00002517          	auipc	a0,0x2
    8000569c:	02850513          	addi	a0,a0,40 # 800076c0 <etext+0x6c0>
    800056a0:	952fb0ef          	jal	800007f2 <_Z5panicPKc>
    panic("virtio disk kalloc");
    800056a4:	00002517          	auipc	a0,0x2
    800056a8:	03c50513          	addi	a0,a0,60 # 800076e0 <etext+0x6e0>
    800056ac:	946fb0ef          	jal	800007f2 <_Z5panicPKc>

00000000800056b0 <_Z14virtio_disk_rwP3bufi>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800056b0:	7159                	addi	sp,sp,-112
    800056b2:	f486                	sd	ra,104(sp)
    800056b4:	f0a2                	sd	s0,96(sp)
    800056b6:	eca6                	sd	s1,88(sp)
    800056b8:	e8ca                	sd	s2,80(sp)
    800056ba:	e4ce                	sd	s3,72(sp)
    800056bc:	e0d2                	sd	s4,64(sp)
    800056be:	fc56                	sd	s5,56(sp)
    800056c0:	f85a                	sd	s6,48(sp)
    800056c2:	f45e                	sd	s7,40(sp)
    800056c4:	f062                	sd	s8,32(sp)
    800056c6:	ec66                	sd	s9,24(sp)
    800056c8:	1880                	addi	s0,sp,112
    800056ca:	8a2a                	mv	s4,a0
    800056cc:	8bae                	mv	s7,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800056ce:	00c52c83          	lw	s9,12(a0)
    800056d2:	001c9c9b          	slliw	s9,s9,0x1
    800056d6:	1c82                	slli	s9,s9,0x20
    800056d8:	020cdc93          	srli	s9,s9,0x20

  acquire(&disk.vdisk_lock);
    800056dc:	0001b517          	auipc	a0,0x1b
    800056e0:	48450513          	addi	a0,a0,1156 # 80020b60 <_ZL4disk+0x128>
    800056e4:	cdcfb0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  for (int i = 0; i < 3; i++) {
    800056e8:	4981                	li	s3,0
  for (int i = 0; i < NUM; i++) {
    800056ea:	44a1                	li	s1,8
      disk.free[i] = 0;
    800056ec:	0001bb17          	auipc	s6,0x1b
    800056f0:	34cb0b13          	addi	s6,s6,844 # 80020a38 <_ZL4disk>
  for (int i = 0; i < 3; i++) {
    800056f4:	4a8d                	li	s5,3
  int idx[3];
  while (1) {
    if (alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    800056f6:	0001bc17          	auipc	s8,0x1b
    800056fa:	46ac0c13          	addi	s8,s8,1130 # 80020b60 <_ZL4disk+0x128>
    800056fe:	a8b9                	j	8000575c <_Z14virtio_disk_rwP3bufi+0xac>
      disk.free[i] = 0;
    80005700:	00fb0733          	add	a4,s6,a5
    80005704:	00070c23          	sb	zero,24(a4) # 10001018 <_entry-0x6fffefe8>
    idx[i] = alloc_desc();
    80005708:	c19c                	sw	a5,0(a1)
    if (idx[i] < 0) {
    8000570a:	0207c563          	bltz	a5,80005734 <_Z14virtio_disk_rwP3bufi+0x84>
  for (int i = 0; i < 3; i++) {
    8000570e:	2905                	addiw	s2,s2,1
    80005710:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005712:	05590963          	beq	s2,s5,80005764 <_Z14virtio_disk_rwP3bufi+0xb4>
    idx[i] = alloc_desc();
    80005716:	85b2                	mv	a1,a2
  for (int i = 0; i < NUM; i++) {
    80005718:	0001b717          	auipc	a4,0x1b
    8000571c:	32070713          	addi	a4,a4,800 # 80020a38 <_ZL4disk>
    80005720:	87ce                	mv	a5,s3
    if (disk.free[i]) {
    80005722:	01874683          	lbu	a3,24(a4)
    80005726:	fee9                	bnez	a3,80005700 <_Z14virtio_disk_rwP3bufi+0x50>
  for (int i = 0; i < NUM; i++) {
    80005728:	2785                	addiw	a5,a5,1
    8000572a:	0705                	addi	a4,a4,1
    8000572c:	fe979be3          	bne	a5,s1,80005722 <_Z14virtio_disk_rwP3bufi+0x72>
    idx[i] = alloc_desc();
    80005730:	57fd                	li	a5,-1
    80005732:	c19c                	sw	a5,0(a1)
      for (int j = 0; j < i; j++)
    80005734:	01205d63          	blez	s2,8000574e <_Z14virtio_disk_rwP3bufi+0x9e>
        free_desc(idx[j]);
    80005738:	f9042503          	lw	a0,-112(s0)
    8000573c:	d07ff0ef          	jal	80005442 <_ZL9free_desci>
      for (int j = 0; j < i; j++)
    80005740:	4785                	li	a5,1
    80005742:	0127d663          	bge	a5,s2,8000574e <_Z14virtio_disk_rwP3bufi+0x9e>
        free_desc(idx[j]);
    80005746:	f9442503          	lw	a0,-108(s0)
    8000574a:	cf9ff0ef          	jal	80005442 <_ZL9free_desci>
    sleep(&disk.free[0], &disk.vdisk_lock);
    8000574e:	85e2                	mv	a1,s8
    80005750:	0001b517          	auipc	a0,0x1b
    80005754:	30050513          	addi	a0,a0,768 # 80020a50 <_ZL4disk+0x18>
    80005758:	f68fc0ef          	jal	80001ec0 <_Z5sleepPvP8spinlock>
  for (int i = 0; i < 3; i++) {
    8000575c:	f9040613          	addi	a2,s0,-112
    80005760:	894e                	mv	s2,s3
    80005762:	bf55                	j	80005716 <_Z14virtio_disk_rwP3bufi+0x66>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005764:	f9042503          	lw	a0,-112(s0)
    80005768:	00451693          	slli	a3,a0,0x4

  if (write)
    8000576c:	0001b797          	auipc	a5,0x1b
    80005770:	2cc78793          	addi	a5,a5,716 # 80020a38 <_ZL4disk>
    80005774:	00a50713          	addi	a4,a0,10
    80005778:	0712                	slli	a4,a4,0x4
    8000577a:	973e                	add	a4,a4,a5
    8000577c:	01703633          	snez	a2,s7
    80005780:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005782:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005786:	01973823          	sd	s9,16(a4)

  disk.desc[idx[0]].addr = (uint64)buf0;
    8000578a:	6398                	ld	a4,0(a5)
    8000578c:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    8000578e:	0a868613          	addi	a2,a3,168
    80005792:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64)buf0;
    80005794:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005796:	6390                	ld	a2,0(a5)
    80005798:	00d605b3          	add	a1,a2,a3
    8000579c:	4741                	li	a4,16
    8000579e:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    800057a0:	4805                	li	a6,1
    800057a2:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    800057a6:	f9442703          	lw	a4,-108(s0)
    800057aa:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64)b->data;
    800057ae:	0712                	slli	a4,a4,0x4
    800057b0:	963a                	add	a2,a2,a4
    800057b2:	058a0593          	addi	a1,s4,88
    800057b6:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    800057b8:	0007b883          	ld	a7,0(a5)
    800057bc:	9746                	add	a4,a4,a7
    800057be:	40000613          	li	a2,1024
    800057c2:	c710                	sw	a2,8(a4)
  if (write)
    800057c4:	001bb613          	seqz	a2,s7
    800057c8:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    800057cc:	00166613          	ori	a2,a2,1
    800057d0:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    800057d4:	f9842583          	lw	a1,-104(s0)
    800057d8:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    800057dc:	00250613          	addi	a2,a0,2
    800057e0:	0612                	slli	a2,a2,0x4
    800057e2:	963e                	add	a2,a2,a5
    800057e4:	577d                	li	a4,-1
    800057e6:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64)&disk.info[idx[0]].status;
    800057ea:	0592                	slli	a1,a1,0x4
    800057ec:	98ae                	add	a7,a7,a1
    800057ee:	03068713          	addi	a4,a3,48
    800057f2:	973e                	add	a4,a4,a5
    800057f4:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    800057f8:	6398                	ld	a4,0(a5)
    800057fa:	972e                	add	a4,a4,a1
    800057fc:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005800:	4689                	li	a3,2
    80005802:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005806:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    8000580a:	010a2223          	sw	a6,4(s4)
  disk.info[idx[0]].b = b;
    8000580e:	01463423          	sd	s4,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005812:	6794                	ld	a3,8(a5)
    80005814:	0026d703          	lhu	a4,2(a3)
    80005818:	8b1d                	andi	a4,a4,7
    8000581a:	0706                	slli	a4,a4,0x1
    8000581c:	96ba                	add	a3,a3,a4
    8000581e:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80005822:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005826:	6798                	ld	a4,8(a5)
    80005828:	00275783          	lhu	a5,2(a4)
    8000582c:	2785                	addiw	a5,a5,1
    8000582e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005832:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005836:	100017b7          	lui	a5,0x10001
    8000583a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while (b->disk == 1) {
    8000583e:	004a2783          	lw	a5,4(s4)
    sleep(b, &disk.vdisk_lock);
    80005842:	0001b917          	auipc	s2,0x1b
    80005846:	31e90913          	addi	s2,s2,798 # 80020b60 <_ZL4disk+0x128>
  while (b->disk == 1) {
    8000584a:	4485                	li	s1,1
    8000584c:	01079a63          	bne	a5,a6,80005860 <_Z14virtio_disk_rwP3bufi+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80005850:	85ca                	mv	a1,s2
    80005852:	8552                	mv	a0,s4
    80005854:	e6cfc0ef          	jal	80001ec0 <_Z5sleepPvP8spinlock>
  while (b->disk == 1) {
    80005858:	004a2783          	lw	a5,4(s4)
    8000585c:	fe978ae3          	beq	a5,s1,80005850 <_Z14virtio_disk_rwP3bufi+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80005860:	f9042903          	lw	s2,-112(s0)
    80005864:	00290713          	addi	a4,s2,2
    80005868:	0712                	slli	a4,a4,0x4
    8000586a:	0001b797          	auipc	a5,0x1b
    8000586e:	1ce78793          	addi	a5,a5,462 # 80020a38 <_ZL4disk>
    80005872:	97ba                	add	a5,a5,a4
    80005874:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005878:	0001b997          	auipc	s3,0x1b
    8000587c:	1c098993          	addi	s3,s3,448 # 80020a38 <_ZL4disk>
    80005880:	00491713          	slli	a4,s2,0x4
    80005884:	0009b783          	ld	a5,0(s3)
    80005888:	97ba                	add	a5,a5,a4
    8000588a:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    8000588e:	854a                	mv	a0,s2
    80005890:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005894:	bafff0ef          	jal	80005442 <_ZL9free_desci>
    if (flag & VRING_DESC_F_NEXT)
    80005898:	8885                	andi	s1,s1,1
    8000589a:	f0fd                	bnez	s1,80005880 <_Z14virtio_disk_rwP3bufi+0x1d0>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    8000589c:	0001b517          	auipc	a0,0x1b
    800058a0:	2c450513          	addi	a0,a0,708 # 80020b60 <_ZL4disk+0x128>
    800058a4:	ba8fb0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    800058a8:	70a6                	ld	ra,104(sp)
    800058aa:	7406                	ld	s0,96(sp)
    800058ac:	64e6                	ld	s1,88(sp)
    800058ae:	6946                	ld	s2,80(sp)
    800058b0:	69a6                	ld	s3,72(sp)
    800058b2:	6a06                	ld	s4,64(sp)
    800058b4:	7ae2                	ld	s5,56(sp)
    800058b6:	7b42                	ld	s6,48(sp)
    800058b8:	7ba2                	ld	s7,40(sp)
    800058ba:	7c02                	ld	s8,32(sp)
    800058bc:	6ce2                	ld	s9,24(sp)
    800058be:	6165                	addi	sp,sp,112
    800058c0:	8082                	ret

00000000800058c2 <_Z16virtio_disk_intrv>:

void
virtio_disk_intr()
{
    800058c2:	1101                	addi	sp,sp,-32
    800058c4:	ec06                	sd	ra,24(sp)
    800058c6:	e822                	sd	s0,16(sp)
    800058c8:	e426                	sd	s1,8(sp)
    800058ca:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    800058cc:	0001b497          	auipc	s1,0x1b
    800058d0:	16c48493          	addi	s1,s1,364 # 80020a38 <_ZL4disk>
    800058d4:	0001b517          	auipc	a0,0x1b
    800058d8:	28c50513          	addi	a0,a0,652 # 80020b60 <_ZL4disk+0x128>
    800058dc:	ae4fb0ef          	jal	80000bc0 <_Z7acquireP8spinlock>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    800058e0:	100017b7          	lui	a5,0x10001
    800058e4:	53b8                	lw	a4,96(a5)
    800058e6:	8b0d                	andi	a4,a4,3
    800058e8:	100017b7          	lui	a5,0x10001
    800058ec:	d3f8                	sw	a4,100(a5)

  __sync_synchronize();
    800058ee:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while (disk.used_idx != disk.used->idx) {
    800058f2:	689c                	ld	a5,16(s1)
    800058f4:	0204d703          	lhu	a4,32(s1)
    800058f8:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    800058fc:	04f70663          	beq	a4,a5,80005948 <_Z16virtio_disk_intrv+0x86>
    __sync_synchronize();
    80005900:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005904:	6898                	ld	a4,16(s1)
    80005906:	0204d783          	lhu	a5,32(s1)
    8000590a:	8b9d                	andi	a5,a5,7
    8000590c:	078e                	slli	a5,a5,0x3
    8000590e:	97ba                	add	a5,a5,a4
    80005910:	43dc                	lw	a5,4(a5)

    if (disk.info[id].status != 0)
    80005912:	00278713          	addi	a4,a5,2
    80005916:	0712                	slli	a4,a4,0x4
    80005918:	9726                	add	a4,a4,s1
    8000591a:	01074703          	lbu	a4,16(a4)
    8000591e:	e321                	bnez	a4,8000595e <_Z16virtio_disk_intrv+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005920:	0789                	addi	a5,a5,2
    80005922:	0792                	slli	a5,a5,0x4
    80005924:	97a6                	add	a5,a5,s1
    80005926:	6788                	ld	a0,8(a5)
    b->disk = 0; // disk is done with buf
    80005928:	00052223          	sw	zero,4(a0)
    wakeup(b);
    8000592c:	de0fc0ef          	jal	80001f0c <_Z6wakeupPv>

    disk.used_idx += 1;
    80005930:	0204d783          	lhu	a5,32(s1)
    80005934:	2785                	addiw	a5,a5,1
    80005936:	17c2                	slli	a5,a5,0x30
    80005938:	93c1                	srli	a5,a5,0x30
    8000593a:	02f49023          	sh	a5,32(s1)
  while (disk.used_idx != disk.used->idx) {
    8000593e:	6898                	ld	a4,16(s1)
    80005940:	00275703          	lhu	a4,2(a4)
    80005944:	faf71ee3          	bne	a4,a5,80005900 <_Z16virtio_disk_intrv+0x3e>
  }

  release(&disk.vdisk_lock);
    80005948:	0001b517          	auipc	a0,0x1b
    8000594c:	21850513          	addi	a0,a0,536 # 80020b60 <_ZL4disk+0x128>
    80005950:	afcfb0ef          	jal	80000c4c <_Z7releaseP8spinlock>
}
    80005954:	60e2                	ld	ra,24(sp)
    80005956:	6442                	ld	s0,16(sp)
    80005958:	64a2                	ld	s1,8(sp)
    8000595a:	6105                	addi	sp,sp,32
    8000595c:	8082                	ret
      panic("virtio_disk_intr status");
    8000595e:	00002517          	auipc	a0,0x2
    80005962:	d9a50513          	addi	a0,a0,-614 # 800076f8 <etext+0x6f8>
    80005966:	e8dfa0ef          	jal	800007f2 <_Z5panicPKc>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
