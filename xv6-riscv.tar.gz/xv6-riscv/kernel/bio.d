kernel/bio.o: kernel/bio.cpp kernel/types.h kernel/param.h \
 kernel/spinlock.h kernel/sleeplock.h kernel/riscv.h kernel/defs.h \
 kernel/fs.h kernel/buf.h
