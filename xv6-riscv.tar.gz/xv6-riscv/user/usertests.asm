
user/_usertests:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <copyinstr1>:
}

// what if you pass ridiculous string pointers to system calls?
void
copyinstr1(char *s)
{
       0:	711d                	addi	sp,sp,-96
       2:	ec86                	sd	ra,88(sp)
       4:	e8a2                	sd	s0,80(sp)
       6:	e4a6                	sd	s1,72(sp)
       8:	e0ca                	sd	s2,64(sp)
       a:	fc4e                	sd	s3,56(sp)
       c:	1080                	addi	s0,sp,96
  uint64 addrs[] = {0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
       e:	00008797          	auipc	a5,0x8
      12:	d0278793          	addi	a5,a5,-766 # 7d10 <malloc+0x27f2>
      16:	638c                	ld	a1,0(a5)
      18:	6790                	ld	a2,8(a5)
      1a:	6b94                	ld	a3,16(a5)
      1c:	6f98                	ld	a4,24(a5)
      1e:	739c                	ld	a5,32(a5)
      20:	fab43423          	sd	a1,-88(s0)
      24:	fac43823          	sd	a2,-80(s0)
      28:	fad43c23          	sd	a3,-72(s0)
      2c:	fce43023          	sd	a4,-64(s0)
      30:	fcf43423          	sd	a5,-56(s0)
                    0xffffffffffffffff};

  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
      34:	fa840493          	addi	s1,s0,-88
      38:	fd040993          	addi	s3,s0,-48
    uint64 addr = addrs[ai];

    int fd = open((char *)addr, O_CREATE | O_WRONLY);
      3c:	0004b903          	ld	s2,0(s1)
      40:	20100593          	li	a1,513
      44:	854a                	mv	a0,s2
      46:	034050ef          	jal	507a <open>
    if (fd >= 0) {
      4a:	00055c63          	bgez	a0,62 <copyinstr1+0x62>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
      4e:	04a1                	addi	s1,s1,8
      50:	ff3496e3          	bne	s1,s3,3c <copyinstr1+0x3c>
      printf("open(%p) returned %d, not -1\n", (void *)addr, fd);
      exit(1);
    }
  }
}
      54:	60e6                	ld	ra,88(sp)
      56:	6446                	ld	s0,80(sp)
      58:	64a6                	ld	s1,72(sp)
      5a:	6906                	ld	s2,64(sp)
      5c:	79e2                	ld	s3,56(sp)
      5e:	6125                	addi	sp,sp,96
      60:	8082                	ret
      printf("open(%p) returned %d, not -1\n", (void *)addr, fd);
      62:	862a                	mv	a2,a0
      64:	85ca                	mv	a1,s2
      66:	00005517          	auipc	a0,0x5
      6a:	5ba50513          	addi	a0,a0,1466 # 5620 <malloc+0x102>
      6e:	3fc050ef          	jal	546a <printf>
      exit(1);
      72:	4505                	li	a0,1
      74:	7c7040ef          	jal	503a <exit>

0000000000000078 <bsstest>:
void
bsstest(char *s)
{
  int i;

  for (i = 0; i < sizeof(uninit); i++) {
      78:	00009797          	auipc	a5,0x9
      7c:	54078793          	addi	a5,a5,1344 # 95b8 <uninit>
      80:	0000c697          	auipc	a3,0xc
      84:	c4868693          	addi	a3,a3,-952 # bcc8 <buf>
    if (uninit[i] != '\0') {
      88:	0007c703          	lbu	a4,0(a5)
      8c:	e709                	bnez	a4,96 <bsstest+0x1e>
  for (i = 0; i < sizeof(uninit); i++) {
      8e:	0785                	addi	a5,a5,1
      90:	fed79ce3          	bne	a5,a3,88 <bsstest+0x10>
      94:	8082                	ret
{
      96:	1141                	addi	sp,sp,-16
      98:	e406                	sd	ra,8(sp)
      9a:	e022                	sd	s0,0(sp)
      9c:	0800                	addi	s0,sp,16
      printf("%s: bss test failed\n", s);
      9e:	85aa                	mv	a1,a0
      a0:	00005517          	auipc	a0,0x5
      a4:	5a050513          	addi	a0,a0,1440 # 5640 <malloc+0x122>
      a8:	3c2050ef          	jal	546a <printf>
      exit(1);
      ac:	4505                	li	a0,1
      ae:	78d040ef          	jal	503a <exit>

00000000000000b2 <opentest>:
{
      b2:	1101                	addi	sp,sp,-32
      b4:	ec06                	sd	ra,24(sp)
      b6:	e822                	sd	s0,16(sp)
      b8:	e426                	sd	s1,8(sp)
      ba:	1000                	addi	s0,sp,32
      bc:	84aa                	mv	s1,a0
  fd = open("echo", 0);
      be:	4581                	li	a1,0
      c0:	00005517          	auipc	a0,0x5
      c4:	59850513          	addi	a0,a0,1432 # 5658 <malloc+0x13a>
      c8:	7b3040ef          	jal	507a <open>
  if (fd < 0) {
      cc:	02054263          	bltz	a0,f0 <opentest+0x3e>
  close(fd);
      d0:	793040ef          	jal	5062 <close>
  fd = open("doesnotexist", 0);
      d4:	4581                	li	a1,0
      d6:	00005517          	auipc	a0,0x5
      da:	5a250513          	addi	a0,a0,1442 # 5678 <malloc+0x15a>
      de:	79d040ef          	jal	507a <open>
  if (fd >= 0) {
      e2:	02055163          	bgez	a0,104 <opentest+0x52>
}
      e6:	60e2                	ld	ra,24(sp)
      e8:	6442                	ld	s0,16(sp)
      ea:	64a2                	ld	s1,8(sp)
      ec:	6105                	addi	sp,sp,32
      ee:	8082                	ret
    printf("%s: open echo failed!\n", s);
      f0:	85a6                	mv	a1,s1
      f2:	00005517          	auipc	a0,0x5
      f6:	56e50513          	addi	a0,a0,1390 # 5660 <malloc+0x142>
      fa:	370050ef          	jal	546a <printf>
    exit(1);
      fe:	4505                	li	a0,1
     100:	73b040ef          	jal	503a <exit>
    printf("%s: open doesnotexist succeeded!\n", s);
     104:	85a6                	mv	a1,s1
     106:	00005517          	auipc	a0,0x5
     10a:	58250513          	addi	a0,a0,1410 # 5688 <malloc+0x16a>
     10e:	35c050ef          	jal	546a <printf>
    exit(1);
     112:	4505                	li	a0,1
     114:	727040ef          	jal	503a <exit>

0000000000000118 <truncate2>:
{
     118:	7179                	addi	sp,sp,-48
     11a:	f406                	sd	ra,40(sp)
     11c:	f022                	sd	s0,32(sp)
     11e:	ec26                	sd	s1,24(sp)
     120:	e84a                	sd	s2,16(sp)
     122:	e44e                	sd	s3,8(sp)
     124:	1800                	addi	s0,sp,48
     126:	89aa                	mv	s3,a0
  unlink("truncfile");
     128:	00005517          	auipc	a0,0x5
     12c:	58850513          	addi	a0,a0,1416 # 56b0 <malloc+0x192>
     130:	75b040ef          	jal	508a <unlink>
  int fd1 = open("truncfile", O_CREATE | O_TRUNC | O_WRONLY);
     134:	60100593          	li	a1,1537
     138:	00005517          	auipc	a0,0x5
     13c:	57850513          	addi	a0,a0,1400 # 56b0 <malloc+0x192>
     140:	73b040ef          	jal	507a <open>
     144:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     146:	4611                	li	a2,4
     148:	00005597          	auipc	a1,0x5
     14c:	57858593          	addi	a1,a1,1400 # 56c0 <malloc+0x1a2>
     150:	70b040ef          	jal	505a <write>
  int fd2 = open("truncfile", O_TRUNC | O_WRONLY);
     154:	40100593          	li	a1,1025
     158:	00005517          	auipc	a0,0x5
     15c:	55850513          	addi	a0,a0,1368 # 56b0 <malloc+0x192>
     160:	71b040ef          	jal	507a <open>
     164:	892a                	mv	s2,a0
  int n = write(fd1, "x", 1);
     166:	4605                	li	a2,1
     168:	00005597          	auipc	a1,0x5
     16c:	56058593          	addi	a1,a1,1376 # 56c8 <malloc+0x1aa>
     170:	8526                	mv	a0,s1
     172:	6e9040ef          	jal	505a <write>
  if (n != -1) {
     176:	57fd                	li	a5,-1
     178:	02f51563          	bne	a0,a5,1a2 <truncate2+0x8a>
  unlink("truncfile");
     17c:	00005517          	auipc	a0,0x5
     180:	53450513          	addi	a0,a0,1332 # 56b0 <malloc+0x192>
     184:	707040ef          	jal	508a <unlink>
  close(fd1);
     188:	8526                	mv	a0,s1
     18a:	6d9040ef          	jal	5062 <close>
  close(fd2);
     18e:	854a                	mv	a0,s2
     190:	6d3040ef          	jal	5062 <close>
}
     194:	70a2                	ld	ra,40(sp)
     196:	7402                	ld	s0,32(sp)
     198:	64e2                	ld	s1,24(sp)
     19a:	6942                	ld	s2,16(sp)
     19c:	69a2                	ld	s3,8(sp)
     19e:	6145                	addi	sp,sp,48
     1a0:	8082                	ret
    printf("%s: write returned %d, expected -1\n", s, n);
     1a2:	862a                	mv	a2,a0
     1a4:	85ce                	mv	a1,s3
     1a6:	00005517          	auipc	a0,0x5
     1aa:	52a50513          	addi	a0,a0,1322 # 56d0 <malloc+0x1b2>
     1ae:	2bc050ef          	jal	546a <printf>
    exit(1);
     1b2:	4505                	li	a0,1
     1b4:	687040ef          	jal	503a <exit>

00000000000001b8 <createtest>:
{
     1b8:	7179                	addi	sp,sp,-48
     1ba:	f406                	sd	ra,40(sp)
     1bc:	f022                	sd	s0,32(sp)
     1be:	ec26                	sd	s1,24(sp)
     1c0:	e84a                	sd	s2,16(sp)
     1c2:	1800                	addi	s0,sp,48
  name[0] = 'a';
     1c4:	06100793          	li	a5,97
     1c8:	fcf40c23          	sb	a5,-40(s0)
  name[2] = '\0';
     1cc:	fc040d23          	sb	zero,-38(s0)
     1d0:	03000493          	li	s1,48
  for (i = 0; i < N; i++) {
     1d4:	06400913          	li	s2,100
    name[1] = '0' + i;
     1d8:	fc940ca3          	sb	s1,-39(s0)
    fd = open(name, O_CREATE | O_RDWR);
     1dc:	20200593          	li	a1,514
     1e0:	fd840513          	addi	a0,s0,-40
     1e4:	697040ef          	jal	507a <open>
    close(fd);
     1e8:	67b040ef          	jal	5062 <close>
  for (i = 0; i < N; i++) {
     1ec:	2485                	addiw	s1,s1,1
     1ee:	0ff4f493          	zext.b	s1,s1
     1f2:	ff2493e3          	bne	s1,s2,1d8 <createtest+0x20>
  name[0] = 'a';
     1f6:	06100793          	li	a5,97
     1fa:	fcf40c23          	sb	a5,-40(s0)
  name[2] = '\0';
     1fe:	fc040d23          	sb	zero,-38(s0)
     202:	03000493          	li	s1,48
  for (i = 0; i < N; i++) {
     206:	06400913          	li	s2,100
    name[1] = '0' + i;
     20a:	fc940ca3          	sb	s1,-39(s0)
    unlink(name);
     20e:	fd840513          	addi	a0,s0,-40
     212:	679040ef          	jal	508a <unlink>
  for (i = 0; i < N; i++) {
     216:	2485                	addiw	s1,s1,1
     218:	0ff4f493          	zext.b	s1,s1
     21c:	ff2497e3          	bne	s1,s2,20a <createtest+0x52>
}
     220:	70a2                	ld	ra,40(sp)
     222:	7402                	ld	s0,32(sp)
     224:	64e2                	ld	s1,24(sp)
     226:	6942                	ld	s2,16(sp)
     228:	6145                	addi	sp,sp,48
     22a:	8082                	ret

000000000000022c <bigwrite>:
{
     22c:	715d                	addi	sp,sp,-80
     22e:	e486                	sd	ra,72(sp)
     230:	e0a2                	sd	s0,64(sp)
     232:	fc26                	sd	s1,56(sp)
     234:	f84a                	sd	s2,48(sp)
     236:	f44e                	sd	s3,40(sp)
     238:	f052                	sd	s4,32(sp)
     23a:	ec56                	sd	s5,24(sp)
     23c:	e85a                	sd	s6,16(sp)
     23e:	e45e                	sd	s7,8(sp)
     240:	0880                	addi	s0,sp,80
     242:	8baa                	mv	s7,a0
  unlink("bigwrite");
     244:	00005517          	auipc	a0,0x5
     248:	4b450513          	addi	a0,a0,1204 # 56f8 <malloc+0x1da>
     24c:	63f040ef          	jal	508a <unlink>
  for (sz = 499; sz < (MAXOPBLOCKS + 2) * BSIZE; sz += 471) {
     250:	1f300493          	li	s1,499
    fd = open("bigwrite", O_CREATE | O_RDWR);
     254:	00005a97          	auipc	s5,0x5
     258:	4a4a8a93          	addi	s5,s5,1188 # 56f8 <malloc+0x1da>
      int cc = write(fd, buf, sz);
     25c:	0000ca17          	auipc	s4,0xc
     260:	a6ca0a13          	addi	s4,s4,-1428 # bcc8 <buf>
  for (sz = 499; sz < (MAXOPBLOCKS + 2) * BSIZE; sz += 471) {
     264:	6b0d                	lui	s6,0x3
     266:	1c9b0b13          	addi	s6,s6,457 # 31c9 <dirfile+0x69>
    fd = open("bigwrite", O_CREATE | O_RDWR);
     26a:	20200593          	li	a1,514
     26e:	8556                	mv	a0,s5
     270:	60b040ef          	jal	507a <open>
     274:	892a                	mv	s2,a0
    if (fd < 0) {
     276:	04054563          	bltz	a0,2c0 <bigwrite+0x94>
      int cc = write(fd, buf, sz);
     27a:	8626                	mv	a2,s1
     27c:	85d2                	mv	a1,s4
     27e:	5dd040ef          	jal	505a <write>
     282:	89aa                	mv	s3,a0
      if (cc != sz) {
     284:	04a49863          	bne	s1,a0,2d4 <bigwrite+0xa8>
      int cc = write(fd, buf, sz);
     288:	8626                	mv	a2,s1
     28a:	85d2                	mv	a1,s4
     28c:	854a                	mv	a0,s2
     28e:	5cd040ef          	jal	505a <write>
      if (cc != sz) {
     292:	04951263          	bne	a0,s1,2d6 <bigwrite+0xaa>
    close(fd);
     296:	854a                	mv	a0,s2
     298:	5cb040ef          	jal	5062 <close>
    unlink("bigwrite");
     29c:	8556                	mv	a0,s5
     29e:	5ed040ef          	jal	508a <unlink>
  for (sz = 499; sz < (MAXOPBLOCKS + 2) * BSIZE; sz += 471) {
     2a2:	1d74849b          	addiw	s1,s1,471
     2a6:	fd6492e3          	bne	s1,s6,26a <bigwrite+0x3e>
}
     2aa:	60a6                	ld	ra,72(sp)
     2ac:	6406                	ld	s0,64(sp)
     2ae:	74e2                	ld	s1,56(sp)
     2b0:	7942                	ld	s2,48(sp)
     2b2:	79a2                	ld	s3,40(sp)
     2b4:	7a02                	ld	s4,32(sp)
     2b6:	6ae2                	ld	s5,24(sp)
     2b8:	6b42                	ld	s6,16(sp)
     2ba:	6ba2                	ld	s7,8(sp)
     2bc:	6161                	addi	sp,sp,80
     2be:	8082                	ret
      printf("%s: cannot create bigwrite\n", s);
     2c0:	85de                	mv	a1,s7
     2c2:	00005517          	auipc	a0,0x5
     2c6:	44650513          	addi	a0,a0,1094 # 5708 <malloc+0x1ea>
     2ca:	1a0050ef          	jal	546a <printf>
      exit(1);
     2ce:	4505                	li	a0,1
     2d0:	56b040ef          	jal	503a <exit>
      if (cc != sz) {
     2d4:	89a6                	mv	s3,s1
        printf("%s: write(%d) ret %d\n", s, sz, cc);
     2d6:	86aa                	mv	a3,a0
     2d8:	864e                	mv	a2,s3
     2da:	85de                	mv	a1,s7
     2dc:	00005517          	auipc	a0,0x5
     2e0:	44c50513          	addi	a0,a0,1100 # 5728 <malloc+0x20a>
     2e4:	186050ef          	jal	546a <printf>
        exit(1);
     2e8:	4505                	li	a0,1
     2ea:	551040ef          	jal	503a <exit>

00000000000002ee <badwrite>:
// file is deleted? if the kernel has this bug, it will panic: balloc:
// out of blocks. assumed_free may need to be raised to be more than
// the number of free blocks. this test takes a long time.
void
badwrite(char *s)
{
     2ee:	7179                	addi	sp,sp,-48
     2f0:	f406                	sd	ra,40(sp)
     2f2:	f022                	sd	s0,32(sp)
     2f4:	ec26                	sd	s1,24(sp)
     2f6:	e84a                	sd	s2,16(sp)
     2f8:	e44e                	sd	s3,8(sp)
     2fa:	e052                	sd	s4,0(sp)
     2fc:	1800                	addi	s0,sp,48
  int assumed_free = 600;

  unlink("junk");
     2fe:	00005517          	auipc	a0,0x5
     302:	44250513          	addi	a0,a0,1090 # 5740 <malloc+0x222>
     306:	585040ef          	jal	508a <unlink>
     30a:	25800913          	li	s2,600
  for (int i = 0; i < assumed_free; i++) {
    int fd = open("junk", O_CREATE | O_WRONLY);
     30e:	00005997          	auipc	s3,0x5
     312:	43298993          	addi	s3,s3,1074 # 5740 <malloc+0x222>
    if (fd < 0) {
      printf("open junk failed\n");
      exit(1);
    }
    write(fd, (char *)0xffffffffffL, 1);
     316:	5a7d                	li	s4,-1
     318:	018a5a13          	srli	s4,s4,0x18
    int fd = open("junk", O_CREATE | O_WRONLY);
     31c:	20100593          	li	a1,513
     320:	854e                	mv	a0,s3
     322:	559040ef          	jal	507a <open>
     326:	84aa                	mv	s1,a0
    if (fd < 0) {
     328:	04054d63          	bltz	a0,382 <badwrite+0x94>
    write(fd, (char *)0xffffffffffL, 1);
     32c:	4605                	li	a2,1
     32e:	85d2                	mv	a1,s4
     330:	52b040ef          	jal	505a <write>
    close(fd);
     334:	8526                	mv	a0,s1
     336:	52d040ef          	jal	5062 <close>
    unlink("junk");
     33a:	854e                	mv	a0,s3
     33c:	54f040ef          	jal	508a <unlink>
  for (int i = 0; i < assumed_free; i++) {
     340:	397d                	addiw	s2,s2,-1
     342:	fc091de3          	bnez	s2,31c <badwrite+0x2e>
  }

  int fd = open("junk", O_CREATE | O_WRONLY);
     346:	20100593          	li	a1,513
     34a:	00005517          	auipc	a0,0x5
     34e:	3f650513          	addi	a0,a0,1014 # 5740 <malloc+0x222>
     352:	529040ef          	jal	507a <open>
     356:	84aa                	mv	s1,a0
  if (fd < 0) {
     358:	02054e63          	bltz	a0,394 <badwrite+0xa6>
    printf("open junk failed\n");
    exit(1);
  }
  if (write(fd, "x", 1) != 1) {
     35c:	4605                	li	a2,1
     35e:	00005597          	auipc	a1,0x5
     362:	36a58593          	addi	a1,a1,874 # 56c8 <malloc+0x1aa>
     366:	4f5040ef          	jal	505a <write>
     36a:	4785                	li	a5,1
     36c:	02f50d63          	beq	a0,a5,3a6 <badwrite+0xb8>
    printf("write failed\n");
     370:	00005517          	auipc	a0,0x5
     374:	3f050513          	addi	a0,a0,1008 # 5760 <malloc+0x242>
     378:	0f2050ef          	jal	546a <printf>
    exit(1);
     37c:	4505                	li	a0,1
     37e:	4bd040ef          	jal	503a <exit>
      printf("open junk failed\n");
     382:	00005517          	auipc	a0,0x5
     386:	3c650513          	addi	a0,a0,966 # 5748 <malloc+0x22a>
     38a:	0e0050ef          	jal	546a <printf>
      exit(1);
     38e:	4505                	li	a0,1
     390:	4ab040ef          	jal	503a <exit>
    printf("open junk failed\n");
     394:	00005517          	auipc	a0,0x5
     398:	3b450513          	addi	a0,a0,948 # 5748 <malloc+0x22a>
     39c:	0ce050ef          	jal	546a <printf>
    exit(1);
     3a0:	4505                	li	a0,1
     3a2:	499040ef          	jal	503a <exit>
  }
  close(fd);
     3a6:	8526                	mv	a0,s1
     3a8:	4bb040ef          	jal	5062 <close>
  unlink("junk");
     3ac:	00005517          	auipc	a0,0x5
     3b0:	39450513          	addi	a0,a0,916 # 5740 <malloc+0x222>
     3b4:	4d7040ef          	jal	508a <unlink>

  exit(0);
     3b8:	4501                	li	a0,0
     3ba:	481040ef          	jal	503a <exit>

00000000000003be <outofinodes>:
  }
}

void
outofinodes(char *s)
{
     3be:	715d                	addi	sp,sp,-80
     3c0:	e486                	sd	ra,72(sp)
     3c2:	e0a2                	sd	s0,64(sp)
     3c4:	fc26                	sd	s1,56(sp)
     3c6:	f84a                	sd	s2,48(sp)
     3c8:	f44e                	sd	s3,40(sp)
     3ca:	0880                	addi	s0,sp,80
  int nzz = 32 * 32;
  for (int i = 0; i < nzz; i++) {
     3cc:	4481                	li	s1,0
    char name[32];
    name[0] = 'z';
     3ce:	07a00913          	li	s2,122
  for (int i = 0; i < nzz; i++) {
     3d2:	40000993          	li	s3,1024
    name[0] = 'z';
     3d6:	fb240823          	sb	s2,-80(s0)
    name[1] = 'z';
     3da:	fb2408a3          	sb	s2,-79(s0)
    name[2] = '0' + (i / 32);
     3de:	41f4d71b          	sraiw	a4,s1,0x1f
     3e2:	01b7571b          	srliw	a4,a4,0x1b
     3e6:	009707bb          	addw	a5,a4,s1
     3ea:	4057d69b          	sraiw	a3,a5,0x5
     3ee:	0306869b          	addiw	a3,a3,48
     3f2:	fad40923          	sb	a3,-78(s0)
    name[3] = '0' + (i % 32);
     3f6:	8bfd                	andi	a5,a5,31
     3f8:	9f99                	subw	a5,a5,a4
     3fa:	0307879b          	addiw	a5,a5,48
     3fe:	faf409a3          	sb	a5,-77(s0)
    name[4] = '\0';
     402:	fa040a23          	sb	zero,-76(s0)
    unlink(name);
     406:	fb040513          	addi	a0,s0,-80
     40a:	481040ef          	jal	508a <unlink>
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
     40e:	60200593          	li	a1,1538
     412:	fb040513          	addi	a0,s0,-80
     416:	465040ef          	jal	507a <open>
    if (fd < 0) {
     41a:	00054763          	bltz	a0,428 <outofinodes+0x6a>
      // failure is eventually expected.
      break;
    }
    close(fd);
     41e:	445040ef          	jal	5062 <close>
  for (int i = 0; i < nzz; i++) {
     422:	2485                	addiw	s1,s1,1
     424:	fb3499e3          	bne	s1,s3,3d6 <outofinodes+0x18>
     428:	4481                	li	s1,0
  }

  for (int i = 0; i < nzz; i++) {
    char name[32];
    name[0] = 'z';
     42a:	07a00913          	li	s2,122
  for (int i = 0; i < nzz; i++) {
     42e:	40000993          	li	s3,1024
    name[0] = 'z';
     432:	fb240823          	sb	s2,-80(s0)
    name[1] = 'z';
     436:	fb2408a3          	sb	s2,-79(s0)
    name[2] = '0' + (i / 32);
     43a:	41f4d71b          	sraiw	a4,s1,0x1f
     43e:	01b7571b          	srliw	a4,a4,0x1b
     442:	009707bb          	addw	a5,a4,s1
     446:	4057d69b          	sraiw	a3,a5,0x5
     44a:	0306869b          	addiw	a3,a3,48
     44e:	fad40923          	sb	a3,-78(s0)
    name[3] = '0' + (i % 32);
     452:	8bfd                	andi	a5,a5,31
     454:	9f99                	subw	a5,a5,a4
     456:	0307879b          	addiw	a5,a5,48
     45a:	faf409a3          	sb	a5,-77(s0)
    name[4] = '\0';
     45e:	fa040a23          	sb	zero,-76(s0)
    unlink(name);
     462:	fb040513          	addi	a0,s0,-80
     466:	425040ef          	jal	508a <unlink>
  for (int i = 0; i < nzz; i++) {
     46a:	2485                	addiw	s1,s1,1
     46c:	fd3493e3          	bne	s1,s3,432 <outofinodes+0x74>
  }
}
     470:	60a6                	ld	ra,72(sp)
     472:	6406                	ld	s0,64(sp)
     474:	74e2                	ld	s1,56(sp)
     476:	7942                	ld	s2,48(sp)
     478:	79a2                	ld	s3,40(sp)
     47a:	6161                	addi	sp,sp,80
     47c:	8082                	ret

000000000000047e <copyin>:
{
     47e:	7159                	addi	sp,sp,-112
     480:	f486                	sd	ra,104(sp)
     482:	f0a2                	sd	s0,96(sp)
     484:	eca6                	sd	s1,88(sp)
     486:	e8ca                	sd	s2,80(sp)
     488:	e4ce                	sd	s3,72(sp)
     48a:	e0d2                	sd	s4,64(sp)
     48c:	fc56                	sd	s5,56(sp)
     48e:	1880                	addi	s0,sp,112
  uint64 addrs[] = {0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
     490:	00008797          	auipc	a5,0x8
     494:	88078793          	addi	a5,a5,-1920 # 7d10 <malloc+0x27f2>
     498:	638c                	ld	a1,0(a5)
     49a:	6790                	ld	a2,8(a5)
     49c:	6b94                	ld	a3,16(a5)
     49e:	6f98                	ld	a4,24(a5)
     4a0:	739c                	ld	a5,32(a5)
     4a2:	f8b43c23          	sd	a1,-104(s0)
     4a6:	fac43023          	sd	a2,-96(s0)
     4aa:	fad43423          	sd	a3,-88(s0)
     4ae:	fae43823          	sd	a4,-80(s0)
     4b2:	faf43c23          	sd	a5,-72(s0)
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     4b6:	f9840913          	addi	s2,s0,-104
     4ba:	fc040a93          	addi	s5,s0,-64
    int fd = open("copyin1", O_CREATE | O_WRONLY);
     4be:	00005a17          	auipc	s4,0x5
     4c2:	2b2a0a13          	addi	s4,s4,690 # 5770 <malloc+0x252>
    uint64 addr = addrs[ai];
     4c6:	00093983          	ld	s3,0(s2)
    int fd = open("copyin1", O_CREATE | O_WRONLY);
     4ca:	20100593          	li	a1,513
     4ce:	8552                	mv	a0,s4
     4d0:	3ab040ef          	jal	507a <open>
     4d4:	84aa                	mv	s1,a0
    if (fd < 0) {
     4d6:	06054763          	bltz	a0,544 <copyin+0xc6>
    int n = write(fd, (void *)addr, 8192);
     4da:	6609                	lui	a2,0x2
     4dc:	85ce                	mv	a1,s3
     4de:	37d040ef          	jal	505a <write>
    if (n >= 0) {
     4e2:	06055a63          	bgez	a0,556 <copyin+0xd8>
    close(fd);
     4e6:	8526                	mv	a0,s1
     4e8:	37b040ef          	jal	5062 <close>
    unlink("copyin1");
     4ec:	8552                	mv	a0,s4
     4ee:	39d040ef          	jal	508a <unlink>
    n = write(1, (char *)addr, 8192);
     4f2:	6609                	lui	a2,0x2
     4f4:	85ce                	mv	a1,s3
     4f6:	4505                	li	a0,1
     4f8:	363040ef          	jal	505a <write>
    if (n > 0) {
     4fc:	06a04863          	bgtz	a0,56c <copyin+0xee>
    if (pipe(fds) < 0) {
     500:	f9040513          	addi	a0,s0,-112
     504:	347040ef          	jal	504a <pipe>
     508:	06054d63          	bltz	a0,582 <copyin+0x104>
    n = write(fds[1], (char *)addr, 8192);
     50c:	6609                	lui	a2,0x2
     50e:	85ce                	mv	a1,s3
     510:	f9442503          	lw	a0,-108(s0)
     514:	347040ef          	jal	505a <write>
    if (n > 0) {
     518:	06a04e63          	bgtz	a0,594 <copyin+0x116>
    close(fds[0]);
     51c:	f9042503          	lw	a0,-112(s0)
     520:	343040ef          	jal	5062 <close>
    close(fds[1]);
     524:	f9442503          	lw	a0,-108(s0)
     528:	33b040ef          	jal	5062 <close>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     52c:	0921                	addi	s2,s2,8
     52e:	f9591ce3          	bne	s2,s5,4c6 <copyin+0x48>
}
     532:	70a6                	ld	ra,104(sp)
     534:	7406                	ld	s0,96(sp)
     536:	64e6                	ld	s1,88(sp)
     538:	6946                	ld	s2,80(sp)
     53a:	69a6                	ld	s3,72(sp)
     53c:	6a06                	ld	s4,64(sp)
     53e:	7ae2                	ld	s5,56(sp)
     540:	6165                	addi	sp,sp,112
     542:	8082                	ret
      printf("open(copyin1) failed\n");
     544:	00005517          	auipc	a0,0x5
     548:	23450513          	addi	a0,a0,564 # 5778 <malloc+0x25a>
     54c:	71f040ef          	jal	546a <printf>
      exit(1);
     550:	4505                	li	a0,1
     552:	2e9040ef          	jal	503a <exit>
      printf("write(fd, %p, 8192) returned %d, not -1\n", (void *)addr, n);
     556:	862a                	mv	a2,a0
     558:	85ce                	mv	a1,s3
     55a:	00005517          	auipc	a0,0x5
     55e:	23650513          	addi	a0,a0,566 # 5790 <malloc+0x272>
     562:	709040ef          	jal	546a <printf>
      exit(1);
     566:	4505                	li	a0,1
     568:	2d3040ef          	jal	503a <exit>
      printf("write(1, %p, 8192) returned %d, not -1 or 0\n", (void *)addr, n);
     56c:	862a                	mv	a2,a0
     56e:	85ce                	mv	a1,s3
     570:	00005517          	auipc	a0,0x5
     574:	25050513          	addi	a0,a0,592 # 57c0 <malloc+0x2a2>
     578:	6f3040ef          	jal	546a <printf>
      exit(1);
     57c:	4505                	li	a0,1
     57e:	2bd040ef          	jal	503a <exit>
      printf("pipe() failed\n");
     582:	00005517          	auipc	a0,0x5
     586:	26e50513          	addi	a0,a0,622 # 57f0 <malloc+0x2d2>
     58a:	6e1040ef          	jal	546a <printf>
      exit(1);
     58e:	4505                	li	a0,1
     590:	2ab040ef          	jal	503a <exit>
      printf("write(pipe, %p, 8192) returned %d, not -1 or 0\n", (void *)addr,
     594:	862a                	mv	a2,a0
     596:	85ce                	mv	a1,s3
     598:	00005517          	auipc	a0,0x5
     59c:	26850513          	addi	a0,a0,616 # 5800 <malloc+0x2e2>
     5a0:	6cb040ef          	jal	546a <printf>
      exit(1);
     5a4:	4505                	li	a0,1
     5a6:	295040ef          	jal	503a <exit>

00000000000005aa <copyout>:
{
     5aa:	7119                	addi	sp,sp,-128
     5ac:	fc86                	sd	ra,120(sp)
     5ae:	f8a2                	sd	s0,112(sp)
     5b0:	f4a6                	sd	s1,104(sp)
     5b2:	f0ca                	sd	s2,96(sp)
     5b4:	ecce                	sd	s3,88(sp)
     5b6:	e8d2                	sd	s4,80(sp)
     5b8:	e4d6                	sd	s5,72(sp)
     5ba:	e0da                	sd	s6,64(sp)
     5bc:	0100                	addi	s0,sp,128
  uint64 addrs[] = {0LL,          0x80000000LL, 0x3fffffe000,
     5be:	00007797          	auipc	a5,0x7
     5c2:	75278793          	addi	a5,a5,1874 # 7d10 <malloc+0x27f2>
     5c6:	7788                	ld	a0,40(a5)
     5c8:	7b8c                	ld	a1,48(a5)
     5ca:	7f90                	ld	a2,56(a5)
     5cc:	63b4                	ld	a3,64(a5)
     5ce:	67b8                	ld	a4,72(a5)
     5d0:	6bbc                	ld	a5,80(a5)
     5d2:	f8a43823          	sd	a0,-112(s0)
     5d6:	f8b43c23          	sd	a1,-104(s0)
     5da:	fac43023          	sd	a2,-96(s0)
     5de:	fad43423          	sd	a3,-88(s0)
     5e2:	fae43823          	sd	a4,-80(s0)
     5e6:	faf43c23          	sd	a5,-72(s0)
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     5ea:	f9040913          	addi	s2,s0,-112
     5ee:	fc040b13          	addi	s6,s0,-64
    int fd = open("README", 0);
     5f2:	00005a17          	auipc	s4,0x5
     5f6:	23ea0a13          	addi	s4,s4,574 # 5830 <malloc+0x312>
    n = write(fds[1], "x", 1);
     5fa:	00005a97          	auipc	s5,0x5
     5fe:	0cea8a93          	addi	s5,s5,206 # 56c8 <malloc+0x1aa>
    uint64 addr = addrs[ai];
     602:	00093983          	ld	s3,0(s2)
    int fd = open("README", 0);
     606:	4581                	li	a1,0
     608:	8552                	mv	a0,s4
     60a:	271040ef          	jal	507a <open>
     60e:	84aa                	mv	s1,a0
    if (fd < 0) {
     610:	06054763          	bltz	a0,67e <copyout+0xd4>
    int n = read(fd, (void *)addr, 8192);
     614:	6609                	lui	a2,0x2
     616:	85ce                	mv	a1,s3
     618:	23b040ef          	jal	5052 <read>
    if (n > 0) {
     61c:	06a04a63          	bgtz	a0,690 <copyout+0xe6>
    close(fd);
     620:	8526                	mv	a0,s1
     622:	241040ef          	jal	5062 <close>
    if (pipe(fds) < 0) {
     626:	f8840513          	addi	a0,s0,-120
     62a:	221040ef          	jal	504a <pipe>
     62e:	06054c63          	bltz	a0,6a6 <copyout+0xfc>
    n = write(fds[1], "x", 1);
     632:	4605                	li	a2,1
     634:	85d6                	mv	a1,s5
     636:	f8c42503          	lw	a0,-116(s0)
     63a:	221040ef          	jal	505a <write>
    if (n != 1) {
     63e:	4785                	li	a5,1
     640:	06f51c63          	bne	a0,a5,6b8 <copyout+0x10e>
    n = read(fds[0], (void *)addr, 8192);
     644:	6609                	lui	a2,0x2
     646:	85ce                	mv	a1,s3
     648:	f8842503          	lw	a0,-120(s0)
     64c:	207040ef          	jal	5052 <read>
    if (n > 0) {
     650:	06a04d63          	bgtz	a0,6ca <copyout+0x120>
    close(fds[0]);
     654:	f8842503          	lw	a0,-120(s0)
     658:	20b040ef          	jal	5062 <close>
    close(fds[1]);
     65c:	f8c42503          	lw	a0,-116(s0)
     660:	203040ef          	jal	5062 <close>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     664:	0921                	addi	s2,s2,8
     666:	f9691ee3          	bne	s2,s6,602 <copyout+0x58>
}
     66a:	70e6                	ld	ra,120(sp)
     66c:	7446                	ld	s0,112(sp)
     66e:	74a6                	ld	s1,104(sp)
     670:	7906                	ld	s2,96(sp)
     672:	69e6                	ld	s3,88(sp)
     674:	6a46                	ld	s4,80(sp)
     676:	6aa6                	ld	s5,72(sp)
     678:	6b06                	ld	s6,64(sp)
     67a:	6109                	addi	sp,sp,128
     67c:	8082                	ret
      printf("open(README) failed\n");
     67e:	00005517          	auipc	a0,0x5
     682:	1ba50513          	addi	a0,a0,442 # 5838 <malloc+0x31a>
     686:	5e5040ef          	jal	546a <printf>
      exit(1);
     68a:	4505                	li	a0,1
     68c:	1af040ef          	jal	503a <exit>
      printf("read(fd, %p, 8192) returned %d, not -1 or 0\n", (void *)addr, n);
     690:	862a                	mv	a2,a0
     692:	85ce                	mv	a1,s3
     694:	00005517          	auipc	a0,0x5
     698:	1bc50513          	addi	a0,a0,444 # 5850 <malloc+0x332>
     69c:	5cf040ef          	jal	546a <printf>
      exit(1);
     6a0:	4505                	li	a0,1
     6a2:	199040ef          	jal	503a <exit>
      printf("pipe() failed\n");
     6a6:	00005517          	auipc	a0,0x5
     6aa:	14a50513          	addi	a0,a0,330 # 57f0 <malloc+0x2d2>
     6ae:	5bd040ef          	jal	546a <printf>
      exit(1);
     6b2:	4505                	li	a0,1
     6b4:	187040ef          	jal	503a <exit>
      printf("pipe write failed\n");
     6b8:	00005517          	auipc	a0,0x5
     6bc:	1c850513          	addi	a0,a0,456 # 5880 <malloc+0x362>
     6c0:	5ab040ef          	jal	546a <printf>
      exit(1);
     6c4:	4505                	li	a0,1
     6c6:	175040ef          	jal	503a <exit>
      printf("read(pipe, %p, 8192) returned %d, not -1 or 0\n", (void *)addr,
     6ca:	862a                	mv	a2,a0
     6cc:	85ce                	mv	a1,s3
     6ce:	00005517          	auipc	a0,0x5
     6d2:	1ca50513          	addi	a0,a0,458 # 5898 <malloc+0x37a>
     6d6:	595040ef          	jal	546a <printf>
      exit(1);
     6da:	4505                	li	a0,1
     6dc:	15f040ef          	jal	503a <exit>

00000000000006e0 <truncate1>:
{
     6e0:	711d                	addi	sp,sp,-96
     6e2:	ec86                	sd	ra,88(sp)
     6e4:	e8a2                	sd	s0,80(sp)
     6e6:	e4a6                	sd	s1,72(sp)
     6e8:	e0ca                	sd	s2,64(sp)
     6ea:	fc4e                	sd	s3,56(sp)
     6ec:	f852                	sd	s4,48(sp)
     6ee:	f456                	sd	s5,40(sp)
     6f0:	1080                	addi	s0,sp,96
     6f2:	8aaa                	mv	s5,a0
  unlink("truncfile");
     6f4:	00005517          	auipc	a0,0x5
     6f8:	fbc50513          	addi	a0,a0,-68 # 56b0 <malloc+0x192>
     6fc:	18f040ef          	jal	508a <unlink>
  int fd1 = open("truncfile", O_CREATE | O_WRONLY | O_TRUNC);
     700:	60100593          	li	a1,1537
     704:	00005517          	auipc	a0,0x5
     708:	fac50513          	addi	a0,a0,-84 # 56b0 <malloc+0x192>
     70c:	16f040ef          	jal	507a <open>
     710:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     712:	4611                	li	a2,4
     714:	00005597          	auipc	a1,0x5
     718:	fac58593          	addi	a1,a1,-84 # 56c0 <malloc+0x1a2>
     71c:	13f040ef          	jal	505a <write>
  close(fd1);
     720:	8526                	mv	a0,s1
     722:	141040ef          	jal	5062 <close>
  int fd2 = open("truncfile", O_RDONLY);
     726:	4581                	li	a1,0
     728:	00005517          	auipc	a0,0x5
     72c:	f8850513          	addi	a0,a0,-120 # 56b0 <malloc+0x192>
     730:	14b040ef          	jal	507a <open>
     734:	84aa                	mv	s1,a0
  int n = read(fd2, buf, sizeof(buf));
     736:	02000613          	li	a2,32
     73a:	fa040593          	addi	a1,s0,-96
     73e:	115040ef          	jal	5052 <read>
  if (n != 4) {
     742:	4791                	li	a5,4
     744:	0af51863          	bne	a0,a5,7f4 <truncate1+0x114>
  fd1 = open("truncfile", O_WRONLY | O_TRUNC);
     748:	40100593          	li	a1,1025
     74c:	00005517          	auipc	a0,0x5
     750:	f6450513          	addi	a0,a0,-156 # 56b0 <malloc+0x192>
     754:	127040ef          	jal	507a <open>
     758:	89aa                	mv	s3,a0
  int fd3 = open("truncfile", O_RDONLY);
     75a:	4581                	li	a1,0
     75c:	00005517          	auipc	a0,0x5
     760:	f5450513          	addi	a0,a0,-172 # 56b0 <malloc+0x192>
     764:	117040ef          	jal	507a <open>
     768:	892a                	mv	s2,a0
  n = read(fd3, buf, sizeof(buf));
     76a:	02000613          	li	a2,32
     76e:	fa040593          	addi	a1,s0,-96
     772:	0e1040ef          	jal	5052 <read>
     776:	8a2a                	mv	s4,a0
  if (n != 0) {
     778:	e949                	bnez	a0,80a <truncate1+0x12a>
  n = read(fd2, buf, sizeof(buf));
     77a:	02000613          	li	a2,32
     77e:	fa040593          	addi	a1,s0,-96
     782:	8526                	mv	a0,s1
     784:	0cf040ef          	jal	5052 <read>
     788:	8a2a                	mv	s4,a0
  if (n != 0) {
     78a:	e155                	bnez	a0,82e <truncate1+0x14e>
  write(fd1, "abcdef", 6);
     78c:	4619                	li	a2,6
     78e:	00005597          	auipc	a1,0x5
     792:	19a58593          	addi	a1,a1,410 # 5928 <malloc+0x40a>
     796:	854e                	mv	a0,s3
     798:	0c3040ef          	jal	505a <write>
  n = read(fd3, buf, sizeof(buf));
     79c:	02000613          	li	a2,32
     7a0:	fa040593          	addi	a1,s0,-96
     7a4:	854a                	mv	a0,s2
     7a6:	0ad040ef          	jal	5052 <read>
  if (n != 6) {
     7aa:	4799                	li	a5,6
     7ac:	0af51363          	bne	a0,a5,852 <truncate1+0x172>
  n = read(fd2, buf, sizeof(buf));
     7b0:	02000613          	li	a2,32
     7b4:	fa040593          	addi	a1,s0,-96
     7b8:	8526                	mv	a0,s1
     7ba:	099040ef          	jal	5052 <read>
  if (n != 2) {
     7be:	4789                	li	a5,2
     7c0:	0af51463          	bne	a0,a5,868 <truncate1+0x188>
  unlink("truncfile");
     7c4:	00005517          	auipc	a0,0x5
     7c8:	eec50513          	addi	a0,a0,-276 # 56b0 <malloc+0x192>
     7cc:	0bf040ef          	jal	508a <unlink>
  close(fd1);
     7d0:	854e                	mv	a0,s3
     7d2:	091040ef          	jal	5062 <close>
  close(fd2);
     7d6:	8526                	mv	a0,s1
     7d8:	08b040ef          	jal	5062 <close>
  close(fd3);
     7dc:	854a                	mv	a0,s2
     7de:	085040ef          	jal	5062 <close>
}
     7e2:	60e6                	ld	ra,88(sp)
     7e4:	6446                	ld	s0,80(sp)
     7e6:	64a6                	ld	s1,72(sp)
     7e8:	6906                	ld	s2,64(sp)
     7ea:	79e2                	ld	s3,56(sp)
     7ec:	7a42                	ld	s4,48(sp)
     7ee:	7aa2                	ld	s5,40(sp)
     7f0:	6125                	addi	sp,sp,96
     7f2:	8082                	ret
    printf("%s: read %d bytes, wanted 4\n", s, n);
     7f4:	862a                	mv	a2,a0
     7f6:	85d6                	mv	a1,s5
     7f8:	00005517          	auipc	a0,0x5
     7fc:	0d050513          	addi	a0,a0,208 # 58c8 <malloc+0x3aa>
     800:	46b040ef          	jal	546a <printf>
    exit(1);
     804:	4505                	li	a0,1
     806:	035040ef          	jal	503a <exit>
    printf("aaa fd3=%d\n", fd3);
     80a:	85ca                	mv	a1,s2
     80c:	00005517          	auipc	a0,0x5
     810:	0dc50513          	addi	a0,a0,220 # 58e8 <malloc+0x3ca>
     814:	457040ef          	jal	546a <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     818:	8652                	mv	a2,s4
     81a:	85d6                	mv	a1,s5
     81c:	00005517          	auipc	a0,0x5
     820:	0dc50513          	addi	a0,a0,220 # 58f8 <malloc+0x3da>
     824:	447040ef          	jal	546a <printf>
    exit(1);
     828:	4505                	li	a0,1
     82a:	011040ef          	jal	503a <exit>
    printf("bbb fd2=%d\n", fd2);
     82e:	85a6                	mv	a1,s1
     830:	00005517          	auipc	a0,0x5
     834:	0e850513          	addi	a0,a0,232 # 5918 <malloc+0x3fa>
     838:	433040ef          	jal	546a <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     83c:	8652                	mv	a2,s4
     83e:	85d6                	mv	a1,s5
     840:	00005517          	auipc	a0,0x5
     844:	0b850513          	addi	a0,a0,184 # 58f8 <malloc+0x3da>
     848:	423040ef          	jal	546a <printf>
    exit(1);
     84c:	4505                	li	a0,1
     84e:	7ec040ef          	jal	503a <exit>
    printf("%s: read %d bytes, wanted 6\n", s, n);
     852:	862a                	mv	a2,a0
     854:	85d6                	mv	a1,s5
     856:	00005517          	auipc	a0,0x5
     85a:	0da50513          	addi	a0,a0,218 # 5930 <malloc+0x412>
     85e:	40d040ef          	jal	546a <printf>
    exit(1);
     862:	4505                	li	a0,1
     864:	7d6040ef          	jal	503a <exit>
    printf("%s: read %d bytes, wanted 2\n", s, n);
     868:	862a                	mv	a2,a0
     86a:	85d6                	mv	a1,s5
     86c:	00005517          	auipc	a0,0x5
     870:	0e450513          	addi	a0,a0,228 # 5950 <malloc+0x432>
     874:	3f7040ef          	jal	546a <printf>
    exit(1);
     878:	4505                	li	a0,1
     87a:	7c0040ef          	jal	503a <exit>

000000000000087e <writetest>:
{
     87e:	7139                	addi	sp,sp,-64
     880:	fc06                	sd	ra,56(sp)
     882:	f822                	sd	s0,48(sp)
     884:	f426                	sd	s1,40(sp)
     886:	f04a                	sd	s2,32(sp)
     888:	ec4e                	sd	s3,24(sp)
     88a:	e852                	sd	s4,16(sp)
     88c:	e456                	sd	s5,8(sp)
     88e:	e05a                	sd	s6,0(sp)
     890:	0080                	addi	s0,sp,64
     892:	8b2a                	mv	s6,a0
  fd = open("small", O_CREATE | O_RDWR);
     894:	20200593          	li	a1,514
     898:	00005517          	auipc	a0,0x5
     89c:	0d850513          	addi	a0,a0,216 # 5970 <malloc+0x452>
     8a0:	7da040ef          	jal	507a <open>
  if (fd < 0) {
     8a4:	08054f63          	bltz	a0,942 <writetest+0xc4>
     8a8:	892a                	mv	s2,a0
     8aa:	4481                	li	s1,0
    if (write(fd, "aaaaaaaaaa", SZ) != SZ) {
     8ac:	00005997          	auipc	s3,0x5
     8b0:	0ec98993          	addi	s3,s3,236 # 5998 <malloc+0x47a>
    if (write(fd, "bbbbbbbbbb", SZ) != SZ) {
     8b4:	00005a97          	auipc	s5,0x5
     8b8:	11ca8a93          	addi	s5,s5,284 # 59d0 <malloc+0x4b2>
  for (i = 0; i < N; i++) {
     8bc:	06400a13          	li	s4,100
    if (write(fd, "aaaaaaaaaa", SZ) != SZ) {
     8c0:	4629                	li	a2,10
     8c2:	85ce                	mv	a1,s3
     8c4:	854a                	mv	a0,s2
     8c6:	794040ef          	jal	505a <write>
     8ca:	47a9                	li	a5,10
     8cc:	08f51563          	bne	a0,a5,956 <writetest+0xd8>
    if (write(fd, "bbbbbbbbbb", SZ) != SZ) {
     8d0:	4629                	li	a2,10
     8d2:	85d6                	mv	a1,s5
     8d4:	854a                	mv	a0,s2
     8d6:	784040ef          	jal	505a <write>
     8da:	47a9                	li	a5,10
     8dc:	08f51863          	bne	a0,a5,96c <writetest+0xee>
  for (i = 0; i < N; i++) {
     8e0:	2485                	addiw	s1,s1,1
     8e2:	fd449fe3          	bne	s1,s4,8c0 <writetest+0x42>
  close(fd);
     8e6:	854a                	mv	a0,s2
     8e8:	77a040ef          	jal	5062 <close>
  fd = open("small", O_RDONLY);
     8ec:	4581                	li	a1,0
     8ee:	00005517          	auipc	a0,0x5
     8f2:	08250513          	addi	a0,a0,130 # 5970 <malloc+0x452>
     8f6:	784040ef          	jal	507a <open>
     8fa:	84aa                	mv	s1,a0
  if (fd < 0) {
     8fc:	08054363          	bltz	a0,982 <writetest+0x104>
  i = read(fd, buf, N * SZ * 2);
     900:	7d000613          	li	a2,2000
     904:	0000b597          	auipc	a1,0xb
     908:	3c458593          	addi	a1,a1,964 # bcc8 <buf>
     90c:	746040ef          	jal	5052 <read>
  if (i != N * SZ * 2) {
     910:	7d000793          	li	a5,2000
     914:	08f51163          	bne	a0,a5,996 <writetest+0x118>
  close(fd);
     918:	8526                	mv	a0,s1
     91a:	748040ef          	jal	5062 <close>
  if (unlink("small") < 0) {
     91e:	00005517          	auipc	a0,0x5
     922:	05250513          	addi	a0,a0,82 # 5970 <malloc+0x452>
     926:	764040ef          	jal	508a <unlink>
     92a:	08054063          	bltz	a0,9aa <writetest+0x12c>
}
     92e:	70e2                	ld	ra,56(sp)
     930:	7442                	ld	s0,48(sp)
     932:	74a2                	ld	s1,40(sp)
     934:	7902                	ld	s2,32(sp)
     936:	69e2                	ld	s3,24(sp)
     938:	6a42                	ld	s4,16(sp)
     93a:	6aa2                	ld	s5,8(sp)
     93c:	6b02                	ld	s6,0(sp)
     93e:	6121                	addi	sp,sp,64
     940:	8082                	ret
    printf("%s: error: creat small failed!\n", s);
     942:	85da                	mv	a1,s6
     944:	00005517          	auipc	a0,0x5
     948:	03450513          	addi	a0,a0,52 # 5978 <malloc+0x45a>
     94c:	31f040ef          	jal	546a <printf>
    exit(1);
     950:	4505                	li	a0,1
     952:	6e8040ef          	jal	503a <exit>
      printf("%s: error: write aa %d new file failed\n", s, i);
     956:	8626                	mv	a2,s1
     958:	85da                	mv	a1,s6
     95a:	00005517          	auipc	a0,0x5
     95e:	04e50513          	addi	a0,a0,78 # 59a8 <malloc+0x48a>
     962:	309040ef          	jal	546a <printf>
      exit(1);
     966:	4505                	li	a0,1
     968:	6d2040ef          	jal	503a <exit>
      printf("%s: error: write bb %d new file failed\n", s, i);
     96c:	8626                	mv	a2,s1
     96e:	85da                	mv	a1,s6
     970:	00005517          	auipc	a0,0x5
     974:	07050513          	addi	a0,a0,112 # 59e0 <malloc+0x4c2>
     978:	2f3040ef          	jal	546a <printf>
      exit(1);
     97c:	4505                	li	a0,1
     97e:	6bc040ef          	jal	503a <exit>
    printf("%s: error: open small failed!\n", s);
     982:	85da                	mv	a1,s6
     984:	00005517          	auipc	a0,0x5
     988:	08450513          	addi	a0,a0,132 # 5a08 <malloc+0x4ea>
     98c:	2df040ef          	jal	546a <printf>
    exit(1);
     990:	4505                	li	a0,1
     992:	6a8040ef          	jal	503a <exit>
    printf("%s: read failed\n", s);
     996:	85da                	mv	a1,s6
     998:	00005517          	auipc	a0,0x5
     99c:	09050513          	addi	a0,a0,144 # 5a28 <malloc+0x50a>
     9a0:	2cb040ef          	jal	546a <printf>
    exit(1);
     9a4:	4505                	li	a0,1
     9a6:	694040ef          	jal	503a <exit>
    printf("%s: unlink small failed\n", s);
     9aa:	85da                	mv	a1,s6
     9ac:	00005517          	auipc	a0,0x5
     9b0:	09450513          	addi	a0,a0,148 # 5a40 <malloc+0x522>
     9b4:	2b7040ef          	jal	546a <printf>
    exit(1);
     9b8:	4505                	li	a0,1
     9ba:	680040ef          	jal	503a <exit>

00000000000009be <writebig>:
{
     9be:	7139                	addi	sp,sp,-64
     9c0:	fc06                	sd	ra,56(sp)
     9c2:	f822                	sd	s0,48(sp)
     9c4:	f426                	sd	s1,40(sp)
     9c6:	f04a                	sd	s2,32(sp)
     9c8:	ec4e                	sd	s3,24(sp)
     9ca:	e852                	sd	s4,16(sp)
     9cc:	e456                	sd	s5,8(sp)
     9ce:	0080                	addi	s0,sp,64
     9d0:	8aaa                	mv	s5,a0
  fd = open("big", O_CREATE | O_RDWR);
     9d2:	20200593          	li	a1,514
     9d6:	00005517          	auipc	a0,0x5
     9da:	08a50513          	addi	a0,a0,138 # 5a60 <malloc+0x542>
     9de:	69c040ef          	jal	507a <open>
     9e2:	89aa                	mv	s3,a0
  for (i = 0; i < MAXFILE; i++) {
     9e4:	4481                	li	s1,0
    ((int *)buf)[0] = i;
     9e6:	0000b917          	auipc	s2,0xb
     9ea:	2e290913          	addi	s2,s2,738 # bcc8 <buf>
  for (i = 0; i < MAXFILE; i++) {
     9ee:	10c00a13          	li	s4,268
  if (fd < 0) {
     9f2:	06054463          	bltz	a0,a5a <writebig+0x9c>
    ((int *)buf)[0] = i;
     9f6:	00992023          	sw	s1,0(s2)
    if (write(fd, buf, BSIZE) != BSIZE) {
     9fa:	40000613          	li	a2,1024
     9fe:	85ca                	mv	a1,s2
     a00:	854e                	mv	a0,s3
     a02:	658040ef          	jal	505a <write>
     a06:	40000793          	li	a5,1024
     a0a:	06f51263          	bne	a0,a5,a6e <writebig+0xb0>
  for (i = 0; i < MAXFILE; i++) {
     a0e:	2485                	addiw	s1,s1,1
     a10:	ff4493e3          	bne	s1,s4,9f6 <writebig+0x38>
  close(fd);
     a14:	854e                	mv	a0,s3
     a16:	64c040ef          	jal	5062 <close>
  fd = open("big", O_RDONLY);
     a1a:	4581                	li	a1,0
     a1c:	00005517          	auipc	a0,0x5
     a20:	04450513          	addi	a0,a0,68 # 5a60 <malloc+0x542>
     a24:	656040ef          	jal	507a <open>
     a28:	89aa                	mv	s3,a0
  n = 0;
     a2a:	4481                	li	s1,0
    i = read(fd, buf, BSIZE);
     a2c:	0000b917          	auipc	s2,0xb
     a30:	29c90913          	addi	s2,s2,668 # bcc8 <buf>
  if (fd < 0) {
     a34:	04054863          	bltz	a0,a84 <writebig+0xc6>
    i = read(fd, buf, BSIZE);
     a38:	40000613          	li	a2,1024
     a3c:	85ca                	mv	a1,s2
     a3e:	854e                	mv	a0,s3
     a40:	612040ef          	jal	5052 <read>
    if (i == 0) {
     a44:	c931                	beqz	a0,a98 <writebig+0xda>
    } else if (i != BSIZE) {
     a46:	40000793          	li	a5,1024
     a4a:	08f51a63          	bne	a0,a5,ade <writebig+0x120>
    if (((int *)buf)[0] != n) {
     a4e:	00092683          	lw	a3,0(s2)
     a52:	0a969163          	bne	a3,s1,af4 <writebig+0x136>
    n++;
     a56:	2485                	addiw	s1,s1,1
    i = read(fd, buf, BSIZE);
     a58:	b7c5                	j	a38 <writebig+0x7a>
    printf("%s: error: creat big failed!\n", s);
     a5a:	85d6                	mv	a1,s5
     a5c:	00005517          	auipc	a0,0x5
     a60:	00c50513          	addi	a0,a0,12 # 5a68 <malloc+0x54a>
     a64:	207040ef          	jal	546a <printf>
    exit(1);
     a68:	4505                	li	a0,1
     a6a:	5d0040ef          	jal	503a <exit>
      printf("%s: error: write big file failed i=%d\n", s, i);
     a6e:	8626                	mv	a2,s1
     a70:	85d6                	mv	a1,s5
     a72:	00005517          	auipc	a0,0x5
     a76:	01650513          	addi	a0,a0,22 # 5a88 <malloc+0x56a>
     a7a:	1f1040ef          	jal	546a <printf>
      exit(1);
     a7e:	4505                	li	a0,1
     a80:	5ba040ef          	jal	503a <exit>
    printf("%s: error: open big failed!\n", s);
     a84:	85d6                	mv	a1,s5
     a86:	00005517          	auipc	a0,0x5
     a8a:	02a50513          	addi	a0,a0,42 # 5ab0 <malloc+0x592>
     a8e:	1dd040ef          	jal	546a <printf>
    exit(1);
     a92:	4505                	li	a0,1
     a94:	5a6040ef          	jal	503a <exit>
      if (n != MAXFILE) {
     a98:	10c00793          	li	a5,268
     a9c:	02f49663          	bne	s1,a5,ac8 <writebig+0x10a>
  close(fd);
     aa0:	854e                	mv	a0,s3
     aa2:	5c0040ef          	jal	5062 <close>
  if (unlink("big") < 0) {
     aa6:	00005517          	auipc	a0,0x5
     aaa:	fba50513          	addi	a0,a0,-70 # 5a60 <malloc+0x542>
     aae:	5dc040ef          	jal	508a <unlink>
     ab2:	04054c63          	bltz	a0,b0a <writebig+0x14c>
}
     ab6:	70e2                	ld	ra,56(sp)
     ab8:	7442                	ld	s0,48(sp)
     aba:	74a2                	ld	s1,40(sp)
     abc:	7902                	ld	s2,32(sp)
     abe:	69e2                	ld	s3,24(sp)
     ac0:	6a42                	ld	s4,16(sp)
     ac2:	6aa2                	ld	s5,8(sp)
     ac4:	6121                	addi	sp,sp,64
     ac6:	8082                	ret
        printf("%s: read only %d blocks from big", s, n);
     ac8:	8626                	mv	a2,s1
     aca:	85d6                	mv	a1,s5
     acc:	00005517          	auipc	a0,0x5
     ad0:	00450513          	addi	a0,a0,4 # 5ad0 <malloc+0x5b2>
     ad4:	197040ef          	jal	546a <printf>
        exit(1);
     ad8:	4505                	li	a0,1
     ada:	560040ef          	jal	503a <exit>
      printf("%s: read failed %d\n", s, i);
     ade:	862a                	mv	a2,a0
     ae0:	85d6                	mv	a1,s5
     ae2:	00005517          	auipc	a0,0x5
     ae6:	01650513          	addi	a0,a0,22 # 5af8 <malloc+0x5da>
     aea:	181040ef          	jal	546a <printf>
      exit(1);
     aee:	4505                	li	a0,1
     af0:	54a040ef          	jal	503a <exit>
      printf("%s: read content of block %d is %d\n", s, n, ((int *)buf)[0]);
     af4:	8626                	mv	a2,s1
     af6:	85d6                	mv	a1,s5
     af8:	00005517          	auipc	a0,0x5
     afc:	01850513          	addi	a0,a0,24 # 5b10 <malloc+0x5f2>
     b00:	16b040ef          	jal	546a <printf>
      exit(1);
     b04:	4505                	li	a0,1
     b06:	534040ef          	jal	503a <exit>
    printf("%s: unlink big failed\n", s);
     b0a:	85d6                	mv	a1,s5
     b0c:	00005517          	auipc	a0,0x5
     b10:	02c50513          	addi	a0,a0,44 # 5b38 <malloc+0x61a>
     b14:	157040ef          	jal	546a <printf>
    exit(1);
     b18:	4505                	li	a0,1
     b1a:	520040ef          	jal	503a <exit>

0000000000000b1e <unlinkread>:
{
     b1e:	7179                	addi	sp,sp,-48
     b20:	f406                	sd	ra,40(sp)
     b22:	f022                	sd	s0,32(sp)
     b24:	ec26                	sd	s1,24(sp)
     b26:	e84a                	sd	s2,16(sp)
     b28:	e44e                	sd	s3,8(sp)
     b2a:	1800                	addi	s0,sp,48
     b2c:	89aa                	mv	s3,a0
  fd = open("unlinkread", O_CREATE | O_RDWR);
     b2e:	20200593          	li	a1,514
     b32:	00005517          	auipc	a0,0x5
     b36:	01e50513          	addi	a0,a0,30 # 5b50 <malloc+0x632>
     b3a:	540040ef          	jal	507a <open>
  if (fd < 0) {
     b3e:	0a054f63          	bltz	a0,bfc <unlinkread+0xde>
     b42:	84aa                	mv	s1,a0
  write(fd, "hello", SZ);
     b44:	4615                	li	a2,5
     b46:	00005597          	auipc	a1,0x5
     b4a:	03a58593          	addi	a1,a1,58 # 5b80 <malloc+0x662>
     b4e:	50c040ef          	jal	505a <write>
  close(fd);
     b52:	8526                	mv	a0,s1
     b54:	50e040ef          	jal	5062 <close>
  fd = open("unlinkread", O_RDWR);
     b58:	4589                	li	a1,2
     b5a:	00005517          	auipc	a0,0x5
     b5e:	ff650513          	addi	a0,a0,-10 # 5b50 <malloc+0x632>
     b62:	518040ef          	jal	507a <open>
     b66:	84aa                	mv	s1,a0
  if (fd < 0) {
     b68:	0a054463          	bltz	a0,c10 <unlinkread+0xf2>
  if (unlink("unlinkread") != 0) {
     b6c:	00005517          	auipc	a0,0x5
     b70:	fe450513          	addi	a0,a0,-28 # 5b50 <malloc+0x632>
     b74:	516040ef          	jal	508a <unlink>
     b78:	e555                	bnez	a0,c24 <unlinkread+0x106>
  fd1 = open("unlinkread", O_CREATE | O_RDWR);
     b7a:	20200593          	li	a1,514
     b7e:	00005517          	auipc	a0,0x5
     b82:	fd250513          	addi	a0,a0,-46 # 5b50 <malloc+0x632>
     b86:	4f4040ef          	jal	507a <open>
     b8a:	892a                	mv	s2,a0
  write(fd1, "yyy", 3);
     b8c:	460d                	li	a2,3
     b8e:	00005597          	auipc	a1,0x5
     b92:	03a58593          	addi	a1,a1,58 # 5bc8 <malloc+0x6aa>
     b96:	4c4040ef          	jal	505a <write>
  close(fd1);
     b9a:	854a                	mv	a0,s2
     b9c:	4c6040ef          	jal	5062 <close>
  if (read(fd, buf, sizeof(buf)) != SZ) {
     ba0:	660d                	lui	a2,0x3
     ba2:	0000b597          	auipc	a1,0xb
     ba6:	12658593          	addi	a1,a1,294 # bcc8 <buf>
     baa:	8526                	mv	a0,s1
     bac:	4a6040ef          	jal	5052 <read>
     bb0:	4795                	li	a5,5
     bb2:	08f51363          	bne	a0,a5,c38 <unlinkread+0x11a>
  if (buf[0] != 'h') {
     bb6:	0000b717          	auipc	a4,0xb
     bba:	11274703          	lbu	a4,274(a4) # bcc8 <buf>
     bbe:	06800793          	li	a5,104
     bc2:	08f71563          	bne	a4,a5,c4c <unlinkread+0x12e>
  if (write(fd, buf, 10) != 10) {
     bc6:	4629                	li	a2,10
     bc8:	0000b597          	auipc	a1,0xb
     bcc:	10058593          	addi	a1,a1,256 # bcc8 <buf>
     bd0:	8526                	mv	a0,s1
     bd2:	488040ef          	jal	505a <write>
     bd6:	47a9                	li	a5,10
     bd8:	08f51463          	bne	a0,a5,c60 <unlinkread+0x142>
  close(fd);
     bdc:	8526                	mv	a0,s1
     bde:	484040ef          	jal	5062 <close>
  unlink("unlinkread");
     be2:	00005517          	auipc	a0,0x5
     be6:	f6e50513          	addi	a0,a0,-146 # 5b50 <malloc+0x632>
     bea:	4a0040ef          	jal	508a <unlink>
}
     bee:	70a2                	ld	ra,40(sp)
     bf0:	7402                	ld	s0,32(sp)
     bf2:	64e2                	ld	s1,24(sp)
     bf4:	6942                	ld	s2,16(sp)
     bf6:	69a2                	ld	s3,8(sp)
     bf8:	6145                	addi	sp,sp,48
     bfa:	8082                	ret
    printf("%s: create unlinkread failed\n", s);
     bfc:	85ce                	mv	a1,s3
     bfe:	00005517          	auipc	a0,0x5
     c02:	f6250513          	addi	a0,a0,-158 # 5b60 <malloc+0x642>
     c06:	065040ef          	jal	546a <printf>
    exit(1);
     c0a:	4505                	li	a0,1
     c0c:	42e040ef          	jal	503a <exit>
    printf("%s: open unlinkread failed\n", s);
     c10:	85ce                	mv	a1,s3
     c12:	00005517          	auipc	a0,0x5
     c16:	f7650513          	addi	a0,a0,-138 # 5b88 <malloc+0x66a>
     c1a:	051040ef          	jal	546a <printf>
    exit(1);
     c1e:	4505                	li	a0,1
     c20:	41a040ef          	jal	503a <exit>
    printf("%s: unlink unlinkread failed\n", s);
     c24:	85ce                	mv	a1,s3
     c26:	00005517          	auipc	a0,0x5
     c2a:	f8250513          	addi	a0,a0,-126 # 5ba8 <malloc+0x68a>
     c2e:	03d040ef          	jal	546a <printf>
    exit(1);
     c32:	4505                	li	a0,1
     c34:	406040ef          	jal	503a <exit>
    printf("%s: unlinkread read failed", s);
     c38:	85ce                	mv	a1,s3
     c3a:	00005517          	auipc	a0,0x5
     c3e:	f9650513          	addi	a0,a0,-106 # 5bd0 <malloc+0x6b2>
     c42:	029040ef          	jal	546a <printf>
    exit(1);
     c46:	4505                	li	a0,1
     c48:	3f2040ef          	jal	503a <exit>
    printf("%s: unlinkread wrong data\n", s);
     c4c:	85ce                	mv	a1,s3
     c4e:	00005517          	auipc	a0,0x5
     c52:	fa250513          	addi	a0,a0,-94 # 5bf0 <malloc+0x6d2>
     c56:	015040ef          	jal	546a <printf>
    exit(1);
     c5a:	4505                	li	a0,1
     c5c:	3de040ef          	jal	503a <exit>
    printf("%s: unlinkread write failed\n", s);
     c60:	85ce                	mv	a1,s3
     c62:	00005517          	auipc	a0,0x5
     c66:	fae50513          	addi	a0,a0,-82 # 5c10 <malloc+0x6f2>
     c6a:	001040ef          	jal	546a <printf>
    exit(1);
     c6e:	4505                	li	a0,1
     c70:	3ca040ef          	jal	503a <exit>

0000000000000c74 <linktest>:
{
     c74:	1101                	addi	sp,sp,-32
     c76:	ec06                	sd	ra,24(sp)
     c78:	e822                	sd	s0,16(sp)
     c7a:	e426                	sd	s1,8(sp)
     c7c:	e04a                	sd	s2,0(sp)
     c7e:	1000                	addi	s0,sp,32
     c80:	892a                	mv	s2,a0
  unlink("lf1");
     c82:	00005517          	auipc	a0,0x5
     c86:	fae50513          	addi	a0,a0,-82 # 5c30 <malloc+0x712>
     c8a:	400040ef          	jal	508a <unlink>
  unlink("lf2");
     c8e:	00005517          	auipc	a0,0x5
     c92:	faa50513          	addi	a0,a0,-86 # 5c38 <malloc+0x71a>
     c96:	3f4040ef          	jal	508a <unlink>
  fd = open("lf1", O_CREATE | O_RDWR);
     c9a:	20200593          	li	a1,514
     c9e:	00005517          	auipc	a0,0x5
     ca2:	f9250513          	addi	a0,a0,-110 # 5c30 <malloc+0x712>
     ca6:	3d4040ef          	jal	507a <open>
  if (fd < 0) {
     caa:	0c054f63          	bltz	a0,d88 <linktest+0x114>
     cae:	84aa                	mv	s1,a0
  if (write(fd, "hello", SZ) != SZ) {
     cb0:	4615                	li	a2,5
     cb2:	00005597          	auipc	a1,0x5
     cb6:	ece58593          	addi	a1,a1,-306 # 5b80 <malloc+0x662>
     cba:	3a0040ef          	jal	505a <write>
     cbe:	4795                	li	a5,5
     cc0:	0cf51e63          	bne	a0,a5,d9c <linktest+0x128>
  close(fd);
     cc4:	8526                	mv	a0,s1
     cc6:	39c040ef          	jal	5062 <close>
  if (link("lf1", "lf2") < 0) {
     cca:	00005597          	auipc	a1,0x5
     cce:	f6e58593          	addi	a1,a1,-146 # 5c38 <malloc+0x71a>
     cd2:	00005517          	auipc	a0,0x5
     cd6:	f5e50513          	addi	a0,a0,-162 # 5c30 <malloc+0x712>
     cda:	3c0040ef          	jal	509a <link>
     cde:	0c054963          	bltz	a0,db0 <linktest+0x13c>
  unlink("lf1");
     ce2:	00005517          	auipc	a0,0x5
     ce6:	f4e50513          	addi	a0,a0,-178 # 5c30 <malloc+0x712>
     cea:	3a0040ef          	jal	508a <unlink>
  if (open("lf1", 0) >= 0) {
     cee:	4581                	li	a1,0
     cf0:	00005517          	auipc	a0,0x5
     cf4:	f4050513          	addi	a0,a0,-192 # 5c30 <malloc+0x712>
     cf8:	382040ef          	jal	507a <open>
     cfc:	0c055463          	bgez	a0,dc4 <linktest+0x150>
  fd = open("lf2", 0);
     d00:	4581                	li	a1,0
     d02:	00005517          	auipc	a0,0x5
     d06:	f3650513          	addi	a0,a0,-202 # 5c38 <malloc+0x71a>
     d0a:	370040ef          	jal	507a <open>
     d0e:	84aa                	mv	s1,a0
  if (fd < 0) {
     d10:	0c054463          	bltz	a0,dd8 <linktest+0x164>
  if (read(fd, buf, sizeof(buf)) != SZ) {
     d14:	660d                	lui	a2,0x3
     d16:	0000b597          	auipc	a1,0xb
     d1a:	fb258593          	addi	a1,a1,-78 # bcc8 <buf>
     d1e:	334040ef          	jal	5052 <read>
     d22:	4795                	li	a5,5
     d24:	0cf51463          	bne	a0,a5,dec <linktest+0x178>
  close(fd);
     d28:	8526                	mv	a0,s1
     d2a:	338040ef          	jal	5062 <close>
  if (link("lf2", "lf2") >= 0) {
     d2e:	00005597          	auipc	a1,0x5
     d32:	f0a58593          	addi	a1,a1,-246 # 5c38 <malloc+0x71a>
     d36:	852e                	mv	a0,a1
     d38:	362040ef          	jal	509a <link>
     d3c:	0c055263          	bgez	a0,e00 <linktest+0x18c>
  unlink("lf2");
     d40:	00005517          	auipc	a0,0x5
     d44:	ef850513          	addi	a0,a0,-264 # 5c38 <malloc+0x71a>
     d48:	342040ef          	jal	508a <unlink>
  if (link("lf2", "lf1") >= 0) {
     d4c:	00005597          	auipc	a1,0x5
     d50:	ee458593          	addi	a1,a1,-284 # 5c30 <malloc+0x712>
     d54:	00005517          	auipc	a0,0x5
     d58:	ee450513          	addi	a0,a0,-284 # 5c38 <malloc+0x71a>
     d5c:	33e040ef          	jal	509a <link>
     d60:	0a055a63          	bgez	a0,e14 <linktest+0x1a0>
  if (link(".", "lf1") >= 0) {
     d64:	00005597          	auipc	a1,0x5
     d68:	ecc58593          	addi	a1,a1,-308 # 5c30 <malloc+0x712>
     d6c:	00005517          	auipc	a0,0x5
     d70:	fd450513          	addi	a0,a0,-44 # 5d40 <malloc+0x822>
     d74:	326040ef          	jal	509a <link>
     d78:	0a055863          	bgez	a0,e28 <linktest+0x1b4>
}
     d7c:	60e2                	ld	ra,24(sp)
     d7e:	6442                	ld	s0,16(sp)
     d80:	64a2                	ld	s1,8(sp)
     d82:	6902                	ld	s2,0(sp)
     d84:	6105                	addi	sp,sp,32
     d86:	8082                	ret
    printf("%s: create lf1 failed\n", s);
     d88:	85ca                	mv	a1,s2
     d8a:	00005517          	auipc	a0,0x5
     d8e:	eb650513          	addi	a0,a0,-330 # 5c40 <malloc+0x722>
     d92:	6d8040ef          	jal	546a <printf>
    exit(1);
     d96:	4505                	li	a0,1
     d98:	2a2040ef          	jal	503a <exit>
    printf("%s: write lf1 failed\n", s);
     d9c:	85ca                	mv	a1,s2
     d9e:	00005517          	auipc	a0,0x5
     da2:	eba50513          	addi	a0,a0,-326 # 5c58 <malloc+0x73a>
     da6:	6c4040ef          	jal	546a <printf>
    exit(1);
     daa:	4505                	li	a0,1
     dac:	28e040ef          	jal	503a <exit>
    printf("%s: link lf1 lf2 failed\n", s);
     db0:	85ca                	mv	a1,s2
     db2:	00005517          	auipc	a0,0x5
     db6:	ebe50513          	addi	a0,a0,-322 # 5c70 <malloc+0x752>
     dba:	6b0040ef          	jal	546a <printf>
    exit(1);
     dbe:	4505                	li	a0,1
     dc0:	27a040ef          	jal	503a <exit>
    printf("%s: unlinked lf1 but it is still there!\n", s);
     dc4:	85ca                	mv	a1,s2
     dc6:	00005517          	auipc	a0,0x5
     dca:	eca50513          	addi	a0,a0,-310 # 5c90 <malloc+0x772>
     dce:	69c040ef          	jal	546a <printf>
    exit(1);
     dd2:	4505                	li	a0,1
     dd4:	266040ef          	jal	503a <exit>
    printf("%s: open lf2 failed\n", s);
     dd8:	85ca                	mv	a1,s2
     dda:	00005517          	auipc	a0,0x5
     dde:	ee650513          	addi	a0,a0,-282 # 5cc0 <malloc+0x7a2>
     de2:	688040ef          	jal	546a <printf>
    exit(1);
     de6:	4505                	li	a0,1
     de8:	252040ef          	jal	503a <exit>
    printf("%s: read lf2 failed\n", s);
     dec:	85ca                	mv	a1,s2
     dee:	00005517          	auipc	a0,0x5
     df2:	eea50513          	addi	a0,a0,-278 # 5cd8 <malloc+0x7ba>
     df6:	674040ef          	jal	546a <printf>
    exit(1);
     dfa:	4505                	li	a0,1
     dfc:	23e040ef          	jal	503a <exit>
    printf("%s: link lf2 lf2 succeeded! oops\n", s);
     e00:	85ca                	mv	a1,s2
     e02:	00005517          	auipc	a0,0x5
     e06:	eee50513          	addi	a0,a0,-274 # 5cf0 <malloc+0x7d2>
     e0a:	660040ef          	jal	546a <printf>
    exit(1);
     e0e:	4505                	li	a0,1
     e10:	22a040ef          	jal	503a <exit>
    printf("%s: link non-existent succeeded! oops\n", s);
     e14:	85ca                	mv	a1,s2
     e16:	00005517          	auipc	a0,0x5
     e1a:	f0250513          	addi	a0,a0,-254 # 5d18 <malloc+0x7fa>
     e1e:	64c040ef          	jal	546a <printf>
    exit(1);
     e22:	4505                	li	a0,1
     e24:	216040ef          	jal	503a <exit>
    printf("%s: link . lf1 succeeded! oops\n", s);
     e28:	85ca                	mv	a1,s2
     e2a:	00005517          	auipc	a0,0x5
     e2e:	f1e50513          	addi	a0,a0,-226 # 5d48 <malloc+0x82a>
     e32:	638040ef          	jal	546a <printf>
    exit(1);
     e36:	4505                	li	a0,1
     e38:	202040ef          	jal	503a <exit>

0000000000000e3c <validatetest>:
{
     e3c:	7139                	addi	sp,sp,-64
     e3e:	fc06                	sd	ra,56(sp)
     e40:	f822                	sd	s0,48(sp)
     e42:	f426                	sd	s1,40(sp)
     e44:	f04a                	sd	s2,32(sp)
     e46:	ec4e                	sd	s3,24(sp)
     e48:	e852                	sd	s4,16(sp)
     e4a:	e456                	sd	s5,8(sp)
     e4c:	e05a                	sd	s6,0(sp)
     e4e:	0080                	addi	s0,sp,64
     e50:	8b2a                	mv	s6,a0
  for (p = 0; p <= (uint)hi; p += PGSIZE) {
     e52:	4481                	li	s1,0
    if (link("nosuchfile", (char *)p) != -1) {
     e54:	00005997          	auipc	s3,0x5
     e58:	f1498993          	addi	s3,s3,-236 # 5d68 <malloc+0x84a>
     e5c:	597d                	li	s2,-1
  for (p = 0; p <= (uint)hi; p += PGSIZE) {
     e5e:	6a85                	lui	s5,0x1
     e60:	00114a37          	lui	s4,0x114
    if (link("nosuchfile", (char *)p) != -1) {
     e64:	85a6                	mv	a1,s1
     e66:	854e                	mv	a0,s3
     e68:	232040ef          	jal	509a <link>
     e6c:	01251f63          	bne	a0,s2,e8a <validatetest+0x4e>
  for (p = 0; p <= (uint)hi; p += PGSIZE) {
     e70:	94d6                	add	s1,s1,s5
     e72:	ff4499e3          	bne	s1,s4,e64 <validatetest+0x28>
}
     e76:	70e2                	ld	ra,56(sp)
     e78:	7442                	ld	s0,48(sp)
     e7a:	74a2                	ld	s1,40(sp)
     e7c:	7902                	ld	s2,32(sp)
     e7e:	69e2                	ld	s3,24(sp)
     e80:	6a42                	ld	s4,16(sp)
     e82:	6aa2                	ld	s5,8(sp)
     e84:	6b02                	ld	s6,0(sp)
     e86:	6121                	addi	sp,sp,64
     e88:	8082                	ret
      printf("%s: link should not succeed\n", s);
     e8a:	85da                	mv	a1,s6
     e8c:	00005517          	auipc	a0,0x5
     e90:	eec50513          	addi	a0,a0,-276 # 5d78 <malloc+0x85a>
     e94:	5d6040ef          	jal	546a <printf>
      exit(1);
     e98:	4505                	li	a0,1
     e9a:	1a0040ef          	jal	503a <exit>

0000000000000e9e <bigdir>:
{
     e9e:	715d                	addi	sp,sp,-80
     ea0:	e486                	sd	ra,72(sp)
     ea2:	e0a2                	sd	s0,64(sp)
     ea4:	fc26                	sd	s1,56(sp)
     ea6:	f84a                	sd	s2,48(sp)
     ea8:	f44e                	sd	s3,40(sp)
     eaa:	f052                	sd	s4,32(sp)
     eac:	ec56                	sd	s5,24(sp)
     eae:	e85a                	sd	s6,16(sp)
     eb0:	0880                	addi	s0,sp,80
     eb2:	89aa                	mv	s3,a0
  unlink("bd");
     eb4:	00005517          	auipc	a0,0x5
     eb8:	ee450513          	addi	a0,a0,-284 # 5d98 <malloc+0x87a>
     ebc:	1ce040ef          	jal	508a <unlink>
  fd = open("bd", O_CREATE);
     ec0:	20000593          	li	a1,512
     ec4:	00005517          	auipc	a0,0x5
     ec8:	ed450513          	addi	a0,a0,-300 # 5d98 <malloc+0x87a>
     ecc:	1ae040ef          	jal	507a <open>
  if (fd < 0) {
     ed0:	0c054163          	bltz	a0,f92 <bigdir+0xf4>
  close(fd);
     ed4:	18e040ef          	jal	5062 <close>
  for (i = 0; i < N; i++) {
     ed8:	4901                	li	s2,0
    name[0] = 'x';
     eda:	07800a93          	li	s5,120
    if (link("bd", name) != 0) {
     ede:	00005a17          	auipc	s4,0x5
     ee2:	ebaa0a13          	addi	s4,s4,-326 # 5d98 <malloc+0x87a>
  for (i = 0; i < N; i++) {
     ee6:	1f400b13          	li	s6,500
    name[0] = 'x';
     eea:	fb540823          	sb	s5,-80(s0)
    name[1] = '0' + (i / 64);
     eee:	41f9571b          	sraiw	a4,s2,0x1f
     ef2:	01a7571b          	srliw	a4,a4,0x1a
     ef6:	012707bb          	addw	a5,a4,s2
     efa:	4067d69b          	sraiw	a3,a5,0x6
     efe:	0306869b          	addiw	a3,a3,48
     f02:	fad408a3          	sb	a3,-79(s0)
    name[2] = '0' + (i % 64);
     f06:	03f7f793          	andi	a5,a5,63
     f0a:	9f99                	subw	a5,a5,a4
     f0c:	0307879b          	addiw	a5,a5,48
     f10:	faf40923          	sb	a5,-78(s0)
    name[3] = '\0';
     f14:	fa0409a3          	sb	zero,-77(s0)
    if (link("bd", name) != 0) {
     f18:	fb040593          	addi	a1,s0,-80
     f1c:	8552                	mv	a0,s4
     f1e:	17c040ef          	jal	509a <link>
     f22:	84aa                	mv	s1,a0
     f24:	e149                	bnez	a0,fa6 <bigdir+0x108>
  for (i = 0; i < N; i++) {
     f26:	2905                	addiw	s2,s2,1
     f28:	fd6911e3          	bne	s2,s6,eea <bigdir+0x4c>
  unlink("bd");
     f2c:	00005517          	auipc	a0,0x5
     f30:	e6c50513          	addi	a0,a0,-404 # 5d98 <malloc+0x87a>
     f34:	156040ef          	jal	508a <unlink>
    name[0] = 'x';
     f38:	07800913          	li	s2,120
  for (i = 0; i < N; i++) {
     f3c:	1f400a13          	li	s4,500
    name[0] = 'x';
     f40:	fb240823          	sb	s2,-80(s0)
    name[1] = '0' + (i / 64);
     f44:	41f4d71b          	sraiw	a4,s1,0x1f
     f48:	01a7571b          	srliw	a4,a4,0x1a
     f4c:	009707bb          	addw	a5,a4,s1
     f50:	4067d69b          	sraiw	a3,a5,0x6
     f54:	0306869b          	addiw	a3,a3,48
     f58:	fad408a3          	sb	a3,-79(s0)
    name[2] = '0' + (i % 64);
     f5c:	03f7f793          	andi	a5,a5,63
     f60:	9f99                	subw	a5,a5,a4
     f62:	0307879b          	addiw	a5,a5,48
     f66:	faf40923          	sb	a5,-78(s0)
    name[3] = '\0';
     f6a:	fa0409a3          	sb	zero,-77(s0)
    if (unlink(name) != 0) {
     f6e:	fb040513          	addi	a0,s0,-80
     f72:	118040ef          	jal	508a <unlink>
     f76:	e529                	bnez	a0,fc0 <bigdir+0x122>
  for (i = 0; i < N; i++) {
     f78:	2485                	addiw	s1,s1,1
     f7a:	fd4493e3          	bne	s1,s4,f40 <bigdir+0xa2>
}
     f7e:	60a6                	ld	ra,72(sp)
     f80:	6406                	ld	s0,64(sp)
     f82:	74e2                	ld	s1,56(sp)
     f84:	7942                	ld	s2,48(sp)
     f86:	79a2                	ld	s3,40(sp)
     f88:	7a02                	ld	s4,32(sp)
     f8a:	6ae2                	ld	s5,24(sp)
     f8c:	6b42                	ld	s6,16(sp)
     f8e:	6161                	addi	sp,sp,80
     f90:	8082                	ret
    printf("%s: bigdir create failed\n", s);
     f92:	85ce                	mv	a1,s3
     f94:	00005517          	auipc	a0,0x5
     f98:	e0c50513          	addi	a0,a0,-500 # 5da0 <malloc+0x882>
     f9c:	4ce040ef          	jal	546a <printf>
    exit(1);
     fa0:	4505                	li	a0,1
     fa2:	098040ef          	jal	503a <exit>
      printf("%s: bigdir i=%d link(bd, %s) failed\n", s, i, name);
     fa6:	fb040693          	addi	a3,s0,-80
     faa:	864a                	mv	a2,s2
     fac:	85ce                	mv	a1,s3
     fae:	00005517          	auipc	a0,0x5
     fb2:	e1250513          	addi	a0,a0,-494 # 5dc0 <malloc+0x8a2>
     fb6:	4b4040ef          	jal	546a <printf>
      exit(1);
     fba:	4505                	li	a0,1
     fbc:	07e040ef          	jal	503a <exit>
      printf("%s: bigdir unlink failed", s);
     fc0:	85ce                	mv	a1,s3
     fc2:	00005517          	auipc	a0,0x5
     fc6:	e2650513          	addi	a0,a0,-474 # 5de8 <malloc+0x8ca>
     fca:	4a0040ef          	jal	546a <printf>
      exit(1);
     fce:	4505                	li	a0,1
     fd0:	06a040ef          	jal	503a <exit>

0000000000000fd4 <pgbug>:
{
     fd4:	7179                	addi	sp,sp,-48
     fd6:	f406                	sd	ra,40(sp)
     fd8:	f022                	sd	s0,32(sp)
     fda:	ec26                	sd	s1,24(sp)
     fdc:	1800                	addi	s0,sp,48
  argv[0] = 0;
     fde:	fc043c23          	sd	zero,-40(s0)
  exec(big, argv);
     fe2:	00007497          	auipc	s1,0x7
     fe6:	01e48493          	addi	s1,s1,30 # 8000 <big>
     fea:	fd840593          	addi	a1,s0,-40
     fee:	6088                	ld	a0,0(s1)
     ff0:	082040ef          	jal	5072 <exec>
  pipe(big);
     ff4:	6088                	ld	a0,0(s1)
     ff6:	054040ef          	jal	504a <pipe>
  exit(0);
     ffa:	4501                	li	a0,0
     ffc:	03e040ef          	jal	503a <exit>

0000000000001000 <badarg>:
{
    1000:	7139                	addi	sp,sp,-64
    1002:	fc06                	sd	ra,56(sp)
    1004:	f822                	sd	s0,48(sp)
    1006:	f426                	sd	s1,40(sp)
    1008:	f04a                	sd	s2,32(sp)
    100a:	ec4e                	sd	s3,24(sp)
    100c:	0080                	addi	s0,sp,64
    100e:	64b1                	lui	s1,0xc
    1010:	35048493          	addi	s1,s1,848 # c350 <buf+0x688>
    argv[0] = (char *)0xffffffff;
    1014:	597d                	li	s2,-1
    1016:	02095913          	srli	s2,s2,0x20
    exec("echo", argv);
    101a:	00004997          	auipc	s3,0x4
    101e:	63e98993          	addi	s3,s3,1598 # 5658 <malloc+0x13a>
    argv[0] = (char *)0xffffffff;
    1022:	fd243023          	sd	s2,-64(s0)
    argv[1] = 0;
    1026:	fc043423          	sd	zero,-56(s0)
    exec("echo", argv);
    102a:	fc040593          	addi	a1,s0,-64
    102e:	854e                	mv	a0,s3
    1030:	042040ef          	jal	5072 <exec>
  for (int i = 0; i < 50000; i++) {
    1034:	34fd                	addiw	s1,s1,-1
    1036:	f4f5                	bnez	s1,1022 <badarg+0x22>
  exit(0);
    1038:	4501                	li	a0,0
    103a:	000040ef          	jal	503a <exit>

000000000000103e <copyinstr2>:
{
    103e:	7155                	addi	sp,sp,-208
    1040:	e586                	sd	ra,200(sp)
    1042:	e1a2                	sd	s0,192(sp)
    1044:	0980                	addi	s0,sp,208
  for (int i = 0; i < MAXPATH; i++)
    1046:	f6840793          	addi	a5,s0,-152
    104a:	fe840693          	addi	a3,s0,-24
    b[i] = 'x';
    104e:	07800713          	li	a4,120
    1052:	00e78023          	sb	a4,0(a5)
  for (int i = 0; i < MAXPATH; i++)
    1056:	0785                	addi	a5,a5,1
    1058:	fed79de3          	bne	a5,a3,1052 <copyinstr2+0x14>
  b[MAXPATH] = '\0';
    105c:	fe040423          	sb	zero,-24(s0)
  int ret = unlink(b);
    1060:	f6840513          	addi	a0,s0,-152
    1064:	026040ef          	jal	508a <unlink>
  if (ret != -1) {
    1068:	57fd                	li	a5,-1
    106a:	0cf51263          	bne	a0,a5,112e <copyinstr2+0xf0>
  int fd = open(b, O_CREATE | O_WRONLY);
    106e:	20100593          	li	a1,513
    1072:	f6840513          	addi	a0,s0,-152
    1076:	004040ef          	jal	507a <open>
  if (fd != -1) {
    107a:	57fd                	li	a5,-1
    107c:	0cf51563          	bne	a0,a5,1146 <copyinstr2+0x108>
  ret = link(b, b);
    1080:	f6840593          	addi	a1,s0,-152
    1084:	852e                	mv	a0,a1
    1086:	014040ef          	jal	509a <link>
  if (ret != -1) {
    108a:	57fd                	li	a5,-1
    108c:	0cf51963          	bne	a0,a5,115e <copyinstr2+0x120>
  char *args[] = {"xx", 0};
    1090:	00006797          	auipc	a5,0x6
    1094:	e4078793          	addi	a5,a5,-448 # 6ed0 <malloc+0x19b2>
    1098:	f4f43c23          	sd	a5,-168(s0)
    109c:	f6043023          	sd	zero,-160(s0)
  ret = exec(b, args);
    10a0:	f5840593          	addi	a1,s0,-168
    10a4:	f6840513          	addi	a0,s0,-152
    10a8:	7cb030ef          	jal	5072 <exec>
  if (ret != -1) {
    10ac:	57fd                	li	a5,-1
    10ae:	0cf51563          	bne	a0,a5,1178 <copyinstr2+0x13a>
  int pid = fork();
    10b2:	781030ef          	jal	5032 <fork>
  if (pid < 0) {
    10b6:	0c054d63          	bltz	a0,1190 <copyinstr2+0x152>
  if (pid == 0) {
    10ba:	0e051863          	bnez	a0,11aa <copyinstr2+0x16c>
    10be:	00007797          	auipc	a5,0x7
    10c2:	4f278793          	addi	a5,a5,1266 # 85b0 <big.0>
    10c6:	00008697          	auipc	a3,0x8
    10ca:	4ea68693          	addi	a3,a3,1258 # 95b0 <big.0+0x1000>
      big[i] = 'x';
    10ce:	07800713          	li	a4,120
    10d2:	00e78023          	sb	a4,0(a5)
    for (int i = 0; i < PGSIZE; i++)
    10d6:	0785                	addi	a5,a5,1
    10d8:	fed79de3          	bne	a5,a3,10d2 <copyinstr2+0x94>
    big[PGSIZE] = '\0';
    10dc:	00008797          	auipc	a5,0x8
    10e0:	4c078a23          	sb	zero,1236(a5) # 95b0 <big.0+0x1000>
    char *args2[] = {big, big, big, 0};
    10e4:	00007797          	auipc	a5,0x7
    10e8:	c2c78793          	addi	a5,a5,-980 # 7d10 <malloc+0x27f2>
    10ec:	6fb0                	ld	a2,88(a5)
    10ee:	73b4                	ld	a3,96(a5)
    10f0:	77b8                	ld	a4,104(a5)
    10f2:	7bbc                	ld	a5,112(a5)
    10f4:	f2c43823          	sd	a2,-208(s0)
    10f8:	f2d43c23          	sd	a3,-200(s0)
    10fc:	f4e43023          	sd	a4,-192(s0)
    1100:	f4f43423          	sd	a5,-184(s0)
    ret = exec("echo", args2);
    1104:	f3040593          	addi	a1,s0,-208
    1108:	00004517          	auipc	a0,0x4
    110c:	55050513          	addi	a0,a0,1360 # 5658 <malloc+0x13a>
    1110:	763030ef          	jal	5072 <exec>
    if (ret != -1) {
    1114:	57fd                	li	a5,-1
    1116:	08f50663          	beq	a0,a5,11a2 <copyinstr2+0x164>
      printf("exec(echo, BIG) returned %d, not -1\n", fd);
    111a:	55fd                	li	a1,-1
    111c:	00005517          	auipc	a0,0x5
    1120:	d7450513          	addi	a0,a0,-652 # 5e90 <malloc+0x972>
    1124:	346040ef          	jal	546a <printf>
      exit(1);
    1128:	4505                	li	a0,1
    112a:	711030ef          	jal	503a <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    112e:	862a                	mv	a2,a0
    1130:	f6840593          	addi	a1,s0,-152
    1134:	00005517          	auipc	a0,0x5
    1138:	cd450513          	addi	a0,a0,-812 # 5e08 <malloc+0x8ea>
    113c:	32e040ef          	jal	546a <printf>
    exit(1);
    1140:	4505                	li	a0,1
    1142:	6f9030ef          	jal	503a <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    1146:	862a                	mv	a2,a0
    1148:	f6840593          	addi	a1,s0,-152
    114c:	00005517          	auipc	a0,0x5
    1150:	cdc50513          	addi	a0,a0,-804 # 5e28 <malloc+0x90a>
    1154:	316040ef          	jal	546a <printf>
    exit(1);
    1158:	4505                	li	a0,1
    115a:	6e1030ef          	jal	503a <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    115e:	86aa                	mv	a3,a0
    1160:	f6840613          	addi	a2,s0,-152
    1164:	85b2                	mv	a1,a2
    1166:	00005517          	auipc	a0,0x5
    116a:	ce250513          	addi	a0,a0,-798 # 5e48 <malloc+0x92a>
    116e:	2fc040ef          	jal	546a <printf>
    exit(1);
    1172:	4505                	li	a0,1
    1174:	6c7030ef          	jal	503a <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    1178:	567d                	li	a2,-1
    117a:	f6840593          	addi	a1,s0,-152
    117e:	00005517          	auipc	a0,0x5
    1182:	cf250513          	addi	a0,a0,-782 # 5e70 <malloc+0x952>
    1186:	2e4040ef          	jal	546a <printf>
    exit(1);
    118a:	4505                	li	a0,1
    118c:	6af030ef          	jal	503a <exit>
    printf("fork failed\n");
    1190:	00006517          	auipc	a0,0x6
    1194:	33050513          	addi	a0,a0,816 # 74c0 <malloc+0x1fa2>
    1198:	2d2040ef          	jal	546a <printf>
    exit(1);
    119c:	4505                	li	a0,1
    119e:	69d030ef          	jal	503a <exit>
    exit(747); // OK
    11a2:	2eb00513          	li	a0,747
    11a6:	695030ef          	jal	503a <exit>
  int st = 0;
    11aa:	f4042a23          	sw	zero,-172(s0)
  wait(&st);
    11ae:	f5440513          	addi	a0,s0,-172
    11b2:	691030ef          	jal	5042 <wait>
  if (st != 747) {
    11b6:	f5442703          	lw	a4,-172(s0)
    11ba:	2eb00793          	li	a5,747
    11be:	00f71663          	bne	a4,a5,11ca <copyinstr2+0x18c>
}
    11c2:	60ae                	ld	ra,200(sp)
    11c4:	640e                	ld	s0,192(sp)
    11c6:	6169                	addi	sp,sp,208
    11c8:	8082                	ret
    printf("exec(echo, BIG) succeeded, should have failed\n");
    11ca:	00005517          	auipc	a0,0x5
    11ce:	cee50513          	addi	a0,a0,-786 # 5eb8 <malloc+0x99a>
    11d2:	298040ef          	jal	546a <printf>
    exit(1);
    11d6:	4505                	li	a0,1
    11d8:	663030ef          	jal	503a <exit>

00000000000011dc <truncate3>:
{
    11dc:	7159                	addi	sp,sp,-112
    11de:	f486                	sd	ra,104(sp)
    11e0:	f0a2                	sd	s0,96(sp)
    11e2:	e8ca                	sd	s2,80(sp)
    11e4:	1880                	addi	s0,sp,112
    11e6:	892a                	mv	s2,a0
  close(open("truncfile", O_CREATE | O_TRUNC | O_WRONLY));
    11e8:	60100593          	li	a1,1537
    11ec:	00004517          	auipc	a0,0x4
    11f0:	4c450513          	addi	a0,a0,1220 # 56b0 <malloc+0x192>
    11f4:	687030ef          	jal	507a <open>
    11f8:	66b030ef          	jal	5062 <close>
  pid = fork();
    11fc:	637030ef          	jal	5032 <fork>
  if (pid < 0) {
    1200:	06054663          	bltz	a0,126c <truncate3+0x90>
  if (pid == 0) {
    1204:	e55d                	bnez	a0,12b2 <truncate3+0xd6>
    1206:	eca6                	sd	s1,88(sp)
    1208:	e4ce                	sd	s3,72(sp)
    120a:	e0d2                	sd	s4,64(sp)
    120c:	fc56                	sd	s5,56(sp)
    120e:	06400993          	li	s3,100
      int fd = open("truncfile", O_WRONLY);
    1212:	00004a17          	auipc	s4,0x4
    1216:	49ea0a13          	addi	s4,s4,1182 # 56b0 <malloc+0x192>
      int n = write(fd, "1234567890", 10);
    121a:	00005a97          	auipc	s5,0x5
    121e:	cfea8a93          	addi	s5,s5,-770 # 5f18 <malloc+0x9fa>
      int fd = open("truncfile", O_WRONLY);
    1222:	4585                	li	a1,1
    1224:	8552                	mv	a0,s4
    1226:	655030ef          	jal	507a <open>
    122a:	84aa                	mv	s1,a0
      if (fd < 0) {
    122c:	04054e63          	bltz	a0,1288 <truncate3+0xac>
      int n = write(fd, "1234567890", 10);
    1230:	4629                	li	a2,10
    1232:	85d6                	mv	a1,s5
    1234:	627030ef          	jal	505a <write>
      if (n != 10) {
    1238:	47a9                	li	a5,10
    123a:	06f51163          	bne	a0,a5,129c <truncate3+0xc0>
      close(fd);
    123e:	8526                	mv	a0,s1
    1240:	623030ef          	jal	5062 <close>
      fd = open("truncfile", O_RDONLY);
    1244:	4581                	li	a1,0
    1246:	8552                	mv	a0,s4
    1248:	633030ef          	jal	507a <open>
    124c:	84aa                	mv	s1,a0
      read(fd, buf, sizeof(buf));
    124e:	02000613          	li	a2,32
    1252:	f9840593          	addi	a1,s0,-104
    1256:	5fd030ef          	jal	5052 <read>
      close(fd);
    125a:	8526                	mv	a0,s1
    125c:	607030ef          	jal	5062 <close>
    for (int i = 0; i < 100; i++) {
    1260:	39fd                	addiw	s3,s3,-1
    1262:	fc0990e3          	bnez	s3,1222 <truncate3+0x46>
    exit(0);
    1266:	4501                	li	a0,0
    1268:	5d3030ef          	jal	503a <exit>
    126c:	eca6                	sd	s1,88(sp)
    126e:	e4ce                	sd	s3,72(sp)
    1270:	e0d2                	sd	s4,64(sp)
    1272:	fc56                	sd	s5,56(sp)
    printf("%s: fork failed\n", s);
    1274:	85ca                	mv	a1,s2
    1276:	00005517          	auipc	a0,0x5
    127a:	c7250513          	addi	a0,a0,-910 # 5ee8 <malloc+0x9ca>
    127e:	1ec040ef          	jal	546a <printf>
    exit(1);
    1282:	4505                	li	a0,1
    1284:	5b7030ef          	jal	503a <exit>
        printf("%s: open failed\n", s);
    1288:	85ca                	mv	a1,s2
    128a:	00005517          	auipc	a0,0x5
    128e:	c7650513          	addi	a0,a0,-906 # 5f00 <malloc+0x9e2>
    1292:	1d8040ef          	jal	546a <printf>
        exit(1);
    1296:	4505                	li	a0,1
    1298:	5a3030ef          	jal	503a <exit>
        printf("%s: write got %d, expected 10\n", s, n);
    129c:	862a                	mv	a2,a0
    129e:	85ca                	mv	a1,s2
    12a0:	00005517          	auipc	a0,0x5
    12a4:	c8850513          	addi	a0,a0,-888 # 5f28 <malloc+0xa0a>
    12a8:	1c2040ef          	jal	546a <printf>
        exit(1);
    12ac:	4505                	li	a0,1
    12ae:	58d030ef          	jal	503a <exit>
    12b2:	eca6                	sd	s1,88(sp)
    12b4:	e4ce                	sd	s3,72(sp)
    12b6:	e0d2                	sd	s4,64(sp)
    12b8:	fc56                	sd	s5,56(sp)
    12ba:	09600993          	li	s3,150
    int fd = open("truncfile", O_CREATE | O_WRONLY | O_TRUNC);
    12be:	00004a17          	auipc	s4,0x4
    12c2:	3f2a0a13          	addi	s4,s4,1010 # 56b0 <malloc+0x192>
    int n = write(fd, "xxx", 3);
    12c6:	00005a97          	auipc	s5,0x5
    12ca:	c82a8a93          	addi	s5,s5,-894 # 5f48 <malloc+0xa2a>
    int fd = open("truncfile", O_CREATE | O_WRONLY | O_TRUNC);
    12ce:	60100593          	li	a1,1537
    12d2:	8552                	mv	a0,s4
    12d4:	5a7030ef          	jal	507a <open>
    12d8:	84aa                	mv	s1,a0
    if (fd < 0) {
    12da:	02054d63          	bltz	a0,1314 <truncate3+0x138>
    int n = write(fd, "xxx", 3);
    12de:	460d                	li	a2,3
    12e0:	85d6                	mv	a1,s5
    12e2:	579030ef          	jal	505a <write>
    if (n != 3) {
    12e6:	478d                	li	a5,3
    12e8:	04f51063          	bne	a0,a5,1328 <truncate3+0x14c>
    close(fd);
    12ec:	8526                	mv	a0,s1
    12ee:	575030ef          	jal	5062 <close>
  for (int i = 0; i < 150; i++) {
    12f2:	39fd                	addiw	s3,s3,-1
    12f4:	fc099de3          	bnez	s3,12ce <truncate3+0xf2>
  wait(&xstatus);
    12f8:	fbc40513          	addi	a0,s0,-68
    12fc:	547030ef          	jal	5042 <wait>
  unlink("truncfile");
    1300:	00004517          	auipc	a0,0x4
    1304:	3b050513          	addi	a0,a0,944 # 56b0 <malloc+0x192>
    1308:	583030ef          	jal	508a <unlink>
  exit(xstatus);
    130c:	fbc42503          	lw	a0,-68(s0)
    1310:	52b030ef          	jal	503a <exit>
      printf("%s: open failed\n", s);
    1314:	85ca                	mv	a1,s2
    1316:	00005517          	auipc	a0,0x5
    131a:	bea50513          	addi	a0,a0,-1046 # 5f00 <malloc+0x9e2>
    131e:	14c040ef          	jal	546a <printf>
      exit(1);
    1322:	4505                	li	a0,1
    1324:	517030ef          	jal	503a <exit>
      printf("%s: write got %d, expected 3\n", s, n);
    1328:	862a                	mv	a2,a0
    132a:	85ca                	mv	a1,s2
    132c:	00005517          	auipc	a0,0x5
    1330:	c2450513          	addi	a0,a0,-988 # 5f50 <malloc+0xa32>
    1334:	136040ef          	jal	546a <printf>
      exit(1);
    1338:	4505                	li	a0,1
    133a:	501030ef          	jal	503a <exit>

000000000000133e <pipe1>:
{
    133e:	711d                	addi	sp,sp,-96
    1340:	ec86                	sd	ra,88(sp)
    1342:	e8a2                	sd	s0,80(sp)
    1344:	fc4e                	sd	s3,56(sp)
    1346:	1080                	addi	s0,sp,96
    1348:	89aa                	mv	s3,a0
  if (pipe(fds) != 0) {
    134a:	fa840513          	addi	a0,s0,-88
    134e:	4fd030ef          	jal	504a <pipe>
    1352:	e92d                	bnez	a0,13c4 <pipe1+0x86>
    1354:	e4a6                	sd	s1,72(sp)
    1356:	f852                	sd	s4,48(sp)
    1358:	84aa                	mv	s1,a0
  pid = fork();
    135a:	4d9030ef          	jal	5032 <fork>
    135e:	8a2a                	mv	s4,a0
  if (pid == 0) {
    1360:	c151                	beqz	a0,13e4 <pipe1+0xa6>
  } else if (pid > 0) {
    1362:	14a05e63          	blez	a0,14be <pipe1+0x180>
    1366:	e0ca                	sd	s2,64(sp)
    1368:	f456                	sd	s5,40(sp)
    close(fds[1]);
    136a:	fac42503          	lw	a0,-84(s0)
    136e:	4f5030ef          	jal	5062 <close>
    total = 0;
    1372:	8a26                	mv	s4,s1
    cc = 1;
    1374:	4905                	li	s2,1
    while ((n = read(fds[0], buf, cc)) > 0) {
    1376:	0000ba97          	auipc	s5,0xb
    137a:	952a8a93          	addi	s5,s5,-1710 # bcc8 <buf>
    137e:	864a                	mv	a2,s2
    1380:	85d6                	mv	a1,s5
    1382:	fa842503          	lw	a0,-88(s0)
    1386:	4cd030ef          	jal	5052 <read>
    138a:	0ea05a63          	blez	a0,147e <pipe1+0x140>
      for (i = 0; i < n; i++) {
    138e:	0000b717          	auipc	a4,0xb
    1392:	93a70713          	addi	a4,a4,-1734 # bcc8 <buf>
    1396:	00a4863b          	addw	a2,s1,a0
        if ((buf[i] & 0xff) != (seq++ & 0xff)) {
    139a:	00074683          	lbu	a3,0(a4)
    139e:	0ff4f793          	zext.b	a5,s1
    13a2:	2485                	addiw	s1,s1,1
    13a4:	0af69d63          	bne	a3,a5,145e <pipe1+0x120>
      for (i = 0; i < n; i++) {
    13a8:	0705                	addi	a4,a4,1
    13aa:	fec498e3          	bne	s1,a2,139a <pipe1+0x5c>
      total += n;
    13ae:	00aa0a3b          	addw	s4,s4,a0
      cc = cc * 2;
    13b2:	0019179b          	slliw	a5,s2,0x1
    13b6:	0007891b          	sext.w	s2,a5
      if (cc > sizeof(buf))
    13ba:	670d                	lui	a4,0x3
    13bc:	fd2771e3          	bgeu	a4,s2,137e <pipe1+0x40>
        cc = sizeof(buf);
    13c0:	690d                	lui	s2,0x3
    13c2:	bf75                	j	137e <pipe1+0x40>
    13c4:	e4a6                	sd	s1,72(sp)
    13c6:	e0ca                	sd	s2,64(sp)
    13c8:	f852                	sd	s4,48(sp)
    13ca:	f456                	sd	s5,40(sp)
    13cc:	f05a                	sd	s6,32(sp)
    13ce:	ec5e                	sd	s7,24(sp)
    printf("%s: pipe() failed\n", s);
    13d0:	85ce                	mv	a1,s3
    13d2:	00005517          	auipc	a0,0x5
    13d6:	b9e50513          	addi	a0,a0,-1122 # 5f70 <malloc+0xa52>
    13da:	090040ef          	jal	546a <printf>
    exit(1);
    13de:	4505                	li	a0,1
    13e0:	45b030ef          	jal	503a <exit>
    13e4:	e0ca                	sd	s2,64(sp)
    13e6:	f456                	sd	s5,40(sp)
    13e8:	f05a                	sd	s6,32(sp)
    13ea:	ec5e                	sd	s7,24(sp)
    close(fds[0]);
    13ec:	fa842503          	lw	a0,-88(s0)
    13f0:	473030ef          	jal	5062 <close>
    for (n = 0; n < N; n++) {
    13f4:	0000bb17          	auipc	s6,0xb
    13f8:	8d4b0b13          	addi	s6,s6,-1836 # bcc8 <buf>
    13fc:	416004bb          	negw	s1,s6
    1400:	0ff4f493          	zext.b	s1,s1
    1404:	409b0913          	addi	s2,s6,1033
      if (write(fds[1], buf, SZ) != SZ) {
    1408:	8bda                	mv	s7,s6
    for (n = 0; n < N; n++) {
    140a:	6a85                	lui	s5,0x1
    140c:	42da8a93          	addi	s5,s5,1069 # 142d <pipe1+0xef>
{
    1410:	87da                	mv	a5,s6
        buf[i] = seq++;
    1412:	0097873b          	addw	a4,a5,s1
    1416:	00e78023          	sb	a4,0(a5)
      for (i = 0; i < SZ; i++)
    141a:	0785                	addi	a5,a5,1
    141c:	ff279be3          	bne	a5,s2,1412 <pipe1+0xd4>
    1420:	409a0a1b          	addiw	s4,s4,1033
      if (write(fds[1], buf, SZ) != SZ) {
    1424:	40900613          	li	a2,1033
    1428:	85de                	mv	a1,s7
    142a:	fac42503          	lw	a0,-84(s0)
    142e:	42d030ef          	jal	505a <write>
    1432:	40900793          	li	a5,1033
    1436:	00f51a63          	bne	a0,a5,144a <pipe1+0x10c>
    for (n = 0; n < N; n++) {
    143a:	24a5                	addiw	s1,s1,9
    143c:	0ff4f493          	zext.b	s1,s1
    1440:	fd5a18e3          	bne	s4,s5,1410 <pipe1+0xd2>
    exit(0);
    1444:	4501                	li	a0,0
    1446:	3f5030ef          	jal	503a <exit>
        printf("%s: pipe1 oops 1\n", s);
    144a:	85ce                	mv	a1,s3
    144c:	00005517          	auipc	a0,0x5
    1450:	b3c50513          	addi	a0,a0,-1220 # 5f88 <malloc+0xa6a>
    1454:	016040ef          	jal	546a <printf>
        exit(1);
    1458:	4505                	li	a0,1
    145a:	3e1030ef          	jal	503a <exit>
          printf("%s: pipe1 oops 2\n", s);
    145e:	85ce                	mv	a1,s3
    1460:	00005517          	auipc	a0,0x5
    1464:	b4050513          	addi	a0,a0,-1216 # 5fa0 <malloc+0xa82>
    1468:	002040ef          	jal	546a <printf>
          return;
    146c:	64a6                	ld	s1,72(sp)
    146e:	6906                	ld	s2,64(sp)
    1470:	7a42                	ld	s4,48(sp)
    1472:	7aa2                	ld	s5,40(sp)
}
    1474:	60e6                	ld	ra,88(sp)
    1476:	6446                	ld	s0,80(sp)
    1478:	79e2                	ld	s3,56(sp)
    147a:	6125                	addi	sp,sp,96
    147c:	8082                	ret
    if (total != N * SZ) {
    147e:	6785                	lui	a5,0x1
    1480:	42d78793          	addi	a5,a5,1069 # 142d <pipe1+0xef>
    1484:	00fa0f63          	beq	s4,a5,14a2 <pipe1+0x164>
    1488:	f05a                	sd	s6,32(sp)
    148a:	ec5e                	sd	s7,24(sp)
      printf("%s: pipe1 oops 3 total %d\n", s, total);
    148c:	8652                	mv	a2,s4
    148e:	85ce                	mv	a1,s3
    1490:	00005517          	auipc	a0,0x5
    1494:	b2850513          	addi	a0,a0,-1240 # 5fb8 <malloc+0xa9a>
    1498:	7d3030ef          	jal	546a <printf>
      exit(1);
    149c:	4505                	li	a0,1
    149e:	39d030ef          	jal	503a <exit>
    14a2:	f05a                	sd	s6,32(sp)
    14a4:	ec5e                	sd	s7,24(sp)
    close(fds[0]);
    14a6:	fa842503          	lw	a0,-88(s0)
    14aa:	3b9030ef          	jal	5062 <close>
    wait(&xstatus);
    14ae:	fa440513          	addi	a0,s0,-92
    14b2:	391030ef          	jal	5042 <wait>
    exit(xstatus);
    14b6:	fa442503          	lw	a0,-92(s0)
    14ba:	381030ef          	jal	503a <exit>
    14be:	e0ca                	sd	s2,64(sp)
    14c0:	f456                	sd	s5,40(sp)
    14c2:	f05a                	sd	s6,32(sp)
    14c4:	ec5e                	sd	s7,24(sp)
    printf("%s: fork() failed\n", s);
    14c6:	85ce                	mv	a1,s3
    14c8:	00005517          	auipc	a0,0x5
    14cc:	b1050513          	addi	a0,a0,-1264 # 5fd8 <malloc+0xaba>
    14d0:	79b030ef          	jal	546a <printf>
    exit(1);
    14d4:	4505                	li	a0,1
    14d6:	365030ef          	jal	503a <exit>

00000000000014da <exitwait>:
{
    14da:	7139                	addi	sp,sp,-64
    14dc:	fc06                	sd	ra,56(sp)
    14de:	f822                	sd	s0,48(sp)
    14e0:	f426                	sd	s1,40(sp)
    14e2:	f04a                	sd	s2,32(sp)
    14e4:	ec4e                	sd	s3,24(sp)
    14e6:	e852                	sd	s4,16(sp)
    14e8:	0080                	addi	s0,sp,64
    14ea:	8a2a                	mv	s4,a0
  for (i = 0; i < 100; i++) {
    14ec:	4901                	li	s2,0
    14ee:	06400993          	li	s3,100
    pid = fork();
    14f2:	341030ef          	jal	5032 <fork>
    14f6:	84aa                	mv	s1,a0
    if (pid < 0) {
    14f8:	02054863          	bltz	a0,1528 <exitwait+0x4e>
    if (pid) {
    14fc:	c525                	beqz	a0,1564 <exitwait+0x8a>
      if (wait(&xstate) != pid) {
    14fe:	fcc40513          	addi	a0,s0,-52
    1502:	341030ef          	jal	5042 <wait>
    1506:	02951b63          	bne	a0,s1,153c <exitwait+0x62>
      if (i != xstate) {
    150a:	fcc42783          	lw	a5,-52(s0)
    150e:	05279163          	bne	a5,s2,1550 <exitwait+0x76>
  for (i = 0; i < 100; i++) {
    1512:	2905                	addiw	s2,s2,1 # 3001 <subdir+0x5b5>
    1514:	fd391fe3          	bne	s2,s3,14f2 <exitwait+0x18>
}
    1518:	70e2                	ld	ra,56(sp)
    151a:	7442                	ld	s0,48(sp)
    151c:	74a2                	ld	s1,40(sp)
    151e:	7902                	ld	s2,32(sp)
    1520:	69e2                	ld	s3,24(sp)
    1522:	6a42                	ld	s4,16(sp)
    1524:	6121                	addi	sp,sp,64
    1526:	8082                	ret
      printf("%s: fork failed\n", s);
    1528:	85d2                	mv	a1,s4
    152a:	00005517          	auipc	a0,0x5
    152e:	9be50513          	addi	a0,a0,-1602 # 5ee8 <malloc+0x9ca>
    1532:	739030ef          	jal	546a <printf>
      exit(1);
    1536:	4505                	li	a0,1
    1538:	303030ef          	jal	503a <exit>
        printf("%s: wait wrong pid\n", s);
    153c:	85d2                	mv	a1,s4
    153e:	00005517          	auipc	a0,0x5
    1542:	ab250513          	addi	a0,a0,-1358 # 5ff0 <malloc+0xad2>
    1546:	725030ef          	jal	546a <printf>
        exit(1);
    154a:	4505                	li	a0,1
    154c:	2ef030ef          	jal	503a <exit>
        printf("%s: wait wrong exit status\n", s);
    1550:	85d2                	mv	a1,s4
    1552:	00005517          	auipc	a0,0x5
    1556:	ab650513          	addi	a0,a0,-1354 # 6008 <malloc+0xaea>
    155a:	711030ef          	jal	546a <printf>
        exit(1);
    155e:	4505                	li	a0,1
    1560:	2db030ef          	jal	503a <exit>
      exit(i);
    1564:	854a                	mv	a0,s2
    1566:	2d5030ef          	jal	503a <exit>

000000000000156a <twochildren>:
{
    156a:	1101                	addi	sp,sp,-32
    156c:	ec06                	sd	ra,24(sp)
    156e:	e822                	sd	s0,16(sp)
    1570:	e426                	sd	s1,8(sp)
    1572:	e04a                	sd	s2,0(sp)
    1574:	1000                	addi	s0,sp,32
    1576:	892a                	mv	s2,a0
    1578:	3e800493          	li	s1,1000
    int pid1 = fork();
    157c:	2b7030ef          	jal	5032 <fork>
    if (pid1 < 0) {
    1580:	02054663          	bltz	a0,15ac <twochildren+0x42>
    if (pid1 == 0) {
    1584:	cd15                	beqz	a0,15c0 <twochildren+0x56>
      int pid2 = fork();
    1586:	2ad030ef          	jal	5032 <fork>
      if (pid2 < 0) {
    158a:	02054d63          	bltz	a0,15c4 <twochildren+0x5a>
      if (pid2 == 0) {
    158e:	c529                	beqz	a0,15d8 <twochildren+0x6e>
        wait(0);
    1590:	4501                	li	a0,0
    1592:	2b1030ef          	jal	5042 <wait>
        wait(0);
    1596:	4501                	li	a0,0
    1598:	2ab030ef          	jal	5042 <wait>
  for (int i = 0; i < 1000; i++) {
    159c:	34fd                	addiw	s1,s1,-1
    159e:	fcf9                	bnez	s1,157c <twochildren+0x12>
}
    15a0:	60e2                	ld	ra,24(sp)
    15a2:	6442                	ld	s0,16(sp)
    15a4:	64a2                	ld	s1,8(sp)
    15a6:	6902                	ld	s2,0(sp)
    15a8:	6105                	addi	sp,sp,32
    15aa:	8082                	ret
      printf("%s: fork failed\n", s);
    15ac:	85ca                	mv	a1,s2
    15ae:	00005517          	auipc	a0,0x5
    15b2:	93a50513          	addi	a0,a0,-1734 # 5ee8 <malloc+0x9ca>
    15b6:	6b5030ef          	jal	546a <printf>
      exit(1);
    15ba:	4505                	li	a0,1
    15bc:	27f030ef          	jal	503a <exit>
      exit(0);
    15c0:	27b030ef          	jal	503a <exit>
        printf("%s: fork failed\n", s);
    15c4:	85ca                	mv	a1,s2
    15c6:	00005517          	auipc	a0,0x5
    15ca:	92250513          	addi	a0,a0,-1758 # 5ee8 <malloc+0x9ca>
    15ce:	69d030ef          	jal	546a <printf>
        exit(1);
    15d2:	4505                	li	a0,1
    15d4:	267030ef          	jal	503a <exit>
        exit(0);
    15d8:	263030ef          	jal	503a <exit>

00000000000015dc <forkfork>:
{
    15dc:	7179                	addi	sp,sp,-48
    15de:	f406                	sd	ra,40(sp)
    15e0:	f022                	sd	s0,32(sp)
    15e2:	ec26                	sd	s1,24(sp)
    15e4:	1800                	addi	s0,sp,48
    15e6:	84aa                	mv	s1,a0
    int pid = fork();
    15e8:	24b030ef          	jal	5032 <fork>
    if (pid < 0) {
    15ec:	02054b63          	bltz	a0,1622 <forkfork+0x46>
    if (pid == 0) {
    15f0:	c139                	beqz	a0,1636 <forkfork+0x5a>
    int pid = fork();
    15f2:	241030ef          	jal	5032 <fork>
    if (pid < 0) {
    15f6:	02054663          	bltz	a0,1622 <forkfork+0x46>
    if (pid == 0) {
    15fa:	cd15                	beqz	a0,1636 <forkfork+0x5a>
    wait(&xstatus);
    15fc:	fdc40513          	addi	a0,s0,-36
    1600:	243030ef          	jal	5042 <wait>
    if (xstatus != 0) {
    1604:	fdc42783          	lw	a5,-36(s0)
    1608:	ebb9                	bnez	a5,165e <forkfork+0x82>
    wait(&xstatus);
    160a:	fdc40513          	addi	a0,s0,-36
    160e:	235030ef          	jal	5042 <wait>
    if (xstatus != 0) {
    1612:	fdc42783          	lw	a5,-36(s0)
    1616:	e7a1                	bnez	a5,165e <forkfork+0x82>
}
    1618:	70a2                	ld	ra,40(sp)
    161a:	7402                	ld	s0,32(sp)
    161c:	64e2                	ld	s1,24(sp)
    161e:	6145                	addi	sp,sp,48
    1620:	8082                	ret
      printf("%s: fork failed", s);
    1622:	85a6                	mv	a1,s1
    1624:	00005517          	auipc	a0,0x5
    1628:	a0450513          	addi	a0,a0,-1532 # 6028 <malloc+0xb0a>
    162c:	63f030ef          	jal	546a <printf>
      exit(1);
    1630:	4505                	li	a0,1
    1632:	209030ef          	jal	503a <exit>
{
    1636:	0c800493          	li	s1,200
        int pid1 = fork();
    163a:	1f9030ef          	jal	5032 <fork>
        if (pid1 < 0) {
    163e:	00054b63          	bltz	a0,1654 <forkfork+0x78>
        if (pid1 == 0) {
    1642:	cd01                	beqz	a0,165a <forkfork+0x7e>
        wait(0);
    1644:	4501                	li	a0,0
    1646:	1fd030ef          	jal	5042 <wait>
      for (int j = 0; j < 200; j++) {
    164a:	34fd                	addiw	s1,s1,-1
    164c:	f4fd                	bnez	s1,163a <forkfork+0x5e>
      exit(0);
    164e:	4501                	li	a0,0
    1650:	1eb030ef          	jal	503a <exit>
          exit(1);
    1654:	4505                	li	a0,1
    1656:	1e5030ef          	jal	503a <exit>
          exit(0);
    165a:	1e1030ef          	jal	503a <exit>
      printf("%s: fork in child failed", s);
    165e:	85a6                	mv	a1,s1
    1660:	00005517          	auipc	a0,0x5
    1664:	9d850513          	addi	a0,a0,-1576 # 6038 <malloc+0xb1a>
    1668:	603030ef          	jal	546a <printf>
      exit(1);
    166c:	4505                	li	a0,1
    166e:	1cd030ef          	jal	503a <exit>

0000000000001672 <reparent2>:
{
    1672:	1101                	addi	sp,sp,-32
    1674:	ec06                	sd	ra,24(sp)
    1676:	e822                	sd	s0,16(sp)
    1678:	e426                	sd	s1,8(sp)
    167a:	1000                	addi	s0,sp,32
    167c:	32000493          	li	s1,800
    int pid1 = fork();
    1680:	1b3030ef          	jal	5032 <fork>
    if (pid1 < 0) {
    1684:	00054b63          	bltz	a0,169a <reparent2+0x28>
    if (pid1 == 0) {
    1688:	c115                	beqz	a0,16ac <reparent2+0x3a>
    wait(0);
    168a:	4501                	li	a0,0
    168c:	1b7030ef          	jal	5042 <wait>
  for (int i = 0; i < 800; i++) {
    1690:	34fd                	addiw	s1,s1,-1
    1692:	f4fd                	bnez	s1,1680 <reparent2+0xe>
  exit(0);
    1694:	4501                	li	a0,0
    1696:	1a5030ef          	jal	503a <exit>
      printf("fork failed\n");
    169a:	00006517          	auipc	a0,0x6
    169e:	e2650513          	addi	a0,a0,-474 # 74c0 <malloc+0x1fa2>
    16a2:	5c9030ef          	jal	546a <printf>
      exit(1);
    16a6:	4505                	li	a0,1
    16a8:	193030ef          	jal	503a <exit>
      fork();
    16ac:	187030ef          	jal	5032 <fork>
      fork();
    16b0:	183030ef          	jal	5032 <fork>
      exit(0);
    16b4:	4501                	li	a0,0
    16b6:	185030ef          	jal	503a <exit>

00000000000016ba <createdelete>:
{
    16ba:	7175                	addi	sp,sp,-144
    16bc:	e506                	sd	ra,136(sp)
    16be:	e122                	sd	s0,128(sp)
    16c0:	fca6                	sd	s1,120(sp)
    16c2:	f8ca                	sd	s2,112(sp)
    16c4:	f4ce                	sd	s3,104(sp)
    16c6:	f0d2                	sd	s4,96(sp)
    16c8:	ecd6                	sd	s5,88(sp)
    16ca:	e8da                	sd	s6,80(sp)
    16cc:	e4de                	sd	s7,72(sp)
    16ce:	e0e2                	sd	s8,64(sp)
    16d0:	fc66                	sd	s9,56(sp)
    16d2:	0900                	addi	s0,sp,144
    16d4:	8caa                	mv	s9,a0
  for (pi = 0; pi < NCHILD; pi++) {
    16d6:	4901                	li	s2,0
    16d8:	4991                	li	s3,4
    pid = fork();
    16da:	159030ef          	jal	5032 <fork>
    16de:	84aa                	mv	s1,a0
    if (pid < 0) {
    16e0:	02054d63          	bltz	a0,171a <createdelete+0x60>
    if (pid == 0) {
    16e4:	c529                	beqz	a0,172e <createdelete+0x74>
  for (pi = 0; pi < NCHILD; pi++) {
    16e6:	2905                	addiw	s2,s2,1
    16e8:	ff3919e3          	bne	s2,s3,16da <createdelete+0x20>
    16ec:	4491                	li	s1,4
    wait(&xstatus);
    16ee:	f7c40513          	addi	a0,s0,-132
    16f2:	151030ef          	jal	5042 <wait>
    if (xstatus != 0)
    16f6:	f7c42903          	lw	s2,-132(s0)
    16fa:	0a091e63          	bnez	s2,17b6 <createdelete+0xfc>
  for (pi = 0; pi < NCHILD; pi++) {
    16fe:	34fd                	addiw	s1,s1,-1
    1700:	f4fd                	bnez	s1,16ee <createdelete+0x34>
  name[0] = name[1] = name[2] = 0;
    1702:	f8040123          	sb	zero,-126(s0)
    1706:	03000993          	li	s3,48
    170a:	5a7d                	li	s4,-1
    170c:	07000c13          	li	s8,112
      if ((i == 0 || i >= N / 2) && fd < 0) {
    1710:	4b25                	li	s6,9
      } else if ((i >= 1 && i < N / 2) && fd >= 0) {
    1712:	4ba1                	li	s7,8
    for (pi = 0; pi < NCHILD; pi++) {
    1714:	07400a93          	li	s5,116
    1718:	aa39                	j	1836 <createdelete+0x17c>
      printf("%s: fork failed\n", s);
    171a:	85e6                	mv	a1,s9
    171c:	00004517          	auipc	a0,0x4
    1720:	7cc50513          	addi	a0,a0,1996 # 5ee8 <malloc+0x9ca>
    1724:	547030ef          	jal	546a <printf>
      exit(1);
    1728:	4505                	li	a0,1
    172a:	111030ef          	jal	503a <exit>
      name[0] = 'p' + pi;
    172e:	0709091b          	addiw	s2,s2,112
    1732:	f9240023          	sb	s2,-128(s0)
      name[2] = '\0';
    1736:	f8040123          	sb	zero,-126(s0)
      for (i = 0; i < N; i++) {
    173a:	4951                	li	s2,20
    173c:	a831                	j	1758 <createdelete+0x9e>
          printf("%s: create failed\n", s);
    173e:	85e6                	mv	a1,s9
    1740:	00005517          	auipc	a0,0x5
    1744:	91850513          	addi	a0,a0,-1768 # 6058 <malloc+0xb3a>
    1748:	523030ef          	jal	546a <printf>
          exit(1);
    174c:	4505                	li	a0,1
    174e:	0ed030ef          	jal	503a <exit>
      for (i = 0; i < N; i++) {
    1752:	2485                	addiw	s1,s1,1
    1754:	05248e63          	beq	s1,s2,17b0 <createdelete+0xf6>
        name[1] = '0' + i;
    1758:	0304879b          	addiw	a5,s1,48
    175c:	f8f400a3          	sb	a5,-127(s0)
        fd = open(name, O_CREATE | O_RDWR);
    1760:	20200593          	li	a1,514
    1764:	f8040513          	addi	a0,s0,-128
    1768:	113030ef          	jal	507a <open>
        if (fd < 0) {
    176c:	fc0549e3          	bltz	a0,173e <createdelete+0x84>
        close(fd);
    1770:	0f3030ef          	jal	5062 <close>
        if (i > 0 && (i % 2) == 0) {
    1774:	10905063          	blez	s1,1874 <createdelete+0x1ba>
    1778:	0014f793          	andi	a5,s1,1
    177c:	fbf9                	bnez	a5,1752 <createdelete+0x98>
          name[1] = '0' + (i / 2);
    177e:	01f4d79b          	srliw	a5,s1,0x1f
    1782:	9fa5                	addw	a5,a5,s1
    1784:	4017d79b          	sraiw	a5,a5,0x1
    1788:	0307879b          	addiw	a5,a5,48
    178c:	f8f400a3          	sb	a5,-127(s0)
          if (unlink(name) < 0) {
    1790:	f8040513          	addi	a0,s0,-128
    1794:	0f7030ef          	jal	508a <unlink>
    1798:	fa055de3          	bgez	a0,1752 <createdelete+0x98>
            printf("%s: unlink failed\n", s);
    179c:	85e6                	mv	a1,s9
    179e:	00005517          	auipc	a0,0x5
    17a2:	8d250513          	addi	a0,a0,-1838 # 6070 <malloc+0xb52>
    17a6:	4c5030ef          	jal	546a <printf>
            exit(1);
    17aa:	4505                	li	a0,1
    17ac:	08f030ef          	jal	503a <exit>
      exit(0);
    17b0:	4501                	li	a0,0
    17b2:	089030ef          	jal	503a <exit>
      exit(1);
    17b6:	4505                	li	a0,1
    17b8:	083030ef          	jal	503a <exit>
        printf("%s: oops createdelete %s didn't exist\n", s, name);
    17bc:	f8040613          	addi	a2,s0,-128
    17c0:	85e6                	mv	a1,s9
    17c2:	00005517          	auipc	a0,0x5
    17c6:	8c650513          	addi	a0,a0,-1850 # 6088 <malloc+0xb6a>
    17ca:	4a1030ef          	jal	546a <printf>
        exit(1);
    17ce:	4505                	li	a0,1
    17d0:	06b030ef          	jal	503a <exit>
      } else if ((i >= 1 && i < N / 2) && fd >= 0) {
    17d4:	034bfb63          	bgeu	s7,s4,180a <createdelete+0x150>
      if (fd >= 0)
    17d8:	02055663          	bgez	a0,1804 <createdelete+0x14a>
    for (pi = 0; pi < NCHILD; pi++) {
    17dc:	2485                	addiw	s1,s1,1
    17de:	0ff4f493          	zext.b	s1,s1
    17e2:	05548263          	beq	s1,s5,1826 <createdelete+0x16c>
      name[0] = 'p' + pi;
    17e6:	f8940023          	sb	s1,-128(s0)
      name[1] = '0' + i;
    17ea:	f93400a3          	sb	s3,-127(s0)
      fd = open(name, 0);
    17ee:	4581                	li	a1,0
    17f0:	f8040513          	addi	a0,s0,-128
    17f4:	087030ef          	jal	507a <open>
      if ((i == 0 || i >= N / 2) && fd < 0) {
    17f8:	00090463          	beqz	s2,1800 <createdelete+0x146>
    17fc:	fd2b5ce3          	bge	s6,s2,17d4 <createdelete+0x11a>
    1800:	fa054ee3          	bltz	a0,17bc <createdelete+0x102>
        close(fd);
    1804:	05f030ef          	jal	5062 <close>
    1808:	bfd1                	j	17dc <createdelete+0x122>
      } else if ((i >= 1 && i < N / 2) && fd >= 0) {
    180a:	fc0549e3          	bltz	a0,17dc <createdelete+0x122>
        printf("%s: oops createdelete %s did exist\n", s, name);
    180e:	f8040613          	addi	a2,s0,-128
    1812:	85e6                	mv	a1,s9
    1814:	00005517          	auipc	a0,0x5
    1818:	89c50513          	addi	a0,a0,-1892 # 60b0 <malloc+0xb92>
    181c:	44f030ef          	jal	546a <printf>
        exit(1);
    1820:	4505                	li	a0,1
    1822:	019030ef          	jal	503a <exit>
  for (i = 0; i < N; i++) {
    1826:	2905                	addiw	s2,s2,1
    1828:	2a05                	addiw	s4,s4,1
    182a:	2985                	addiw	s3,s3,1
    182c:	0ff9f993          	zext.b	s3,s3
    1830:	47d1                	li	a5,20
    1832:	02f90863          	beq	s2,a5,1862 <createdelete+0x1a8>
    for (pi = 0; pi < NCHILD; pi++) {
    1836:	84e2                	mv	s1,s8
    1838:	b77d                	j	17e6 <createdelete+0x12c>
  for (i = 0; i < N; i++) {
    183a:	2905                	addiw	s2,s2,1
    183c:	0ff97913          	zext.b	s2,s2
    1840:	03490c63          	beq	s2,s4,1878 <createdelete+0x1be>
  name[0] = name[1] = name[2] = 0;
    1844:	84d6                	mv	s1,s5
      name[0] = 'p' + pi;
    1846:	f8940023          	sb	s1,-128(s0)
      name[1] = '0' + i;
    184a:	f92400a3          	sb	s2,-127(s0)
      unlink(name);
    184e:	f8040513          	addi	a0,s0,-128
    1852:	039030ef          	jal	508a <unlink>
    for (pi = 0; pi < NCHILD; pi++) {
    1856:	2485                	addiw	s1,s1,1
    1858:	0ff4f493          	zext.b	s1,s1
    185c:	ff3495e3          	bne	s1,s3,1846 <createdelete+0x18c>
    1860:	bfe9                	j	183a <createdelete+0x180>
    1862:	03000913          	li	s2,48
  name[0] = name[1] = name[2] = 0;
    1866:	07000a93          	li	s5,112
    for (pi = 0; pi < NCHILD; pi++) {
    186a:	07400993          	li	s3,116
  for (i = 0; i < N; i++) {
    186e:	04400a13          	li	s4,68
    1872:	bfc9                	j	1844 <createdelete+0x18a>
      for (i = 0; i < N; i++) {
    1874:	2485                	addiw	s1,s1,1
    1876:	b5cd                	j	1758 <createdelete+0x9e>
}
    1878:	60aa                	ld	ra,136(sp)
    187a:	640a                	ld	s0,128(sp)
    187c:	74e6                	ld	s1,120(sp)
    187e:	7946                	ld	s2,112(sp)
    1880:	79a6                	ld	s3,104(sp)
    1882:	7a06                	ld	s4,96(sp)
    1884:	6ae6                	ld	s5,88(sp)
    1886:	6b46                	ld	s6,80(sp)
    1888:	6ba6                	ld	s7,72(sp)
    188a:	6c06                	ld	s8,64(sp)
    188c:	7ce2                	ld	s9,56(sp)
    188e:	6149                	addi	sp,sp,144
    1890:	8082                	ret

0000000000001892 <linkunlink>:
{
    1892:	711d                	addi	sp,sp,-96
    1894:	ec86                	sd	ra,88(sp)
    1896:	e8a2                	sd	s0,80(sp)
    1898:	e4a6                	sd	s1,72(sp)
    189a:	e0ca                	sd	s2,64(sp)
    189c:	fc4e                	sd	s3,56(sp)
    189e:	f852                	sd	s4,48(sp)
    18a0:	f456                	sd	s5,40(sp)
    18a2:	f05a                	sd	s6,32(sp)
    18a4:	ec5e                	sd	s7,24(sp)
    18a6:	e862                	sd	s8,16(sp)
    18a8:	e466                	sd	s9,8(sp)
    18aa:	1080                	addi	s0,sp,96
    18ac:	84aa                	mv	s1,a0
  unlink("x");
    18ae:	00004517          	auipc	a0,0x4
    18b2:	e1a50513          	addi	a0,a0,-486 # 56c8 <malloc+0x1aa>
    18b6:	7d4030ef          	jal	508a <unlink>
  pid = fork();
    18ba:	778030ef          	jal	5032 <fork>
  if (pid < 0) {
    18be:	02054b63          	bltz	a0,18f4 <linkunlink+0x62>
    18c2:	8caa                	mv	s9,a0
  unsigned int x = (pid ? 1 : 97);
    18c4:	06100913          	li	s2,97
    18c8:	c111                	beqz	a0,18cc <linkunlink+0x3a>
    18ca:	4905                	li	s2,1
    18cc:	06400493          	li	s1,100
    x = x * 1103515245 + 12345;
    18d0:	41c65a37          	lui	s4,0x41c65
    18d4:	e6da0a1b          	addiw	s4,s4,-403 # 41c64e6d <base+0x41c561a5>
    18d8:	698d                	lui	s3,0x3
    18da:	0399899b          	addiw	s3,s3,57 # 3039 <subdir+0x5ed>
    if ((x % 3) == 0) {
    18de:	4a8d                	li	s5,3
    } else if ((x % 3) == 1) {
    18e0:	4b85                	li	s7,1
      unlink("x");
    18e2:	00004b17          	auipc	s6,0x4
    18e6:	de6b0b13          	addi	s6,s6,-538 # 56c8 <malloc+0x1aa>
      link("cat", "x");
    18ea:	00004c17          	auipc	s8,0x4
    18ee:	7eec0c13          	addi	s8,s8,2030 # 60d8 <malloc+0xbba>
    18f2:	a025                	j	191a <linkunlink+0x88>
    printf("%s: fork failed\n", s);
    18f4:	85a6                	mv	a1,s1
    18f6:	00004517          	auipc	a0,0x4
    18fa:	5f250513          	addi	a0,a0,1522 # 5ee8 <malloc+0x9ca>
    18fe:	36d030ef          	jal	546a <printf>
    exit(1);
    1902:	4505                	li	a0,1
    1904:	736030ef          	jal	503a <exit>
      close(open("x", O_RDWR | O_CREATE));
    1908:	20200593          	li	a1,514
    190c:	855a                	mv	a0,s6
    190e:	76c030ef          	jal	507a <open>
    1912:	750030ef          	jal	5062 <close>
  for (i = 0; i < 100; i++) {
    1916:	34fd                	addiw	s1,s1,-1
    1918:	c495                	beqz	s1,1944 <linkunlink+0xb2>
    x = x * 1103515245 + 12345;
    191a:	034907bb          	mulw	a5,s2,s4
    191e:	013787bb          	addw	a5,a5,s3
    1922:	0007891b          	sext.w	s2,a5
    if ((x % 3) == 0) {
    1926:	0357f7bb          	remuw	a5,a5,s5
    192a:	2781                	sext.w	a5,a5
    192c:	dff1                	beqz	a5,1908 <linkunlink+0x76>
    } else if ((x % 3) == 1) {
    192e:	01778663          	beq	a5,s7,193a <linkunlink+0xa8>
      unlink("x");
    1932:	855a                	mv	a0,s6
    1934:	756030ef          	jal	508a <unlink>
    1938:	bff9                	j	1916 <linkunlink+0x84>
      link("cat", "x");
    193a:	85da                	mv	a1,s6
    193c:	8562                	mv	a0,s8
    193e:	75c030ef          	jal	509a <link>
    1942:	bfd1                	j	1916 <linkunlink+0x84>
  if (pid)
    1944:	020c8263          	beqz	s9,1968 <linkunlink+0xd6>
    wait(0);
    1948:	4501                	li	a0,0
    194a:	6f8030ef          	jal	5042 <wait>
}
    194e:	60e6                	ld	ra,88(sp)
    1950:	6446                	ld	s0,80(sp)
    1952:	64a6                	ld	s1,72(sp)
    1954:	6906                	ld	s2,64(sp)
    1956:	79e2                	ld	s3,56(sp)
    1958:	7a42                	ld	s4,48(sp)
    195a:	7aa2                	ld	s5,40(sp)
    195c:	7b02                	ld	s6,32(sp)
    195e:	6be2                	ld	s7,24(sp)
    1960:	6c42                	ld	s8,16(sp)
    1962:	6ca2                	ld	s9,8(sp)
    1964:	6125                	addi	sp,sp,96
    1966:	8082                	ret
    exit(0);
    1968:	4501                	li	a0,0
    196a:	6d0030ef          	jal	503a <exit>

000000000000196e <forktest>:
{
    196e:	7179                	addi	sp,sp,-48
    1970:	f406                	sd	ra,40(sp)
    1972:	f022                	sd	s0,32(sp)
    1974:	ec26                	sd	s1,24(sp)
    1976:	e84a                	sd	s2,16(sp)
    1978:	e44e                	sd	s3,8(sp)
    197a:	1800                	addi	s0,sp,48
    197c:	89aa                	mv	s3,a0
  for (n = 0; n < N; n++) {
    197e:	4481                	li	s1,0
    1980:	3e800913          	li	s2,1000
    pid = fork();
    1984:	6ae030ef          	jal	5032 <fork>
    if (pid < 0)
    1988:	06054063          	bltz	a0,19e8 <forktest+0x7a>
    if (pid == 0)
    198c:	cd11                	beqz	a0,19a8 <forktest+0x3a>
  for (n = 0; n < N; n++) {
    198e:	2485                	addiw	s1,s1,1
    1990:	ff249ae3          	bne	s1,s2,1984 <forktest+0x16>
    printf("%s: fork claimed to work 1000 times!\n", s);
    1994:	85ce                	mv	a1,s3
    1996:	00004517          	auipc	a0,0x4
    199a:	79250513          	addi	a0,a0,1938 # 6128 <malloc+0xc0a>
    199e:	2cd030ef          	jal	546a <printf>
    exit(1);
    19a2:	4505                	li	a0,1
    19a4:	696030ef          	jal	503a <exit>
      exit(0);
    19a8:	692030ef          	jal	503a <exit>
    printf("%s: no fork at all!\n", s);
    19ac:	85ce                	mv	a1,s3
    19ae:	00004517          	auipc	a0,0x4
    19b2:	73250513          	addi	a0,a0,1842 # 60e0 <malloc+0xbc2>
    19b6:	2b5030ef          	jal	546a <printf>
    exit(1);
    19ba:	4505                	li	a0,1
    19bc:	67e030ef          	jal	503a <exit>
      printf("%s: wait stopped early\n", s);
    19c0:	85ce                	mv	a1,s3
    19c2:	00004517          	auipc	a0,0x4
    19c6:	73650513          	addi	a0,a0,1846 # 60f8 <malloc+0xbda>
    19ca:	2a1030ef          	jal	546a <printf>
      exit(1);
    19ce:	4505                	li	a0,1
    19d0:	66a030ef          	jal	503a <exit>
    printf("%s: wait got too many\n", s);
    19d4:	85ce                	mv	a1,s3
    19d6:	00004517          	auipc	a0,0x4
    19da:	73a50513          	addi	a0,a0,1850 # 6110 <malloc+0xbf2>
    19de:	28d030ef          	jal	546a <printf>
    exit(1);
    19e2:	4505                	li	a0,1
    19e4:	656030ef          	jal	503a <exit>
  if (n == 0) {
    19e8:	d0f1                	beqz	s1,19ac <forktest+0x3e>
  for (; n > 0; n--) {
    19ea:	00905963          	blez	s1,19fc <forktest+0x8e>
    if (wait(0) < 0) {
    19ee:	4501                	li	a0,0
    19f0:	652030ef          	jal	5042 <wait>
    19f4:	fc0546e3          	bltz	a0,19c0 <forktest+0x52>
  for (; n > 0; n--) {
    19f8:	34fd                	addiw	s1,s1,-1
    19fa:	f8f5                	bnez	s1,19ee <forktest+0x80>
  if (wait(0) != -1) {
    19fc:	4501                	li	a0,0
    19fe:	644030ef          	jal	5042 <wait>
    1a02:	57fd                	li	a5,-1
    1a04:	fcf518e3          	bne	a0,a5,19d4 <forktest+0x66>
}
    1a08:	70a2                	ld	ra,40(sp)
    1a0a:	7402                	ld	s0,32(sp)
    1a0c:	64e2                	ld	s1,24(sp)
    1a0e:	6942                	ld	s2,16(sp)
    1a10:	69a2                	ld	s3,8(sp)
    1a12:	6145                	addi	sp,sp,48
    1a14:	8082                	ret

0000000000001a16 <kernmem>:
{
    1a16:	715d                	addi	sp,sp,-80
    1a18:	e486                	sd	ra,72(sp)
    1a1a:	e0a2                	sd	s0,64(sp)
    1a1c:	fc26                	sd	s1,56(sp)
    1a1e:	f84a                	sd	s2,48(sp)
    1a20:	f44e                	sd	s3,40(sp)
    1a22:	f052                	sd	s4,32(sp)
    1a24:	ec56                	sd	s5,24(sp)
    1a26:	0880                	addi	s0,sp,80
    1a28:	8aaa                	mv	s5,a0
  for (a = (char *)(KERNBASE); a < (char *)(KERNBASE + 2000000); a += 50000) {
    1a2a:	4485                	li	s1,1
    1a2c:	04fe                	slli	s1,s1,0x1f
    if (xstatus != -1) // did kernel kill child?
    1a2e:	5a7d                	li	s4,-1
  for (a = (char *)(KERNBASE); a < (char *)(KERNBASE + 2000000); a += 50000) {
    1a30:	69b1                	lui	s3,0xc
    1a32:	35098993          	addi	s3,s3,848 # c350 <buf+0x688>
    1a36:	1003d937          	lui	s2,0x1003d
    1a3a:	090e                	slli	s2,s2,0x3
    1a3c:	48090913          	addi	s2,s2,1152 # 1003d480 <base+0x1002e7b8>
    pid = fork();
    1a40:	5f2030ef          	jal	5032 <fork>
    if (pid < 0) {
    1a44:	02054763          	bltz	a0,1a72 <kernmem+0x5c>
    if (pid == 0) {
    1a48:	cd1d                	beqz	a0,1a86 <kernmem+0x70>
    wait(&xstatus);
    1a4a:	fbc40513          	addi	a0,s0,-68
    1a4e:	5f4030ef          	jal	5042 <wait>
    if (xstatus != -1) // did kernel kill child?
    1a52:	fbc42783          	lw	a5,-68(s0)
    1a56:	05479563          	bne	a5,s4,1aa0 <kernmem+0x8a>
  for (a = (char *)(KERNBASE); a < (char *)(KERNBASE + 2000000); a += 50000) {
    1a5a:	94ce                	add	s1,s1,s3
    1a5c:	ff2492e3          	bne	s1,s2,1a40 <kernmem+0x2a>
}
    1a60:	60a6                	ld	ra,72(sp)
    1a62:	6406                	ld	s0,64(sp)
    1a64:	74e2                	ld	s1,56(sp)
    1a66:	7942                	ld	s2,48(sp)
    1a68:	79a2                	ld	s3,40(sp)
    1a6a:	7a02                	ld	s4,32(sp)
    1a6c:	6ae2                	ld	s5,24(sp)
    1a6e:	6161                	addi	sp,sp,80
    1a70:	8082                	ret
      printf("%s: fork failed\n", s);
    1a72:	85d6                	mv	a1,s5
    1a74:	00004517          	auipc	a0,0x4
    1a78:	47450513          	addi	a0,a0,1140 # 5ee8 <malloc+0x9ca>
    1a7c:	1ef030ef          	jal	546a <printf>
      exit(1);
    1a80:	4505                	li	a0,1
    1a82:	5b8030ef          	jal	503a <exit>
      printf("%s: oops could read %p = %x\n", s, a, *a);
    1a86:	0004c683          	lbu	a3,0(s1)
    1a8a:	8626                	mv	a2,s1
    1a8c:	85d6                	mv	a1,s5
    1a8e:	00004517          	auipc	a0,0x4
    1a92:	6c250513          	addi	a0,a0,1730 # 6150 <malloc+0xc32>
    1a96:	1d5030ef          	jal	546a <printf>
      exit(1);
    1a9a:	4505                	li	a0,1
    1a9c:	59e030ef          	jal	503a <exit>
      exit(1);
    1aa0:	4505                	li	a0,1
    1aa2:	598030ef          	jal	503a <exit>

0000000000001aa6 <MAXVAplus>:
{
    1aa6:	7179                	addi	sp,sp,-48
    1aa8:	f406                	sd	ra,40(sp)
    1aaa:	f022                	sd	s0,32(sp)
    1aac:	1800                	addi	s0,sp,48
  volatile uint64 a = MAXVA;
    1aae:	4785                	li	a5,1
    1ab0:	179a                	slli	a5,a5,0x26
    1ab2:	fcf43c23          	sd	a5,-40(s0)
  for (; a != 0; a <<= 1) {
    1ab6:	fd843783          	ld	a5,-40(s0)
    1aba:	cf85                	beqz	a5,1af2 <MAXVAplus+0x4c>
    1abc:	ec26                	sd	s1,24(sp)
    1abe:	e84a                	sd	s2,16(sp)
    1ac0:	892a                	mv	s2,a0
    if (xstatus != -1) // did kernel kill child?
    1ac2:	54fd                	li	s1,-1
    pid = fork();
    1ac4:	56e030ef          	jal	5032 <fork>
    if (pid < 0) {
    1ac8:	02054963          	bltz	a0,1afa <MAXVAplus+0x54>
    if (pid == 0) {
    1acc:	c129                	beqz	a0,1b0e <MAXVAplus+0x68>
    wait(&xstatus);
    1ace:	fd440513          	addi	a0,s0,-44
    1ad2:	570030ef          	jal	5042 <wait>
    if (xstatus != -1) // did kernel kill child?
    1ad6:	fd442783          	lw	a5,-44(s0)
    1ada:	04979c63          	bne	a5,s1,1b32 <MAXVAplus+0x8c>
  for (; a != 0; a <<= 1) {
    1ade:	fd843783          	ld	a5,-40(s0)
    1ae2:	0786                	slli	a5,a5,0x1
    1ae4:	fcf43c23          	sd	a5,-40(s0)
    1ae8:	fd843783          	ld	a5,-40(s0)
    1aec:	ffe1                	bnez	a5,1ac4 <MAXVAplus+0x1e>
    1aee:	64e2                	ld	s1,24(sp)
    1af0:	6942                	ld	s2,16(sp)
}
    1af2:	70a2                	ld	ra,40(sp)
    1af4:	7402                	ld	s0,32(sp)
    1af6:	6145                	addi	sp,sp,48
    1af8:	8082                	ret
      printf("%s: fork failed\n", s);
    1afa:	85ca                	mv	a1,s2
    1afc:	00004517          	auipc	a0,0x4
    1b00:	3ec50513          	addi	a0,a0,1004 # 5ee8 <malloc+0x9ca>
    1b04:	167030ef          	jal	546a <printf>
      exit(1);
    1b08:	4505                	li	a0,1
    1b0a:	530030ef          	jal	503a <exit>
      *(char *)a = 99;
    1b0e:	fd843783          	ld	a5,-40(s0)
    1b12:	06300713          	li	a4,99
    1b16:	00e78023          	sb	a4,0(a5)
      printf("%s: oops wrote %p\n", s, (void *)a);
    1b1a:	fd843603          	ld	a2,-40(s0)
    1b1e:	85ca                	mv	a1,s2
    1b20:	00004517          	auipc	a0,0x4
    1b24:	65050513          	addi	a0,a0,1616 # 6170 <malloc+0xc52>
    1b28:	143030ef          	jal	546a <printf>
      exit(1);
    1b2c:	4505                	li	a0,1
    1b2e:	50c030ef          	jal	503a <exit>
      exit(1);
    1b32:	4505                	li	a0,1
    1b34:	506030ef          	jal	503a <exit>

0000000000001b38 <stacktest>:
{
    1b38:	7179                	addi	sp,sp,-48
    1b3a:	f406                	sd	ra,40(sp)
    1b3c:	f022                	sd	s0,32(sp)
    1b3e:	ec26                	sd	s1,24(sp)
    1b40:	1800                	addi	s0,sp,48
    1b42:	84aa                	mv	s1,a0
  pid = fork();
    1b44:	4ee030ef          	jal	5032 <fork>
  if (pid == 0) {
    1b48:	cd11                	beqz	a0,1b64 <stacktest+0x2c>
  } else if (pid < 0) {
    1b4a:	02054c63          	bltz	a0,1b82 <stacktest+0x4a>
  wait(&xstatus);
    1b4e:	fdc40513          	addi	a0,s0,-36
    1b52:	4f0030ef          	jal	5042 <wait>
  if (xstatus == -1) // kernel killed child?
    1b56:	fdc42503          	lw	a0,-36(s0)
    1b5a:	57fd                	li	a5,-1
    1b5c:	02f50d63          	beq	a0,a5,1b96 <stacktest+0x5e>
    exit(xstatus);
    1b60:	4da030ef          	jal	503a <exit>

static inline uint64
r_sp()
{
  uint64 x;
  asm volatile("mv %0, sp" : "=r"(x));
    1b64:	870a                	mv	a4,sp
    printf("%s: stacktest: read below stack %d\n", s, *sp);
    1b66:	77fd                	lui	a5,0xfffff
    1b68:	97ba                	add	a5,a5,a4
    1b6a:	0007c603          	lbu	a2,0(a5) # fffffffffffff000 <base+0xffffffffffff0338>
    1b6e:	85a6                	mv	a1,s1
    1b70:	00004517          	auipc	a0,0x4
    1b74:	61850513          	addi	a0,a0,1560 # 6188 <malloc+0xc6a>
    1b78:	0f3030ef          	jal	546a <printf>
    exit(1);
    1b7c:	4505                	li	a0,1
    1b7e:	4bc030ef          	jal	503a <exit>
    printf("%s: fork failed\n", s);
    1b82:	85a6                	mv	a1,s1
    1b84:	00004517          	auipc	a0,0x4
    1b88:	36450513          	addi	a0,a0,868 # 5ee8 <malloc+0x9ca>
    1b8c:	0df030ef          	jal	546a <printf>
    exit(1);
    1b90:	4505                	li	a0,1
    1b92:	4a8030ef          	jal	503a <exit>
    exit(0);
    1b96:	4501                	li	a0,0
    1b98:	4a2030ef          	jal	503a <exit>

0000000000001b9c <nowrite>:
{
    1b9c:	7159                	addi	sp,sp,-112
    1b9e:	f486                	sd	ra,104(sp)
    1ba0:	f0a2                	sd	s0,96(sp)
    1ba2:	eca6                	sd	s1,88(sp)
    1ba4:	e8ca                	sd	s2,80(sp)
    1ba6:	e4ce                	sd	s3,72(sp)
    1ba8:	1880                	addi	s0,sp,112
    1baa:	89aa                	mv	s3,a0
  uint64 addrs[] = {0,
    1bac:	00006797          	auipc	a5,0x6
    1bb0:	16478793          	addi	a5,a5,356 # 7d10 <malloc+0x27f2>
    1bb4:	7788                	ld	a0,40(a5)
    1bb6:	7b8c                	ld	a1,48(a5)
    1bb8:	7f90                	ld	a2,56(a5)
    1bba:	63b4                	ld	a3,64(a5)
    1bbc:	67b8                	ld	a4,72(a5)
    1bbe:	6bbc                	ld	a5,80(a5)
    1bc0:	f8a43c23          	sd	a0,-104(s0)
    1bc4:	fab43023          	sd	a1,-96(s0)
    1bc8:	fac43423          	sd	a2,-88(s0)
    1bcc:	fad43823          	sd	a3,-80(s0)
    1bd0:	fae43c23          	sd	a4,-72(s0)
    1bd4:	fcf43023          	sd	a5,-64(s0)
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
    1bd8:	4481                	li	s1,0
    1bda:	4919                	li	s2,6
    pid = fork();
    1bdc:	456030ef          	jal	5032 <fork>
    if (pid == 0) {
    1be0:	c105                	beqz	a0,1c00 <nowrite+0x64>
    } else if (pid < 0) {
    1be2:	04054263          	bltz	a0,1c26 <nowrite+0x8a>
    wait(&xstatus);
    1be6:	fcc40513          	addi	a0,s0,-52
    1bea:	458030ef          	jal	5042 <wait>
    if (xstatus == 0) {
    1bee:	fcc42783          	lw	a5,-52(s0)
    1bf2:	c7a1                	beqz	a5,1c3a <nowrite+0x9e>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
    1bf4:	2485                	addiw	s1,s1,1
    1bf6:	ff2493e3          	bne	s1,s2,1bdc <nowrite+0x40>
  exit(0);
    1bfa:	4501                	li	a0,0
    1bfc:	43e030ef          	jal	503a <exit>
      volatile int *addr = (int *)addrs[ai];
    1c00:	048e                	slli	s1,s1,0x3
    1c02:	fd048793          	addi	a5,s1,-48
    1c06:	008784b3          	add	s1,a5,s0
    1c0a:	fc84b603          	ld	a2,-56(s1)
      *addr = 10;
    1c0e:	47a9                	li	a5,10
    1c10:	c21c                	sw	a5,0(a2)
      printf("%s: write to %p did not fail!\n", s, addr);
    1c12:	85ce                	mv	a1,s3
    1c14:	00004517          	auipc	a0,0x4
    1c18:	59c50513          	addi	a0,a0,1436 # 61b0 <malloc+0xc92>
    1c1c:	04f030ef          	jal	546a <printf>
      exit(0);
    1c20:	4501                	li	a0,0
    1c22:	418030ef          	jal	503a <exit>
      printf("%s: fork failed\n", s);
    1c26:	85ce                	mv	a1,s3
    1c28:	00004517          	auipc	a0,0x4
    1c2c:	2c050513          	addi	a0,a0,704 # 5ee8 <malloc+0x9ca>
    1c30:	03b030ef          	jal	546a <printf>
      exit(1);
    1c34:	4505                	li	a0,1
    1c36:	404030ef          	jal	503a <exit>
      exit(1);
    1c3a:	4505                	li	a0,1
    1c3c:	3fe030ef          	jal	503a <exit>

0000000000001c40 <manywrites>:
{
    1c40:	711d                	addi	sp,sp,-96
    1c42:	ec86                	sd	ra,88(sp)
    1c44:	e8a2                	sd	s0,80(sp)
    1c46:	e4a6                	sd	s1,72(sp)
    1c48:	e0ca                	sd	s2,64(sp)
    1c4a:	fc4e                	sd	s3,56(sp)
    1c4c:	f456                	sd	s5,40(sp)
    1c4e:	1080                	addi	s0,sp,96
    1c50:	8aaa                	mv	s5,a0
  for (int ci = 0; ci < nchildren; ci++) {
    1c52:	4981                	li	s3,0
    1c54:	4911                	li	s2,4
    int pid = fork();
    1c56:	3dc030ef          	jal	5032 <fork>
    1c5a:	84aa                	mv	s1,a0
    if (pid < 0) {
    1c5c:	02054963          	bltz	a0,1c8e <manywrites+0x4e>
    if (pid == 0) {
    1c60:	c139                	beqz	a0,1ca6 <manywrites+0x66>
  for (int ci = 0; ci < nchildren; ci++) {
    1c62:	2985                	addiw	s3,s3,1
    1c64:	ff2999e3          	bne	s3,s2,1c56 <manywrites+0x16>
    1c68:	f852                	sd	s4,48(sp)
    1c6a:	f05a                	sd	s6,32(sp)
    1c6c:	ec5e                	sd	s7,24(sp)
    1c6e:	4491                	li	s1,4
    int st = 0;
    1c70:	fa042423          	sw	zero,-88(s0)
    wait(&st);
    1c74:	fa840513          	addi	a0,s0,-88
    1c78:	3ca030ef          	jal	5042 <wait>
    if (st != 0)
    1c7c:	fa842503          	lw	a0,-88(s0)
    1c80:	0c051863          	bnez	a0,1d50 <manywrites+0x110>
  for (int ci = 0; ci < nchildren; ci++) {
    1c84:	34fd                	addiw	s1,s1,-1
    1c86:	f4ed                	bnez	s1,1c70 <manywrites+0x30>
  exit(0);
    1c88:	4501                	li	a0,0
    1c8a:	3b0030ef          	jal	503a <exit>
    1c8e:	f852                	sd	s4,48(sp)
    1c90:	f05a                	sd	s6,32(sp)
    1c92:	ec5e                	sd	s7,24(sp)
      printf("fork failed\n");
    1c94:	00006517          	auipc	a0,0x6
    1c98:	82c50513          	addi	a0,a0,-2004 # 74c0 <malloc+0x1fa2>
    1c9c:	7ce030ef          	jal	546a <printf>
      exit(1);
    1ca0:	4505                	li	a0,1
    1ca2:	398030ef          	jal	503a <exit>
    1ca6:	f852                	sd	s4,48(sp)
    1ca8:	f05a                	sd	s6,32(sp)
    1caa:	ec5e                	sd	s7,24(sp)
      name[0] = 'b';
    1cac:	06200793          	li	a5,98
    1cb0:	faf40423          	sb	a5,-88(s0)
      name[1] = 'a' + ci;
    1cb4:	0619879b          	addiw	a5,s3,97
    1cb8:	faf404a3          	sb	a5,-87(s0)
      name[2] = '\0';
    1cbc:	fa040523          	sb	zero,-86(s0)
      unlink(name);
    1cc0:	fa840513          	addi	a0,s0,-88
    1cc4:	3c6030ef          	jal	508a <unlink>
    1cc8:	4bf9                	li	s7,30
          int cc = write(fd, buf, sz);
    1cca:	0000ab17          	auipc	s6,0xa
    1cce:	ffeb0b13          	addi	s6,s6,-2 # bcc8 <buf>
        for (int i = 0; i < ci + 1; i++) {
    1cd2:	8a26                	mv	s4,s1
    1cd4:	0209c863          	bltz	s3,1d04 <manywrites+0xc4>
          int fd = open(name, O_CREATE | O_RDWR);
    1cd8:	20200593          	li	a1,514
    1cdc:	fa840513          	addi	a0,s0,-88
    1ce0:	39a030ef          	jal	507a <open>
    1ce4:	892a                	mv	s2,a0
          if (fd < 0) {
    1ce6:	02054d63          	bltz	a0,1d20 <manywrites+0xe0>
          int cc = write(fd, buf, sz);
    1cea:	660d                	lui	a2,0x3
    1cec:	85da                	mv	a1,s6
    1cee:	36c030ef          	jal	505a <write>
          if (cc != sz) {
    1cf2:	678d                	lui	a5,0x3
    1cf4:	04f51263          	bne	a0,a5,1d38 <manywrites+0xf8>
          close(fd);
    1cf8:	854a                	mv	a0,s2
    1cfa:	368030ef          	jal	5062 <close>
        for (int i = 0; i < ci + 1; i++) {
    1cfe:	2a05                	addiw	s4,s4,1
    1d00:	fd49dce3          	bge	s3,s4,1cd8 <manywrites+0x98>
        unlink(name);
    1d04:	fa840513          	addi	a0,s0,-88
    1d08:	382030ef          	jal	508a <unlink>
      for (int iters = 0; iters < howmany; iters++) {
    1d0c:	3bfd                	addiw	s7,s7,-1
    1d0e:	fc0b92e3          	bnez	s7,1cd2 <manywrites+0x92>
      unlink(name);
    1d12:	fa840513          	addi	a0,s0,-88
    1d16:	374030ef          	jal	508a <unlink>
      exit(0);
    1d1a:	4501                	li	a0,0
    1d1c:	31e030ef          	jal	503a <exit>
            printf("%s: cannot create %s\n", s, name);
    1d20:	fa840613          	addi	a2,s0,-88
    1d24:	85d6                	mv	a1,s5
    1d26:	00004517          	auipc	a0,0x4
    1d2a:	4aa50513          	addi	a0,a0,1194 # 61d0 <malloc+0xcb2>
    1d2e:	73c030ef          	jal	546a <printf>
            exit(1);
    1d32:	4505                	li	a0,1
    1d34:	306030ef          	jal	503a <exit>
            printf("%s: write(%d) ret %d\n", s, sz, cc);
    1d38:	86aa                	mv	a3,a0
    1d3a:	660d                	lui	a2,0x3
    1d3c:	85d6                	mv	a1,s5
    1d3e:	00004517          	auipc	a0,0x4
    1d42:	9ea50513          	addi	a0,a0,-1558 # 5728 <malloc+0x20a>
    1d46:	724030ef          	jal	546a <printf>
            exit(1);
    1d4a:	4505                	li	a0,1
    1d4c:	2ee030ef          	jal	503a <exit>
      exit(st);
    1d50:	2ea030ef          	jal	503a <exit>

0000000000001d54 <copyinstr3>:
{
    1d54:	7179                	addi	sp,sp,-48
    1d56:	f406                	sd	ra,40(sp)
    1d58:	f022                	sd	s0,32(sp)
    1d5a:	ec26                	sd	s1,24(sp)
    1d5c:	1800                	addi	s0,sp,48
  sbrk(8192);
    1d5e:	6509                	lui	a0,0x2
    1d60:	2a6030ef          	jal	5006 <sbrk>
  uint64 top = (uint64)sbrk(0);
    1d64:	4501                	li	a0,0
    1d66:	2a0030ef          	jal	5006 <sbrk>
  if ((top % PGSIZE) != 0) {
    1d6a:	03451793          	slli	a5,a0,0x34
    1d6e:	e7bd                	bnez	a5,1ddc <copyinstr3+0x88>
  top = (uint64)sbrk(0);
    1d70:	4501                	li	a0,0
    1d72:	294030ef          	jal	5006 <sbrk>
  if (top % PGSIZE) {
    1d76:	03451793          	slli	a5,a0,0x34
    1d7a:	ebad                	bnez	a5,1dec <copyinstr3+0x98>
  char *b = (char *)(top - 1);
    1d7c:	fff50493          	addi	s1,a0,-1 # 1fff <sbrkbasic+0xa1>
  *b = 'x';
    1d80:	07800793          	li	a5,120
    1d84:	fef50fa3          	sb	a5,-1(a0)
  int ret = unlink(b);
    1d88:	8526                	mv	a0,s1
    1d8a:	300030ef          	jal	508a <unlink>
  if (ret != -1) {
    1d8e:	57fd                	li	a5,-1
    1d90:	06f51763          	bne	a0,a5,1dfe <copyinstr3+0xaa>
  int fd = open(b, O_CREATE | O_WRONLY);
    1d94:	20100593          	li	a1,513
    1d98:	8526                	mv	a0,s1
    1d9a:	2e0030ef          	jal	507a <open>
  if (fd != -1) {
    1d9e:	57fd                	li	a5,-1
    1da0:	06f51a63          	bne	a0,a5,1e14 <copyinstr3+0xc0>
  ret = link(b, b);
    1da4:	85a6                	mv	a1,s1
    1da6:	8526                	mv	a0,s1
    1da8:	2f2030ef          	jal	509a <link>
  if (ret != -1) {
    1dac:	57fd                	li	a5,-1
    1dae:	06f51e63          	bne	a0,a5,1e2a <copyinstr3+0xd6>
  char *args[] = {"xx", 0};
    1db2:	00005797          	auipc	a5,0x5
    1db6:	11e78793          	addi	a5,a5,286 # 6ed0 <malloc+0x19b2>
    1dba:	fcf43823          	sd	a5,-48(s0)
    1dbe:	fc043c23          	sd	zero,-40(s0)
  ret = exec(b, args);
    1dc2:	fd040593          	addi	a1,s0,-48
    1dc6:	8526                	mv	a0,s1
    1dc8:	2aa030ef          	jal	5072 <exec>
  if (ret != -1) {
    1dcc:	57fd                	li	a5,-1
    1dce:	06f51a63          	bne	a0,a5,1e42 <copyinstr3+0xee>
}
    1dd2:	70a2                	ld	ra,40(sp)
    1dd4:	7402                	ld	s0,32(sp)
    1dd6:	64e2                	ld	s1,24(sp)
    1dd8:	6145                	addi	sp,sp,48
    1dda:	8082                	ret
    sbrk(PGSIZE - (top % PGSIZE));
    1ddc:	0347d513          	srli	a0,a5,0x34
    1de0:	6785                	lui	a5,0x1
    1de2:	40a7853b          	subw	a0,a5,a0
    1de6:	220030ef          	jal	5006 <sbrk>
    1dea:	b759                	j	1d70 <copyinstr3+0x1c>
    printf("oops\n");
    1dec:	00004517          	auipc	a0,0x4
    1df0:	3fc50513          	addi	a0,a0,1020 # 61e8 <malloc+0xcca>
    1df4:	676030ef          	jal	546a <printf>
    exit(1);
    1df8:	4505                	li	a0,1
    1dfa:	240030ef          	jal	503a <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    1dfe:	862a                	mv	a2,a0
    1e00:	85a6                	mv	a1,s1
    1e02:	00004517          	auipc	a0,0x4
    1e06:	00650513          	addi	a0,a0,6 # 5e08 <malloc+0x8ea>
    1e0a:	660030ef          	jal	546a <printf>
    exit(1);
    1e0e:	4505                	li	a0,1
    1e10:	22a030ef          	jal	503a <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    1e14:	862a                	mv	a2,a0
    1e16:	85a6                	mv	a1,s1
    1e18:	00004517          	auipc	a0,0x4
    1e1c:	01050513          	addi	a0,a0,16 # 5e28 <malloc+0x90a>
    1e20:	64a030ef          	jal	546a <printf>
    exit(1);
    1e24:	4505                	li	a0,1
    1e26:	214030ef          	jal	503a <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    1e2a:	86aa                	mv	a3,a0
    1e2c:	8626                	mv	a2,s1
    1e2e:	85a6                	mv	a1,s1
    1e30:	00004517          	auipc	a0,0x4
    1e34:	01850513          	addi	a0,a0,24 # 5e48 <malloc+0x92a>
    1e38:	632030ef          	jal	546a <printf>
    exit(1);
    1e3c:	4505                	li	a0,1
    1e3e:	1fc030ef          	jal	503a <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    1e42:	567d                	li	a2,-1
    1e44:	85a6                	mv	a1,s1
    1e46:	00004517          	auipc	a0,0x4
    1e4a:	02a50513          	addi	a0,a0,42 # 5e70 <malloc+0x952>
    1e4e:	61c030ef          	jal	546a <printf>
    exit(1);
    1e52:	4505                	li	a0,1
    1e54:	1e6030ef          	jal	503a <exit>

0000000000001e58 <rwsbrk>:
{
    1e58:	1101                	addi	sp,sp,-32
    1e5a:	ec06                	sd	ra,24(sp)
    1e5c:	e822                	sd	s0,16(sp)
    1e5e:	1000                	addi	s0,sp,32
  uint64 a = (uint64)sbrk(8192);
    1e60:	6509                	lui	a0,0x2
    1e62:	1a4030ef          	jal	5006 <sbrk>
  if (a == (uint64)SBRK_ERROR) {
    1e66:	57fd                	li	a5,-1
    1e68:	04f50a63          	beq	a0,a5,1ebc <rwsbrk+0x64>
    1e6c:	e426                	sd	s1,8(sp)
    1e6e:	84aa                	mv	s1,a0
  if (sbrk(-8192) == SBRK_ERROR) {
    1e70:	7579                	lui	a0,0xffffe
    1e72:	194030ef          	jal	5006 <sbrk>
    1e76:	57fd                	li	a5,-1
    1e78:	04f50d63          	beq	a0,a5,1ed2 <rwsbrk+0x7a>
    1e7c:	e04a                	sd	s2,0(sp)
  fd = open("rwsbrk", O_CREATE | O_WRONLY);
    1e7e:	20100593          	li	a1,513
    1e82:	00004517          	auipc	a0,0x4
    1e86:	3a650513          	addi	a0,a0,934 # 6228 <malloc+0xd0a>
    1e8a:	1f0030ef          	jal	507a <open>
    1e8e:	892a                	mv	s2,a0
  if (fd < 0) {
    1e90:	04054b63          	bltz	a0,1ee6 <rwsbrk+0x8e>
  n = write(fd, (void *)(a + PGSIZE), 1024);
    1e94:	6785                	lui	a5,0x1
    1e96:	94be                	add	s1,s1,a5
    1e98:	40000613          	li	a2,1024
    1e9c:	85a6                	mv	a1,s1
    1e9e:	1bc030ef          	jal	505a <write>
    1ea2:	862a                	mv	a2,a0
  if (n >= 0) {
    1ea4:	04054a63          	bltz	a0,1ef8 <rwsbrk+0xa0>
    printf("write(fd, %p, 1024) returned %d, not -1\n", (void *)a + PGSIZE, n);
    1ea8:	85a6                	mv	a1,s1
    1eaa:	00004517          	auipc	a0,0x4
    1eae:	39e50513          	addi	a0,a0,926 # 6248 <malloc+0xd2a>
    1eb2:	5b8030ef          	jal	546a <printf>
    exit(1);
    1eb6:	4505                	li	a0,1
    1eb8:	182030ef          	jal	503a <exit>
    1ebc:	e426                	sd	s1,8(sp)
    1ebe:	e04a                	sd	s2,0(sp)
    printf("sbrk(rwsbrk) failed\n");
    1ec0:	00004517          	auipc	a0,0x4
    1ec4:	33050513          	addi	a0,a0,816 # 61f0 <malloc+0xcd2>
    1ec8:	5a2030ef          	jal	546a <printf>
    exit(1);
    1ecc:	4505                	li	a0,1
    1ece:	16c030ef          	jal	503a <exit>
    1ed2:	e04a                	sd	s2,0(sp)
    printf("sbrk(rwsbrk) shrink failed\n");
    1ed4:	00004517          	auipc	a0,0x4
    1ed8:	33450513          	addi	a0,a0,820 # 6208 <malloc+0xcea>
    1edc:	58e030ef          	jal	546a <printf>
    exit(1);
    1ee0:	4505                	li	a0,1
    1ee2:	158030ef          	jal	503a <exit>
    printf("open(rwsbrk) failed\n");
    1ee6:	00004517          	auipc	a0,0x4
    1eea:	34a50513          	addi	a0,a0,842 # 6230 <malloc+0xd12>
    1eee:	57c030ef          	jal	546a <printf>
    exit(1);
    1ef2:	4505                	li	a0,1
    1ef4:	146030ef          	jal	503a <exit>
  close(fd);
    1ef8:	854a                	mv	a0,s2
    1efa:	168030ef          	jal	5062 <close>
  unlink("rwsbrk");
    1efe:	00004517          	auipc	a0,0x4
    1f02:	32a50513          	addi	a0,a0,810 # 6228 <malloc+0xd0a>
    1f06:	184030ef          	jal	508a <unlink>
  fd = open("README", O_RDONLY);
    1f0a:	4581                	li	a1,0
    1f0c:	00004517          	auipc	a0,0x4
    1f10:	92450513          	addi	a0,a0,-1756 # 5830 <malloc+0x312>
    1f14:	166030ef          	jal	507a <open>
    1f18:	892a                	mv	s2,a0
  if (fd < 0) {
    1f1a:	02054363          	bltz	a0,1f40 <rwsbrk+0xe8>
  n = read(fd, (void *)(a + PGSIZE), 10);
    1f1e:	4629                	li	a2,10
    1f20:	85a6                	mv	a1,s1
    1f22:	130030ef          	jal	5052 <read>
    1f26:	862a                	mv	a2,a0
  if (n >= 0) {
    1f28:	02054563          	bltz	a0,1f52 <rwsbrk+0xfa>
    printf("read(fd, %p, 10) returned %d, not -1\n", (void *)a + PGSIZE, n);
    1f2c:	85a6                	mv	a1,s1
    1f2e:	00004517          	auipc	a0,0x4
    1f32:	34a50513          	addi	a0,a0,842 # 6278 <malloc+0xd5a>
    1f36:	534030ef          	jal	546a <printf>
    exit(1);
    1f3a:	4505                	li	a0,1
    1f3c:	0fe030ef          	jal	503a <exit>
    printf("open(README) failed\n");
    1f40:	00004517          	auipc	a0,0x4
    1f44:	8f850513          	addi	a0,a0,-1800 # 5838 <malloc+0x31a>
    1f48:	522030ef          	jal	546a <printf>
    exit(1);
    1f4c:	4505                	li	a0,1
    1f4e:	0ec030ef          	jal	503a <exit>
  close(fd);
    1f52:	854a                	mv	a0,s2
    1f54:	10e030ef          	jal	5062 <close>
  exit(0);
    1f58:	4501                	li	a0,0
    1f5a:	0e0030ef          	jal	503a <exit>

0000000000001f5e <sbrkbasic>:
{
    1f5e:	7139                	addi	sp,sp,-64
    1f60:	fc06                	sd	ra,56(sp)
    1f62:	f822                	sd	s0,48(sp)
    1f64:	ec4e                	sd	s3,24(sp)
    1f66:	0080                	addi	s0,sp,64
    1f68:	89aa                	mv	s3,a0
  pid = fork();
    1f6a:	0c8030ef          	jal	5032 <fork>
  if (pid < 0) {
    1f6e:	02054b63          	bltz	a0,1fa4 <sbrkbasic+0x46>
  if (pid == 0) {
    1f72:	e939                	bnez	a0,1fc8 <sbrkbasic+0x6a>
    a = sbrk(TOOMUCH);
    1f74:	40000537          	lui	a0,0x40000
    1f78:	08e030ef          	jal	5006 <sbrk>
    if (a == (char *)SBRK_ERROR) {
    1f7c:	57fd                	li	a5,-1
    1f7e:	02f50f63          	beq	a0,a5,1fbc <sbrkbasic+0x5e>
    1f82:	f426                	sd	s1,40(sp)
    1f84:	f04a                	sd	s2,32(sp)
    1f86:	e852                	sd	s4,16(sp)
    for (b = a; b < a + TOOMUCH; b += PGSIZE) {
    1f88:	400007b7          	lui	a5,0x40000
    1f8c:	97aa                	add	a5,a5,a0
      *b = 99;
    1f8e:	06300693          	li	a3,99
    for (b = a; b < a + TOOMUCH; b += PGSIZE) {
    1f92:	6705                	lui	a4,0x1
      *b = 99;
    1f94:	00d50023          	sb	a3,0(a0) # 40000000 <base+0x3fff1338>
    for (b = a; b < a + TOOMUCH; b += PGSIZE) {
    1f98:	953a                	add	a0,a0,a4
    1f9a:	fef51de3          	bne	a0,a5,1f94 <sbrkbasic+0x36>
    exit(1);
    1f9e:	4505                	li	a0,1
    1fa0:	09a030ef          	jal	503a <exit>
    1fa4:	f426                	sd	s1,40(sp)
    1fa6:	f04a                	sd	s2,32(sp)
    1fa8:	e852                	sd	s4,16(sp)
    printf("fork failed in sbrkbasic\n");
    1faa:	00004517          	auipc	a0,0x4
    1fae:	2f650513          	addi	a0,a0,758 # 62a0 <malloc+0xd82>
    1fb2:	4b8030ef          	jal	546a <printf>
    exit(1);
    1fb6:	4505                	li	a0,1
    1fb8:	082030ef          	jal	503a <exit>
    1fbc:	f426                	sd	s1,40(sp)
    1fbe:	f04a                	sd	s2,32(sp)
    1fc0:	e852                	sd	s4,16(sp)
      exit(0);
    1fc2:	4501                	li	a0,0
    1fc4:	076030ef          	jal	503a <exit>
  wait(&xstatus);
    1fc8:	fcc40513          	addi	a0,s0,-52
    1fcc:	076030ef          	jal	5042 <wait>
  if (xstatus == 1) {
    1fd0:	fcc42703          	lw	a4,-52(s0)
    1fd4:	4785                	li	a5,1
    1fd6:	00f70e63          	beq	a4,a5,1ff2 <sbrkbasic+0x94>
    1fda:	f426                	sd	s1,40(sp)
    1fdc:	f04a                	sd	s2,32(sp)
    1fde:	e852                	sd	s4,16(sp)
  a = sbrk(0);
    1fe0:	4501                	li	a0,0
    1fe2:	024030ef          	jal	5006 <sbrk>
    1fe6:	84aa                	mv	s1,a0
  for (i = 0; i < 5000; i++) {
    1fe8:	4901                	li	s2,0
    1fea:	6a05                	lui	s4,0x1
    1fec:	388a0a13          	addi	s4,s4,904 # 1388 <pipe1+0x4a>
    1ff0:	a839                	j	200e <sbrkbasic+0xb0>
    1ff2:	f426                	sd	s1,40(sp)
    1ff4:	f04a                	sd	s2,32(sp)
    1ff6:	e852                	sd	s4,16(sp)
    printf("%s: too much memory allocated!\n", s);
    1ff8:	85ce                	mv	a1,s3
    1ffa:	00004517          	auipc	a0,0x4
    1ffe:	2c650513          	addi	a0,a0,710 # 62c0 <malloc+0xda2>
    2002:	468030ef          	jal	546a <printf>
    exit(1);
    2006:	4505                	li	a0,1
    2008:	032030ef          	jal	503a <exit>
    200c:	84be                	mv	s1,a5
    b = sbrk(1);
    200e:	4505                	li	a0,1
    2010:	7f7020ef          	jal	5006 <sbrk>
    if (b != a) {
    2014:	04951263          	bne	a0,s1,2058 <sbrkbasic+0xfa>
    *b = 1;
    2018:	4785                	li	a5,1
    201a:	00f48023          	sb	a5,0(s1)
    a = b + 1;
    201e:	00148793          	addi	a5,s1,1
  for (i = 0; i < 5000; i++) {
    2022:	2905                	addiw	s2,s2,1
    2024:	ff4914e3          	bne	s2,s4,200c <sbrkbasic+0xae>
  pid = fork();
    2028:	00a030ef          	jal	5032 <fork>
    202c:	892a                	mv	s2,a0
  if (pid < 0) {
    202e:	04054263          	bltz	a0,2072 <sbrkbasic+0x114>
  c = sbrk(1);
    2032:	4505                	li	a0,1
    2034:	7d3020ef          	jal	5006 <sbrk>
  c = sbrk(1);
    2038:	4505                	li	a0,1
    203a:	7cd020ef          	jal	5006 <sbrk>
  if (c != a + 1) {
    203e:	0489                	addi	s1,s1,2
    2040:	04a48363          	beq	s1,a0,2086 <sbrkbasic+0x128>
    printf("%s: sbrk test failed post-fork\n", s);
    2044:	85ce                	mv	a1,s3
    2046:	00004517          	auipc	a0,0x4
    204a:	2da50513          	addi	a0,a0,730 # 6320 <malloc+0xe02>
    204e:	41c030ef          	jal	546a <printf>
    exit(1);
    2052:	4505                	li	a0,1
    2054:	7e7020ef          	jal	503a <exit>
      printf("%s: sbrk test failed %d %p %p\n", s, i, a, b);
    2058:	872a                	mv	a4,a0
    205a:	86a6                	mv	a3,s1
    205c:	864a                	mv	a2,s2
    205e:	85ce                	mv	a1,s3
    2060:	00004517          	auipc	a0,0x4
    2064:	28050513          	addi	a0,a0,640 # 62e0 <malloc+0xdc2>
    2068:	402030ef          	jal	546a <printf>
      exit(1);
    206c:	4505                	li	a0,1
    206e:	7cd020ef          	jal	503a <exit>
    printf("%s: sbrk test fork failed\n", s);
    2072:	85ce                	mv	a1,s3
    2074:	00004517          	auipc	a0,0x4
    2078:	28c50513          	addi	a0,a0,652 # 6300 <malloc+0xde2>
    207c:	3ee030ef          	jal	546a <printf>
    exit(1);
    2080:	4505                	li	a0,1
    2082:	7b9020ef          	jal	503a <exit>
  if (pid == 0)
    2086:	00091563          	bnez	s2,2090 <sbrkbasic+0x132>
    exit(0);
    208a:	4501                	li	a0,0
    208c:	7af020ef          	jal	503a <exit>
  wait(&xstatus);
    2090:	fcc40513          	addi	a0,s0,-52
    2094:	7af020ef          	jal	5042 <wait>
  exit(xstatus);
    2098:	fcc42503          	lw	a0,-52(s0)
    209c:	79f020ef          	jal	503a <exit>

00000000000020a0 <sbrkmuch>:
{
    20a0:	7179                	addi	sp,sp,-48
    20a2:	f406                	sd	ra,40(sp)
    20a4:	f022                	sd	s0,32(sp)
    20a6:	ec26                	sd	s1,24(sp)
    20a8:	e84a                	sd	s2,16(sp)
    20aa:	e44e                	sd	s3,8(sp)
    20ac:	e052                	sd	s4,0(sp)
    20ae:	1800                	addi	s0,sp,48
    20b0:	89aa                	mv	s3,a0
  oldbrk = sbrk(0);
    20b2:	4501                	li	a0,0
    20b4:	753020ef          	jal	5006 <sbrk>
    20b8:	892a                	mv	s2,a0
  a = sbrk(0);
    20ba:	4501                	li	a0,0
    20bc:	74b020ef          	jal	5006 <sbrk>
    20c0:	84aa                	mv	s1,a0
  p = sbrk(amt);
    20c2:	06400537          	lui	a0,0x6400
    20c6:	9d05                	subw	a0,a0,s1
    20c8:	73f020ef          	jal	5006 <sbrk>
  if (p != a) {
    20cc:	08a49763          	bne	s1,a0,215a <sbrkmuch+0xba>
  *lastaddr = 99;
    20d0:	064007b7          	lui	a5,0x6400
    20d4:	06300713          	li	a4,99
    20d8:	fee78fa3          	sb	a4,-1(a5) # 63fffff <base+0x63f1337>
  a = sbrk(0);
    20dc:	4501                	li	a0,0
    20de:	729020ef          	jal	5006 <sbrk>
    20e2:	84aa                	mv	s1,a0
  c = sbrk(-PGSIZE);
    20e4:	757d                	lui	a0,0xfffff
    20e6:	721020ef          	jal	5006 <sbrk>
  if (c == (char *)SBRK_ERROR) {
    20ea:	57fd                	li	a5,-1
    20ec:	08f50163          	beq	a0,a5,216e <sbrkmuch+0xce>
  c = sbrk(0);
    20f0:	4501                	li	a0,0
    20f2:	715020ef          	jal	5006 <sbrk>
  if (c != a - PGSIZE) {
    20f6:	77fd                	lui	a5,0xfffff
    20f8:	97a6                	add	a5,a5,s1
    20fa:	08f51463          	bne	a0,a5,2182 <sbrkmuch+0xe2>
  a = sbrk(0);
    20fe:	4501                	li	a0,0
    2100:	707020ef          	jal	5006 <sbrk>
    2104:	84aa                	mv	s1,a0
  c = sbrk(PGSIZE);
    2106:	6505                	lui	a0,0x1
    2108:	6ff020ef          	jal	5006 <sbrk>
    210c:	8a2a                	mv	s4,a0
  if (c != a || sbrk(0) != a + PGSIZE) {
    210e:	08a49663          	bne	s1,a0,219a <sbrkmuch+0xfa>
    2112:	4501                	li	a0,0
    2114:	6f3020ef          	jal	5006 <sbrk>
    2118:	6785                	lui	a5,0x1
    211a:	97a6                	add	a5,a5,s1
    211c:	06f51f63          	bne	a0,a5,219a <sbrkmuch+0xfa>
  if (*lastaddr == 99) {
    2120:	064007b7          	lui	a5,0x6400
    2124:	fff7c703          	lbu	a4,-1(a5) # 63fffff <base+0x63f1337>
    2128:	06300793          	li	a5,99
    212c:	08f70363          	beq	a4,a5,21b2 <sbrkmuch+0x112>
  a = sbrk(0);
    2130:	4501                	li	a0,0
    2132:	6d5020ef          	jal	5006 <sbrk>
    2136:	84aa                	mv	s1,a0
  c = sbrk(-(sbrk(0) - oldbrk));
    2138:	4501                	li	a0,0
    213a:	6cd020ef          	jal	5006 <sbrk>
    213e:	40a9053b          	subw	a0,s2,a0
    2142:	6c5020ef          	jal	5006 <sbrk>
  if (c != a) {
    2146:	08a49063          	bne	s1,a0,21c6 <sbrkmuch+0x126>
}
    214a:	70a2                	ld	ra,40(sp)
    214c:	7402                	ld	s0,32(sp)
    214e:	64e2                	ld	s1,24(sp)
    2150:	6942                	ld	s2,16(sp)
    2152:	69a2                	ld	s3,8(sp)
    2154:	6a02                	ld	s4,0(sp)
    2156:	6145                	addi	sp,sp,48
    2158:	8082                	ret
    printf("%s: sbrk test failed to grow big address space; enough phys mem?\n",
    215a:	85ce                	mv	a1,s3
    215c:	00004517          	auipc	a0,0x4
    2160:	1e450513          	addi	a0,a0,484 # 6340 <malloc+0xe22>
    2164:	306030ef          	jal	546a <printf>
    exit(1);
    2168:	4505                	li	a0,1
    216a:	6d1020ef          	jal	503a <exit>
    printf("%s: sbrk could not deallocate\n", s);
    216e:	85ce                	mv	a1,s3
    2170:	00004517          	auipc	a0,0x4
    2174:	21850513          	addi	a0,a0,536 # 6388 <malloc+0xe6a>
    2178:	2f2030ef          	jal	546a <printf>
    exit(1);
    217c:	4505                	li	a0,1
    217e:	6bd020ef          	jal	503a <exit>
    printf("%s: sbrk deallocation produced wrong address, a %p c %p\n", s, a,
    2182:	86aa                	mv	a3,a0
    2184:	8626                	mv	a2,s1
    2186:	85ce                	mv	a1,s3
    2188:	00004517          	auipc	a0,0x4
    218c:	22050513          	addi	a0,a0,544 # 63a8 <malloc+0xe8a>
    2190:	2da030ef          	jal	546a <printf>
    exit(1);
    2194:	4505                	li	a0,1
    2196:	6a5020ef          	jal	503a <exit>
    printf("%s: sbrk re-allocation failed, a %p c %p\n", s, a, c);
    219a:	86d2                	mv	a3,s4
    219c:	8626                	mv	a2,s1
    219e:	85ce                	mv	a1,s3
    21a0:	00004517          	auipc	a0,0x4
    21a4:	24850513          	addi	a0,a0,584 # 63e8 <malloc+0xeca>
    21a8:	2c2030ef          	jal	546a <printf>
    exit(1);
    21ac:	4505                	li	a0,1
    21ae:	68d020ef          	jal	503a <exit>
    printf("%s: sbrk de-allocation didn't really deallocate\n", s);
    21b2:	85ce                	mv	a1,s3
    21b4:	00004517          	auipc	a0,0x4
    21b8:	26450513          	addi	a0,a0,612 # 6418 <malloc+0xefa>
    21bc:	2ae030ef          	jal	546a <printf>
    exit(1);
    21c0:	4505                	li	a0,1
    21c2:	679020ef          	jal	503a <exit>
    printf("%s: sbrk downsize failed, a %p c %p\n", s, a, c);
    21c6:	86aa                	mv	a3,a0
    21c8:	8626                	mv	a2,s1
    21ca:	85ce                	mv	a1,s3
    21cc:	00004517          	auipc	a0,0x4
    21d0:	28450513          	addi	a0,a0,644 # 6450 <malloc+0xf32>
    21d4:	296030ef          	jal	546a <printf>
    exit(1);
    21d8:	4505                	li	a0,1
    21da:	661020ef          	jal	503a <exit>

00000000000021de <sbrkarg>:
{
    21de:	7179                	addi	sp,sp,-48
    21e0:	f406                	sd	ra,40(sp)
    21e2:	f022                	sd	s0,32(sp)
    21e4:	ec26                	sd	s1,24(sp)
    21e6:	e84a                	sd	s2,16(sp)
    21e8:	e44e                	sd	s3,8(sp)
    21ea:	1800                	addi	s0,sp,48
    21ec:	89aa                	mv	s3,a0
  a = sbrk(PGSIZE);
    21ee:	6505                	lui	a0,0x1
    21f0:	617020ef          	jal	5006 <sbrk>
    21f4:	892a                	mv	s2,a0
  fd = open("sbrk", O_CREATE | O_WRONLY);
    21f6:	20100593          	li	a1,513
    21fa:	00004517          	auipc	a0,0x4
    21fe:	27e50513          	addi	a0,a0,638 # 6478 <malloc+0xf5a>
    2202:	679020ef          	jal	507a <open>
    2206:	84aa                	mv	s1,a0
  unlink("sbrk");
    2208:	00004517          	auipc	a0,0x4
    220c:	27050513          	addi	a0,a0,624 # 6478 <malloc+0xf5a>
    2210:	67b020ef          	jal	508a <unlink>
  if (fd < 0) {
    2214:	0204c963          	bltz	s1,2246 <sbrkarg+0x68>
  if ((n = write(fd, a, PGSIZE)) < 0) {
    2218:	6605                	lui	a2,0x1
    221a:	85ca                	mv	a1,s2
    221c:	8526                	mv	a0,s1
    221e:	63d020ef          	jal	505a <write>
    2222:	02054c63          	bltz	a0,225a <sbrkarg+0x7c>
  close(fd);
    2226:	8526                	mv	a0,s1
    2228:	63b020ef          	jal	5062 <close>
  a = sbrk(PGSIZE);
    222c:	6505                	lui	a0,0x1
    222e:	5d9020ef          	jal	5006 <sbrk>
  if (pipe((int *)a) != 0) {
    2232:	619020ef          	jal	504a <pipe>
    2236:	ed05                	bnez	a0,226e <sbrkarg+0x90>
}
    2238:	70a2                	ld	ra,40(sp)
    223a:	7402                	ld	s0,32(sp)
    223c:	64e2                	ld	s1,24(sp)
    223e:	6942                	ld	s2,16(sp)
    2240:	69a2                	ld	s3,8(sp)
    2242:	6145                	addi	sp,sp,48
    2244:	8082                	ret
    printf("%s: open sbrk failed\n", s);
    2246:	85ce                	mv	a1,s3
    2248:	00004517          	auipc	a0,0x4
    224c:	23850513          	addi	a0,a0,568 # 6480 <malloc+0xf62>
    2250:	21a030ef          	jal	546a <printf>
    exit(1);
    2254:	4505                	li	a0,1
    2256:	5e5020ef          	jal	503a <exit>
    printf("%s: write sbrk failed\n", s);
    225a:	85ce                	mv	a1,s3
    225c:	00004517          	auipc	a0,0x4
    2260:	23c50513          	addi	a0,a0,572 # 6498 <malloc+0xf7a>
    2264:	206030ef          	jal	546a <printf>
    exit(1);
    2268:	4505                	li	a0,1
    226a:	5d1020ef          	jal	503a <exit>
    printf("%s: pipe() failed\n", s);
    226e:	85ce                	mv	a1,s3
    2270:	00004517          	auipc	a0,0x4
    2274:	d0050513          	addi	a0,a0,-768 # 5f70 <malloc+0xa52>
    2278:	1f2030ef          	jal	546a <printf>
    exit(1);
    227c:	4505                	li	a0,1
    227e:	5bd020ef          	jal	503a <exit>

0000000000002282 <argptest>:
{
    2282:	1101                	addi	sp,sp,-32
    2284:	ec06                	sd	ra,24(sp)
    2286:	e822                	sd	s0,16(sp)
    2288:	e426                	sd	s1,8(sp)
    228a:	e04a                	sd	s2,0(sp)
    228c:	1000                	addi	s0,sp,32
    228e:	892a                	mv	s2,a0
  fd = open("init", O_RDONLY);
    2290:	4581                	li	a1,0
    2292:	00004517          	auipc	a0,0x4
    2296:	21e50513          	addi	a0,a0,542 # 64b0 <malloc+0xf92>
    229a:	5e1020ef          	jal	507a <open>
  if (fd < 0) {
    229e:	02054563          	bltz	a0,22c8 <argptest+0x46>
    22a2:	84aa                	mv	s1,a0
  read(fd, sbrk(0) - 1, -1);
    22a4:	4501                	li	a0,0
    22a6:	561020ef          	jal	5006 <sbrk>
    22aa:	567d                	li	a2,-1
    22ac:	fff50593          	addi	a1,a0,-1
    22b0:	8526                	mv	a0,s1
    22b2:	5a1020ef          	jal	5052 <read>
  close(fd);
    22b6:	8526                	mv	a0,s1
    22b8:	5ab020ef          	jal	5062 <close>
}
    22bc:	60e2                	ld	ra,24(sp)
    22be:	6442                	ld	s0,16(sp)
    22c0:	64a2                	ld	s1,8(sp)
    22c2:	6902                	ld	s2,0(sp)
    22c4:	6105                	addi	sp,sp,32
    22c6:	8082                	ret
    printf("%s: open failed\n", s);
    22c8:	85ca                	mv	a1,s2
    22ca:	00004517          	auipc	a0,0x4
    22ce:	c3650513          	addi	a0,a0,-970 # 5f00 <malloc+0x9e2>
    22d2:	198030ef          	jal	546a <printf>
    exit(1);
    22d6:	4505                	li	a0,1
    22d8:	563020ef          	jal	503a <exit>

00000000000022dc <sbrkbugs>:
{
    22dc:	1141                	addi	sp,sp,-16
    22de:	e406                	sd	ra,8(sp)
    22e0:	e022                	sd	s0,0(sp)
    22e2:	0800                	addi	s0,sp,16
  int pid = fork();
    22e4:	54f020ef          	jal	5032 <fork>
  if (pid < 0) {
    22e8:	00054c63          	bltz	a0,2300 <sbrkbugs+0x24>
  if (pid == 0) {
    22ec:	e11d                	bnez	a0,2312 <sbrkbugs+0x36>
    int sz = (uint64)sbrk(0);
    22ee:	519020ef          	jal	5006 <sbrk>
    sbrk(-sz);
    22f2:	40a0053b          	negw	a0,a0
    22f6:	511020ef          	jal	5006 <sbrk>
    exit(0);
    22fa:	4501                	li	a0,0
    22fc:	53f020ef          	jal	503a <exit>
    printf("fork failed\n");
    2300:	00005517          	auipc	a0,0x5
    2304:	1c050513          	addi	a0,a0,448 # 74c0 <malloc+0x1fa2>
    2308:	162030ef          	jal	546a <printf>
    exit(1);
    230c:	4505                	li	a0,1
    230e:	52d020ef          	jal	503a <exit>
  wait(0);
    2312:	4501                	li	a0,0
    2314:	52f020ef          	jal	5042 <wait>
  pid = fork();
    2318:	51b020ef          	jal	5032 <fork>
  if (pid < 0) {
    231c:	00054f63          	bltz	a0,233a <sbrkbugs+0x5e>
  if (pid == 0) {
    2320:	e515                	bnez	a0,234c <sbrkbugs+0x70>
    int sz = (uint64)sbrk(0);
    2322:	4e5020ef          	jal	5006 <sbrk>
    sbrk(-(sz - 3500));
    2326:	6785                	lui	a5,0x1
    2328:	dac7879b          	addiw	a5,a5,-596 # dac <linktest+0x138>
    232c:	40a7853b          	subw	a0,a5,a0
    2330:	4d7020ef          	jal	5006 <sbrk>
    exit(0);
    2334:	4501                	li	a0,0
    2336:	505020ef          	jal	503a <exit>
    printf("fork failed\n");
    233a:	00005517          	auipc	a0,0x5
    233e:	18650513          	addi	a0,a0,390 # 74c0 <malloc+0x1fa2>
    2342:	128030ef          	jal	546a <printf>
    exit(1);
    2346:	4505                	li	a0,1
    2348:	4f3020ef          	jal	503a <exit>
  wait(0);
    234c:	4501                	li	a0,0
    234e:	4f5020ef          	jal	5042 <wait>
  pid = fork();
    2352:	4e1020ef          	jal	5032 <fork>
  if (pid < 0) {
    2356:	02054263          	bltz	a0,237a <sbrkbugs+0x9e>
  if (pid == 0) {
    235a:	e90d                	bnez	a0,238c <sbrkbugs+0xb0>
    sbrk((10 * PGSIZE + 2048) - (uint64)sbrk(0));
    235c:	4ab020ef          	jal	5006 <sbrk>
    2360:	67ad                	lui	a5,0xb
    2362:	8007879b          	addiw	a5,a5,-2048 # a800 <uninit+0x1248>
    2366:	40a7853b          	subw	a0,a5,a0
    236a:	49d020ef          	jal	5006 <sbrk>
    sbrk(-10);
    236e:	5559                	li	a0,-10
    2370:	497020ef          	jal	5006 <sbrk>
    exit(0);
    2374:	4501                	li	a0,0
    2376:	4c5020ef          	jal	503a <exit>
    printf("fork failed\n");
    237a:	00005517          	auipc	a0,0x5
    237e:	14650513          	addi	a0,a0,326 # 74c0 <malloc+0x1fa2>
    2382:	0e8030ef          	jal	546a <printf>
    exit(1);
    2386:	4505                	li	a0,1
    2388:	4b3020ef          	jal	503a <exit>
  wait(0);
    238c:	4501                	li	a0,0
    238e:	4b5020ef          	jal	5042 <wait>
  exit(0);
    2392:	4501                	li	a0,0
    2394:	4a7020ef          	jal	503a <exit>

0000000000002398 <sbrklast>:
{
    2398:	7179                	addi	sp,sp,-48
    239a:	f406                	sd	ra,40(sp)
    239c:	f022                	sd	s0,32(sp)
    239e:	ec26                	sd	s1,24(sp)
    23a0:	e84a                	sd	s2,16(sp)
    23a2:	e44e                	sd	s3,8(sp)
    23a4:	e052                	sd	s4,0(sp)
    23a6:	1800                	addi	s0,sp,48
  uint64 top = (uint64)sbrk(0);
    23a8:	4501                	li	a0,0
    23aa:	45d020ef          	jal	5006 <sbrk>
  if ((top % PGSIZE) != 0)
    23ae:	03451793          	slli	a5,a0,0x34
    23b2:	ebad                	bnez	a5,2424 <sbrklast+0x8c>
  sbrk(PGSIZE);
    23b4:	6505                	lui	a0,0x1
    23b6:	451020ef          	jal	5006 <sbrk>
  sbrk(10);
    23ba:	4529                	li	a0,10
    23bc:	44b020ef          	jal	5006 <sbrk>
  sbrk(-20);
    23c0:	5531                	li	a0,-20
    23c2:	445020ef          	jal	5006 <sbrk>
  top = (uint64)sbrk(0);
    23c6:	4501                	li	a0,0
    23c8:	43f020ef          	jal	5006 <sbrk>
    23cc:	84aa                	mv	s1,a0
  char *p = (char *)(top - 64);
    23ce:	fc050913          	addi	s2,a0,-64 # fc0 <bigdir+0x122>
  p[0] = 'x';
    23d2:	07800a13          	li	s4,120
    23d6:	fd450023          	sb	s4,-64(a0)
  p[1] = '\0';
    23da:	fc0500a3          	sb	zero,-63(a0)
  int fd = open(p, O_RDWR | O_CREATE);
    23de:	20200593          	li	a1,514
    23e2:	854a                	mv	a0,s2
    23e4:	497020ef          	jal	507a <open>
    23e8:	89aa                	mv	s3,a0
  write(fd, p, 1);
    23ea:	4605                	li	a2,1
    23ec:	85ca                	mv	a1,s2
    23ee:	46d020ef          	jal	505a <write>
  close(fd);
    23f2:	854e                	mv	a0,s3
    23f4:	46f020ef          	jal	5062 <close>
  fd = open(p, O_RDWR);
    23f8:	4589                	li	a1,2
    23fa:	854a                	mv	a0,s2
    23fc:	47f020ef          	jal	507a <open>
  p[0] = '\0';
    2400:	fc048023          	sb	zero,-64(s1)
  read(fd, p, 1);
    2404:	4605                	li	a2,1
    2406:	85ca                	mv	a1,s2
    2408:	44b020ef          	jal	5052 <read>
  if (p[0] != 'x')
    240c:	fc04c783          	lbu	a5,-64(s1)
    2410:	03479263          	bne	a5,s4,2434 <sbrklast+0x9c>
}
    2414:	70a2                	ld	ra,40(sp)
    2416:	7402                	ld	s0,32(sp)
    2418:	64e2                	ld	s1,24(sp)
    241a:	6942                	ld	s2,16(sp)
    241c:	69a2                	ld	s3,8(sp)
    241e:	6a02                	ld	s4,0(sp)
    2420:	6145                	addi	sp,sp,48
    2422:	8082                	ret
    sbrk(PGSIZE - (top % PGSIZE));
    2424:	0347d513          	srli	a0,a5,0x34
    2428:	6785                	lui	a5,0x1
    242a:	40a7853b          	subw	a0,a5,a0
    242e:	3d9020ef          	jal	5006 <sbrk>
    2432:	b749                	j	23b4 <sbrklast+0x1c>
    exit(1);
    2434:	4505                	li	a0,1
    2436:	405020ef          	jal	503a <exit>

000000000000243a <sbrk8000>:
{
    243a:	1141                	addi	sp,sp,-16
    243c:	e406                	sd	ra,8(sp)
    243e:	e022                	sd	s0,0(sp)
    2440:	0800                	addi	s0,sp,16
  sbrk(0x80000004);
    2442:	80000537          	lui	a0,0x80000
    2446:	0511                	addi	a0,a0,4 # ffffffff80000004 <base+0xffffffff7fff133c>
    2448:	3bf020ef          	jal	5006 <sbrk>
  volatile char *top = sbrk(0);
    244c:	4501                	li	a0,0
    244e:	3b9020ef          	jal	5006 <sbrk>
  *(top - 1) = *(top - 1) + 1;
    2452:	fff54783          	lbu	a5,-1(a0)
    2456:	2785                	addiw	a5,a5,1 # 1001 <badarg+0x1>
    2458:	0ff7f793          	zext.b	a5,a5
    245c:	fef50fa3          	sb	a5,-1(a0)
}
    2460:	60a2                	ld	ra,8(sp)
    2462:	6402                	ld	s0,0(sp)
    2464:	0141                	addi	sp,sp,16
    2466:	8082                	ret

0000000000002468 <execout>:
{
    2468:	715d                	addi	sp,sp,-80
    246a:	e486                	sd	ra,72(sp)
    246c:	e0a2                	sd	s0,64(sp)
    246e:	fc26                	sd	s1,56(sp)
    2470:	f84a                	sd	s2,48(sp)
    2472:	f44e                	sd	s3,40(sp)
    2474:	f052                	sd	s4,32(sp)
    2476:	0880                	addi	s0,sp,80
  for (int avail = 0; avail < 15; avail++) {
    2478:	4901                	li	s2,0
    247a:	49bd                	li	s3,15
    int pid = fork();
    247c:	3b7020ef          	jal	5032 <fork>
    2480:	84aa                	mv	s1,a0
    if (pid < 0) {
    2482:	00054c63          	bltz	a0,249a <execout+0x32>
    } else if (pid == 0) {
    2486:	c11d                	beqz	a0,24ac <execout+0x44>
      wait((int *)0);
    2488:	4501                	li	a0,0
    248a:	3b9020ef          	jal	5042 <wait>
  for (int avail = 0; avail < 15; avail++) {
    248e:	2905                	addiw	s2,s2,1
    2490:	ff3916e3          	bne	s2,s3,247c <execout+0x14>
  exit(0);
    2494:	4501                	li	a0,0
    2496:	3a5020ef          	jal	503a <exit>
      printf("fork failed\n");
    249a:	00005517          	auipc	a0,0x5
    249e:	02650513          	addi	a0,a0,38 # 74c0 <malloc+0x1fa2>
    24a2:	7c9020ef          	jal	546a <printf>
      exit(1);
    24a6:	4505                	li	a0,1
    24a8:	393020ef          	jal	503a <exit>
        if (a == SBRK_ERROR)
    24ac:	59fd                	li	s3,-1
        *(a + PGSIZE - 1) = 1;
    24ae:	4a05                	li	s4,1
        char *a = sbrk(PGSIZE);
    24b0:	6505                	lui	a0,0x1
    24b2:	355020ef          	jal	5006 <sbrk>
        if (a == SBRK_ERROR)
    24b6:	01350763          	beq	a0,s3,24c4 <execout+0x5c>
        *(a + PGSIZE - 1) = 1;
    24ba:	6785                	lui	a5,0x1
    24bc:	953e                	add	a0,a0,a5
    24be:	ff450fa3          	sb	s4,-1(a0) # fff <pgbug+0x2b>
      while (1) {
    24c2:	b7fd                	j	24b0 <execout+0x48>
      for (int i = 0; i < avail; i++)
    24c4:	01205863          	blez	s2,24d4 <execout+0x6c>
        sbrk(-PGSIZE);
    24c8:	757d                	lui	a0,0xfffff
    24ca:	33d020ef          	jal	5006 <sbrk>
      for (int i = 0; i < avail; i++)
    24ce:	2485                	addiw	s1,s1,1
    24d0:	ff249ce3          	bne	s1,s2,24c8 <execout+0x60>
      close(1);
    24d4:	4505                	li	a0,1
    24d6:	38d020ef          	jal	5062 <close>
      char *args[] = {"echo", "x", 0};
    24da:	00003517          	auipc	a0,0x3
    24de:	17e50513          	addi	a0,a0,382 # 5658 <malloc+0x13a>
    24e2:	faa43c23          	sd	a0,-72(s0)
    24e6:	00003797          	auipc	a5,0x3
    24ea:	1e278793          	addi	a5,a5,482 # 56c8 <malloc+0x1aa>
    24ee:	fcf43023          	sd	a5,-64(s0)
    24f2:	fc043423          	sd	zero,-56(s0)
      exec("echo", args);
    24f6:	fb840593          	addi	a1,s0,-72
    24fa:	379020ef          	jal	5072 <exec>
      exit(0);
    24fe:	4501                	li	a0,0
    2500:	33b020ef          	jal	503a <exit>

0000000000002504 <fourteen>:
{
    2504:	1101                	addi	sp,sp,-32
    2506:	ec06                	sd	ra,24(sp)
    2508:	e822                	sd	s0,16(sp)
    250a:	e426                	sd	s1,8(sp)
    250c:	1000                	addi	s0,sp,32
    250e:	84aa                	mv	s1,a0
  if (mkdir("12345678901234") != 0) {
    2510:	00004517          	auipc	a0,0x4
    2514:	17850513          	addi	a0,a0,376 # 6688 <malloc+0x116a>
    2518:	38b020ef          	jal	50a2 <mkdir>
    251c:	e555                	bnez	a0,25c8 <fourteen+0xc4>
  if (mkdir("12345678901234/123456789012345") != 0) {
    251e:	00004517          	auipc	a0,0x4
    2522:	fc250513          	addi	a0,a0,-62 # 64e0 <malloc+0xfc2>
    2526:	37d020ef          	jal	50a2 <mkdir>
    252a:	e94d                	bnez	a0,25dc <fourteen+0xd8>
  fd = open("123456789012345/123456789012345/123456789012345", O_CREATE);
    252c:	20000593          	li	a1,512
    2530:	00004517          	auipc	a0,0x4
    2534:	00850513          	addi	a0,a0,8 # 6538 <malloc+0x101a>
    2538:	343020ef          	jal	507a <open>
  if (fd < 0) {
    253c:	0a054a63          	bltz	a0,25f0 <fourteen+0xec>
  close(fd);
    2540:	323020ef          	jal	5062 <close>
  fd = open("12345678901234/12345678901234/12345678901234", 0);
    2544:	4581                	li	a1,0
    2546:	00004517          	auipc	a0,0x4
    254a:	06a50513          	addi	a0,a0,106 # 65b0 <malloc+0x1092>
    254e:	32d020ef          	jal	507a <open>
  if (fd < 0) {
    2552:	0a054963          	bltz	a0,2604 <fourteen+0x100>
  close(fd);
    2556:	30d020ef          	jal	5062 <close>
  if (mkdir("12345678901234/12345678901234") == 0) {
    255a:	00004517          	auipc	a0,0x4
    255e:	0c650513          	addi	a0,a0,198 # 6620 <malloc+0x1102>
    2562:	341020ef          	jal	50a2 <mkdir>
    2566:	c94d                	beqz	a0,2618 <fourteen+0x114>
  if (mkdir("123456789012345/12345678901234") == 0) {
    2568:	00004517          	auipc	a0,0x4
    256c:	11050513          	addi	a0,a0,272 # 6678 <malloc+0x115a>
    2570:	333020ef          	jal	50a2 <mkdir>
    2574:	cd45                	beqz	a0,262c <fourteen+0x128>
  unlink("123456789012345/12345678901234");
    2576:	00004517          	auipc	a0,0x4
    257a:	10250513          	addi	a0,a0,258 # 6678 <malloc+0x115a>
    257e:	30d020ef          	jal	508a <unlink>
  unlink("12345678901234/12345678901234");
    2582:	00004517          	auipc	a0,0x4
    2586:	09e50513          	addi	a0,a0,158 # 6620 <malloc+0x1102>
    258a:	301020ef          	jal	508a <unlink>
  unlink("12345678901234/12345678901234/12345678901234");
    258e:	00004517          	auipc	a0,0x4
    2592:	02250513          	addi	a0,a0,34 # 65b0 <malloc+0x1092>
    2596:	2f5020ef          	jal	508a <unlink>
  unlink("123456789012345/123456789012345/123456789012345");
    259a:	00004517          	auipc	a0,0x4
    259e:	f9e50513          	addi	a0,a0,-98 # 6538 <malloc+0x101a>
    25a2:	2e9020ef          	jal	508a <unlink>
  unlink("12345678901234/123456789012345");
    25a6:	00004517          	auipc	a0,0x4
    25aa:	f3a50513          	addi	a0,a0,-198 # 64e0 <malloc+0xfc2>
    25ae:	2dd020ef          	jal	508a <unlink>
  unlink("12345678901234");
    25b2:	00004517          	auipc	a0,0x4
    25b6:	0d650513          	addi	a0,a0,214 # 6688 <malloc+0x116a>
    25ba:	2d1020ef          	jal	508a <unlink>
}
    25be:	60e2                	ld	ra,24(sp)
    25c0:	6442                	ld	s0,16(sp)
    25c2:	64a2                	ld	s1,8(sp)
    25c4:	6105                	addi	sp,sp,32
    25c6:	8082                	ret
    printf("%s: mkdir 12345678901234 failed\n", s);
    25c8:	85a6                	mv	a1,s1
    25ca:	00004517          	auipc	a0,0x4
    25ce:	eee50513          	addi	a0,a0,-274 # 64b8 <malloc+0xf9a>
    25d2:	699020ef          	jal	546a <printf>
    exit(1);
    25d6:	4505                	li	a0,1
    25d8:	263020ef          	jal	503a <exit>
    printf("%s: mkdir 12345678901234/123456789012345 failed\n", s);
    25dc:	85a6                	mv	a1,s1
    25de:	00004517          	auipc	a0,0x4
    25e2:	f2250513          	addi	a0,a0,-222 # 6500 <malloc+0xfe2>
    25e6:	685020ef          	jal	546a <printf>
    exit(1);
    25ea:	4505                	li	a0,1
    25ec:	24f020ef          	jal	503a <exit>
    printf(
    25f0:	85a6                	mv	a1,s1
    25f2:	00004517          	auipc	a0,0x4
    25f6:	f7650513          	addi	a0,a0,-138 # 6568 <malloc+0x104a>
    25fa:	671020ef          	jal	546a <printf>
    exit(1);
    25fe:	4505                	li	a0,1
    2600:	23b020ef          	jal	503a <exit>
    printf("%s: open 12345678901234/12345678901234/12345678901234 failed\n", s);
    2604:	85a6                	mv	a1,s1
    2606:	00004517          	auipc	a0,0x4
    260a:	fda50513          	addi	a0,a0,-38 # 65e0 <malloc+0x10c2>
    260e:	65d020ef          	jal	546a <printf>
    exit(1);
    2612:	4505                	li	a0,1
    2614:	227020ef          	jal	503a <exit>
    printf("%s: mkdir 12345678901234/12345678901234 succeeded!\n", s);
    2618:	85a6                	mv	a1,s1
    261a:	00004517          	auipc	a0,0x4
    261e:	02650513          	addi	a0,a0,38 # 6640 <malloc+0x1122>
    2622:	649020ef          	jal	546a <printf>
    exit(1);
    2626:	4505                	li	a0,1
    2628:	213020ef          	jal	503a <exit>
    printf("%s: mkdir 12345678901234/123456789012345 succeeded!\n", s);
    262c:	85a6                	mv	a1,s1
    262e:	00004517          	auipc	a0,0x4
    2632:	06a50513          	addi	a0,a0,106 # 6698 <malloc+0x117a>
    2636:	635020ef          	jal	546a <printf>
    exit(1);
    263a:	4505                	li	a0,1
    263c:	1ff020ef          	jal	503a <exit>

0000000000002640 <diskfull>:
{
    2640:	b8010113          	addi	sp,sp,-1152
    2644:	46113c23          	sd	ra,1144(sp)
    2648:	46813823          	sd	s0,1136(sp)
    264c:	46913423          	sd	s1,1128(sp)
    2650:	47213023          	sd	s2,1120(sp)
    2654:	45313c23          	sd	s3,1112(sp)
    2658:	45413823          	sd	s4,1104(sp)
    265c:	45513423          	sd	s5,1096(sp)
    2660:	45613023          	sd	s6,1088(sp)
    2664:	43713c23          	sd	s7,1080(sp)
    2668:	43813823          	sd	s8,1072(sp)
    266c:	43913423          	sd	s9,1064(sp)
    2670:	48010413          	addi	s0,sp,1152
    2674:	8caa                	mv	s9,a0
  unlink("diskfulldir");
    2676:	00004517          	auipc	a0,0x4
    267a:	05a50513          	addi	a0,a0,90 # 66d0 <malloc+0x11b2>
    267e:	20d020ef          	jal	508a <unlink>
    2682:	03000993          	li	s3,48
    name[0] = 'b';
    2686:	06200b13          	li	s6,98
    name[1] = 'i';
    268a:	06900a93          	li	s5,105
    name[2] = 'g';
    268e:	06700a13          	li	s4,103
    2692:	10c00b93          	li	s7,268
  for (fi = 0; done == 0 && '0' + fi < 0177; fi++) {
    2696:	07f00c13          	li	s8,127
    269a:	aab9                	j	27f8 <diskfull+0x1b8>
      printf("%s: could not create file %s\n", s, name);
    269c:	b8040613          	addi	a2,s0,-1152
    26a0:	85e6                	mv	a1,s9
    26a2:	00004517          	auipc	a0,0x4
    26a6:	03e50513          	addi	a0,a0,62 # 66e0 <malloc+0x11c2>
    26aa:	5c1020ef          	jal	546a <printf>
      break;
    26ae:	a039                	j	26bc <diskfull+0x7c>
        close(fd);
    26b0:	854a                	mv	a0,s2
    26b2:	1b1020ef          	jal	5062 <close>
    close(fd);
    26b6:	854a                	mv	a0,s2
    26b8:	1ab020ef          	jal	5062 <close>
  for (int i = 0; i < nzz; i++) {
    26bc:	4481                	li	s1,0
    name[0] = 'z';
    26be:	07a00913          	li	s2,122
  for (int i = 0; i < nzz; i++) {
    26c2:	08000993          	li	s3,128
    name[0] = 'z';
    26c6:	bb240023          	sb	s2,-1120(s0)
    name[1] = 'z';
    26ca:	bb2400a3          	sb	s2,-1119(s0)
    name[2] = '0' + (i / 32);
    26ce:	41f4d71b          	sraiw	a4,s1,0x1f
    26d2:	01b7571b          	srliw	a4,a4,0x1b
    26d6:	009707bb          	addw	a5,a4,s1
    26da:	4057d69b          	sraiw	a3,a5,0x5
    26de:	0306869b          	addiw	a3,a3,48
    26e2:	bad40123          	sb	a3,-1118(s0)
    name[3] = '0' + (i % 32);
    26e6:	8bfd                	andi	a5,a5,31
    26e8:	9f99                	subw	a5,a5,a4
    26ea:	0307879b          	addiw	a5,a5,48
    26ee:	baf401a3          	sb	a5,-1117(s0)
    name[4] = '\0';
    26f2:	ba040223          	sb	zero,-1116(s0)
    unlink(name);
    26f6:	ba040513          	addi	a0,s0,-1120
    26fa:	191020ef          	jal	508a <unlink>
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
    26fe:	60200593          	li	a1,1538
    2702:	ba040513          	addi	a0,s0,-1120
    2706:	175020ef          	jal	507a <open>
    if (fd < 0)
    270a:	00054763          	bltz	a0,2718 <diskfull+0xd8>
    close(fd);
    270e:	155020ef          	jal	5062 <close>
  for (int i = 0; i < nzz; i++) {
    2712:	2485                	addiw	s1,s1,1
    2714:	fb3499e3          	bne	s1,s3,26c6 <diskfull+0x86>
  if (mkdir("diskfulldir") == 0)
    2718:	00004517          	auipc	a0,0x4
    271c:	fb850513          	addi	a0,a0,-72 # 66d0 <malloc+0x11b2>
    2720:	183020ef          	jal	50a2 <mkdir>
    2724:	12050063          	beqz	a0,2844 <diskfull+0x204>
  unlink("diskfulldir");
    2728:	00004517          	auipc	a0,0x4
    272c:	fa850513          	addi	a0,a0,-88 # 66d0 <malloc+0x11b2>
    2730:	15b020ef          	jal	508a <unlink>
  for (int i = 0; i < nzz; i++) {
    2734:	4481                	li	s1,0
    name[0] = 'z';
    2736:	07a00913          	li	s2,122
  for (int i = 0; i < nzz; i++) {
    273a:	08000993          	li	s3,128
    name[0] = 'z';
    273e:	bb240023          	sb	s2,-1120(s0)
    name[1] = 'z';
    2742:	bb2400a3          	sb	s2,-1119(s0)
    name[2] = '0' + (i / 32);
    2746:	41f4d71b          	sraiw	a4,s1,0x1f
    274a:	01b7571b          	srliw	a4,a4,0x1b
    274e:	009707bb          	addw	a5,a4,s1
    2752:	4057d69b          	sraiw	a3,a5,0x5
    2756:	0306869b          	addiw	a3,a3,48
    275a:	bad40123          	sb	a3,-1118(s0)
    name[3] = '0' + (i % 32);
    275e:	8bfd                	andi	a5,a5,31
    2760:	9f99                	subw	a5,a5,a4
    2762:	0307879b          	addiw	a5,a5,48
    2766:	baf401a3          	sb	a5,-1117(s0)
    name[4] = '\0';
    276a:	ba040223          	sb	zero,-1116(s0)
    unlink(name);
    276e:	ba040513          	addi	a0,s0,-1120
    2772:	119020ef          	jal	508a <unlink>
  for (int i = 0; i < nzz; i++) {
    2776:	2485                	addiw	s1,s1,1
    2778:	fd3493e3          	bne	s1,s3,273e <diskfull+0xfe>
    277c:	03000493          	li	s1,48
    name[0] = 'b';
    2780:	06200a93          	li	s5,98
    name[1] = 'i';
    2784:	06900a13          	li	s4,105
    name[2] = 'g';
    2788:	06700993          	li	s3,103
  for (int i = 0; '0' + i < 0177; i++) {
    278c:	07f00913          	li	s2,127
    name[0] = 'b';
    2790:	bb540023          	sb	s5,-1120(s0)
    name[1] = 'i';
    2794:	bb4400a3          	sb	s4,-1119(s0)
    name[2] = 'g';
    2798:	bb340123          	sb	s3,-1118(s0)
    name[3] = '0' + i;
    279c:	ba9401a3          	sb	s1,-1117(s0)
    name[4] = '\0';
    27a0:	ba040223          	sb	zero,-1116(s0)
    unlink(name);
    27a4:	ba040513          	addi	a0,s0,-1120
    27a8:	0e3020ef          	jal	508a <unlink>
  for (int i = 0; '0' + i < 0177; i++) {
    27ac:	2485                	addiw	s1,s1,1
    27ae:	0ff4f493          	zext.b	s1,s1
    27b2:	fd249fe3          	bne	s1,s2,2790 <diskfull+0x150>
}
    27b6:	47813083          	ld	ra,1144(sp)
    27ba:	47013403          	ld	s0,1136(sp)
    27be:	46813483          	ld	s1,1128(sp)
    27c2:	46013903          	ld	s2,1120(sp)
    27c6:	45813983          	ld	s3,1112(sp)
    27ca:	45013a03          	ld	s4,1104(sp)
    27ce:	44813a83          	ld	s5,1096(sp)
    27d2:	44013b03          	ld	s6,1088(sp)
    27d6:	43813b83          	ld	s7,1080(sp)
    27da:	43013c03          	ld	s8,1072(sp)
    27de:	42813c83          	ld	s9,1064(sp)
    27e2:	48010113          	addi	sp,sp,1152
    27e6:	8082                	ret
    close(fd);
    27e8:	854a                	mv	a0,s2
    27ea:	079020ef          	jal	5062 <close>
  for (fi = 0; done == 0 && '0' + fi < 0177; fi++) {
    27ee:	2985                	addiw	s3,s3,1
    27f0:	0ff9f993          	zext.b	s3,s3
    27f4:	ed8984e3          	beq	s3,s8,26bc <diskfull+0x7c>
    name[0] = 'b';
    27f8:	b9640023          	sb	s6,-1152(s0)
    name[1] = 'i';
    27fc:	b95400a3          	sb	s5,-1151(s0)
    name[2] = 'g';
    2800:	b9440123          	sb	s4,-1150(s0)
    name[3] = '0' + fi;
    2804:	b93401a3          	sb	s3,-1149(s0)
    name[4] = '\0';
    2808:	b8040223          	sb	zero,-1148(s0)
    unlink(name);
    280c:	b8040513          	addi	a0,s0,-1152
    2810:	07b020ef          	jal	508a <unlink>
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
    2814:	60200593          	li	a1,1538
    2818:	b8040513          	addi	a0,s0,-1152
    281c:	05f020ef          	jal	507a <open>
    2820:	892a                	mv	s2,a0
    if (fd < 0) {
    2822:	e6054de3          	bltz	a0,269c <diskfull+0x5c>
    2826:	84de                	mv	s1,s7
      if (write(fd, buf, BSIZE) != BSIZE) {
    2828:	40000613          	li	a2,1024
    282c:	ba040593          	addi	a1,s0,-1120
    2830:	854a                	mv	a0,s2
    2832:	029020ef          	jal	505a <write>
    2836:	40000793          	li	a5,1024
    283a:	e6f51be3          	bne	a0,a5,26b0 <diskfull+0x70>
    for (int i = 0; i < MAXFILE; i++) {
    283e:	34fd                	addiw	s1,s1,-1
    2840:	f4e5                	bnez	s1,2828 <diskfull+0x1e8>
    2842:	b75d                	j	27e8 <diskfull+0x1a8>
    printf("%s: mkdir(diskfulldir) unexpectedly succeeded!\n", s);
    2844:	85e6                	mv	a1,s9
    2846:	00004517          	auipc	a0,0x4
    284a:	eba50513          	addi	a0,a0,-326 # 6700 <malloc+0x11e2>
    284e:	41d020ef          	jal	546a <printf>
    2852:	bdd9                	j	2728 <diskfull+0xe8>

0000000000002854 <iputtest>:
{
    2854:	1101                	addi	sp,sp,-32
    2856:	ec06                	sd	ra,24(sp)
    2858:	e822                	sd	s0,16(sp)
    285a:	e426                	sd	s1,8(sp)
    285c:	1000                	addi	s0,sp,32
    285e:	84aa                	mv	s1,a0
  if (mkdir("iputdir") < 0) {
    2860:	00004517          	auipc	a0,0x4
    2864:	ed050513          	addi	a0,a0,-304 # 6730 <malloc+0x1212>
    2868:	03b020ef          	jal	50a2 <mkdir>
    286c:	02054f63          	bltz	a0,28aa <iputtest+0x56>
  if (chdir("iputdir") < 0) {
    2870:	00004517          	auipc	a0,0x4
    2874:	ec050513          	addi	a0,a0,-320 # 6730 <malloc+0x1212>
    2878:	033020ef          	jal	50aa <chdir>
    287c:	04054163          	bltz	a0,28be <iputtest+0x6a>
  if (unlink("../iputdir") < 0) {
    2880:	00004517          	auipc	a0,0x4
    2884:	ef050513          	addi	a0,a0,-272 # 6770 <malloc+0x1252>
    2888:	003020ef          	jal	508a <unlink>
    288c:	04054363          	bltz	a0,28d2 <iputtest+0x7e>
  if (chdir("/") < 0) {
    2890:	00004517          	auipc	a0,0x4
    2894:	f1050513          	addi	a0,a0,-240 # 67a0 <malloc+0x1282>
    2898:	013020ef          	jal	50aa <chdir>
    289c:	04054563          	bltz	a0,28e6 <iputtest+0x92>
}
    28a0:	60e2                	ld	ra,24(sp)
    28a2:	6442                	ld	s0,16(sp)
    28a4:	64a2                	ld	s1,8(sp)
    28a6:	6105                	addi	sp,sp,32
    28a8:	8082                	ret
    printf("%s: mkdir failed\n", s);
    28aa:	85a6                	mv	a1,s1
    28ac:	00004517          	auipc	a0,0x4
    28b0:	e8c50513          	addi	a0,a0,-372 # 6738 <malloc+0x121a>
    28b4:	3b7020ef          	jal	546a <printf>
    exit(1);
    28b8:	4505                	li	a0,1
    28ba:	780020ef          	jal	503a <exit>
    printf("%s: chdir iputdir failed\n", s);
    28be:	85a6                	mv	a1,s1
    28c0:	00004517          	auipc	a0,0x4
    28c4:	e9050513          	addi	a0,a0,-368 # 6750 <malloc+0x1232>
    28c8:	3a3020ef          	jal	546a <printf>
    exit(1);
    28cc:	4505                	li	a0,1
    28ce:	76c020ef          	jal	503a <exit>
    printf("%s: unlink ../iputdir failed\n", s);
    28d2:	85a6                	mv	a1,s1
    28d4:	00004517          	auipc	a0,0x4
    28d8:	eac50513          	addi	a0,a0,-340 # 6780 <malloc+0x1262>
    28dc:	38f020ef          	jal	546a <printf>
    exit(1);
    28e0:	4505                	li	a0,1
    28e2:	758020ef          	jal	503a <exit>
    printf("%s: chdir / failed\n", s);
    28e6:	85a6                	mv	a1,s1
    28e8:	00004517          	auipc	a0,0x4
    28ec:	ec050513          	addi	a0,a0,-320 # 67a8 <malloc+0x128a>
    28f0:	37b020ef          	jal	546a <printf>
    exit(1);
    28f4:	4505                	li	a0,1
    28f6:	744020ef          	jal	503a <exit>

00000000000028fa <exitiputtest>:
{
    28fa:	7179                	addi	sp,sp,-48
    28fc:	f406                	sd	ra,40(sp)
    28fe:	f022                	sd	s0,32(sp)
    2900:	ec26                	sd	s1,24(sp)
    2902:	1800                	addi	s0,sp,48
    2904:	84aa                	mv	s1,a0
  pid = fork();
    2906:	72c020ef          	jal	5032 <fork>
  if (pid < 0) {
    290a:	02054e63          	bltz	a0,2946 <exitiputtest+0x4c>
  if (pid == 0) {
    290e:	e541                	bnez	a0,2996 <exitiputtest+0x9c>
    if (mkdir("iputdir") < 0) {
    2910:	00004517          	auipc	a0,0x4
    2914:	e2050513          	addi	a0,a0,-480 # 6730 <malloc+0x1212>
    2918:	78a020ef          	jal	50a2 <mkdir>
    291c:	02054f63          	bltz	a0,295a <exitiputtest+0x60>
    if (chdir("iputdir") < 0) {
    2920:	00004517          	auipc	a0,0x4
    2924:	e1050513          	addi	a0,a0,-496 # 6730 <malloc+0x1212>
    2928:	782020ef          	jal	50aa <chdir>
    292c:	04054163          	bltz	a0,296e <exitiputtest+0x74>
    if (unlink("../iputdir") < 0) {
    2930:	00004517          	auipc	a0,0x4
    2934:	e4050513          	addi	a0,a0,-448 # 6770 <malloc+0x1252>
    2938:	752020ef          	jal	508a <unlink>
    293c:	04054363          	bltz	a0,2982 <exitiputtest+0x88>
    exit(0);
    2940:	4501                	li	a0,0
    2942:	6f8020ef          	jal	503a <exit>
    printf("%s: fork failed\n", s);
    2946:	85a6                	mv	a1,s1
    2948:	00003517          	auipc	a0,0x3
    294c:	5a050513          	addi	a0,a0,1440 # 5ee8 <malloc+0x9ca>
    2950:	31b020ef          	jal	546a <printf>
    exit(1);
    2954:	4505                	li	a0,1
    2956:	6e4020ef          	jal	503a <exit>
      printf("%s: mkdir failed\n", s);
    295a:	85a6                	mv	a1,s1
    295c:	00004517          	auipc	a0,0x4
    2960:	ddc50513          	addi	a0,a0,-548 # 6738 <malloc+0x121a>
    2964:	307020ef          	jal	546a <printf>
      exit(1);
    2968:	4505                	li	a0,1
    296a:	6d0020ef          	jal	503a <exit>
      printf("%s: child chdir failed\n", s);
    296e:	85a6                	mv	a1,s1
    2970:	00004517          	auipc	a0,0x4
    2974:	e5050513          	addi	a0,a0,-432 # 67c0 <malloc+0x12a2>
    2978:	2f3020ef          	jal	546a <printf>
      exit(1);
    297c:	4505                	li	a0,1
    297e:	6bc020ef          	jal	503a <exit>
      printf("%s: unlink ../iputdir failed\n", s);
    2982:	85a6                	mv	a1,s1
    2984:	00004517          	auipc	a0,0x4
    2988:	dfc50513          	addi	a0,a0,-516 # 6780 <malloc+0x1262>
    298c:	2df020ef          	jal	546a <printf>
      exit(1);
    2990:	4505                	li	a0,1
    2992:	6a8020ef          	jal	503a <exit>
  wait(&xstatus);
    2996:	fdc40513          	addi	a0,s0,-36
    299a:	6a8020ef          	jal	5042 <wait>
  exit(xstatus);
    299e:	fdc42503          	lw	a0,-36(s0)
    29a2:	698020ef          	jal	503a <exit>

00000000000029a6 <dirtest>:
{
    29a6:	1101                	addi	sp,sp,-32
    29a8:	ec06                	sd	ra,24(sp)
    29aa:	e822                	sd	s0,16(sp)
    29ac:	e426                	sd	s1,8(sp)
    29ae:	1000                	addi	s0,sp,32
    29b0:	84aa                	mv	s1,a0
  if (mkdir("dir0") < 0) {
    29b2:	00004517          	auipc	a0,0x4
    29b6:	e2650513          	addi	a0,a0,-474 # 67d8 <malloc+0x12ba>
    29ba:	6e8020ef          	jal	50a2 <mkdir>
    29be:	02054f63          	bltz	a0,29fc <dirtest+0x56>
  if (chdir("dir0") < 0) {
    29c2:	00004517          	auipc	a0,0x4
    29c6:	e1650513          	addi	a0,a0,-490 # 67d8 <malloc+0x12ba>
    29ca:	6e0020ef          	jal	50aa <chdir>
    29ce:	04054163          	bltz	a0,2a10 <dirtest+0x6a>
  if (chdir("..") < 0) {
    29d2:	00004517          	auipc	a0,0x4
    29d6:	e2650513          	addi	a0,a0,-474 # 67f8 <malloc+0x12da>
    29da:	6d0020ef          	jal	50aa <chdir>
    29de:	04054363          	bltz	a0,2a24 <dirtest+0x7e>
  if (unlink("dir0") < 0) {
    29e2:	00004517          	auipc	a0,0x4
    29e6:	df650513          	addi	a0,a0,-522 # 67d8 <malloc+0x12ba>
    29ea:	6a0020ef          	jal	508a <unlink>
    29ee:	04054563          	bltz	a0,2a38 <dirtest+0x92>
}
    29f2:	60e2                	ld	ra,24(sp)
    29f4:	6442                	ld	s0,16(sp)
    29f6:	64a2                	ld	s1,8(sp)
    29f8:	6105                	addi	sp,sp,32
    29fa:	8082                	ret
    printf("%s: mkdir failed\n", s);
    29fc:	85a6                	mv	a1,s1
    29fe:	00004517          	auipc	a0,0x4
    2a02:	d3a50513          	addi	a0,a0,-710 # 6738 <malloc+0x121a>
    2a06:	265020ef          	jal	546a <printf>
    exit(1);
    2a0a:	4505                	li	a0,1
    2a0c:	62e020ef          	jal	503a <exit>
    printf("%s: chdir dir0 failed\n", s);
    2a10:	85a6                	mv	a1,s1
    2a12:	00004517          	auipc	a0,0x4
    2a16:	dce50513          	addi	a0,a0,-562 # 67e0 <malloc+0x12c2>
    2a1a:	251020ef          	jal	546a <printf>
    exit(1);
    2a1e:	4505                	li	a0,1
    2a20:	61a020ef          	jal	503a <exit>
    printf("%s: chdir .. failed\n", s);
    2a24:	85a6                	mv	a1,s1
    2a26:	00004517          	auipc	a0,0x4
    2a2a:	dda50513          	addi	a0,a0,-550 # 6800 <malloc+0x12e2>
    2a2e:	23d020ef          	jal	546a <printf>
    exit(1);
    2a32:	4505                	li	a0,1
    2a34:	606020ef          	jal	503a <exit>
    printf("%s: unlink dir0 failed\n", s);
    2a38:	85a6                	mv	a1,s1
    2a3a:	00004517          	auipc	a0,0x4
    2a3e:	dde50513          	addi	a0,a0,-546 # 6818 <malloc+0x12fa>
    2a42:	229020ef          	jal	546a <printf>
    exit(1);
    2a46:	4505                	li	a0,1
    2a48:	5f2020ef          	jal	503a <exit>

0000000000002a4c <subdir>:
{
    2a4c:	1101                	addi	sp,sp,-32
    2a4e:	ec06                	sd	ra,24(sp)
    2a50:	e822                	sd	s0,16(sp)
    2a52:	e426                	sd	s1,8(sp)
    2a54:	e04a                	sd	s2,0(sp)
    2a56:	1000                	addi	s0,sp,32
    2a58:	892a                	mv	s2,a0
  unlink("ff");
    2a5a:	00004517          	auipc	a0,0x4
    2a5e:	f0650513          	addi	a0,a0,-250 # 6960 <malloc+0x1442>
    2a62:	628020ef          	jal	508a <unlink>
  if (mkdir("dd") != 0) {
    2a66:	00004517          	auipc	a0,0x4
    2a6a:	dca50513          	addi	a0,a0,-566 # 6830 <malloc+0x1312>
    2a6e:	634020ef          	jal	50a2 <mkdir>
    2a72:	2e051263          	bnez	a0,2d56 <subdir+0x30a>
  fd = open("dd/ff", O_CREATE | O_RDWR);
    2a76:	20200593          	li	a1,514
    2a7a:	00004517          	auipc	a0,0x4
    2a7e:	dd650513          	addi	a0,a0,-554 # 6850 <malloc+0x1332>
    2a82:	5f8020ef          	jal	507a <open>
    2a86:	84aa                	mv	s1,a0
  if (fd < 0) {
    2a88:	2e054163          	bltz	a0,2d6a <subdir+0x31e>
  write(fd, "ff", 2);
    2a8c:	4609                	li	a2,2
    2a8e:	00004597          	auipc	a1,0x4
    2a92:	ed258593          	addi	a1,a1,-302 # 6960 <malloc+0x1442>
    2a96:	5c4020ef          	jal	505a <write>
  close(fd);
    2a9a:	8526                	mv	a0,s1
    2a9c:	5c6020ef          	jal	5062 <close>
  if (unlink("dd") >= 0) {
    2aa0:	00004517          	auipc	a0,0x4
    2aa4:	d9050513          	addi	a0,a0,-624 # 6830 <malloc+0x1312>
    2aa8:	5e2020ef          	jal	508a <unlink>
    2aac:	2c055963          	bgez	a0,2d7e <subdir+0x332>
  if (mkdir("/dd/dd") != 0) {
    2ab0:	00004517          	auipc	a0,0x4
    2ab4:	df850513          	addi	a0,a0,-520 # 68a8 <malloc+0x138a>
    2ab8:	5ea020ef          	jal	50a2 <mkdir>
    2abc:	2c051b63          	bnez	a0,2d92 <subdir+0x346>
  fd = open("dd/dd/ff", O_CREATE | O_RDWR);
    2ac0:	20200593          	li	a1,514
    2ac4:	00004517          	auipc	a0,0x4
    2ac8:	e0c50513          	addi	a0,a0,-500 # 68d0 <malloc+0x13b2>
    2acc:	5ae020ef          	jal	507a <open>
    2ad0:	84aa                	mv	s1,a0
  if (fd < 0) {
    2ad2:	2c054a63          	bltz	a0,2da6 <subdir+0x35a>
  write(fd, "FF", 2);
    2ad6:	4609                	li	a2,2
    2ad8:	00004597          	auipc	a1,0x4
    2adc:	e2858593          	addi	a1,a1,-472 # 6900 <malloc+0x13e2>
    2ae0:	57a020ef          	jal	505a <write>
  close(fd);
    2ae4:	8526                	mv	a0,s1
    2ae6:	57c020ef          	jal	5062 <close>
  fd = open("dd/dd/../ff", 0);
    2aea:	4581                	li	a1,0
    2aec:	00004517          	auipc	a0,0x4
    2af0:	e1c50513          	addi	a0,a0,-484 # 6908 <malloc+0x13ea>
    2af4:	586020ef          	jal	507a <open>
    2af8:	84aa                	mv	s1,a0
  if (fd < 0) {
    2afa:	2c054063          	bltz	a0,2dba <subdir+0x36e>
  cc = read(fd, buf, sizeof(buf));
    2afe:	660d                	lui	a2,0x3
    2b00:	00009597          	auipc	a1,0x9
    2b04:	1c858593          	addi	a1,a1,456 # bcc8 <buf>
    2b08:	54a020ef          	jal	5052 <read>
  if (cc != 2 || buf[0] != 'f') {
    2b0c:	4789                	li	a5,2
    2b0e:	2cf51063          	bne	a0,a5,2dce <subdir+0x382>
    2b12:	00009717          	auipc	a4,0x9
    2b16:	1b674703          	lbu	a4,438(a4) # bcc8 <buf>
    2b1a:	06600793          	li	a5,102
    2b1e:	2af71863          	bne	a4,a5,2dce <subdir+0x382>
  close(fd);
    2b22:	8526                	mv	a0,s1
    2b24:	53e020ef          	jal	5062 <close>
  if (link("dd/dd/ff", "dd/dd/ffff") != 0) {
    2b28:	00004597          	auipc	a1,0x4
    2b2c:	e3058593          	addi	a1,a1,-464 # 6958 <malloc+0x143a>
    2b30:	00004517          	auipc	a0,0x4
    2b34:	da050513          	addi	a0,a0,-608 # 68d0 <malloc+0x13b2>
    2b38:	562020ef          	jal	509a <link>
    2b3c:	2a051363          	bnez	a0,2de2 <subdir+0x396>
  if (unlink("dd/dd/ff") != 0) {
    2b40:	00004517          	auipc	a0,0x4
    2b44:	d9050513          	addi	a0,a0,-624 # 68d0 <malloc+0x13b2>
    2b48:	542020ef          	jal	508a <unlink>
    2b4c:	2a051563          	bnez	a0,2df6 <subdir+0x3aa>
  if (open("dd/dd/ff", O_RDONLY) >= 0) {
    2b50:	4581                	li	a1,0
    2b52:	00004517          	auipc	a0,0x4
    2b56:	d7e50513          	addi	a0,a0,-642 # 68d0 <malloc+0x13b2>
    2b5a:	520020ef          	jal	507a <open>
    2b5e:	2a055663          	bgez	a0,2e0a <subdir+0x3be>
  if (chdir("dd") != 0) {
    2b62:	00004517          	auipc	a0,0x4
    2b66:	cce50513          	addi	a0,a0,-818 # 6830 <malloc+0x1312>
    2b6a:	540020ef          	jal	50aa <chdir>
    2b6e:	2a051863          	bnez	a0,2e1e <subdir+0x3d2>
  if (chdir("dd/../../dd") != 0) {
    2b72:	00004517          	auipc	a0,0x4
    2b76:	e7e50513          	addi	a0,a0,-386 # 69f0 <malloc+0x14d2>
    2b7a:	530020ef          	jal	50aa <chdir>
    2b7e:	2a051a63          	bnez	a0,2e32 <subdir+0x3e6>
  if (chdir("dd/../../../dd") != 0) {
    2b82:	00004517          	auipc	a0,0x4
    2b86:	e9e50513          	addi	a0,a0,-354 # 6a20 <malloc+0x1502>
    2b8a:	520020ef          	jal	50aa <chdir>
    2b8e:	2a051c63          	bnez	a0,2e46 <subdir+0x3fa>
  if (chdir("./..") != 0) {
    2b92:	00004517          	auipc	a0,0x4
    2b96:	ec650513          	addi	a0,a0,-314 # 6a58 <malloc+0x153a>
    2b9a:	510020ef          	jal	50aa <chdir>
    2b9e:	2a051e63          	bnez	a0,2e5a <subdir+0x40e>
  fd = open("dd/dd/ffff", 0);
    2ba2:	4581                	li	a1,0
    2ba4:	00004517          	auipc	a0,0x4
    2ba8:	db450513          	addi	a0,a0,-588 # 6958 <malloc+0x143a>
    2bac:	4ce020ef          	jal	507a <open>
    2bb0:	84aa                	mv	s1,a0
  if (fd < 0) {
    2bb2:	2a054e63          	bltz	a0,2e6e <subdir+0x422>
  if (read(fd, buf, sizeof(buf)) != 2) {
    2bb6:	660d                	lui	a2,0x3
    2bb8:	00009597          	auipc	a1,0x9
    2bbc:	11058593          	addi	a1,a1,272 # bcc8 <buf>
    2bc0:	492020ef          	jal	5052 <read>
    2bc4:	4789                	li	a5,2
    2bc6:	2af51e63          	bne	a0,a5,2e82 <subdir+0x436>
  close(fd);
    2bca:	8526                	mv	a0,s1
    2bcc:	496020ef          	jal	5062 <close>
  if (open("dd/dd/ff", O_RDONLY) >= 0) {
    2bd0:	4581                	li	a1,0
    2bd2:	00004517          	auipc	a0,0x4
    2bd6:	cfe50513          	addi	a0,a0,-770 # 68d0 <malloc+0x13b2>
    2bda:	4a0020ef          	jal	507a <open>
    2bde:	2a055c63          	bgez	a0,2e96 <subdir+0x44a>
  if (open("dd/ff/ff", O_CREATE | O_RDWR) >= 0) {
    2be2:	20200593          	li	a1,514
    2be6:	00004517          	auipc	a0,0x4
    2bea:	f0250513          	addi	a0,a0,-254 # 6ae8 <malloc+0x15ca>
    2bee:	48c020ef          	jal	507a <open>
    2bf2:	2a055c63          	bgez	a0,2eaa <subdir+0x45e>
  if (open("dd/xx/ff", O_CREATE | O_RDWR) >= 0) {
    2bf6:	20200593          	li	a1,514
    2bfa:	00004517          	auipc	a0,0x4
    2bfe:	f1e50513          	addi	a0,a0,-226 # 6b18 <malloc+0x15fa>
    2c02:	478020ef          	jal	507a <open>
    2c06:	2a055c63          	bgez	a0,2ebe <subdir+0x472>
  if (open("dd", O_CREATE) >= 0) {
    2c0a:	20000593          	li	a1,512
    2c0e:	00004517          	auipc	a0,0x4
    2c12:	c2250513          	addi	a0,a0,-990 # 6830 <malloc+0x1312>
    2c16:	464020ef          	jal	507a <open>
    2c1a:	2a055c63          	bgez	a0,2ed2 <subdir+0x486>
  if (open("dd", O_RDWR) >= 0) {
    2c1e:	4589                	li	a1,2
    2c20:	00004517          	auipc	a0,0x4
    2c24:	c1050513          	addi	a0,a0,-1008 # 6830 <malloc+0x1312>
    2c28:	452020ef          	jal	507a <open>
    2c2c:	2a055d63          	bgez	a0,2ee6 <subdir+0x49a>
  if (open("dd", O_WRONLY) >= 0) {
    2c30:	4585                	li	a1,1
    2c32:	00004517          	auipc	a0,0x4
    2c36:	bfe50513          	addi	a0,a0,-1026 # 6830 <malloc+0x1312>
    2c3a:	440020ef          	jal	507a <open>
    2c3e:	2a055e63          	bgez	a0,2efa <subdir+0x4ae>
  if (link("dd/ff/ff", "dd/dd/xx") == 0) {
    2c42:	00004597          	auipc	a1,0x4
    2c46:	f6658593          	addi	a1,a1,-154 # 6ba8 <malloc+0x168a>
    2c4a:	00004517          	auipc	a0,0x4
    2c4e:	e9e50513          	addi	a0,a0,-354 # 6ae8 <malloc+0x15ca>
    2c52:	448020ef          	jal	509a <link>
    2c56:	2a050c63          	beqz	a0,2f0e <subdir+0x4c2>
  if (link("dd/xx/ff", "dd/dd/xx") == 0) {
    2c5a:	00004597          	auipc	a1,0x4
    2c5e:	f4e58593          	addi	a1,a1,-178 # 6ba8 <malloc+0x168a>
    2c62:	00004517          	auipc	a0,0x4
    2c66:	eb650513          	addi	a0,a0,-330 # 6b18 <malloc+0x15fa>
    2c6a:	430020ef          	jal	509a <link>
    2c6e:	2a050a63          	beqz	a0,2f22 <subdir+0x4d6>
  if (link("dd/ff", "dd/dd/ffff") == 0) {
    2c72:	00004597          	auipc	a1,0x4
    2c76:	ce658593          	addi	a1,a1,-794 # 6958 <malloc+0x143a>
    2c7a:	00004517          	auipc	a0,0x4
    2c7e:	bd650513          	addi	a0,a0,-1066 # 6850 <malloc+0x1332>
    2c82:	418020ef          	jal	509a <link>
    2c86:	2a050863          	beqz	a0,2f36 <subdir+0x4ea>
  if (mkdir("dd/ff/ff") == 0) {
    2c8a:	00004517          	auipc	a0,0x4
    2c8e:	e5e50513          	addi	a0,a0,-418 # 6ae8 <malloc+0x15ca>
    2c92:	410020ef          	jal	50a2 <mkdir>
    2c96:	2a050a63          	beqz	a0,2f4a <subdir+0x4fe>
  if (mkdir("dd/xx/ff") == 0) {
    2c9a:	00004517          	auipc	a0,0x4
    2c9e:	e7e50513          	addi	a0,a0,-386 # 6b18 <malloc+0x15fa>
    2ca2:	400020ef          	jal	50a2 <mkdir>
    2ca6:	2a050c63          	beqz	a0,2f5e <subdir+0x512>
  if (mkdir("dd/dd/ffff") == 0) {
    2caa:	00004517          	auipc	a0,0x4
    2cae:	cae50513          	addi	a0,a0,-850 # 6958 <malloc+0x143a>
    2cb2:	3f0020ef          	jal	50a2 <mkdir>
    2cb6:	2a050e63          	beqz	a0,2f72 <subdir+0x526>
  if (unlink("dd/xx/ff") == 0) {
    2cba:	00004517          	auipc	a0,0x4
    2cbe:	e5e50513          	addi	a0,a0,-418 # 6b18 <malloc+0x15fa>
    2cc2:	3c8020ef          	jal	508a <unlink>
    2cc6:	2c050063          	beqz	a0,2f86 <subdir+0x53a>
  if (unlink("dd/ff/ff") == 0) {
    2cca:	00004517          	auipc	a0,0x4
    2cce:	e1e50513          	addi	a0,a0,-482 # 6ae8 <malloc+0x15ca>
    2cd2:	3b8020ef          	jal	508a <unlink>
    2cd6:	2c050263          	beqz	a0,2f9a <subdir+0x54e>
  if (chdir("dd/ff") == 0) {
    2cda:	00004517          	auipc	a0,0x4
    2cde:	b7650513          	addi	a0,a0,-1162 # 6850 <malloc+0x1332>
    2ce2:	3c8020ef          	jal	50aa <chdir>
    2ce6:	2c050463          	beqz	a0,2fae <subdir+0x562>
  if (chdir("dd/xx") == 0) {
    2cea:	00004517          	auipc	a0,0x4
    2cee:	00e50513          	addi	a0,a0,14 # 6cf8 <malloc+0x17da>
    2cf2:	3b8020ef          	jal	50aa <chdir>
    2cf6:	2c050663          	beqz	a0,2fc2 <subdir+0x576>
  if (unlink("dd/dd/ffff") != 0) {
    2cfa:	00004517          	auipc	a0,0x4
    2cfe:	c5e50513          	addi	a0,a0,-930 # 6958 <malloc+0x143a>
    2d02:	388020ef          	jal	508a <unlink>
    2d06:	2c051863          	bnez	a0,2fd6 <subdir+0x58a>
  if (unlink("dd/ff") != 0) {
    2d0a:	00004517          	auipc	a0,0x4
    2d0e:	b4650513          	addi	a0,a0,-1210 # 6850 <malloc+0x1332>
    2d12:	378020ef          	jal	508a <unlink>
    2d16:	2c051a63          	bnez	a0,2fea <subdir+0x59e>
  if (unlink("dd") == 0) {
    2d1a:	00004517          	auipc	a0,0x4
    2d1e:	b1650513          	addi	a0,a0,-1258 # 6830 <malloc+0x1312>
    2d22:	368020ef          	jal	508a <unlink>
    2d26:	2c050c63          	beqz	a0,2ffe <subdir+0x5b2>
  if (unlink("dd/dd") < 0) {
    2d2a:	00004517          	auipc	a0,0x4
    2d2e:	03e50513          	addi	a0,a0,62 # 6d68 <malloc+0x184a>
    2d32:	358020ef          	jal	508a <unlink>
    2d36:	2c054e63          	bltz	a0,3012 <subdir+0x5c6>
  if (unlink("dd") < 0) {
    2d3a:	00004517          	auipc	a0,0x4
    2d3e:	af650513          	addi	a0,a0,-1290 # 6830 <malloc+0x1312>
    2d42:	348020ef          	jal	508a <unlink>
    2d46:	2e054063          	bltz	a0,3026 <subdir+0x5da>
}
    2d4a:	60e2                	ld	ra,24(sp)
    2d4c:	6442                	ld	s0,16(sp)
    2d4e:	64a2                	ld	s1,8(sp)
    2d50:	6902                	ld	s2,0(sp)
    2d52:	6105                	addi	sp,sp,32
    2d54:	8082                	ret
    printf("%s: mkdir dd failed\n", s);
    2d56:	85ca                	mv	a1,s2
    2d58:	00004517          	auipc	a0,0x4
    2d5c:	ae050513          	addi	a0,a0,-1312 # 6838 <malloc+0x131a>
    2d60:	70a020ef          	jal	546a <printf>
    exit(1);
    2d64:	4505                	li	a0,1
    2d66:	2d4020ef          	jal	503a <exit>
    printf("%s: create dd/ff failed\n", s);
    2d6a:	85ca                	mv	a1,s2
    2d6c:	00004517          	auipc	a0,0x4
    2d70:	aec50513          	addi	a0,a0,-1300 # 6858 <malloc+0x133a>
    2d74:	6f6020ef          	jal	546a <printf>
    exit(1);
    2d78:	4505                	li	a0,1
    2d7a:	2c0020ef          	jal	503a <exit>
    printf("%s: unlink dd (non-empty dir) succeeded!\n", s);
    2d7e:	85ca                	mv	a1,s2
    2d80:	00004517          	auipc	a0,0x4
    2d84:	af850513          	addi	a0,a0,-1288 # 6878 <malloc+0x135a>
    2d88:	6e2020ef          	jal	546a <printf>
    exit(1);
    2d8c:	4505                	li	a0,1
    2d8e:	2ac020ef          	jal	503a <exit>
    printf("%s: subdir mkdir dd/dd failed\n", s);
    2d92:	85ca                	mv	a1,s2
    2d94:	00004517          	auipc	a0,0x4
    2d98:	b1c50513          	addi	a0,a0,-1252 # 68b0 <malloc+0x1392>
    2d9c:	6ce020ef          	jal	546a <printf>
    exit(1);
    2da0:	4505                	li	a0,1
    2da2:	298020ef          	jal	503a <exit>
    printf("%s: create dd/dd/ff failed\n", s);
    2da6:	85ca                	mv	a1,s2
    2da8:	00004517          	auipc	a0,0x4
    2dac:	b3850513          	addi	a0,a0,-1224 # 68e0 <malloc+0x13c2>
    2db0:	6ba020ef          	jal	546a <printf>
    exit(1);
    2db4:	4505                	li	a0,1
    2db6:	284020ef          	jal	503a <exit>
    printf("%s: open dd/dd/../ff failed\n", s);
    2dba:	85ca                	mv	a1,s2
    2dbc:	00004517          	auipc	a0,0x4
    2dc0:	b5c50513          	addi	a0,a0,-1188 # 6918 <malloc+0x13fa>
    2dc4:	6a6020ef          	jal	546a <printf>
    exit(1);
    2dc8:	4505                	li	a0,1
    2dca:	270020ef          	jal	503a <exit>
    printf("%s: dd/dd/../ff wrong content\n", s);
    2dce:	85ca                	mv	a1,s2
    2dd0:	00004517          	auipc	a0,0x4
    2dd4:	b6850513          	addi	a0,a0,-1176 # 6938 <malloc+0x141a>
    2dd8:	692020ef          	jal	546a <printf>
    exit(1);
    2ddc:	4505                	li	a0,1
    2dde:	25c020ef          	jal	503a <exit>
    printf("%s: link dd/dd/ff dd/dd/ffff failed\n", s);
    2de2:	85ca                	mv	a1,s2
    2de4:	00004517          	auipc	a0,0x4
    2de8:	b8450513          	addi	a0,a0,-1148 # 6968 <malloc+0x144a>
    2dec:	67e020ef          	jal	546a <printf>
    exit(1);
    2df0:	4505                	li	a0,1
    2df2:	248020ef          	jal	503a <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    2df6:	85ca                	mv	a1,s2
    2df8:	00004517          	auipc	a0,0x4
    2dfc:	b9850513          	addi	a0,a0,-1128 # 6990 <malloc+0x1472>
    2e00:	66a020ef          	jal	546a <printf>
    exit(1);
    2e04:	4505                	li	a0,1
    2e06:	234020ef          	jal	503a <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded\n", s);
    2e0a:	85ca                	mv	a1,s2
    2e0c:	00004517          	auipc	a0,0x4
    2e10:	ba450513          	addi	a0,a0,-1116 # 69b0 <malloc+0x1492>
    2e14:	656020ef          	jal	546a <printf>
    exit(1);
    2e18:	4505                	li	a0,1
    2e1a:	220020ef          	jal	503a <exit>
    printf("%s: chdir dd failed\n", s);
    2e1e:	85ca                	mv	a1,s2
    2e20:	00004517          	auipc	a0,0x4
    2e24:	bb850513          	addi	a0,a0,-1096 # 69d8 <malloc+0x14ba>
    2e28:	642020ef          	jal	546a <printf>
    exit(1);
    2e2c:	4505                	li	a0,1
    2e2e:	20c020ef          	jal	503a <exit>
    printf("%s: chdir dd/../../dd failed\n", s);
    2e32:	85ca                	mv	a1,s2
    2e34:	00004517          	auipc	a0,0x4
    2e38:	bcc50513          	addi	a0,a0,-1076 # 6a00 <malloc+0x14e2>
    2e3c:	62e020ef          	jal	546a <printf>
    exit(1);
    2e40:	4505                	li	a0,1
    2e42:	1f8020ef          	jal	503a <exit>
    printf("%s: chdir dd/../../../dd failed\n", s);
    2e46:	85ca                	mv	a1,s2
    2e48:	00004517          	auipc	a0,0x4
    2e4c:	be850513          	addi	a0,a0,-1048 # 6a30 <malloc+0x1512>
    2e50:	61a020ef          	jal	546a <printf>
    exit(1);
    2e54:	4505                	li	a0,1
    2e56:	1e4020ef          	jal	503a <exit>
    printf("%s: chdir ./.. failed\n", s);
    2e5a:	85ca                	mv	a1,s2
    2e5c:	00004517          	auipc	a0,0x4
    2e60:	c0450513          	addi	a0,a0,-1020 # 6a60 <malloc+0x1542>
    2e64:	606020ef          	jal	546a <printf>
    exit(1);
    2e68:	4505                	li	a0,1
    2e6a:	1d0020ef          	jal	503a <exit>
    printf("%s: open dd/dd/ffff failed\n", s);
    2e6e:	85ca                	mv	a1,s2
    2e70:	00004517          	auipc	a0,0x4
    2e74:	c0850513          	addi	a0,a0,-1016 # 6a78 <malloc+0x155a>
    2e78:	5f2020ef          	jal	546a <printf>
    exit(1);
    2e7c:	4505                	li	a0,1
    2e7e:	1bc020ef          	jal	503a <exit>
    printf("%s: read dd/dd/ffff wrong len\n", s);
    2e82:	85ca                	mv	a1,s2
    2e84:	00004517          	auipc	a0,0x4
    2e88:	c1450513          	addi	a0,a0,-1004 # 6a98 <malloc+0x157a>
    2e8c:	5de020ef          	jal	546a <printf>
    exit(1);
    2e90:	4505                	li	a0,1
    2e92:	1a8020ef          	jal	503a <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded!\n", s);
    2e96:	85ca                	mv	a1,s2
    2e98:	00004517          	auipc	a0,0x4
    2e9c:	c2050513          	addi	a0,a0,-992 # 6ab8 <malloc+0x159a>
    2ea0:	5ca020ef          	jal	546a <printf>
    exit(1);
    2ea4:	4505                	li	a0,1
    2ea6:	194020ef          	jal	503a <exit>
    printf("%s: create dd/ff/ff succeeded!\n", s);
    2eaa:	85ca                	mv	a1,s2
    2eac:	00004517          	auipc	a0,0x4
    2eb0:	c4c50513          	addi	a0,a0,-948 # 6af8 <malloc+0x15da>
    2eb4:	5b6020ef          	jal	546a <printf>
    exit(1);
    2eb8:	4505                	li	a0,1
    2eba:	180020ef          	jal	503a <exit>
    printf("%s: create dd/xx/ff succeeded!\n", s);
    2ebe:	85ca                	mv	a1,s2
    2ec0:	00004517          	auipc	a0,0x4
    2ec4:	c6850513          	addi	a0,a0,-920 # 6b28 <malloc+0x160a>
    2ec8:	5a2020ef          	jal	546a <printf>
    exit(1);
    2ecc:	4505                	li	a0,1
    2ece:	16c020ef          	jal	503a <exit>
    printf("%s: create dd succeeded!\n", s);
    2ed2:	85ca                	mv	a1,s2
    2ed4:	00004517          	auipc	a0,0x4
    2ed8:	c7450513          	addi	a0,a0,-908 # 6b48 <malloc+0x162a>
    2edc:	58e020ef          	jal	546a <printf>
    exit(1);
    2ee0:	4505                	li	a0,1
    2ee2:	158020ef          	jal	503a <exit>
    printf("%s: open dd rdwr succeeded!\n", s);
    2ee6:	85ca                	mv	a1,s2
    2ee8:	00004517          	auipc	a0,0x4
    2eec:	c8050513          	addi	a0,a0,-896 # 6b68 <malloc+0x164a>
    2ef0:	57a020ef          	jal	546a <printf>
    exit(1);
    2ef4:	4505                	li	a0,1
    2ef6:	144020ef          	jal	503a <exit>
    printf("%s: open dd wronly succeeded!\n", s);
    2efa:	85ca                	mv	a1,s2
    2efc:	00004517          	auipc	a0,0x4
    2f00:	c8c50513          	addi	a0,a0,-884 # 6b88 <malloc+0x166a>
    2f04:	566020ef          	jal	546a <printf>
    exit(1);
    2f08:	4505                	li	a0,1
    2f0a:	130020ef          	jal	503a <exit>
    printf("%s: link dd/ff/ff dd/dd/xx succeeded!\n", s);
    2f0e:	85ca                	mv	a1,s2
    2f10:	00004517          	auipc	a0,0x4
    2f14:	ca850513          	addi	a0,a0,-856 # 6bb8 <malloc+0x169a>
    2f18:	552020ef          	jal	546a <printf>
    exit(1);
    2f1c:	4505                	li	a0,1
    2f1e:	11c020ef          	jal	503a <exit>
    printf("%s: link dd/xx/ff dd/dd/xx succeeded!\n", s);
    2f22:	85ca                	mv	a1,s2
    2f24:	00004517          	auipc	a0,0x4
    2f28:	cbc50513          	addi	a0,a0,-836 # 6be0 <malloc+0x16c2>
    2f2c:	53e020ef          	jal	546a <printf>
    exit(1);
    2f30:	4505                	li	a0,1
    2f32:	108020ef          	jal	503a <exit>
    printf("%s: link dd/ff dd/dd/ffff succeeded!\n", s);
    2f36:	85ca                	mv	a1,s2
    2f38:	00004517          	auipc	a0,0x4
    2f3c:	cd050513          	addi	a0,a0,-816 # 6c08 <malloc+0x16ea>
    2f40:	52a020ef          	jal	546a <printf>
    exit(1);
    2f44:	4505                	li	a0,1
    2f46:	0f4020ef          	jal	503a <exit>
    printf("%s: mkdir dd/ff/ff succeeded!\n", s);
    2f4a:	85ca                	mv	a1,s2
    2f4c:	00004517          	auipc	a0,0x4
    2f50:	ce450513          	addi	a0,a0,-796 # 6c30 <malloc+0x1712>
    2f54:	516020ef          	jal	546a <printf>
    exit(1);
    2f58:	4505                	li	a0,1
    2f5a:	0e0020ef          	jal	503a <exit>
    printf("%s: mkdir dd/xx/ff succeeded!\n", s);
    2f5e:	85ca                	mv	a1,s2
    2f60:	00004517          	auipc	a0,0x4
    2f64:	cf050513          	addi	a0,a0,-784 # 6c50 <malloc+0x1732>
    2f68:	502020ef          	jal	546a <printf>
    exit(1);
    2f6c:	4505                	li	a0,1
    2f6e:	0cc020ef          	jal	503a <exit>
    printf("%s: mkdir dd/dd/ffff succeeded!\n", s);
    2f72:	85ca                	mv	a1,s2
    2f74:	00004517          	auipc	a0,0x4
    2f78:	cfc50513          	addi	a0,a0,-772 # 6c70 <malloc+0x1752>
    2f7c:	4ee020ef          	jal	546a <printf>
    exit(1);
    2f80:	4505                	li	a0,1
    2f82:	0b8020ef          	jal	503a <exit>
    printf("%s: unlink dd/xx/ff succeeded!\n", s);
    2f86:	85ca                	mv	a1,s2
    2f88:	00004517          	auipc	a0,0x4
    2f8c:	d1050513          	addi	a0,a0,-752 # 6c98 <malloc+0x177a>
    2f90:	4da020ef          	jal	546a <printf>
    exit(1);
    2f94:	4505                	li	a0,1
    2f96:	0a4020ef          	jal	503a <exit>
    printf("%s: unlink dd/ff/ff succeeded!\n", s);
    2f9a:	85ca                	mv	a1,s2
    2f9c:	00004517          	auipc	a0,0x4
    2fa0:	d1c50513          	addi	a0,a0,-740 # 6cb8 <malloc+0x179a>
    2fa4:	4c6020ef          	jal	546a <printf>
    exit(1);
    2fa8:	4505                	li	a0,1
    2faa:	090020ef          	jal	503a <exit>
    printf("%s: chdir dd/ff succeeded!\n", s);
    2fae:	85ca                	mv	a1,s2
    2fb0:	00004517          	auipc	a0,0x4
    2fb4:	d2850513          	addi	a0,a0,-728 # 6cd8 <malloc+0x17ba>
    2fb8:	4b2020ef          	jal	546a <printf>
    exit(1);
    2fbc:	4505                	li	a0,1
    2fbe:	07c020ef          	jal	503a <exit>
    printf("%s: chdir dd/xx succeeded!\n", s);
    2fc2:	85ca                	mv	a1,s2
    2fc4:	00004517          	auipc	a0,0x4
    2fc8:	d3c50513          	addi	a0,a0,-708 # 6d00 <malloc+0x17e2>
    2fcc:	49e020ef          	jal	546a <printf>
    exit(1);
    2fd0:	4505                	li	a0,1
    2fd2:	068020ef          	jal	503a <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    2fd6:	85ca                	mv	a1,s2
    2fd8:	00004517          	auipc	a0,0x4
    2fdc:	9b850513          	addi	a0,a0,-1608 # 6990 <malloc+0x1472>
    2fe0:	48a020ef          	jal	546a <printf>
    exit(1);
    2fe4:	4505                	li	a0,1
    2fe6:	054020ef          	jal	503a <exit>
    printf("%s: unlink dd/ff failed\n", s);
    2fea:	85ca                	mv	a1,s2
    2fec:	00004517          	auipc	a0,0x4
    2ff0:	d3450513          	addi	a0,a0,-716 # 6d20 <malloc+0x1802>
    2ff4:	476020ef          	jal	546a <printf>
    exit(1);
    2ff8:	4505                	li	a0,1
    2ffa:	040020ef          	jal	503a <exit>
    printf("%s: unlink non-empty dd succeeded!\n", s);
    2ffe:	85ca                	mv	a1,s2
    3000:	00004517          	auipc	a0,0x4
    3004:	d4050513          	addi	a0,a0,-704 # 6d40 <malloc+0x1822>
    3008:	462020ef          	jal	546a <printf>
    exit(1);
    300c:	4505                	li	a0,1
    300e:	02c020ef          	jal	503a <exit>
    printf("%s: unlink dd/dd failed\n", s);
    3012:	85ca                	mv	a1,s2
    3014:	00004517          	auipc	a0,0x4
    3018:	d5c50513          	addi	a0,a0,-676 # 6d70 <malloc+0x1852>
    301c:	44e020ef          	jal	546a <printf>
    exit(1);
    3020:	4505                	li	a0,1
    3022:	018020ef          	jal	503a <exit>
    printf("%s: unlink dd failed\n", s);
    3026:	85ca                	mv	a1,s2
    3028:	00004517          	auipc	a0,0x4
    302c:	d6850513          	addi	a0,a0,-664 # 6d90 <malloc+0x1872>
    3030:	43a020ef          	jal	546a <printf>
    exit(1);
    3034:	4505                	li	a0,1
    3036:	004020ef          	jal	503a <exit>

000000000000303a <rmdot>:
{
    303a:	1101                	addi	sp,sp,-32
    303c:	ec06                	sd	ra,24(sp)
    303e:	e822                	sd	s0,16(sp)
    3040:	e426                	sd	s1,8(sp)
    3042:	1000                	addi	s0,sp,32
    3044:	84aa                	mv	s1,a0
  if (mkdir("dots") != 0) {
    3046:	00004517          	auipc	a0,0x4
    304a:	d6250513          	addi	a0,a0,-670 # 6da8 <malloc+0x188a>
    304e:	054020ef          	jal	50a2 <mkdir>
    3052:	e53d                	bnez	a0,30c0 <rmdot+0x86>
  if (chdir("dots") != 0) {
    3054:	00004517          	auipc	a0,0x4
    3058:	d5450513          	addi	a0,a0,-684 # 6da8 <malloc+0x188a>
    305c:	04e020ef          	jal	50aa <chdir>
    3060:	e935                	bnez	a0,30d4 <rmdot+0x9a>
  if (unlink(".") == 0) {
    3062:	00003517          	auipc	a0,0x3
    3066:	cde50513          	addi	a0,a0,-802 # 5d40 <malloc+0x822>
    306a:	020020ef          	jal	508a <unlink>
    306e:	cd2d                	beqz	a0,30e8 <rmdot+0xae>
  if (unlink("..") == 0) {
    3070:	00003517          	auipc	a0,0x3
    3074:	78850513          	addi	a0,a0,1928 # 67f8 <malloc+0x12da>
    3078:	012020ef          	jal	508a <unlink>
    307c:	c141                	beqz	a0,30fc <rmdot+0xc2>
  if (chdir("/") != 0) {
    307e:	00003517          	auipc	a0,0x3
    3082:	72250513          	addi	a0,a0,1826 # 67a0 <malloc+0x1282>
    3086:	024020ef          	jal	50aa <chdir>
    308a:	e159                	bnez	a0,3110 <rmdot+0xd6>
  if (unlink("dots/.") == 0) {
    308c:	00004517          	auipc	a0,0x4
    3090:	d8450513          	addi	a0,a0,-636 # 6e10 <malloc+0x18f2>
    3094:	7f7010ef          	jal	508a <unlink>
    3098:	c551                	beqz	a0,3124 <rmdot+0xea>
  if (unlink("dots/..") == 0) {
    309a:	00004517          	auipc	a0,0x4
    309e:	d9e50513          	addi	a0,a0,-610 # 6e38 <malloc+0x191a>
    30a2:	7e9010ef          	jal	508a <unlink>
    30a6:	c949                	beqz	a0,3138 <rmdot+0xfe>
  if (unlink("dots") != 0) {
    30a8:	00004517          	auipc	a0,0x4
    30ac:	d0050513          	addi	a0,a0,-768 # 6da8 <malloc+0x188a>
    30b0:	7db010ef          	jal	508a <unlink>
    30b4:	ed41                	bnez	a0,314c <rmdot+0x112>
}
    30b6:	60e2                	ld	ra,24(sp)
    30b8:	6442                	ld	s0,16(sp)
    30ba:	64a2                	ld	s1,8(sp)
    30bc:	6105                	addi	sp,sp,32
    30be:	8082                	ret
    printf("%s: mkdir dots failed\n", s);
    30c0:	85a6                	mv	a1,s1
    30c2:	00004517          	auipc	a0,0x4
    30c6:	cee50513          	addi	a0,a0,-786 # 6db0 <malloc+0x1892>
    30ca:	3a0020ef          	jal	546a <printf>
    exit(1);
    30ce:	4505                	li	a0,1
    30d0:	76b010ef          	jal	503a <exit>
    printf("%s: chdir dots failed\n", s);
    30d4:	85a6                	mv	a1,s1
    30d6:	00004517          	auipc	a0,0x4
    30da:	cf250513          	addi	a0,a0,-782 # 6dc8 <malloc+0x18aa>
    30de:	38c020ef          	jal	546a <printf>
    exit(1);
    30e2:	4505                	li	a0,1
    30e4:	757010ef          	jal	503a <exit>
    printf("%s: rm . worked!\n", s);
    30e8:	85a6                	mv	a1,s1
    30ea:	00004517          	auipc	a0,0x4
    30ee:	cf650513          	addi	a0,a0,-778 # 6de0 <malloc+0x18c2>
    30f2:	378020ef          	jal	546a <printf>
    exit(1);
    30f6:	4505                	li	a0,1
    30f8:	743010ef          	jal	503a <exit>
    printf("%s: rm .. worked!\n", s);
    30fc:	85a6                	mv	a1,s1
    30fe:	00004517          	auipc	a0,0x4
    3102:	cfa50513          	addi	a0,a0,-774 # 6df8 <malloc+0x18da>
    3106:	364020ef          	jal	546a <printf>
    exit(1);
    310a:	4505                	li	a0,1
    310c:	72f010ef          	jal	503a <exit>
    printf("%s: chdir / failed\n", s);
    3110:	85a6                	mv	a1,s1
    3112:	00003517          	auipc	a0,0x3
    3116:	69650513          	addi	a0,a0,1686 # 67a8 <malloc+0x128a>
    311a:	350020ef          	jal	546a <printf>
    exit(1);
    311e:	4505                	li	a0,1
    3120:	71b010ef          	jal	503a <exit>
    printf("%s: unlink dots/. worked!\n", s);
    3124:	85a6                	mv	a1,s1
    3126:	00004517          	auipc	a0,0x4
    312a:	cf250513          	addi	a0,a0,-782 # 6e18 <malloc+0x18fa>
    312e:	33c020ef          	jal	546a <printf>
    exit(1);
    3132:	4505                	li	a0,1
    3134:	707010ef          	jal	503a <exit>
    printf("%s: unlink dots/.. worked!\n", s);
    3138:	85a6                	mv	a1,s1
    313a:	00004517          	auipc	a0,0x4
    313e:	d0650513          	addi	a0,a0,-762 # 6e40 <malloc+0x1922>
    3142:	328020ef          	jal	546a <printf>
    exit(1);
    3146:	4505                	li	a0,1
    3148:	6f3010ef          	jal	503a <exit>
    printf("%s: unlink dots failed!\n", s);
    314c:	85a6                	mv	a1,s1
    314e:	00004517          	auipc	a0,0x4
    3152:	d1250513          	addi	a0,a0,-750 # 6e60 <malloc+0x1942>
    3156:	314020ef          	jal	546a <printf>
    exit(1);
    315a:	4505                	li	a0,1
    315c:	6df010ef          	jal	503a <exit>

0000000000003160 <dirfile>:
{
    3160:	1101                	addi	sp,sp,-32
    3162:	ec06                	sd	ra,24(sp)
    3164:	e822                	sd	s0,16(sp)
    3166:	e426                	sd	s1,8(sp)
    3168:	e04a                	sd	s2,0(sp)
    316a:	1000                	addi	s0,sp,32
    316c:	892a                	mv	s2,a0
  fd = open("dirfile", O_CREATE);
    316e:	20000593          	li	a1,512
    3172:	00004517          	auipc	a0,0x4
    3176:	d0e50513          	addi	a0,a0,-754 # 6e80 <malloc+0x1962>
    317a:	701010ef          	jal	507a <open>
  if (fd < 0) {
    317e:	0c054563          	bltz	a0,3248 <dirfile+0xe8>
  close(fd);
    3182:	6e1010ef          	jal	5062 <close>
  if (chdir("dirfile") == 0) {
    3186:	00004517          	auipc	a0,0x4
    318a:	cfa50513          	addi	a0,a0,-774 # 6e80 <malloc+0x1962>
    318e:	71d010ef          	jal	50aa <chdir>
    3192:	c569                	beqz	a0,325c <dirfile+0xfc>
  fd = open("dirfile/xx", 0);
    3194:	4581                	li	a1,0
    3196:	00004517          	auipc	a0,0x4
    319a:	d3250513          	addi	a0,a0,-718 # 6ec8 <malloc+0x19aa>
    319e:	6dd010ef          	jal	507a <open>
  if (fd >= 0) {
    31a2:	0c055763          	bgez	a0,3270 <dirfile+0x110>
  fd = open("dirfile/xx", O_CREATE);
    31a6:	20000593          	li	a1,512
    31aa:	00004517          	auipc	a0,0x4
    31ae:	d1e50513          	addi	a0,a0,-738 # 6ec8 <malloc+0x19aa>
    31b2:	6c9010ef          	jal	507a <open>
  if (fd >= 0) {
    31b6:	0c055763          	bgez	a0,3284 <dirfile+0x124>
  if (mkdir("dirfile/xx") == 0) {
    31ba:	00004517          	auipc	a0,0x4
    31be:	d0e50513          	addi	a0,a0,-754 # 6ec8 <malloc+0x19aa>
    31c2:	6e1010ef          	jal	50a2 <mkdir>
    31c6:	0c050963          	beqz	a0,3298 <dirfile+0x138>
  if (unlink("dirfile/xx") == 0) {
    31ca:	00004517          	auipc	a0,0x4
    31ce:	cfe50513          	addi	a0,a0,-770 # 6ec8 <malloc+0x19aa>
    31d2:	6b9010ef          	jal	508a <unlink>
    31d6:	0c050b63          	beqz	a0,32ac <dirfile+0x14c>
  if (link("README", "dirfile/xx") == 0) {
    31da:	00004597          	auipc	a1,0x4
    31de:	cee58593          	addi	a1,a1,-786 # 6ec8 <malloc+0x19aa>
    31e2:	00002517          	auipc	a0,0x2
    31e6:	64e50513          	addi	a0,a0,1614 # 5830 <malloc+0x312>
    31ea:	6b1010ef          	jal	509a <link>
    31ee:	0c050963          	beqz	a0,32c0 <dirfile+0x160>
  if (unlink("dirfile") != 0) {
    31f2:	00004517          	auipc	a0,0x4
    31f6:	c8e50513          	addi	a0,a0,-882 # 6e80 <malloc+0x1962>
    31fa:	691010ef          	jal	508a <unlink>
    31fe:	0c051b63          	bnez	a0,32d4 <dirfile+0x174>
  fd = open(".", O_RDWR);
    3202:	4589                	li	a1,2
    3204:	00003517          	auipc	a0,0x3
    3208:	b3c50513          	addi	a0,a0,-1220 # 5d40 <malloc+0x822>
    320c:	66f010ef          	jal	507a <open>
  if (fd >= 0) {
    3210:	0c055c63          	bgez	a0,32e8 <dirfile+0x188>
  fd = open(".", 0);
    3214:	4581                	li	a1,0
    3216:	00003517          	auipc	a0,0x3
    321a:	b2a50513          	addi	a0,a0,-1238 # 5d40 <malloc+0x822>
    321e:	65d010ef          	jal	507a <open>
    3222:	84aa                	mv	s1,a0
  if (write(fd, "x", 1) > 0) {
    3224:	4605                	li	a2,1
    3226:	00002597          	auipc	a1,0x2
    322a:	4a258593          	addi	a1,a1,1186 # 56c8 <malloc+0x1aa>
    322e:	62d010ef          	jal	505a <write>
    3232:	0ca04563          	bgtz	a0,32fc <dirfile+0x19c>
  close(fd);
    3236:	8526                	mv	a0,s1
    3238:	62b010ef          	jal	5062 <close>
}
    323c:	60e2                	ld	ra,24(sp)
    323e:	6442                	ld	s0,16(sp)
    3240:	64a2                	ld	s1,8(sp)
    3242:	6902                	ld	s2,0(sp)
    3244:	6105                	addi	sp,sp,32
    3246:	8082                	ret
    printf("%s: create dirfile failed\n", s);
    3248:	85ca                	mv	a1,s2
    324a:	00004517          	auipc	a0,0x4
    324e:	c3e50513          	addi	a0,a0,-962 # 6e88 <malloc+0x196a>
    3252:	218020ef          	jal	546a <printf>
    exit(1);
    3256:	4505                	li	a0,1
    3258:	5e3010ef          	jal	503a <exit>
    printf("%s: chdir dirfile succeeded!\n", s);
    325c:	85ca                	mv	a1,s2
    325e:	00004517          	auipc	a0,0x4
    3262:	c4a50513          	addi	a0,a0,-950 # 6ea8 <malloc+0x198a>
    3266:	204020ef          	jal	546a <printf>
    exit(1);
    326a:	4505                	li	a0,1
    326c:	5cf010ef          	jal	503a <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    3270:	85ca                	mv	a1,s2
    3272:	00004517          	auipc	a0,0x4
    3276:	c6650513          	addi	a0,a0,-922 # 6ed8 <malloc+0x19ba>
    327a:	1f0020ef          	jal	546a <printf>
    exit(1);
    327e:	4505                	li	a0,1
    3280:	5bb010ef          	jal	503a <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    3284:	85ca                	mv	a1,s2
    3286:	00004517          	auipc	a0,0x4
    328a:	c5250513          	addi	a0,a0,-942 # 6ed8 <malloc+0x19ba>
    328e:	1dc020ef          	jal	546a <printf>
    exit(1);
    3292:	4505                	li	a0,1
    3294:	5a7010ef          	jal	503a <exit>
    printf("%s: mkdir dirfile/xx succeeded!\n", s);
    3298:	85ca                	mv	a1,s2
    329a:	00004517          	auipc	a0,0x4
    329e:	c6650513          	addi	a0,a0,-922 # 6f00 <malloc+0x19e2>
    32a2:	1c8020ef          	jal	546a <printf>
    exit(1);
    32a6:	4505                	li	a0,1
    32a8:	593010ef          	jal	503a <exit>
    printf("%s: unlink dirfile/xx succeeded!\n", s);
    32ac:	85ca                	mv	a1,s2
    32ae:	00004517          	auipc	a0,0x4
    32b2:	c7a50513          	addi	a0,a0,-902 # 6f28 <malloc+0x1a0a>
    32b6:	1b4020ef          	jal	546a <printf>
    exit(1);
    32ba:	4505                	li	a0,1
    32bc:	57f010ef          	jal	503a <exit>
    printf("%s: link to dirfile/xx succeeded!\n", s);
    32c0:	85ca                	mv	a1,s2
    32c2:	00004517          	auipc	a0,0x4
    32c6:	c8e50513          	addi	a0,a0,-882 # 6f50 <malloc+0x1a32>
    32ca:	1a0020ef          	jal	546a <printf>
    exit(1);
    32ce:	4505                	li	a0,1
    32d0:	56b010ef          	jal	503a <exit>
    printf("%s: unlink dirfile failed!\n", s);
    32d4:	85ca                	mv	a1,s2
    32d6:	00004517          	auipc	a0,0x4
    32da:	ca250513          	addi	a0,a0,-862 # 6f78 <malloc+0x1a5a>
    32de:	18c020ef          	jal	546a <printf>
    exit(1);
    32e2:	4505                	li	a0,1
    32e4:	557010ef          	jal	503a <exit>
    printf("%s: open . for writing succeeded!\n", s);
    32e8:	85ca                	mv	a1,s2
    32ea:	00004517          	auipc	a0,0x4
    32ee:	cae50513          	addi	a0,a0,-850 # 6f98 <malloc+0x1a7a>
    32f2:	178020ef          	jal	546a <printf>
    exit(1);
    32f6:	4505                	li	a0,1
    32f8:	543010ef          	jal	503a <exit>
    printf("%s: write . succeeded!\n", s);
    32fc:	85ca                	mv	a1,s2
    32fe:	00004517          	auipc	a0,0x4
    3302:	cc250513          	addi	a0,a0,-830 # 6fc0 <malloc+0x1aa2>
    3306:	164020ef          	jal	546a <printf>
    exit(1);
    330a:	4505                	li	a0,1
    330c:	52f010ef          	jal	503a <exit>

0000000000003310 <iref>:
{
    3310:	7139                	addi	sp,sp,-64
    3312:	fc06                	sd	ra,56(sp)
    3314:	f822                	sd	s0,48(sp)
    3316:	f426                	sd	s1,40(sp)
    3318:	f04a                	sd	s2,32(sp)
    331a:	ec4e                	sd	s3,24(sp)
    331c:	e852                	sd	s4,16(sp)
    331e:	e456                	sd	s5,8(sp)
    3320:	e05a                	sd	s6,0(sp)
    3322:	0080                	addi	s0,sp,64
    3324:	8b2a                	mv	s6,a0
    3326:	03300913          	li	s2,51
    if (mkdir("irefd") != 0) {
    332a:	00004a17          	auipc	s4,0x4
    332e:	caea0a13          	addi	s4,s4,-850 # 6fd8 <malloc+0x1aba>
    mkdir("");
    3332:	00003497          	auipc	s1,0x3
    3336:	7ae48493          	addi	s1,s1,1966 # 6ae0 <malloc+0x15c2>
    link("README", "");
    333a:	00002a97          	auipc	s5,0x2
    333e:	4f6a8a93          	addi	s5,s5,1270 # 5830 <malloc+0x312>
    fd = open("xx", O_CREATE);
    3342:	00004997          	auipc	s3,0x4
    3346:	b8e98993          	addi	s3,s3,-1138 # 6ed0 <malloc+0x19b2>
    334a:	a835                	j	3386 <iref+0x76>
      printf("%s: mkdir irefd failed\n", s);
    334c:	85da                	mv	a1,s6
    334e:	00004517          	auipc	a0,0x4
    3352:	c9250513          	addi	a0,a0,-878 # 6fe0 <malloc+0x1ac2>
    3356:	114020ef          	jal	546a <printf>
      exit(1);
    335a:	4505                	li	a0,1
    335c:	4df010ef          	jal	503a <exit>
      printf("%s: chdir irefd failed\n", s);
    3360:	85da                	mv	a1,s6
    3362:	00004517          	auipc	a0,0x4
    3366:	c9650513          	addi	a0,a0,-874 # 6ff8 <malloc+0x1ada>
    336a:	100020ef          	jal	546a <printf>
      exit(1);
    336e:	4505                	li	a0,1
    3370:	4cb010ef          	jal	503a <exit>
      close(fd);
    3374:	4ef010ef          	jal	5062 <close>
    3378:	a82d                	j	33b2 <iref+0xa2>
    unlink("xx");
    337a:	854e                	mv	a0,s3
    337c:	50f010ef          	jal	508a <unlink>
  for (i = 0; i < NINODE + 1; i++) {
    3380:	397d                	addiw	s2,s2,-1
    3382:	04090263          	beqz	s2,33c6 <iref+0xb6>
    if (mkdir("irefd") != 0) {
    3386:	8552                	mv	a0,s4
    3388:	51b010ef          	jal	50a2 <mkdir>
    338c:	f161                	bnez	a0,334c <iref+0x3c>
    if (chdir("irefd") != 0) {
    338e:	8552                	mv	a0,s4
    3390:	51b010ef          	jal	50aa <chdir>
    3394:	f571                	bnez	a0,3360 <iref+0x50>
    mkdir("");
    3396:	8526                	mv	a0,s1
    3398:	50b010ef          	jal	50a2 <mkdir>
    link("README", "");
    339c:	85a6                	mv	a1,s1
    339e:	8556                	mv	a0,s5
    33a0:	4fb010ef          	jal	509a <link>
    fd = open("", O_CREATE);
    33a4:	20000593          	li	a1,512
    33a8:	8526                	mv	a0,s1
    33aa:	4d1010ef          	jal	507a <open>
    if (fd >= 0)
    33ae:	fc0553e3          	bgez	a0,3374 <iref+0x64>
    fd = open("xx", O_CREATE);
    33b2:	20000593          	li	a1,512
    33b6:	854e                	mv	a0,s3
    33b8:	4c3010ef          	jal	507a <open>
    if (fd >= 0)
    33bc:	fa054fe3          	bltz	a0,337a <iref+0x6a>
      close(fd);
    33c0:	4a3010ef          	jal	5062 <close>
    33c4:	bf5d                	j	337a <iref+0x6a>
    33c6:	03300493          	li	s1,51
    chdir("..");
    33ca:	00003997          	auipc	s3,0x3
    33ce:	42e98993          	addi	s3,s3,1070 # 67f8 <malloc+0x12da>
    unlink("irefd");
    33d2:	00004917          	auipc	s2,0x4
    33d6:	c0690913          	addi	s2,s2,-1018 # 6fd8 <malloc+0x1aba>
    chdir("..");
    33da:	854e                	mv	a0,s3
    33dc:	4cf010ef          	jal	50aa <chdir>
    unlink("irefd");
    33e0:	854a                	mv	a0,s2
    33e2:	4a9010ef          	jal	508a <unlink>
  for (i = 0; i < NINODE + 1; i++) {
    33e6:	34fd                	addiw	s1,s1,-1
    33e8:	f8ed                	bnez	s1,33da <iref+0xca>
  chdir("/");
    33ea:	00003517          	auipc	a0,0x3
    33ee:	3b650513          	addi	a0,a0,950 # 67a0 <malloc+0x1282>
    33f2:	4b9010ef          	jal	50aa <chdir>
}
    33f6:	70e2                	ld	ra,56(sp)
    33f8:	7442                	ld	s0,48(sp)
    33fa:	74a2                	ld	s1,40(sp)
    33fc:	7902                	ld	s2,32(sp)
    33fe:	69e2                	ld	s3,24(sp)
    3400:	6a42                	ld	s4,16(sp)
    3402:	6aa2                	ld	s5,8(sp)
    3404:	6b02                	ld	s6,0(sp)
    3406:	6121                	addi	sp,sp,64
    3408:	8082                	ret

000000000000340a <openiputtest>:
{
    340a:	7179                	addi	sp,sp,-48
    340c:	f406                	sd	ra,40(sp)
    340e:	f022                	sd	s0,32(sp)
    3410:	ec26                	sd	s1,24(sp)
    3412:	1800                	addi	s0,sp,48
    3414:	84aa                	mv	s1,a0
  if (mkdir("oidir") < 0) {
    3416:	00004517          	auipc	a0,0x4
    341a:	bfa50513          	addi	a0,a0,-1030 # 7010 <malloc+0x1af2>
    341e:	485010ef          	jal	50a2 <mkdir>
    3422:	02054a63          	bltz	a0,3456 <openiputtest+0x4c>
  pid = fork();
    3426:	40d010ef          	jal	5032 <fork>
  if (pid < 0) {
    342a:	04054063          	bltz	a0,346a <openiputtest+0x60>
  if (pid == 0) {
    342e:	e939                	bnez	a0,3484 <openiputtest+0x7a>
    int fd = open("oidir", O_RDWR);
    3430:	4589                	li	a1,2
    3432:	00004517          	auipc	a0,0x4
    3436:	bde50513          	addi	a0,a0,-1058 # 7010 <malloc+0x1af2>
    343a:	441010ef          	jal	507a <open>
    if (fd >= 0) {
    343e:	04054063          	bltz	a0,347e <openiputtest+0x74>
      printf("%s: open directory for write succeeded\n", s);
    3442:	85a6                	mv	a1,s1
    3444:	00004517          	auipc	a0,0x4
    3448:	bec50513          	addi	a0,a0,-1044 # 7030 <malloc+0x1b12>
    344c:	01e020ef          	jal	546a <printf>
      exit(1);
    3450:	4505                	li	a0,1
    3452:	3e9010ef          	jal	503a <exit>
    printf("%s: mkdir oidir failed\n", s);
    3456:	85a6                	mv	a1,s1
    3458:	00004517          	auipc	a0,0x4
    345c:	bc050513          	addi	a0,a0,-1088 # 7018 <malloc+0x1afa>
    3460:	00a020ef          	jal	546a <printf>
    exit(1);
    3464:	4505                	li	a0,1
    3466:	3d5010ef          	jal	503a <exit>
    printf("%s: fork failed\n", s);
    346a:	85a6                	mv	a1,s1
    346c:	00003517          	auipc	a0,0x3
    3470:	a7c50513          	addi	a0,a0,-1412 # 5ee8 <malloc+0x9ca>
    3474:	7f7010ef          	jal	546a <printf>
    exit(1);
    3478:	4505                	li	a0,1
    347a:	3c1010ef          	jal	503a <exit>
    exit(0);
    347e:	4501                	li	a0,0
    3480:	3bb010ef          	jal	503a <exit>
  pause(1);
    3484:	4505                	li	a0,1
    3486:	445010ef          	jal	50ca <pause>
  if (unlink("oidir") != 0) {
    348a:	00004517          	auipc	a0,0x4
    348e:	b8650513          	addi	a0,a0,-1146 # 7010 <malloc+0x1af2>
    3492:	3f9010ef          	jal	508a <unlink>
    3496:	c919                	beqz	a0,34ac <openiputtest+0xa2>
    printf("%s: unlink failed\n", s);
    3498:	85a6                	mv	a1,s1
    349a:	00003517          	auipc	a0,0x3
    349e:	bd650513          	addi	a0,a0,-1066 # 6070 <malloc+0xb52>
    34a2:	7c9010ef          	jal	546a <printf>
    exit(1);
    34a6:	4505                	li	a0,1
    34a8:	393010ef          	jal	503a <exit>
  wait(&xstatus);
    34ac:	fdc40513          	addi	a0,s0,-36
    34b0:	393010ef          	jal	5042 <wait>
  exit(xstatus);
    34b4:	fdc42503          	lw	a0,-36(s0)
    34b8:	383010ef          	jal	503a <exit>

00000000000034bc <forkforkfork>:
{
    34bc:	1101                	addi	sp,sp,-32
    34be:	ec06                	sd	ra,24(sp)
    34c0:	e822                	sd	s0,16(sp)
    34c2:	e426                	sd	s1,8(sp)
    34c4:	1000                	addi	s0,sp,32
    34c6:	84aa                	mv	s1,a0
  unlink("stopforking");
    34c8:	00004517          	auipc	a0,0x4
    34cc:	b9050513          	addi	a0,a0,-1136 # 7058 <malloc+0x1b3a>
    34d0:	3bb010ef          	jal	508a <unlink>
  int pid = fork();
    34d4:	35f010ef          	jal	5032 <fork>
  if (pid < 0) {
    34d8:	02054b63          	bltz	a0,350e <forkforkfork+0x52>
  if (pid == 0) {
    34dc:	c139                	beqz	a0,3522 <forkforkfork+0x66>
  pause(20); // two seconds
    34de:	4551                	li	a0,20
    34e0:	3eb010ef          	jal	50ca <pause>
  close(open("stopforking", O_CREATE | O_RDWR));
    34e4:	20200593          	li	a1,514
    34e8:	00004517          	auipc	a0,0x4
    34ec:	b7050513          	addi	a0,a0,-1168 # 7058 <malloc+0x1b3a>
    34f0:	38b010ef          	jal	507a <open>
    34f4:	36f010ef          	jal	5062 <close>
  wait(0);
    34f8:	4501                	li	a0,0
    34fa:	349010ef          	jal	5042 <wait>
  pause(10); // one second
    34fe:	4529                	li	a0,10
    3500:	3cb010ef          	jal	50ca <pause>
}
    3504:	60e2                	ld	ra,24(sp)
    3506:	6442                	ld	s0,16(sp)
    3508:	64a2                	ld	s1,8(sp)
    350a:	6105                	addi	sp,sp,32
    350c:	8082                	ret
    printf("%s: fork failed", s);
    350e:	85a6                	mv	a1,s1
    3510:	00003517          	auipc	a0,0x3
    3514:	b1850513          	addi	a0,a0,-1256 # 6028 <malloc+0xb0a>
    3518:	753010ef          	jal	546a <printf>
    exit(1);
    351c:	4505                	li	a0,1
    351e:	31d010ef          	jal	503a <exit>
      int fd = open("stopforking", 0);
    3522:	00004497          	auipc	s1,0x4
    3526:	b3648493          	addi	s1,s1,-1226 # 7058 <malloc+0x1b3a>
    352a:	4581                	li	a1,0
    352c:	8526                	mv	a0,s1
    352e:	34d010ef          	jal	507a <open>
      if (fd >= 0) {
    3532:	02055163          	bgez	a0,3554 <forkforkfork+0x98>
      if (fork() < 0) {
    3536:	2fd010ef          	jal	5032 <fork>
    353a:	fe0558e3          	bgez	a0,352a <forkforkfork+0x6e>
        close(open("stopforking", O_CREATE | O_RDWR));
    353e:	20200593          	li	a1,514
    3542:	00004517          	auipc	a0,0x4
    3546:	b1650513          	addi	a0,a0,-1258 # 7058 <malloc+0x1b3a>
    354a:	331010ef          	jal	507a <open>
    354e:	315010ef          	jal	5062 <close>
    3552:	bfe1                	j	352a <forkforkfork+0x6e>
        exit(0);
    3554:	4501                	li	a0,0
    3556:	2e5010ef          	jal	503a <exit>

000000000000355a <exectest>:
{
    355a:	711d                	addi	sp,sp,-96
    355c:	ec86                	sd	ra,88(sp)
    355e:	e8a2                	sd	s0,80(sp)
    3560:	e0ca                	sd	s2,64(sp)
    3562:	1080                	addi	s0,sp,96
    3564:	892a                	mv	s2,a0
  char *echoargv[] = {"echo", "OK", 0};
    3566:	00002797          	auipc	a5,0x2
    356a:	0f278793          	addi	a5,a5,242 # 5658 <malloc+0x13a>
    356e:	faf43823          	sd	a5,-80(s0)
    3572:	00004797          	auipc	a5,0x4
    3576:	af678793          	addi	a5,a5,-1290 # 7068 <malloc+0x1b4a>
    357a:	faf43c23          	sd	a5,-72(s0)
    357e:	fc043023          	sd	zero,-64(s0)
  unlink("echo-ok");
    3582:	00004517          	auipc	a0,0x4
    3586:	aee50513          	addi	a0,a0,-1298 # 7070 <malloc+0x1b52>
    358a:	301010ef          	jal	508a <unlink>
  pid = fork();
    358e:	2a5010ef          	jal	5032 <fork>
  if (pid < 0) {
    3592:	04054763          	bltz	a0,35e0 <exectest+0x86>
    3596:	e4a6                	sd	s1,72(sp)
    3598:	fc4e                	sd	s3,56(sp)
    359a:	84aa                	mv	s1,a0
  if (pid == 0) {
    359c:	ed49                	bnez	a0,3636 <exectest+0xdc>
    int errfd = dup(1);
    359e:	4505                	li	a0,1
    35a0:	313010ef          	jal	50b2 <dup>
    35a4:	89aa                	mv	s3,a0
    if (errfd < 0) {
    35a6:	04054963          	bltz	a0,35f8 <exectest+0x9e>
    close(1);
    35aa:	4505                	li	a0,1
    35ac:	2b7010ef          	jal	5062 <close>
    fd = open("echo-ok", O_CREATE | O_WRONLY);
    35b0:	20100593          	li	a1,513
    35b4:	00004517          	auipc	a0,0x4
    35b8:	abc50513          	addi	a0,a0,-1348 # 7070 <malloc+0x1b52>
    35bc:	2bf010ef          	jal	507a <open>
    if (fd < 0) {
    35c0:	04054663          	bltz	a0,360c <exectest+0xb2>
    if (fd != 1) {
    35c4:	4785                	li	a5,1
    35c6:	04f50e63          	beq	a0,a5,3622 <exectest+0xc8>
      fprintf(errfd, "%s: wrong fd\n", s);
    35ca:	864a                	mv	a2,s2
    35cc:	00004597          	auipc	a1,0x4
    35d0:	abc58593          	addi	a1,a1,-1348 # 7088 <malloc+0x1b6a>
    35d4:	854e                	mv	a0,s3
    35d6:	66b010ef          	jal	5440 <fprintf>
      exit(1);
    35da:	4505                	li	a0,1
    35dc:	25f010ef          	jal	503a <exit>
    35e0:	e4a6                	sd	s1,72(sp)
    35e2:	fc4e                	sd	s3,56(sp)
    printf("%s: fork failed\n", s);
    35e4:	85ca                	mv	a1,s2
    35e6:	00003517          	auipc	a0,0x3
    35ea:	90250513          	addi	a0,a0,-1790 # 5ee8 <malloc+0x9ca>
    35ee:	67d010ef          	jal	546a <printf>
    exit(1);
    35f2:	4505                	li	a0,1
    35f4:	247010ef          	jal	503a <exit>
      printf("%s: dup failed\n", s);
    35f8:	85ca                	mv	a1,s2
    35fa:	00004517          	auipc	a0,0x4
    35fe:	a7e50513          	addi	a0,a0,-1410 # 7078 <malloc+0x1b5a>
    3602:	669010ef          	jal	546a <printf>
      exit(1);
    3606:	4505                	li	a0,1
    3608:	233010ef          	jal	503a <exit>
      fprintf(errfd, "%s: create failed\n", s);
    360c:	864a                	mv	a2,s2
    360e:	00003597          	auipc	a1,0x3
    3612:	a4a58593          	addi	a1,a1,-1462 # 6058 <malloc+0xb3a>
    3616:	854e                	mv	a0,s3
    3618:	629010ef          	jal	5440 <fprintf>
      exit(1);
    361c:	4505                	li	a0,1
    361e:	21d010ef          	jal	503a <exit>
    if (exec("echo", echoargv) < 0) {
    3622:	fb040593          	addi	a1,s0,-80
    3626:	00002517          	auipc	a0,0x2
    362a:	03250513          	addi	a0,a0,50 # 5658 <malloc+0x13a>
    362e:	245010ef          	jal	5072 <exec>
    3632:	02054563          	bltz	a0,365c <exectest+0x102>
  if (wait(&xstatus) != pid) {
    3636:	fcc40513          	addi	a0,s0,-52
    363a:	209010ef          	jal	5042 <wait>
    363e:	02951a63          	bne	a0,s1,3672 <exectest+0x118>
  if (xstatus != 0) {
    3642:	fcc42603          	lw	a2,-52(s0)
    3646:	ce15                	beqz	a2,3682 <exectest+0x128>
    printf("%s: nonzero wait status %d\n", s, xstatus);
    3648:	85ca                	mv	a1,s2
    364a:	00004517          	auipc	a0,0x4
    364e:	a7e50513          	addi	a0,a0,-1410 # 70c8 <malloc+0x1baa>
    3652:	619010ef          	jal	546a <printf>
    exit(1);
    3656:	4505                	li	a0,1
    3658:	1e3010ef          	jal	503a <exit>
      fprintf(errfd, "%s: exec echo failed\n", s);
    365c:	864a                	mv	a2,s2
    365e:	00004597          	auipc	a1,0x4
    3662:	a3a58593          	addi	a1,a1,-1478 # 7098 <malloc+0x1b7a>
    3666:	854e                	mv	a0,s3
    3668:	5d9010ef          	jal	5440 <fprintf>
      exit(1);
    366c:	4505                	li	a0,1
    366e:	1cd010ef          	jal	503a <exit>
    printf("%s: wait failed!\n", s);
    3672:	85ca                	mv	a1,s2
    3674:	00004517          	auipc	a0,0x4
    3678:	a3c50513          	addi	a0,a0,-1476 # 70b0 <malloc+0x1b92>
    367c:	5ef010ef          	jal	546a <printf>
    3680:	b7c9                	j	3642 <exectest+0xe8>
  fd = open("echo-ok", O_RDONLY);
    3682:	4581                	li	a1,0
    3684:	00004517          	auipc	a0,0x4
    3688:	9ec50513          	addi	a0,a0,-1556 # 7070 <malloc+0x1b52>
    368c:	1ef010ef          	jal	507a <open>
  if (fd < 0) {
    3690:	02054463          	bltz	a0,36b8 <exectest+0x15e>
  if (read(fd, buf, 2) != 2) {
    3694:	4609                	li	a2,2
    3696:	fa840593          	addi	a1,s0,-88
    369a:	1b9010ef          	jal	5052 <read>
    369e:	4789                	li	a5,2
    36a0:	02f50663          	beq	a0,a5,36cc <exectest+0x172>
    printf("%s: read failed\n", s);
    36a4:	85ca                	mv	a1,s2
    36a6:	00002517          	auipc	a0,0x2
    36aa:	38250513          	addi	a0,a0,898 # 5a28 <malloc+0x50a>
    36ae:	5bd010ef          	jal	546a <printf>
    exit(1);
    36b2:	4505                	li	a0,1
    36b4:	187010ef          	jal	503a <exit>
    printf("%s: open failed\n", s);
    36b8:	85ca                	mv	a1,s2
    36ba:	00003517          	auipc	a0,0x3
    36be:	84650513          	addi	a0,a0,-1978 # 5f00 <malloc+0x9e2>
    36c2:	5a9010ef          	jal	546a <printf>
    exit(1);
    36c6:	4505                	li	a0,1
    36c8:	173010ef          	jal	503a <exit>
  unlink("echo-ok");
    36cc:	00004517          	auipc	a0,0x4
    36d0:	9a450513          	addi	a0,a0,-1628 # 7070 <malloc+0x1b52>
    36d4:	1b7010ef          	jal	508a <unlink>
  if (buf[0] == 'O' && buf[1] == 'K')
    36d8:	fa844703          	lbu	a4,-88(s0)
    36dc:	04f00793          	li	a5,79
    36e0:	00f71863          	bne	a4,a5,36f0 <exectest+0x196>
    36e4:	fa944703          	lbu	a4,-87(s0)
    36e8:	04b00793          	li	a5,75
    36ec:	00f70c63          	beq	a4,a5,3704 <exectest+0x1aa>
    printf("%s: wrong output\n", s);
    36f0:	85ca                	mv	a1,s2
    36f2:	00004517          	auipc	a0,0x4
    36f6:	9f650513          	addi	a0,a0,-1546 # 70e8 <malloc+0x1bca>
    36fa:	571010ef          	jal	546a <printf>
    exit(1);
    36fe:	4505                	li	a0,1
    3700:	13b010ef          	jal	503a <exit>
    exit(0);
    3704:	4501                	li	a0,0
    3706:	135010ef          	jal	503a <exit>

000000000000370a <killstatus>:
{
    370a:	7139                	addi	sp,sp,-64
    370c:	fc06                	sd	ra,56(sp)
    370e:	f822                	sd	s0,48(sp)
    3710:	f426                	sd	s1,40(sp)
    3712:	f04a                	sd	s2,32(sp)
    3714:	ec4e                	sd	s3,24(sp)
    3716:	e852                	sd	s4,16(sp)
    3718:	0080                	addi	s0,sp,64
    371a:	8a2a                	mv	s4,a0
    371c:	06400913          	li	s2,100
    if (xst != -1) {
    3720:	59fd                	li	s3,-1
    int pid1 = fork();
    3722:	111010ef          	jal	5032 <fork>
    3726:	84aa                	mv	s1,a0
    if (pid1 < 0) {
    3728:	02054763          	bltz	a0,3756 <killstatus+0x4c>
    if (pid1 == 0) {
    372c:	cd1d                	beqz	a0,376a <killstatus+0x60>
    pause(1);
    372e:	4505                	li	a0,1
    3730:	19b010ef          	jal	50ca <pause>
    kill(pid1);
    3734:	8526                	mv	a0,s1
    3736:	135010ef          	jal	506a <kill>
    wait(&xst);
    373a:	fcc40513          	addi	a0,s0,-52
    373e:	105010ef          	jal	5042 <wait>
    if (xst != -1) {
    3742:	fcc42783          	lw	a5,-52(s0)
    3746:	03379563          	bne	a5,s3,3770 <killstatus+0x66>
  for (int i = 0; i < 100; i++) {
    374a:	397d                	addiw	s2,s2,-1
    374c:	fc091be3          	bnez	s2,3722 <killstatus+0x18>
  exit(0);
    3750:	4501                	li	a0,0
    3752:	0e9010ef          	jal	503a <exit>
      printf("%s: fork failed\n", s);
    3756:	85d2                	mv	a1,s4
    3758:	00002517          	auipc	a0,0x2
    375c:	79050513          	addi	a0,a0,1936 # 5ee8 <malloc+0x9ca>
    3760:	50b010ef          	jal	546a <printf>
      exit(1);
    3764:	4505                	li	a0,1
    3766:	0d5010ef          	jal	503a <exit>
        getpid();
    376a:	151010ef          	jal	50ba <getpid>
      while (1) {
    376e:	bff5                	j	376a <killstatus+0x60>
      printf("%s: status should be -1\n", s);
    3770:	85d2                	mv	a1,s4
    3772:	00004517          	auipc	a0,0x4
    3776:	98e50513          	addi	a0,a0,-1650 # 7100 <malloc+0x1be2>
    377a:	4f1010ef          	jal	546a <printf>
      exit(1);
    377e:	4505                	li	a0,1
    3780:	0bb010ef          	jal	503a <exit>

0000000000003784 <preempt>:
{
    3784:	7139                	addi	sp,sp,-64
    3786:	fc06                	sd	ra,56(sp)
    3788:	f822                	sd	s0,48(sp)
    378a:	f426                	sd	s1,40(sp)
    378c:	f04a                	sd	s2,32(sp)
    378e:	ec4e                	sd	s3,24(sp)
    3790:	e852                	sd	s4,16(sp)
    3792:	0080                	addi	s0,sp,64
    3794:	892a                	mv	s2,a0
  pid1 = fork();
    3796:	09d010ef          	jal	5032 <fork>
  if (pid1 < 0) {
    379a:	00054563          	bltz	a0,37a4 <preempt+0x20>
    379e:	84aa                	mv	s1,a0
  if (pid1 == 0)
    37a0:	ed01                	bnez	a0,37b8 <preempt+0x34>
    for (;;)
    37a2:	a001                	j	37a2 <preempt+0x1e>
    printf("%s: fork failed", s);
    37a4:	85ca                	mv	a1,s2
    37a6:	00003517          	auipc	a0,0x3
    37aa:	88250513          	addi	a0,a0,-1918 # 6028 <malloc+0xb0a>
    37ae:	4bd010ef          	jal	546a <printf>
    exit(1);
    37b2:	4505                	li	a0,1
    37b4:	087010ef          	jal	503a <exit>
  pid2 = fork();
    37b8:	07b010ef          	jal	5032 <fork>
    37bc:	89aa                	mv	s3,a0
  if (pid2 < 0) {
    37be:	00054463          	bltz	a0,37c6 <preempt+0x42>
  if (pid2 == 0)
    37c2:	ed01                	bnez	a0,37da <preempt+0x56>
    for (;;)
    37c4:	a001                	j	37c4 <preempt+0x40>
    printf("%s: fork failed\n", s);
    37c6:	85ca                	mv	a1,s2
    37c8:	00002517          	auipc	a0,0x2
    37cc:	72050513          	addi	a0,a0,1824 # 5ee8 <malloc+0x9ca>
    37d0:	49b010ef          	jal	546a <printf>
    exit(1);
    37d4:	4505                	li	a0,1
    37d6:	065010ef          	jal	503a <exit>
  pipe(pfds);
    37da:	fc840513          	addi	a0,s0,-56
    37de:	06d010ef          	jal	504a <pipe>
  pid3 = fork();
    37e2:	051010ef          	jal	5032 <fork>
    37e6:	8a2a                	mv	s4,a0
  if (pid3 < 0) {
    37e8:	02054863          	bltz	a0,3818 <preempt+0x94>
  if (pid3 == 0) {
    37ec:	e921                	bnez	a0,383c <preempt+0xb8>
    close(pfds[0]);
    37ee:	fc842503          	lw	a0,-56(s0)
    37f2:	071010ef          	jal	5062 <close>
    if (write(pfds[1], "x", 1) != 1)
    37f6:	4605                	li	a2,1
    37f8:	00002597          	auipc	a1,0x2
    37fc:	ed058593          	addi	a1,a1,-304 # 56c8 <malloc+0x1aa>
    3800:	fcc42503          	lw	a0,-52(s0)
    3804:	057010ef          	jal	505a <write>
    3808:	4785                	li	a5,1
    380a:	02f51163          	bne	a0,a5,382c <preempt+0xa8>
    close(pfds[1]);
    380e:	fcc42503          	lw	a0,-52(s0)
    3812:	051010ef          	jal	5062 <close>
    for (;;)
    3816:	a001                	j	3816 <preempt+0x92>
    printf("%s: fork failed\n", s);
    3818:	85ca                	mv	a1,s2
    381a:	00002517          	auipc	a0,0x2
    381e:	6ce50513          	addi	a0,a0,1742 # 5ee8 <malloc+0x9ca>
    3822:	449010ef          	jal	546a <printf>
    exit(1);
    3826:	4505                	li	a0,1
    3828:	013010ef          	jal	503a <exit>
      printf("%s: preempt write error", s);
    382c:	85ca                	mv	a1,s2
    382e:	00004517          	auipc	a0,0x4
    3832:	8f250513          	addi	a0,a0,-1806 # 7120 <malloc+0x1c02>
    3836:	435010ef          	jal	546a <printf>
    383a:	bfd1                	j	380e <preempt+0x8a>
  close(pfds[1]);
    383c:	fcc42503          	lw	a0,-52(s0)
    3840:	023010ef          	jal	5062 <close>
  if (read(pfds[0], buf, sizeof(buf)) != 1) {
    3844:	660d                	lui	a2,0x3
    3846:	00008597          	auipc	a1,0x8
    384a:	48258593          	addi	a1,a1,1154 # bcc8 <buf>
    384e:	fc842503          	lw	a0,-56(s0)
    3852:	001010ef          	jal	5052 <read>
    3856:	4785                	li	a5,1
    3858:	02f50163          	beq	a0,a5,387a <preempt+0xf6>
    printf("%s: preempt read error", s);
    385c:	85ca                	mv	a1,s2
    385e:	00004517          	auipc	a0,0x4
    3862:	8da50513          	addi	a0,a0,-1830 # 7138 <malloc+0x1c1a>
    3866:	405010ef          	jal	546a <printf>
}
    386a:	70e2                	ld	ra,56(sp)
    386c:	7442                	ld	s0,48(sp)
    386e:	74a2                	ld	s1,40(sp)
    3870:	7902                	ld	s2,32(sp)
    3872:	69e2                	ld	s3,24(sp)
    3874:	6a42                	ld	s4,16(sp)
    3876:	6121                	addi	sp,sp,64
    3878:	8082                	ret
  close(pfds[0]);
    387a:	fc842503          	lw	a0,-56(s0)
    387e:	7e4010ef          	jal	5062 <close>
  printf("kill... ");
    3882:	00004517          	auipc	a0,0x4
    3886:	8ce50513          	addi	a0,a0,-1842 # 7150 <malloc+0x1c32>
    388a:	3e1010ef          	jal	546a <printf>
  kill(pid1);
    388e:	8526                	mv	a0,s1
    3890:	7da010ef          	jal	506a <kill>
  kill(pid2);
    3894:	854e                	mv	a0,s3
    3896:	7d4010ef          	jal	506a <kill>
  kill(pid3);
    389a:	8552                	mv	a0,s4
    389c:	7ce010ef          	jal	506a <kill>
  printf("wait... ");
    38a0:	00004517          	auipc	a0,0x4
    38a4:	8c050513          	addi	a0,a0,-1856 # 7160 <malloc+0x1c42>
    38a8:	3c3010ef          	jal	546a <printf>
  wait(0);
    38ac:	4501                	li	a0,0
    38ae:	794010ef          	jal	5042 <wait>
  wait(0);
    38b2:	4501                	li	a0,0
    38b4:	78e010ef          	jal	5042 <wait>
  wait(0);
    38b8:	4501                	li	a0,0
    38ba:	788010ef          	jal	5042 <wait>
    38be:	b775                	j	386a <preempt+0xe6>

00000000000038c0 <reparent>:
{
    38c0:	7179                	addi	sp,sp,-48
    38c2:	f406                	sd	ra,40(sp)
    38c4:	f022                	sd	s0,32(sp)
    38c6:	ec26                	sd	s1,24(sp)
    38c8:	e84a                	sd	s2,16(sp)
    38ca:	e44e                	sd	s3,8(sp)
    38cc:	e052                	sd	s4,0(sp)
    38ce:	1800                	addi	s0,sp,48
    38d0:	89aa                	mv	s3,a0
  int master_pid = getpid();
    38d2:	7e8010ef          	jal	50ba <getpid>
    38d6:	8a2a                	mv	s4,a0
    38d8:	0c800913          	li	s2,200
    int pid = fork();
    38dc:	756010ef          	jal	5032 <fork>
    38e0:	84aa                	mv	s1,a0
    if (pid < 0) {
    38e2:	00054e63          	bltz	a0,38fe <reparent+0x3e>
    if (pid) {
    38e6:	c121                	beqz	a0,3926 <reparent+0x66>
      if (wait(0) != pid) {
    38e8:	4501                	li	a0,0
    38ea:	758010ef          	jal	5042 <wait>
    38ee:	02951263          	bne	a0,s1,3912 <reparent+0x52>
  for (int i = 0; i < 200; i++) {
    38f2:	397d                	addiw	s2,s2,-1
    38f4:	fe0914e3          	bnez	s2,38dc <reparent+0x1c>
  exit(0);
    38f8:	4501                	li	a0,0
    38fa:	740010ef          	jal	503a <exit>
      printf("%s: fork failed\n", s);
    38fe:	85ce                	mv	a1,s3
    3900:	00002517          	auipc	a0,0x2
    3904:	5e850513          	addi	a0,a0,1512 # 5ee8 <malloc+0x9ca>
    3908:	363010ef          	jal	546a <printf>
      exit(1);
    390c:	4505                	li	a0,1
    390e:	72c010ef          	jal	503a <exit>
        printf("%s: wait wrong pid\n", s);
    3912:	85ce                	mv	a1,s3
    3914:	00002517          	auipc	a0,0x2
    3918:	6dc50513          	addi	a0,a0,1756 # 5ff0 <malloc+0xad2>
    391c:	34f010ef          	jal	546a <printf>
        exit(1);
    3920:	4505                	li	a0,1
    3922:	718010ef          	jal	503a <exit>
      int pid2 = fork();
    3926:	70c010ef          	jal	5032 <fork>
      if (pid2 < 0) {
    392a:	00054563          	bltz	a0,3934 <reparent+0x74>
      exit(0);
    392e:	4501                	li	a0,0
    3930:	70a010ef          	jal	503a <exit>
        kill(master_pid);
    3934:	8552                	mv	a0,s4
    3936:	734010ef          	jal	506a <kill>
        exit(1);
    393a:	4505                	li	a0,1
    393c:	6fe010ef          	jal	503a <exit>

0000000000003940 <sbrkfail>:
{
    3940:	7175                	addi	sp,sp,-144
    3942:	e506                	sd	ra,136(sp)
    3944:	e122                	sd	s0,128(sp)
    3946:	fca6                	sd	s1,120(sp)
    3948:	f8ca                	sd	s2,112(sp)
    394a:	f4ce                	sd	s3,104(sp)
    394c:	f0d2                	sd	s4,96(sp)
    394e:	ecd6                	sd	s5,88(sp)
    3950:	e8da                	sd	s6,80(sp)
    3952:	e4de                	sd	s7,72(sp)
    3954:	0900                	addi	s0,sp,144
    3956:	8b2a                	mv	s6,a0
  if (pipe(fds) != 0) {
    3958:	fa040513          	addi	a0,s0,-96
    395c:	6ee010ef          	jal	504a <pipe>
    3960:	e919                	bnez	a0,3976 <sbrkfail+0x36>
    3962:	8aaa                	mv	s5,a0
    3964:	f7040493          	addi	s1,s0,-144
    3968:	f9840993          	addi	s3,s0,-104
    396c:	8926                	mv	s2,s1
    if (pids[i] != -1) {
    396e:	5a7d                	li	s4,-1
      if (scratch == '0')
    3970:	03000b93          	li	s7,48
    3974:	a08d                	j	39d6 <sbrkfail+0x96>
    printf("%s: pipe() failed\n", s);
    3976:	85da                	mv	a1,s6
    3978:	00002517          	auipc	a0,0x2
    397c:	5f850513          	addi	a0,a0,1528 # 5f70 <malloc+0xa52>
    3980:	2eb010ef          	jal	546a <printf>
    exit(1);
    3984:	4505                	li	a0,1
    3986:	6b4010ef          	jal	503a <exit>
      if (sbrk(BIG - (uint64)sbrk(0)) == (char *)SBRK_ERROR)
    398a:	67c010ef          	jal	5006 <sbrk>
    398e:	064007b7          	lui	a5,0x6400
    3992:	40a7853b          	subw	a0,a5,a0
    3996:	670010ef          	jal	5006 <sbrk>
    399a:	57fd                	li	a5,-1
    399c:	02f50063          	beq	a0,a5,39bc <sbrkfail+0x7c>
        write(fds[1], "1", 1);
    39a0:	4605                	li	a2,1
    39a2:	00004597          	auipc	a1,0x4
    39a6:	07e58593          	addi	a1,a1,126 # 7a20 <malloc+0x2502>
    39aa:	fa442503          	lw	a0,-92(s0)
    39ae:	6ac010ef          	jal	505a <write>
        pause(1000);
    39b2:	3e800513          	li	a0,1000
    39b6:	714010ef          	jal	50ca <pause>
      for (;;)
    39ba:	bfe5                	j	39b2 <sbrkfail+0x72>
        write(fds[1], "0", 1);
    39bc:	4605                	li	a2,1
    39be:	00003597          	auipc	a1,0x3
    39c2:	7b258593          	addi	a1,a1,1970 # 7170 <malloc+0x1c52>
    39c6:	fa442503          	lw	a0,-92(s0)
    39ca:	690010ef          	jal	505a <write>
    39ce:	b7d5                	j	39b2 <sbrkfail+0x72>
  for (i = 0; i < sizeof(pids) / sizeof(pids[0]); i++) {
    39d0:	0911                	addi	s2,s2,4
    39d2:	03390663          	beq	s2,s3,39fe <sbrkfail+0xbe>
    if ((pids[i] = fork()) == 0) {
    39d6:	65c010ef          	jal	5032 <fork>
    39da:	00a92023          	sw	a0,0(s2)
    39de:	d555                	beqz	a0,398a <sbrkfail+0x4a>
    if (pids[i] != -1) {
    39e0:	ff4508e3          	beq	a0,s4,39d0 <sbrkfail+0x90>
      read(fds[0], &scratch, 1);
    39e4:	4605                	li	a2,1
    39e6:	f9f40593          	addi	a1,s0,-97
    39ea:	fa042503          	lw	a0,-96(s0)
    39ee:	664010ef          	jal	5052 <read>
      if (scratch == '0')
    39f2:	f9f44783          	lbu	a5,-97(s0)
    39f6:	fd779de3          	bne	a5,s7,39d0 <sbrkfail+0x90>
        failed = 1;
    39fa:	4a85                	li	s5,1
    39fc:	bfd1                	j	39d0 <sbrkfail+0x90>
  if (!failed) {
    39fe:	000a8863          	beqz	s5,3a0e <sbrkfail+0xce>
  c = sbrk(PGSIZE);
    3a02:	6505                	lui	a0,0x1
    3a04:	602010ef          	jal	5006 <sbrk>
    3a08:	8a2a                	mv	s4,a0
    if (pids[i] == -1)
    3a0a:	597d                	li	s2,-1
    3a0c:	a821                	j	3a24 <sbrkfail+0xe4>
    printf("%s: no allocation failed; allocate more?\n", s);
    3a0e:	85da                	mv	a1,s6
    3a10:	00003517          	auipc	a0,0x3
    3a14:	76850513          	addi	a0,a0,1896 # 7178 <malloc+0x1c5a>
    3a18:	253010ef          	jal	546a <printf>
    3a1c:	b7dd                	j	3a02 <sbrkfail+0xc2>
  for (i = 0; i < sizeof(pids) / sizeof(pids[0]); i++) {
    3a1e:	0491                	addi	s1,s1,4
    3a20:	01348b63          	beq	s1,s3,3a36 <sbrkfail+0xf6>
    if (pids[i] == -1)
    3a24:	4088                	lw	a0,0(s1)
    3a26:	ff250ce3          	beq	a0,s2,3a1e <sbrkfail+0xde>
    kill(pids[i]);
    3a2a:	640010ef          	jal	506a <kill>
    wait(0);
    3a2e:	4501                	li	a0,0
    3a30:	612010ef          	jal	5042 <wait>
    3a34:	b7ed                	j	3a1e <sbrkfail+0xde>
  if (c == (char *)SBRK_ERROR) {
    3a36:	57fd                	li	a5,-1
    3a38:	02fa0a63          	beq	s4,a5,3a6c <sbrkfail+0x12c>
  pid = fork();
    3a3c:	5f6010ef          	jal	5032 <fork>
  if (pid < 0) {
    3a40:	04054063          	bltz	a0,3a80 <sbrkfail+0x140>
  if (pid == 0) {
    3a44:	e939                	bnez	a0,3a9a <sbrkfail+0x15a>
    a = sbrk(10 * BIG);
    3a46:	3e800537          	lui	a0,0x3e800
    3a4a:	5bc010ef          	jal	5006 <sbrk>
    if (a == (char *)SBRK_ERROR) {
    3a4e:	57fd                	li	a5,-1
    3a50:	04f50263          	beq	a0,a5,3a94 <sbrkfail+0x154>
    printf("%s: allocate a lot of memory succeeded %d\n", s, 10 * BIG);
    3a54:	3e800637          	lui	a2,0x3e800
    3a58:	85da                	mv	a1,s6
    3a5a:	00003517          	auipc	a0,0x3
    3a5e:	76e50513          	addi	a0,a0,1902 # 71c8 <malloc+0x1caa>
    3a62:	209010ef          	jal	546a <printf>
    exit(1);
    3a66:	4505                	li	a0,1
    3a68:	5d2010ef          	jal	503a <exit>
    printf("%s: failed sbrk leaked memory\n", s);
    3a6c:	85da                	mv	a1,s6
    3a6e:	00003517          	auipc	a0,0x3
    3a72:	73a50513          	addi	a0,a0,1850 # 71a8 <malloc+0x1c8a>
    3a76:	1f5010ef          	jal	546a <printf>
    exit(1);
    3a7a:	4505                	li	a0,1
    3a7c:	5be010ef          	jal	503a <exit>
    printf("%s: fork failed\n", s);
    3a80:	85da                	mv	a1,s6
    3a82:	00002517          	auipc	a0,0x2
    3a86:	46650513          	addi	a0,a0,1126 # 5ee8 <malloc+0x9ca>
    3a8a:	1e1010ef          	jal	546a <printf>
    exit(1);
    3a8e:	4505                	li	a0,1
    3a90:	5aa010ef          	jal	503a <exit>
      exit(0);
    3a94:	4501                	li	a0,0
    3a96:	5a4010ef          	jal	503a <exit>
  wait(&xstatus);
    3a9a:	fac40513          	addi	a0,s0,-84
    3a9e:	5a4010ef          	jal	5042 <wait>
  if (xstatus != 0)
    3aa2:	fac42783          	lw	a5,-84(s0)
    3aa6:	ef81                	bnez	a5,3abe <sbrkfail+0x17e>
}
    3aa8:	60aa                	ld	ra,136(sp)
    3aaa:	640a                	ld	s0,128(sp)
    3aac:	74e6                	ld	s1,120(sp)
    3aae:	7946                	ld	s2,112(sp)
    3ab0:	79a6                	ld	s3,104(sp)
    3ab2:	7a06                	ld	s4,96(sp)
    3ab4:	6ae6                	ld	s5,88(sp)
    3ab6:	6b46                	ld	s6,80(sp)
    3ab8:	6ba6                	ld	s7,72(sp)
    3aba:	6149                	addi	sp,sp,144
    3abc:	8082                	ret
    exit(1);
    3abe:	4505                	li	a0,1
    3ac0:	57a010ef          	jal	503a <exit>

0000000000003ac4 <mem>:
{
    3ac4:	7139                	addi	sp,sp,-64
    3ac6:	fc06                	sd	ra,56(sp)
    3ac8:	f822                	sd	s0,48(sp)
    3aca:	f426                	sd	s1,40(sp)
    3acc:	f04a                	sd	s2,32(sp)
    3ace:	ec4e                	sd	s3,24(sp)
    3ad0:	0080                	addi	s0,sp,64
    3ad2:	89aa                	mv	s3,a0
  if ((pid = fork()) == 0) {
    3ad4:	55e010ef          	jal	5032 <fork>
    m1 = 0;
    3ad8:	4481                	li	s1,0
    while ((m2 = malloc(10001)) != 0) {
    3ada:	6909                	lui	s2,0x2
    3adc:	71190913          	addi	s2,s2,1809 # 2711 <diskfull+0xd1>
  if ((pid = fork()) == 0) {
    3ae0:	cd11                	beqz	a0,3afc <mem+0x38>
    wait(&xstatus);
    3ae2:	fcc40513          	addi	a0,s0,-52
    3ae6:	55c010ef          	jal	5042 <wait>
    if (xstatus == -1) {
    3aea:	fcc42503          	lw	a0,-52(s0)
    3aee:	57fd                	li	a5,-1
    3af0:	04f50363          	beq	a0,a5,3b36 <mem+0x72>
    exit(xstatus);
    3af4:	546010ef          	jal	503a <exit>
      *(char **)m2 = m1;
    3af8:	e104                	sd	s1,0(a0)
      m1 = m2;
    3afa:	84aa                	mv	s1,a0
    while ((m2 = malloc(10001)) != 0) {
    3afc:	854a                	mv	a0,s2
    3afe:	221010ef          	jal	551e <malloc>
    3b02:	f97d                	bnez	a0,3af8 <mem+0x34>
    while (m1) {
    3b04:	c491                	beqz	s1,3b10 <mem+0x4c>
      m2 = *(char **)m1;
    3b06:	8526                	mv	a0,s1
    3b08:	6084                	ld	s1,0(s1)
      free(m1);
    3b0a:	193010ef          	jal	549c <free>
    while (m1) {
    3b0e:	fce5                	bnez	s1,3b06 <mem+0x42>
    m1 = malloc(1024 * 20);
    3b10:	6515                	lui	a0,0x5
    3b12:	20d010ef          	jal	551e <malloc>
    if (m1 == 0) {
    3b16:	c511                	beqz	a0,3b22 <mem+0x5e>
    free(m1);
    3b18:	185010ef          	jal	549c <free>
    exit(0);
    3b1c:	4501                	li	a0,0
    3b1e:	51c010ef          	jal	503a <exit>
      printf("%s: couldn't allocate mem?!!\n", s);
    3b22:	85ce                	mv	a1,s3
    3b24:	00003517          	auipc	a0,0x3
    3b28:	6d450513          	addi	a0,a0,1748 # 71f8 <malloc+0x1cda>
    3b2c:	13f010ef          	jal	546a <printf>
      exit(1);
    3b30:	4505                	li	a0,1
    3b32:	508010ef          	jal	503a <exit>
      exit(0);
    3b36:	4501                	li	a0,0
    3b38:	502010ef          	jal	503a <exit>

0000000000003b3c <sharedfd>:
{
    3b3c:	7159                	addi	sp,sp,-112
    3b3e:	f486                	sd	ra,104(sp)
    3b40:	f0a2                	sd	s0,96(sp)
    3b42:	e0d2                	sd	s4,64(sp)
    3b44:	1880                	addi	s0,sp,112
    3b46:	8a2a                	mv	s4,a0
  unlink("sharedfd");
    3b48:	00003517          	auipc	a0,0x3
    3b4c:	6d050513          	addi	a0,a0,1744 # 7218 <malloc+0x1cfa>
    3b50:	53a010ef          	jal	508a <unlink>
  fd = open("sharedfd", O_CREATE | O_RDWR);
    3b54:	20200593          	li	a1,514
    3b58:	00003517          	auipc	a0,0x3
    3b5c:	6c050513          	addi	a0,a0,1728 # 7218 <malloc+0x1cfa>
    3b60:	51a010ef          	jal	507a <open>
  if (fd < 0) {
    3b64:	04054863          	bltz	a0,3bb4 <sharedfd+0x78>
    3b68:	eca6                	sd	s1,88(sp)
    3b6a:	e8ca                	sd	s2,80(sp)
    3b6c:	e4ce                	sd	s3,72(sp)
    3b6e:	fc56                	sd	s5,56(sp)
    3b70:	f85a                	sd	s6,48(sp)
    3b72:	f45e                	sd	s7,40(sp)
    3b74:	892a                	mv	s2,a0
  pid = fork();
    3b76:	4bc010ef          	jal	5032 <fork>
    3b7a:	89aa                	mv	s3,a0
  memset(buf, pid == 0 ? 'c' : 'p', sizeof(buf));
    3b7c:	07000593          	li	a1,112
    3b80:	e119                	bnez	a0,3b86 <sharedfd+0x4a>
    3b82:	06300593          	li	a1,99
    3b86:	4629                	li	a2,10
    3b88:	fa040513          	addi	a0,s0,-96
    3b8c:	29c010ef          	jal	4e28 <memset>
    3b90:	3e800493          	li	s1,1000
    if (write(fd, buf, sizeof(buf)) != sizeof(buf)) {
    3b94:	4629                	li	a2,10
    3b96:	fa040593          	addi	a1,s0,-96
    3b9a:	854a                	mv	a0,s2
    3b9c:	4be010ef          	jal	505a <write>
    3ba0:	47a9                	li	a5,10
    3ba2:	02f51963          	bne	a0,a5,3bd4 <sharedfd+0x98>
  for (i = 0; i < N; i++) {
    3ba6:	34fd                	addiw	s1,s1,-1
    3ba8:	f4f5                	bnez	s1,3b94 <sharedfd+0x58>
  if (pid == 0) {
    3baa:	02099f63          	bnez	s3,3be8 <sharedfd+0xac>
    exit(0);
    3bae:	4501                	li	a0,0
    3bb0:	48a010ef          	jal	503a <exit>
    3bb4:	eca6                	sd	s1,88(sp)
    3bb6:	e8ca                	sd	s2,80(sp)
    3bb8:	e4ce                	sd	s3,72(sp)
    3bba:	fc56                	sd	s5,56(sp)
    3bbc:	f85a                	sd	s6,48(sp)
    3bbe:	f45e                	sd	s7,40(sp)
    printf("%s: cannot open sharedfd for writing", s);
    3bc0:	85d2                	mv	a1,s4
    3bc2:	00003517          	auipc	a0,0x3
    3bc6:	66650513          	addi	a0,a0,1638 # 7228 <malloc+0x1d0a>
    3bca:	0a1010ef          	jal	546a <printf>
    exit(1);
    3bce:	4505                	li	a0,1
    3bd0:	46a010ef          	jal	503a <exit>
      printf("%s: write sharedfd failed\n", s);
    3bd4:	85d2                	mv	a1,s4
    3bd6:	00003517          	auipc	a0,0x3
    3bda:	67a50513          	addi	a0,a0,1658 # 7250 <malloc+0x1d32>
    3bde:	08d010ef          	jal	546a <printf>
      exit(1);
    3be2:	4505                	li	a0,1
    3be4:	456010ef          	jal	503a <exit>
    wait(&xstatus);
    3be8:	f9c40513          	addi	a0,s0,-100
    3bec:	456010ef          	jal	5042 <wait>
    if (xstatus != 0)
    3bf0:	f9c42983          	lw	s3,-100(s0)
    3bf4:	00098563          	beqz	s3,3bfe <sharedfd+0xc2>
      exit(xstatus);
    3bf8:	854e                	mv	a0,s3
    3bfa:	440010ef          	jal	503a <exit>
  close(fd);
    3bfe:	854a                	mv	a0,s2
    3c00:	462010ef          	jal	5062 <close>
  fd = open("sharedfd", 0);
    3c04:	4581                	li	a1,0
    3c06:	00003517          	auipc	a0,0x3
    3c0a:	61250513          	addi	a0,a0,1554 # 7218 <malloc+0x1cfa>
    3c0e:	46c010ef          	jal	507a <open>
    3c12:	8baa                	mv	s7,a0
  nc = np = 0;
    3c14:	8ace                	mv	s5,s3
  if (fd < 0) {
    3c16:	02054363          	bltz	a0,3c3c <sharedfd+0x100>
    3c1a:	faa40913          	addi	s2,s0,-86
      if (buf[i] == 'c')
    3c1e:	06300493          	li	s1,99
      if (buf[i] == 'p')
    3c22:	07000b13          	li	s6,112
  while ((n = read(fd, buf, sizeof(buf))) > 0) {
    3c26:	4629                	li	a2,10
    3c28:	fa040593          	addi	a1,s0,-96
    3c2c:	855e                	mv	a0,s7
    3c2e:	424010ef          	jal	5052 <read>
    3c32:	02a05b63          	blez	a0,3c68 <sharedfd+0x12c>
    3c36:	fa040793          	addi	a5,s0,-96
    3c3a:	a839                	j	3c58 <sharedfd+0x11c>
    printf("%s: cannot open sharedfd for reading\n", s);
    3c3c:	85d2                	mv	a1,s4
    3c3e:	00003517          	auipc	a0,0x3
    3c42:	63250513          	addi	a0,a0,1586 # 7270 <malloc+0x1d52>
    3c46:	025010ef          	jal	546a <printf>
    exit(1);
    3c4a:	4505                	li	a0,1
    3c4c:	3ee010ef          	jal	503a <exit>
        nc++;
    3c50:	2985                	addiw	s3,s3,1
    for (i = 0; i < sizeof(buf); i++) {
    3c52:	0785                	addi	a5,a5,1 # 6400001 <base+0x63f1339>
    3c54:	fd2789e3          	beq	a5,s2,3c26 <sharedfd+0xea>
      if (buf[i] == 'c')
    3c58:	0007c703          	lbu	a4,0(a5)
    3c5c:	fe970ae3          	beq	a4,s1,3c50 <sharedfd+0x114>
      if (buf[i] == 'p')
    3c60:	ff6719e3          	bne	a4,s6,3c52 <sharedfd+0x116>
        np++;
    3c64:	2a85                	addiw	s5,s5,1
    3c66:	b7f5                	j	3c52 <sharedfd+0x116>
  close(fd);
    3c68:	855e                	mv	a0,s7
    3c6a:	3f8010ef          	jal	5062 <close>
  unlink("sharedfd");
    3c6e:	00003517          	auipc	a0,0x3
    3c72:	5aa50513          	addi	a0,a0,1450 # 7218 <malloc+0x1cfa>
    3c76:	414010ef          	jal	508a <unlink>
  if (nc == N * SZ && np == N * SZ) {
    3c7a:	6789                	lui	a5,0x2
    3c7c:	71078793          	addi	a5,a5,1808 # 2710 <diskfull+0xd0>
    3c80:	00f99763          	bne	s3,a5,3c8e <sharedfd+0x152>
    3c84:	6789                	lui	a5,0x2
    3c86:	71078793          	addi	a5,a5,1808 # 2710 <diskfull+0xd0>
    3c8a:	00fa8c63          	beq	s5,a5,3ca2 <sharedfd+0x166>
    printf("%s: nc/np test fails\n", s);
    3c8e:	85d2                	mv	a1,s4
    3c90:	00003517          	auipc	a0,0x3
    3c94:	60850513          	addi	a0,a0,1544 # 7298 <malloc+0x1d7a>
    3c98:	7d2010ef          	jal	546a <printf>
    exit(1);
    3c9c:	4505                	li	a0,1
    3c9e:	39c010ef          	jal	503a <exit>
    exit(0);
    3ca2:	4501                	li	a0,0
    3ca4:	396010ef          	jal	503a <exit>

0000000000003ca8 <fourfiles>:
{
    3ca8:	7135                	addi	sp,sp,-160
    3caa:	ed06                	sd	ra,152(sp)
    3cac:	e922                	sd	s0,144(sp)
    3cae:	e526                	sd	s1,136(sp)
    3cb0:	e14a                	sd	s2,128(sp)
    3cb2:	fcce                	sd	s3,120(sp)
    3cb4:	f8d2                	sd	s4,112(sp)
    3cb6:	f4d6                	sd	s5,104(sp)
    3cb8:	f0da                	sd	s6,96(sp)
    3cba:	ecde                	sd	s7,88(sp)
    3cbc:	e8e2                	sd	s8,80(sp)
    3cbe:	e4e6                	sd	s9,72(sp)
    3cc0:	e0ea                	sd	s10,64(sp)
    3cc2:	fc6e                	sd	s11,56(sp)
    3cc4:	1100                	addi	s0,sp,160
    3cc6:	8caa                	mv	s9,a0
  char *names[] = {"f0", "f1", "f2", "f3"};
    3cc8:	00003797          	auipc	a5,0x3
    3ccc:	5e878793          	addi	a5,a5,1512 # 72b0 <malloc+0x1d92>
    3cd0:	f6f43823          	sd	a5,-144(s0)
    3cd4:	00003797          	auipc	a5,0x3
    3cd8:	5e478793          	addi	a5,a5,1508 # 72b8 <malloc+0x1d9a>
    3cdc:	f6f43c23          	sd	a5,-136(s0)
    3ce0:	00003797          	auipc	a5,0x3
    3ce4:	5e078793          	addi	a5,a5,1504 # 72c0 <malloc+0x1da2>
    3ce8:	f8f43023          	sd	a5,-128(s0)
    3cec:	00003797          	auipc	a5,0x3
    3cf0:	5dc78793          	addi	a5,a5,1500 # 72c8 <malloc+0x1daa>
    3cf4:	f8f43423          	sd	a5,-120(s0)
  for (pi = 0; pi < NCHILD; pi++) {
    3cf8:	f7040b93          	addi	s7,s0,-144
  char *names[] = {"f0", "f1", "f2", "f3"};
    3cfc:	895e                	mv	s2,s7
  for (pi = 0; pi < NCHILD; pi++) {
    3cfe:	4481                	li	s1,0
    3d00:	4a11                	li	s4,4
    fname = names[pi];
    3d02:	00093983          	ld	s3,0(s2)
    unlink(fname);
    3d06:	854e                	mv	a0,s3
    3d08:	382010ef          	jal	508a <unlink>
    pid = fork();
    3d0c:	326010ef          	jal	5032 <fork>
    if (pid < 0) {
    3d10:	02054e63          	bltz	a0,3d4c <fourfiles+0xa4>
    if (pid == 0) {
    3d14:	c531                	beqz	a0,3d60 <fourfiles+0xb8>
  for (pi = 0; pi < NCHILD; pi++) {
    3d16:	2485                	addiw	s1,s1,1
    3d18:	0921                	addi	s2,s2,8
    3d1a:	ff4494e3          	bne	s1,s4,3d02 <fourfiles+0x5a>
    3d1e:	4491                	li	s1,4
    wait(&xstatus);
    3d20:	f6c40513          	addi	a0,s0,-148
    3d24:	31e010ef          	jal	5042 <wait>
    if (xstatus != 0)
    3d28:	f6c42a83          	lw	s5,-148(s0)
    3d2c:	0a0a9463          	bnez	s5,3dd4 <fourfiles+0x12c>
  for (pi = 0; pi < NCHILD; pi++) {
    3d30:	34fd                	addiw	s1,s1,-1
    3d32:	f4fd                	bnez	s1,3d20 <fourfiles+0x78>
    3d34:	03000b13          	li	s6,48
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
    3d38:	00008a17          	auipc	s4,0x8
    3d3c:	f90a0a13          	addi	s4,s4,-112 # bcc8 <buf>
    if (total != N * SZ) {
    3d40:	6d05                	lui	s10,0x1
    3d42:	770d0d13          	addi	s10,s10,1904 # 1770 <createdelete+0xb6>
  for (i = 0; i < NCHILD; i++) {
    3d46:	03400d93          	li	s11,52
    3d4a:	a0ed                	j	3e34 <fourfiles+0x18c>
      printf("%s: fork failed\n", s);
    3d4c:	85e6                	mv	a1,s9
    3d4e:	00002517          	auipc	a0,0x2
    3d52:	19a50513          	addi	a0,a0,410 # 5ee8 <malloc+0x9ca>
    3d56:	714010ef          	jal	546a <printf>
      exit(1);
    3d5a:	4505                	li	a0,1
    3d5c:	2de010ef          	jal	503a <exit>
      fd = open(fname, O_CREATE | O_RDWR);
    3d60:	20200593          	li	a1,514
    3d64:	854e                	mv	a0,s3
    3d66:	314010ef          	jal	507a <open>
    3d6a:	892a                	mv	s2,a0
      if (fd < 0) {
    3d6c:	04054163          	bltz	a0,3dae <fourfiles+0x106>
      memset(buf, '0' + pi, SZ);
    3d70:	1f400613          	li	a2,500
    3d74:	0304859b          	addiw	a1,s1,48
    3d78:	00008517          	auipc	a0,0x8
    3d7c:	f5050513          	addi	a0,a0,-176 # bcc8 <buf>
    3d80:	0a8010ef          	jal	4e28 <memset>
    3d84:	44b1                	li	s1,12
        if ((n = write(fd, buf, SZ)) != SZ) {
    3d86:	00008997          	auipc	s3,0x8
    3d8a:	f4298993          	addi	s3,s3,-190 # bcc8 <buf>
    3d8e:	1f400613          	li	a2,500
    3d92:	85ce                	mv	a1,s3
    3d94:	854a                	mv	a0,s2
    3d96:	2c4010ef          	jal	505a <write>
    3d9a:	85aa                	mv	a1,a0
    3d9c:	1f400793          	li	a5,500
    3da0:	02f51163          	bne	a0,a5,3dc2 <fourfiles+0x11a>
      for (i = 0; i < N; i++) {
    3da4:	34fd                	addiw	s1,s1,-1
    3da6:	f4e5                	bnez	s1,3d8e <fourfiles+0xe6>
      exit(0);
    3da8:	4501                	li	a0,0
    3daa:	290010ef          	jal	503a <exit>
        printf("%s: create failed\n", s);
    3dae:	85e6                	mv	a1,s9
    3db0:	00002517          	auipc	a0,0x2
    3db4:	2a850513          	addi	a0,a0,680 # 6058 <malloc+0xb3a>
    3db8:	6b2010ef          	jal	546a <printf>
        exit(1);
    3dbc:	4505                	li	a0,1
    3dbe:	27c010ef          	jal	503a <exit>
          printf("write failed %d\n", n);
    3dc2:	00003517          	auipc	a0,0x3
    3dc6:	50e50513          	addi	a0,a0,1294 # 72d0 <malloc+0x1db2>
    3dca:	6a0010ef          	jal	546a <printf>
          exit(1);
    3dce:	4505                	li	a0,1
    3dd0:	26a010ef          	jal	503a <exit>
      exit(xstatus);
    3dd4:	8556                	mv	a0,s5
    3dd6:	264010ef          	jal	503a <exit>
          printf("%s: wrong char\n", s);
    3dda:	85e6                	mv	a1,s9
    3ddc:	00003517          	auipc	a0,0x3
    3de0:	50c50513          	addi	a0,a0,1292 # 72e8 <malloc+0x1dca>
    3de4:	686010ef          	jal	546a <printf>
          exit(1);
    3de8:	4505                	li	a0,1
    3dea:	250010ef          	jal	503a <exit>
      total += n;
    3dee:	00a9093b          	addw	s2,s2,a0
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
    3df2:	660d                	lui	a2,0x3
    3df4:	85d2                	mv	a1,s4
    3df6:	854e                	mv	a0,s3
    3df8:	25a010ef          	jal	5052 <read>
    3dfc:	02a05063          	blez	a0,3e1c <fourfiles+0x174>
    3e00:	00008797          	auipc	a5,0x8
    3e04:	ec878793          	addi	a5,a5,-312 # bcc8 <buf>
    3e08:	00f506b3          	add	a3,a0,a5
        if (buf[j] != '0' + i) {
    3e0c:	0007c703          	lbu	a4,0(a5)
    3e10:	fc9715e3          	bne	a4,s1,3dda <fourfiles+0x132>
      for (j = 0; j < n; j++) {
    3e14:	0785                	addi	a5,a5,1
    3e16:	fed79be3          	bne	a5,a3,3e0c <fourfiles+0x164>
    3e1a:	bfd1                	j	3dee <fourfiles+0x146>
    close(fd);
    3e1c:	854e                	mv	a0,s3
    3e1e:	244010ef          	jal	5062 <close>
    if (total != N * SZ) {
    3e22:	03a91463          	bne	s2,s10,3e4a <fourfiles+0x1a2>
    unlink(fname);
    3e26:	8562                	mv	a0,s8
    3e28:	262010ef          	jal	508a <unlink>
  for (i = 0; i < NCHILD; i++) {
    3e2c:	0ba1                	addi	s7,s7,8
    3e2e:	2b05                	addiw	s6,s6,1
    3e30:	03bb0763          	beq	s6,s11,3e5e <fourfiles+0x1b6>
    fname = names[i];
    3e34:	000bbc03          	ld	s8,0(s7)
    fd = open(fname, 0);
    3e38:	4581                	li	a1,0
    3e3a:	8562                	mv	a0,s8
    3e3c:	23e010ef          	jal	507a <open>
    3e40:	89aa                	mv	s3,a0
    total = 0;
    3e42:	8956                	mv	s2,s5
        if (buf[j] != '0' + i) {
    3e44:	000b049b          	sext.w	s1,s6
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
    3e48:	b76d                	j	3df2 <fourfiles+0x14a>
      printf("wrong length %d\n", total);
    3e4a:	85ca                	mv	a1,s2
    3e4c:	00003517          	auipc	a0,0x3
    3e50:	4ac50513          	addi	a0,a0,1196 # 72f8 <malloc+0x1dda>
    3e54:	616010ef          	jal	546a <printf>
      exit(1);
    3e58:	4505                	li	a0,1
    3e5a:	1e0010ef          	jal	503a <exit>
}
    3e5e:	60ea                	ld	ra,152(sp)
    3e60:	644a                	ld	s0,144(sp)
    3e62:	64aa                	ld	s1,136(sp)
    3e64:	690a                	ld	s2,128(sp)
    3e66:	79e6                	ld	s3,120(sp)
    3e68:	7a46                	ld	s4,112(sp)
    3e6a:	7aa6                	ld	s5,104(sp)
    3e6c:	7b06                	ld	s6,96(sp)
    3e6e:	6be6                	ld	s7,88(sp)
    3e70:	6c46                	ld	s8,80(sp)
    3e72:	6ca6                	ld	s9,72(sp)
    3e74:	6d06                	ld	s10,64(sp)
    3e76:	7de2                	ld	s11,56(sp)
    3e78:	610d                	addi	sp,sp,160
    3e7a:	8082                	ret

0000000000003e7c <concreate>:
{
    3e7c:	7135                	addi	sp,sp,-160
    3e7e:	ed06                	sd	ra,152(sp)
    3e80:	e922                	sd	s0,144(sp)
    3e82:	e526                	sd	s1,136(sp)
    3e84:	e14a                	sd	s2,128(sp)
    3e86:	fcce                	sd	s3,120(sp)
    3e88:	f8d2                	sd	s4,112(sp)
    3e8a:	f4d6                	sd	s5,104(sp)
    3e8c:	f0da                	sd	s6,96(sp)
    3e8e:	ecde                	sd	s7,88(sp)
    3e90:	1100                	addi	s0,sp,160
    3e92:	89aa                	mv	s3,a0
  file[0] = 'C';
    3e94:	04300793          	li	a5,67
    3e98:	faf40423          	sb	a5,-88(s0)
  file[2] = '\0';
    3e9c:	fa040523          	sb	zero,-86(s0)
  for (i = 0; i < N; i++) {
    3ea0:	4901                	li	s2,0
    if (pid && (i % 3) == 1) {
    3ea2:	4b0d                	li	s6,3
    3ea4:	4a85                	li	s5,1
      link("C0", file);
    3ea6:	00003b97          	auipc	s7,0x3
    3eaa:	46ab8b93          	addi	s7,s7,1130 # 7310 <malloc+0x1df2>
  for (i = 0; i < N; i++) {
    3eae:	02800a13          	li	s4,40
    3eb2:	a41d                	j	40d8 <concreate+0x25c>
      link("C0", file);
    3eb4:	fa840593          	addi	a1,s0,-88
    3eb8:	855e                	mv	a0,s7
    3eba:	1e0010ef          	jal	509a <link>
    if (pid == 0) {
    3ebe:	a411                	j	40c2 <concreate+0x246>
    } else if (pid == 0 && (i % 5) == 1) {
    3ec0:	4795                	li	a5,5
    3ec2:	02f9693b          	remw	s2,s2,a5
    3ec6:	4785                	li	a5,1
    3ec8:	02f90563          	beq	s2,a5,3ef2 <concreate+0x76>
      fd = open(file, O_CREATE | O_RDWR);
    3ecc:	20200593          	li	a1,514
    3ed0:	fa840513          	addi	a0,s0,-88
    3ed4:	1a6010ef          	jal	507a <open>
      if (fd < 0) {
    3ed8:	1e055063          	bgez	a0,40b8 <concreate+0x23c>
        printf("concreate create %s failed\n", file);
    3edc:	fa840593          	addi	a1,s0,-88
    3ee0:	00003517          	auipc	a0,0x3
    3ee4:	43850513          	addi	a0,a0,1080 # 7318 <malloc+0x1dfa>
    3ee8:	582010ef          	jal	546a <printf>
        exit(1);
    3eec:	4505                	li	a0,1
    3eee:	14c010ef          	jal	503a <exit>
      link("C0", file);
    3ef2:	fa840593          	addi	a1,s0,-88
    3ef6:	00003517          	auipc	a0,0x3
    3efa:	41a50513          	addi	a0,a0,1050 # 7310 <malloc+0x1df2>
    3efe:	19c010ef          	jal	509a <link>
      exit(0);
    3f02:	4501                	li	a0,0
    3f04:	136010ef          	jal	503a <exit>
        exit(1);
    3f08:	4505                	li	a0,1
    3f0a:	130010ef          	jal	503a <exit>
  memset(fa, 0, sizeof(fa));
    3f0e:	02800613          	li	a2,40
    3f12:	4581                	li	a1,0
    3f14:	f8040513          	addi	a0,s0,-128
    3f18:	711000ef          	jal	4e28 <memset>
  fd = open(".", 0);
    3f1c:	4581                	li	a1,0
    3f1e:	00002517          	auipc	a0,0x2
    3f22:	e2250513          	addi	a0,a0,-478 # 5d40 <malloc+0x822>
    3f26:	154010ef          	jal	507a <open>
    3f2a:	892a                	mv	s2,a0
  n = 0;
    3f2c:	8aa6                	mv	s5,s1
    if (de.name[0] == 'C' && de.name[2] == '\0') {
    3f2e:	04300a13          	li	s4,67
      if (i < 0 || i >= sizeof(fa)) {
    3f32:	02700b13          	li	s6,39
      fa[i] = 1;
    3f36:	4b85                	li	s7,1
  while (read(fd, &de, sizeof(de)) > 0) {
    3f38:	4641                	li	a2,16
    3f3a:	f7040593          	addi	a1,s0,-144
    3f3e:	854a                	mv	a0,s2
    3f40:	112010ef          	jal	5052 <read>
    3f44:	06a05a63          	blez	a0,3fb8 <concreate+0x13c>
    if (de.inum == 0)
    3f48:	f7045783          	lhu	a5,-144(s0)
    3f4c:	d7f5                	beqz	a5,3f38 <concreate+0xbc>
    if (de.name[0] == 'C' && de.name[2] == '\0') {
    3f4e:	f7244783          	lbu	a5,-142(s0)
    3f52:	ff4793e3          	bne	a5,s4,3f38 <concreate+0xbc>
    3f56:	f7444783          	lbu	a5,-140(s0)
    3f5a:	fff9                	bnez	a5,3f38 <concreate+0xbc>
      i = de.name[1] - '0';
    3f5c:	f7344783          	lbu	a5,-141(s0)
    3f60:	fd07879b          	addiw	a5,a5,-48
    3f64:	0007871b          	sext.w	a4,a5
      if (i < 0 || i >= sizeof(fa)) {
    3f68:	02eb6063          	bltu	s6,a4,3f88 <concreate+0x10c>
      if (fa[i]) {
    3f6c:	fb070793          	addi	a5,a4,-80
    3f70:	97a2                	add	a5,a5,s0
    3f72:	fd07c783          	lbu	a5,-48(a5)
    3f76:	e78d                	bnez	a5,3fa0 <concreate+0x124>
      fa[i] = 1;
    3f78:	fb070793          	addi	a5,a4,-80
    3f7c:	00878733          	add	a4,a5,s0
    3f80:	fd770823          	sb	s7,-48(a4)
      n++;
    3f84:	2a85                	addiw	s5,s5,1
    3f86:	bf4d                	j	3f38 <concreate+0xbc>
        printf("%s: concreate weird file %s\n", s, de.name);
    3f88:	f7240613          	addi	a2,s0,-142
    3f8c:	85ce                	mv	a1,s3
    3f8e:	00003517          	auipc	a0,0x3
    3f92:	3aa50513          	addi	a0,a0,938 # 7338 <malloc+0x1e1a>
    3f96:	4d4010ef          	jal	546a <printf>
        exit(1);
    3f9a:	4505                	li	a0,1
    3f9c:	09e010ef          	jal	503a <exit>
        printf("%s: concreate duplicate file %s\n", s, de.name);
    3fa0:	f7240613          	addi	a2,s0,-142
    3fa4:	85ce                	mv	a1,s3
    3fa6:	00003517          	auipc	a0,0x3
    3faa:	3b250513          	addi	a0,a0,946 # 7358 <malloc+0x1e3a>
    3fae:	4bc010ef          	jal	546a <printf>
        exit(1);
    3fb2:	4505                	li	a0,1
    3fb4:	086010ef          	jal	503a <exit>
  close(fd);
    3fb8:	854a                	mv	a0,s2
    3fba:	0a8010ef          	jal	5062 <close>
  if (n != N) {
    3fbe:	02800793          	li	a5,40
    3fc2:	00fa9763          	bne	s5,a5,3fd0 <concreate+0x154>
    if (((i % 3) == 0 && pid == 0) || ((i % 3) == 1 && pid != 0)) {
    3fc6:	4a8d                	li	s5,3
    3fc8:	4b05                	li	s6,1
  for (i = 0; i < N; i++) {
    3fca:	02800a13          	li	s4,40
    3fce:	a079                	j	405c <concreate+0x1e0>
    printf("%s: concreate not enough files in directory listing\n", s);
    3fd0:	85ce                	mv	a1,s3
    3fd2:	00003517          	auipc	a0,0x3
    3fd6:	3ae50513          	addi	a0,a0,942 # 7380 <malloc+0x1e62>
    3fda:	490010ef          	jal	546a <printf>
    exit(1);
    3fde:	4505                	li	a0,1
    3fe0:	05a010ef          	jal	503a <exit>
      printf("%s: fork failed\n", s);
    3fe4:	85ce                	mv	a1,s3
    3fe6:	00002517          	auipc	a0,0x2
    3fea:	f0250513          	addi	a0,a0,-254 # 5ee8 <malloc+0x9ca>
    3fee:	47c010ef          	jal	546a <printf>
      exit(1);
    3ff2:	4505                	li	a0,1
    3ff4:	046010ef          	jal	503a <exit>
      close(open(file, 0));
    3ff8:	4581                	li	a1,0
    3ffa:	fa840513          	addi	a0,s0,-88
    3ffe:	07c010ef          	jal	507a <open>
    4002:	060010ef          	jal	5062 <close>
      close(open(file, 0));
    4006:	4581                	li	a1,0
    4008:	fa840513          	addi	a0,s0,-88
    400c:	06e010ef          	jal	507a <open>
    4010:	052010ef          	jal	5062 <close>
      close(open(file, 0));
    4014:	4581                	li	a1,0
    4016:	fa840513          	addi	a0,s0,-88
    401a:	060010ef          	jal	507a <open>
    401e:	044010ef          	jal	5062 <close>
      close(open(file, 0));
    4022:	4581                	li	a1,0
    4024:	fa840513          	addi	a0,s0,-88
    4028:	052010ef          	jal	507a <open>
    402c:	036010ef          	jal	5062 <close>
      close(open(file, 0));
    4030:	4581                	li	a1,0
    4032:	fa840513          	addi	a0,s0,-88
    4036:	044010ef          	jal	507a <open>
    403a:	028010ef          	jal	5062 <close>
      close(open(file, 0));
    403e:	4581                	li	a1,0
    4040:	fa840513          	addi	a0,s0,-88
    4044:	036010ef          	jal	507a <open>
    4048:	01a010ef          	jal	5062 <close>
    if (pid == 0)
    404c:	06090363          	beqz	s2,40b2 <concreate+0x236>
      wait(0);
    4050:	4501                	li	a0,0
    4052:	7f1000ef          	jal	5042 <wait>
  for (i = 0; i < N; i++) {
    4056:	2485                	addiw	s1,s1,1
    4058:	0b448963          	beq	s1,s4,410a <concreate+0x28e>
    file[1] = '0' + i;
    405c:	0304879b          	addiw	a5,s1,48
    4060:	faf404a3          	sb	a5,-87(s0)
    pid = fork();
    4064:	7cf000ef          	jal	5032 <fork>
    4068:	892a                	mv	s2,a0
    if (pid < 0) {
    406a:	f6054de3          	bltz	a0,3fe4 <concreate+0x168>
    if (((i % 3) == 0 && pid == 0) || ((i % 3) == 1 && pid != 0)) {
    406e:	0354e73b          	remw	a4,s1,s5
    4072:	00a767b3          	or	a5,a4,a0
    4076:	2781                	sext.w	a5,a5
    4078:	d3c1                	beqz	a5,3ff8 <concreate+0x17c>
    407a:	01671363          	bne	a4,s6,4080 <concreate+0x204>
    407e:	fd2d                	bnez	a0,3ff8 <concreate+0x17c>
      unlink(file);
    4080:	fa840513          	addi	a0,s0,-88
    4084:	006010ef          	jal	508a <unlink>
      unlink(file);
    4088:	fa840513          	addi	a0,s0,-88
    408c:	7ff000ef          	jal	508a <unlink>
      unlink(file);
    4090:	fa840513          	addi	a0,s0,-88
    4094:	7f7000ef          	jal	508a <unlink>
      unlink(file);
    4098:	fa840513          	addi	a0,s0,-88
    409c:	7ef000ef          	jal	508a <unlink>
      unlink(file);
    40a0:	fa840513          	addi	a0,s0,-88
    40a4:	7e7000ef          	jal	508a <unlink>
      unlink(file);
    40a8:	fa840513          	addi	a0,s0,-88
    40ac:	7df000ef          	jal	508a <unlink>
    40b0:	bf71                	j	404c <concreate+0x1d0>
      exit(0);
    40b2:	4501                	li	a0,0
    40b4:	787000ef          	jal	503a <exit>
      close(fd);
    40b8:	7ab000ef          	jal	5062 <close>
    if (pid == 0) {
    40bc:	b599                	j	3f02 <concreate+0x86>
      close(fd);
    40be:	7a5000ef          	jal	5062 <close>
      wait(&xstatus);
    40c2:	f6c40513          	addi	a0,s0,-148
    40c6:	77d000ef          	jal	5042 <wait>
      if (xstatus != 0)
    40ca:	f6c42483          	lw	s1,-148(s0)
    40ce:	e2049de3          	bnez	s1,3f08 <concreate+0x8c>
  for (i = 0; i < N; i++) {
    40d2:	2905                	addiw	s2,s2,1
    40d4:	e3490de3          	beq	s2,s4,3f0e <concreate+0x92>
    file[1] = '0' + i;
    40d8:	0309079b          	addiw	a5,s2,48
    40dc:	faf404a3          	sb	a5,-87(s0)
    unlink(file);
    40e0:	fa840513          	addi	a0,s0,-88
    40e4:	7a7000ef          	jal	508a <unlink>
    pid = fork();
    40e8:	74b000ef          	jal	5032 <fork>
    if (pid && (i % 3) == 1) {
    40ec:	dc050ae3          	beqz	a0,3ec0 <concreate+0x44>
    40f0:	036967bb          	remw	a5,s2,s6
    40f4:	dd5780e3          	beq	a5,s5,3eb4 <concreate+0x38>
      fd = open(file, O_CREATE | O_RDWR);
    40f8:	20200593          	li	a1,514
    40fc:	fa840513          	addi	a0,s0,-88
    4100:	77b000ef          	jal	507a <open>
      if (fd < 0) {
    4104:	fa055de3          	bgez	a0,40be <concreate+0x242>
    4108:	bbd1                	j	3edc <concreate+0x60>
}
    410a:	60ea                	ld	ra,152(sp)
    410c:	644a                	ld	s0,144(sp)
    410e:	64aa                	ld	s1,136(sp)
    4110:	690a                	ld	s2,128(sp)
    4112:	79e6                	ld	s3,120(sp)
    4114:	7a46                	ld	s4,112(sp)
    4116:	7aa6                	ld	s5,104(sp)
    4118:	7b06                	ld	s6,96(sp)
    411a:	6be6                	ld	s7,88(sp)
    411c:	610d                	addi	sp,sp,160
    411e:	8082                	ret

0000000000004120 <bigfile>:
{
    4120:	7139                	addi	sp,sp,-64
    4122:	fc06                	sd	ra,56(sp)
    4124:	f822                	sd	s0,48(sp)
    4126:	f426                	sd	s1,40(sp)
    4128:	f04a                	sd	s2,32(sp)
    412a:	ec4e                	sd	s3,24(sp)
    412c:	e852                	sd	s4,16(sp)
    412e:	e456                	sd	s5,8(sp)
    4130:	0080                	addi	s0,sp,64
    4132:	8aaa                	mv	s5,a0
  unlink("bigfile.dat");
    4134:	00003517          	auipc	a0,0x3
    4138:	28450513          	addi	a0,a0,644 # 73b8 <malloc+0x1e9a>
    413c:	74f000ef          	jal	508a <unlink>
  fd = open("bigfile.dat", O_CREATE | O_RDWR);
    4140:	20200593          	li	a1,514
    4144:	00003517          	auipc	a0,0x3
    4148:	27450513          	addi	a0,a0,628 # 73b8 <malloc+0x1e9a>
    414c:	72f000ef          	jal	507a <open>
    4150:	89aa                	mv	s3,a0
  for (i = 0; i < N; i++) {
    4152:	4481                	li	s1,0
    memset(buf, i, SZ);
    4154:	00008917          	auipc	s2,0x8
    4158:	b7490913          	addi	s2,s2,-1164 # bcc8 <buf>
  for (i = 0; i < N; i++) {
    415c:	4a51                	li	s4,20
  if (fd < 0) {
    415e:	08054663          	bltz	a0,41ea <bigfile+0xca>
    memset(buf, i, SZ);
    4162:	25800613          	li	a2,600
    4166:	85a6                	mv	a1,s1
    4168:	854a                	mv	a0,s2
    416a:	4bf000ef          	jal	4e28 <memset>
    if (write(fd, buf, SZ) != SZ) {
    416e:	25800613          	li	a2,600
    4172:	85ca                	mv	a1,s2
    4174:	854e                	mv	a0,s3
    4176:	6e5000ef          	jal	505a <write>
    417a:	25800793          	li	a5,600
    417e:	08f51063          	bne	a0,a5,41fe <bigfile+0xde>
  for (i = 0; i < N; i++) {
    4182:	2485                	addiw	s1,s1,1
    4184:	fd449fe3          	bne	s1,s4,4162 <bigfile+0x42>
  close(fd);
    4188:	854e                	mv	a0,s3
    418a:	6d9000ef          	jal	5062 <close>
  fd = open("bigfile.dat", 0);
    418e:	4581                	li	a1,0
    4190:	00003517          	auipc	a0,0x3
    4194:	22850513          	addi	a0,a0,552 # 73b8 <malloc+0x1e9a>
    4198:	6e3000ef          	jal	507a <open>
    419c:	8a2a                	mv	s4,a0
  total = 0;
    419e:	4981                	li	s3,0
  for (i = 0;; i++) {
    41a0:	4481                	li	s1,0
    cc = read(fd, buf, SZ / 2);
    41a2:	00008917          	auipc	s2,0x8
    41a6:	b2690913          	addi	s2,s2,-1242 # bcc8 <buf>
  if (fd < 0) {
    41aa:	06054463          	bltz	a0,4212 <bigfile+0xf2>
    cc = read(fd, buf, SZ / 2);
    41ae:	12c00613          	li	a2,300
    41b2:	85ca                	mv	a1,s2
    41b4:	8552                	mv	a0,s4
    41b6:	69d000ef          	jal	5052 <read>
    if (cc < 0) {
    41ba:	06054663          	bltz	a0,4226 <bigfile+0x106>
    if (cc == 0)
    41be:	c155                	beqz	a0,4262 <bigfile+0x142>
    if (cc != SZ / 2) {
    41c0:	12c00793          	li	a5,300
    41c4:	06f51b63          	bne	a0,a5,423a <bigfile+0x11a>
    if (buf[0] != i / 2 || buf[SZ / 2 - 1] != i / 2) {
    41c8:	01f4d79b          	srliw	a5,s1,0x1f
    41cc:	9fa5                	addw	a5,a5,s1
    41ce:	4017d79b          	sraiw	a5,a5,0x1
    41d2:	00094703          	lbu	a4,0(s2)
    41d6:	06f71c63          	bne	a4,a5,424e <bigfile+0x12e>
    41da:	12b94703          	lbu	a4,299(s2)
    41de:	06f71863          	bne	a4,a5,424e <bigfile+0x12e>
    total += cc;
    41e2:	12c9899b          	addiw	s3,s3,300
  for (i = 0;; i++) {
    41e6:	2485                	addiw	s1,s1,1
    cc = read(fd, buf, SZ / 2);
    41e8:	b7d9                	j	41ae <bigfile+0x8e>
    printf("%s: cannot create bigfile", s);
    41ea:	85d6                	mv	a1,s5
    41ec:	00003517          	auipc	a0,0x3
    41f0:	1dc50513          	addi	a0,a0,476 # 73c8 <malloc+0x1eaa>
    41f4:	276010ef          	jal	546a <printf>
    exit(1);
    41f8:	4505                	li	a0,1
    41fa:	641000ef          	jal	503a <exit>
      printf("%s: write bigfile failed\n", s);
    41fe:	85d6                	mv	a1,s5
    4200:	00003517          	auipc	a0,0x3
    4204:	1e850513          	addi	a0,a0,488 # 73e8 <malloc+0x1eca>
    4208:	262010ef          	jal	546a <printf>
      exit(1);
    420c:	4505                	li	a0,1
    420e:	62d000ef          	jal	503a <exit>
    printf("%s: cannot open bigfile\n", s);
    4212:	85d6                	mv	a1,s5
    4214:	00003517          	auipc	a0,0x3
    4218:	1f450513          	addi	a0,a0,500 # 7408 <malloc+0x1eea>
    421c:	24e010ef          	jal	546a <printf>
    exit(1);
    4220:	4505                	li	a0,1
    4222:	619000ef          	jal	503a <exit>
      printf("%s: read bigfile failed\n", s);
    4226:	85d6                	mv	a1,s5
    4228:	00003517          	auipc	a0,0x3
    422c:	20050513          	addi	a0,a0,512 # 7428 <malloc+0x1f0a>
    4230:	23a010ef          	jal	546a <printf>
      exit(1);
    4234:	4505                	li	a0,1
    4236:	605000ef          	jal	503a <exit>
      printf("%s: short read bigfile\n", s);
    423a:	85d6                	mv	a1,s5
    423c:	00003517          	auipc	a0,0x3
    4240:	20c50513          	addi	a0,a0,524 # 7448 <malloc+0x1f2a>
    4244:	226010ef          	jal	546a <printf>
      exit(1);
    4248:	4505                	li	a0,1
    424a:	5f1000ef          	jal	503a <exit>
      printf("%s: read bigfile wrong data\n", s);
    424e:	85d6                	mv	a1,s5
    4250:	00003517          	auipc	a0,0x3
    4254:	21050513          	addi	a0,a0,528 # 7460 <malloc+0x1f42>
    4258:	212010ef          	jal	546a <printf>
      exit(1);
    425c:	4505                	li	a0,1
    425e:	5dd000ef          	jal	503a <exit>
  close(fd);
    4262:	8552                	mv	a0,s4
    4264:	5ff000ef          	jal	5062 <close>
  if (total != N * SZ) {
    4268:	678d                	lui	a5,0x3
    426a:	ee078793          	addi	a5,a5,-288 # 2ee0 <subdir+0x494>
    426e:	02f99163          	bne	s3,a5,4290 <bigfile+0x170>
  unlink("bigfile.dat");
    4272:	00003517          	auipc	a0,0x3
    4276:	14650513          	addi	a0,a0,326 # 73b8 <malloc+0x1e9a>
    427a:	611000ef          	jal	508a <unlink>
}
    427e:	70e2                	ld	ra,56(sp)
    4280:	7442                	ld	s0,48(sp)
    4282:	74a2                	ld	s1,40(sp)
    4284:	7902                	ld	s2,32(sp)
    4286:	69e2                	ld	s3,24(sp)
    4288:	6a42                	ld	s4,16(sp)
    428a:	6aa2                	ld	s5,8(sp)
    428c:	6121                	addi	sp,sp,64
    428e:	8082                	ret
    printf("%s: read bigfile wrong total\n", s);
    4290:	85d6                	mv	a1,s5
    4292:	00003517          	auipc	a0,0x3
    4296:	1ee50513          	addi	a0,a0,494 # 7480 <malloc+0x1f62>
    429a:	1d0010ef          	jal	546a <printf>
    exit(1);
    429e:	4505                	li	a0,1
    42a0:	59b000ef          	jal	503a <exit>

00000000000042a4 <bigargtest>:
{
    42a4:	7121                	addi	sp,sp,-448
    42a6:	ff06                	sd	ra,440(sp)
    42a8:	fb22                	sd	s0,432(sp)
    42aa:	f726                	sd	s1,424(sp)
    42ac:	0380                	addi	s0,sp,448
    42ae:	84aa                	mv	s1,a0
  unlink("bigarg-ok");
    42b0:	00003517          	auipc	a0,0x3
    42b4:	1f050513          	addi	a0,a0,496 # 74a0 <malloc+0x1f82>
    42b8:	5d3000ef          	jal	508a <unlink>
  pid = fork();
    42bc:	577000ef          	jal	5032 <fork>
  if (pid == 0) {
    42c0:	c915                	beqz	a0,42f4 <bigargtest+0x50>
  } else if (pid < 0) {
    42c2:	08054a63          	bltz	a0,4356 <bigargtest+0xb2>
  wait(&xstatus);
    42c6:	fdc40513          	addi	a0,s0,-36
    42ca:	579000ef          	jal	5042 <wait>
  if (xstatus != 0)
    42ce:	fdc42503          	lw	a0,-36(s0)
    42d2:	ed41                	bnez	a0,436a <bigargtest+0xc6>
  fd = open("bigarg-ok", 0);
    42d4:	4581                	li	a1,0
    42d6:	00003517          	auipc	a0,0x3
    42da:	1ca50513          	addi	a0,a0,458 # 74a0 <malloc+0x1f82>
    42de:	59d000ef          	jal	507a <open>
  if (fd < 0) {
    42e2:	08054663          	bltz	a0,436e <bigargtest+0xca>
  close(fd);
    42e6:	57d000ef          	jal	5062 <close>
}
    42ea:	70fa                	ld	ra,440(sp)
    42ec:	745a                	ld	s0,432(sp)
    42ee:	74ba                	ld	s1,424(sp)
    42f0:	6139                	addi	sp,sp,448
    42f2:	8082                	ret
    memset(big, ' ', sizeof(big));
    42f4:	19000613          	li	a2,400
    42f8:	02000593          	li	a1,32
    42fc:	e4840513          	addi	a0,s0,-440
    4300:	329000ef          	jal	4e28 <memset>
    big[sizeof(big) - 1] = '\0';
    4304:	fc040ba3          	sb	zero,-41(s0)
    for (i = 0; i < MAXARG - 1; i++)
    4308:	00004797          	auipc	a5,0x4
    430c:	1a878793          	addi	a5,a5,424 # 84b0 <args.1>
    4310:	00004697          	auipc	a3,0x4
    4314:	29868693          	addi	a3,a3,664 # 85a8 <args.1+0xf8>
      args[i] = big;
    4318:	e4840713          	addi	a4,s0,-440
    431c:	e398                	sd	a4,0(a5)
    for (i = 0; i < MAXARG - 1; i++)
    431e:	07a1                	addi	a5,a5,8
    4320:	fed79ee3          	bne	a5,a3,431c <bigargtest+0x78>
    args[MAXARG - 1] = 0;
    4324:	00004597          	auipc	a1,0x4
    4328:	18c58593          	addi	a1,a1,396 # 84b0 <args.1>
    432c:	0e05bc23          	sd	zero,248(a1)
    exec("echo", args);
    4330:	00001517          	auipc	a0,0x1
    4334:	32850513          	addi	a0,a0,808 # 5658 <malloc+0x13a>
    4338:	53b000ef          	jal	5072 <exec>
    fd = open("bigarg-ok", O_CREATE);
    433c:	20000593          	li	a1,512
    4340:	00003517          	auipc	a0,0x3
    4344:	16050513          	addi	a0,a0,352 # 74a0 <malloc+0x1f82>
    4348:	533000ef          	jal	507a <open>
    close(fd);
    434c:	517000ef          	jal	5062 <close>
    exit(0);
    4350:	4501                	li	a0,0
    4352:	4e9000ef          	jal	503a <exit>
    printf("%s: bigargtest: fork failed\n", s);
    4356:	85a6                	mv	a1,s1
    4358:	00003517          	auipc	a0,0x3
    435c:	15850513          	addi	a0,a0,344 # 74b0 <malloc+0x1f92>
    4360:	10a010ef          	jal	546a <printf>
    exit(1);
    4364:	4505                	li	a0,1
    4366:	4d5000ef          	jal	503a <exit>
    exit(xstatus);
    436a:	4d1000ef          	jal	503a <exit>
    printf("%s: bigarg test failed!\n", s);
    436e:	85a6                	mv	a1,s1
    4370:	00003517          	auipc	a0,0x3
    4374:	16050513          	addi	a0,a0,352 # 74d0 <malloc+0x1fb2>
    4378:	0f2010ef          	jal	546a <printf>
    exit(1);
    437c:	4505                	li	a0,1
    437e:	4bd000ef          	jal	503a <exit>

0000000000004382 <partial_write>:
{
    4382:	bc010113          	addi	sp,sp,-1088
    4386:	42113c23          	sd	ra,1080(sp)
    438a:	42813823          	sd	s0,1072(sp)
    438e:	42913423          	sd	s1,1064(sp)
    4392:	43213023          	sd	s2,1056(sp)
    4396:	41313c23          	sd	s3,1048(sp)
    439a:	44010413          	addi	s0,sp,1088
    439e:	89aa                	mv	s3,a0
  unlink("testfile");
    43a0:	00003517          	auipc	a0,0x3
    43a4:	15050513          	addi	a0,a0,336 # 74f0 <malloc+0x1fd2>
    43a8:	4e3000ef          	jal	508a <unlink>
  int fd = open("testfile", O_CREATE | O_RDWR);
    43ac:	20200593          	li	a1,514
    43b0:	00003517          	auipc	a0,0x3
    43b4:	14050513          	addi	a0,a0,320 # 74f0 <malloc+0x1fd2>
    43b8:	4c3000ef          	jal	507a <open>
  if (fd < 0) {
    43bc:	14054c63          	bltz	a0,4514 <partial_write+0x192>
    43c0:	84aa                	mv	s1,a0
  int cc = write(fd, "A", 1);
    43c2:	4605                	li	a2,1
    43c4:	00003597          	auipc	a1,0x3
    43c8:	15c58593          	addi	a1,a1,348 # 7520 <malloc+0x2002>
    43cc:	48f000ef          	jal	505a <write>
  if (cc != 1) {
    43d0:	4785                	li	a5,1
    43d2:	14f51b63          	bne	a0,a5,4528 <partial_write+0x1a6>
  close(fd);
    43d6:	8526                	mv	a0,s1
    43d8:	48b000ef          	jal	5062 <close>
  fd = open("testfile", O_RDWR);
    43dc:	4589                	li	a1,2
    43de:	00003517          	auipc	a0,0x3
    43e2:	11250513          	addi	a0,a0,274 # 74f0 <malloc+0x1fd2>
    43e6:	495000ef          	jal	507a <open>
    43ea:	892a                	mv	s2,a0
  if (fd < 0) {
    43ec:	14054863          	bltz	a0,453c <partial_write+0x1ba>
  char *p = sbrk(0);
    43f0:	4501                	li	a0,0
    43f2:	415000ef          	jal	5006 <sbrk>
  sbrk(PGSIZE - ((uint64)p % PGSIZE));
    43f6:	6485                	lui	s1,0x1
    43f8:	14fd                	addi	s1,s1,-1 # fff <pgbug+0x2b>
    43fa:	009577b3          	and	a5,a0,s1
    43fe:	6505                	lui	a0,0x1
    4400:	9d1d                	subw	a0,a0,a5
    4402:	405000ef          	jal	5006 <sbrk>
  p = sbrk(0);
    4406:	4501                	li	a0,0
    4408:	3ff000ef          	jal	5006 <sbrk>
  if ((uint64)p % PGSIZE != 0) {
    440c:	8ce9                	and	s1,s1,a0
    440e:	14049163          	bnez	s1,4550 <partial_write+0x1ce>
  p[-1] = 'X';
    4412:	05800793          	li	a5,88
    4416:	fef50fa3          	sb	a5,-1(a0) # fff <pgbug+0x2b>
  cc = write(fd, p - 1, 2);
    441a:	4609                	li	a2,2
    441c:	fff50593          	addi	a1,a0,-1
    4420:	854a                	mv	a0,s2
    4422:	439000ef          	jal	505a <write>
  if (cc != -1) {
    4426:	57fd                	li	a5,-1
    4428:	12f51e63          	bne	a0,a5,4564 <partial_write+0x1e2>
  close(fd);
    442c:	854a                	mv	a0,s2
    442e:	435000ef          	jal	5062 <close>
  fd = open("testfile", O_RDONLY);
    4432:	4581                	li	a1,0
    4434:	00003517          	auipc	a0,0x3
    4438:	0bc50513          	addi	a0,a0,188 # 74f0 <malloc+0x1fd2>
    443c:	43f000ef          	jal	507a <open>
    4440:	84aa                	mv	s1,a0
  if (fd < 0) {
    4442:	12054b63          	bltz	a0,4578 <partial_write+0x1f6>
  cc = read(fd, &b, 1);
    4446:	4605                	li	a2,1
    4448:	fcf40593          	addi	a1,s0,-49
    444c:	407000ef          	jal	5052 <read>
  if (cc != 1) {
    4450:	4785                	li	a5,1
    4452:	12f51d63          	bne	a0,a5,458c <partial_write+0x20a>
  close(fd);
    4456:	8526                	mv	a0,s1
    4458:	40b000ef          	jal	5062 <close>
  if (b != 'X') {
    445c:	fcf44603          	lbu	a2,-49(s0)
    4460:	05800793          	li	a5,88
    4464:	12f61e63          	bne	a2,a5,45a0 <partial_write+0x21e>
  fd = open("bigfile", O_CREATE | O_RDWR);
    4468:	20200593          	li	a1,514
    446c:	00003517          	auipc	a0,0x3
    4470:	18450513          	addi	a0,a0,388 # 75f0 <malloc+0x20d2>
    4474:	407000ef          	jal	507a <open>
    4478:	892a                	mv	s2,a0
    447a:	04000493          	li	s1,64
    memset(buf, 0, sizeof(buf));
    447e:	40000613          	li	a2,1024
    4482:	4581                	li	a1,0
    4484:	bc840513          	addi	a0,s0,-1080
    4488:	1a1000ef          	jal	4e28 <memset>
    cc = write(fd, buf, sizeof(buf));
    448c:	40000613          	li	a2,1024
    4490:	bc840593          	addi	a1,s0,-1080
    4494:	854a                	mv	a0,s2
    4496:	3c5000ef          	jal	505a <write>
    if (cc != sizeof(buf)) {
    449a:	40000793          	li	a5,1024
    449e:	10f51b63          	bne	a0,a5,45b4 <partial_write+0x232>
  for (int i = 0; i < 64; i++) {
    44a2:	34fd                	addiw	s1,s1,-1
    44a4:	fce9                	bnez	s1,447e <partial_write+0xfc>
  close(fd);
    44a6:	854a                	mv	a0,s2
    44a8:	3bb000ef          	jal	5062 <close>
  unlink("bigfile");
    44ac:	00003517          	auipc	a0,0x3
    44b0:	14450513          	addi	a0,a0,324 # 75f0 <malloc+0x20d2>
    44b4:	3d7000ef          	jal	508a <unlink>
  fd = open("testfile", O_RDONLY);
    44b8:	4581                	li	a1,0
    44ba:	00003517          	auipc	a0,0x3
    44be:	03650513          	addi	a0,a0,54 # 74f0 <malloc+0x1fd2>
    44c2:	3b9000ef          	jal	507a <open>
    44c6:	84aa                	mv	s1,a0
  if (fd < 0) {
    44c8:	10054063          	bltz	a0,45c8 <partial_write+0x246>
  cc = read(fd, &b, 1);
    44cc:	4605                	li	a2,1
    44ce:	fcf40593          	addi	a1,s0,-49
    44d2:	381000ef          	jal	5052 <read>
  if (cc != 1) {
    44d6:	4785                	li	a5,1
    44d8:	10f51263          	bne	a0,a5,45dc <partial_write+0x25a>
  close(fd);
    44dc:	8526                	mv	a0,s1
    44de:	385000ef          	jal	5062 <close>
  if (b != 'X') {
    44e2:	fcf44603          	lbu	a2,-49(s0)
    44e6:	05800793          	li	a5,88
    44ea:	10f61363          	bne	a2,a5,45f0 <partial_write+0x26e>
  unlink("testfile");
    44ee:	00003517          	auipc	a0,0x3
    44f2:	00250513          	addi	a0,a0,2 # 74f0 <malloc+0x1fd2>
    44f6:	395000ef          	jal	508a <unlink>
}
    44fa:	43813083          	ld	ra,1080(sp)
    44fe:	43013403          	ld	s0,1072(sp)
    4502:	42813483          	ld	s1,1064(sp)
    4506:	42013903          	ld	s2,1056(sp)
    450a:	41813983          	ld	s3,1048(sp)
    450e:	44010113          	addi	sp,sp,1088
    4512:	8082                	ret
    printf("%s: cannot create testfile\n", s);
    4514:	85ce                	mv	a1,s3
    4516:	00003517          	auipc	a0,0x3
    451a:	fea50513          	addi	a0,a0,-22 # 7500 <malloc+0x1fe2>
    451e:	74d000ef          	jal	546a <printf>
    exit(1);
    4522:	4505                	li	a0,1
    4524:	317000ef          	jal	503a <exit>
    printf("%s: could not write A\n", s);
    4528:	85ce                	mv	a1,s3
    452a:	00003517          	auipc	a0,0x3
    452e:	ffe50513          	addi	a0,a0,-2 # 7528 <malloc+0x200a>
    4532:	739000ef          	jal	546a <printf>
    exit(1);
    4536:	4505                	li	a0,1
    4538:	303000ef          	jal	503a <exit>
    printf("%s: cannot re-open testfile\n", s);
    453c:	85ce                	mv	a1,s3
    453e:	00003517          	auipc	a0,0x3
    4542:	00250513          	addi	a0,a0,2 # 7540 <malloc+0x2022>
    4546:	725000ef          	jal	546a <printf>
    exit(1);
    454a:	4505                	li	a0,1
    454c:	2ef000ef          	jal	503a <exit>
    printf("%s: sbrk did not align\n", s);
    4550:	85ce                	mv	a1,s3
    4552:	00003517          	auipc	a0,0x3
    4556:	00e50513          	addi	a0,a0,14 # 7560 <malloc+0x2042>
    455a:	711000ef          	jal	546a <printf>
    exit(1);
    455e:	4505                	li	a0,1
    4560:	2db000ef          	jal	503a <exit>
    printf("%s: write succeeded, should have failed\n", s);
    4564:	85ce                	mv	a1,s3
    4566:	00003517          	auipc	a0,0x3
    456a:	01250513          	addi	a0,a0,18 # 7578 <malloc+0x205a>
    456e:	6fd000ef          	jal	546a <printf>
    exit(1);
    4572:	4505                	li	a0,1
    4574:	2c7000ef          	jal	503a <exit>
    printf("%s: cannot re-open testfile\n", s);
    4578:	85ce                	mv	a1,s3
    457a:	00003517          	auipc	a0,0x3
    457e:	fc650513          	addi	a0,a0,-58 # 7540 <malloc+0x2022>
    4582:	6e9000ef          	jal	546a <printf>
    exit(1);
    4586:	4505                	li	a0,1
    4588:	2b3000ef          	jal	503a <exit>
    printf("%s: cannot read testfile\n", s);
    458c:	85ce                	mv	a1,s3
    458e:	00003517          	auipc	a0,0x3
    4592:	01a50513          	addi	a0,a0,26 # 75a8 <malloc+0x208a>
    4596:	6d5000ef          	jal	546a <printf>
    exit(1);
    459a:	4505                	li	a0,1
    459c:	29f000ef          	jal	503a <exit>
    printf("%s: read returned %c, expected X\n", s, b);
    45a0:	85ce                	mv	a1,s3
    45a2:	00003517          	auipc	a0,0x3
    45a6:	02650513          	addi	a0,a0,38 # 75c8 <malloc+0x20aa>
    45aa:	6c1000ef          	jal	546a <printf>
    exit(1);
    45ae:	4505                	li	a0,1
    45b0:	28b000ef          	jal	503a <exit>
      printf("%s: could not write to bigfile\n", s);
    45b4:	85ce                	mv	a1,s3
    45b6:	00003517          	auipc	a0,0x3
    45ba:	04250513          	addi	a0,a0,66 # 75f8 <malloc+0x20da>
    45be:	6ad000ef          	jal	546a <printf>
      exit(-1);
    45c2:	557d                	li	a0,-1
    45c4:	277000ef          	jal	503a <exit>
    printf("%s: cannot re-open testfile\n", s);
    45c8:	85ce                	mv	a1,s3
    45ca:	00003517          	auipc	a0,0x3
    45ce:	f7650513          	addi	a0,a0,-138 # 7540 <malloc+0x2022>
    45d2:	699000ef          	jal	546a <printf>
    exit(1);
    45d6:	4505                	li	a0,1
    45d8:	263000ef          	jal	503a <exit>
    printf("%s: cannot read testfile\n", s);
    45dc:	85ce                	mv	a1,s3
    45de:	00003517          	auipc	a0,0x3
    45e2:	fca50513          	addi	a0,a0,-54 # 75a8 <malloc+0x208a>
    45e6:	685000ef          	jal	546a <printf>
    exit(1);
    45ea:	4505                	li	a0,1
    45ec:	24f000ef          	jal	503a <exit>
    printf("%s: read returned %c, expected X\n", s, b);
    45f0:	85ce                	mv	a1,s3
    45f2:	00003517          	auipc	a0,0x3
    45f6:	fd650513          	addi	a0,a0,-42 # 75c8 <malloc+0x20aa>
    45fa:	671000ef          	jal	546a <printf>
    exit(1);
    45fe:	4505                	li	a0,1
    4600:	23b000ef          	jal	503a <exit>

0000000000004604 <lazy_alloc>:
{
    4604:	1141                	addi	sp,sp,-16
    4606:	e406                	sd	ra,8(sp)
    4608:	e022                	sd	s0,0(sp)
    460a:	0800                	addi	s0,sp,16
  prev_end = sbrklazy(REGION_SZ);
    460c:	40000537          	lui	a0,0x40000
    4610:	20d000ef          	jal	501c <sbrklazy>
  if (prev_end == (char *)SBRK_ERROR) {
    4614:	57fd                	li	a5,-1
    4616:	02f50a63          	beq	a0,a5,464a <lazy_alloc+0x46>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE)
    461a:	6605                	lui	a2,0x1
    461c:	962a                	add	a2,a2,a0
    461e:	400017b7          	lui	a5,0x40001
    4622:	00f50733          	add	a4,a0,a5
    4626:	87b2                	mv	a5,a2
    4628:	000406b7          	lui	a3,0x40
    *(char **)i = i;
    462c:	e39c                	sd	a5,0(a5)
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE)
    462e:	97b6                	add	a5,a5,a3
    4630:	fee79ee3          	bne	a5,a4,462c <lazy_alloc+0x28>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE) {
    4634:	000406b7          	lui	a3,0x40
    if (*(char **)i != i) {
    4638:	621c                	ld	a5,0(a2)
    463a:	02c79163          	bne	a5,a2,465c <lazy_alloc+0x58>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE) {
    463e:	9636                	add	a2,a2,a3
    4640:	fee61ce3          	bne	a2,a4,4638 <lazy_alloc+0x34>
  exit(0);
    4644:	4501                	li	a0,0
    4646:	1f5000ef          	jal	503a <exit>
    printf("sbrklazy() failed\n");
    464a:	00003517          	auipc	a0,0x3
    464e:	fce50513          	addi	a0,a0,-50 # 7618 <malloc+0x20fa>
    4652:	619000ef          	jal	546a <printf>
    exit(1);
    4656:	4505                	li	a0,1
    4658:	1e3000ef          	jal	503a <exit>
      printf("failed to read value from memory\n");
    465c:	00003517          	auipc	a0,0x3
    4660:	fd450513          	addi	a0,a0,-44 # 7630 <malloc+0x2112>
    4664:	607000ef          	jal	546a <printf>
      exit(1);
    4668:	4505                	li	a0,1
    466a:	1d1000ef          	jal	503a <exit>

000000000000466e <lazy_unmap>:
{
    466e:	7139                	addi	sp,sp,-64
    4670:	fc06                	sd	ra,56(sp)
    4672:	f822                	sd	s0,48(sp)
    4674:	0080                	addi	s0,sp,64
  prev_end = sbrklazy(REGION_SZ);
    4676:	40000537          	lui	a0,0x40000
    467a:	1a3000ef          	jal	501c <sbrklazy>
  if (prev_end == (char *)SBRK_ERROR) {
    467e:	57fd                	li	a5,-1
    4680:	04f50663          	beq	a0,a5,46cc <lazy_unmap+0x5e>
    4684:	f426                	sd	s1,40(sp)
    4686:	f04a                	sd	s2,32(sp)
    4688:	ec4e                	sd	s3,24(sp)
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE)
    468a:	6905                	lui	s2,0x1
    468c:	992a                	add	s2,s2,a0
    468e:	400017b7          	lui	a5,0x40001
    4692:	00f504b3          	add	s1,a0,a5
    4696:	87ca                	mv	a5,s2
    4698:	01000737          	lui	a4,0x1000
    *(char **)i = i;
    469c:	e39c                	sd	a5,0(a5)
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE)
    469e:	97ba                	add	a5,a5,a4
    46a0:	fe979ee3          	bne	a5,s1,469c <lazy_unmap+0x2e>
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE) {
    46a4:	010009b7          	lui	s3,0x1000
    pid = fork();
    46a8:	18b000ef          	jal	5032 <fork>
    if (pid < 0) {
    46ac:	02054c63          	bltz	a0,46e4 <lazy_unmap+0x76>
    } else if (pid == 0) {
    46b0:	c139                	beqz	a0,46f6 <lazy_unmap+0x88>
      wait(&status);
    46b2:	fcc40513          	addi	a0,s0,-52
    46b6:	18d000ef          	jal	5042 <wait>
      if (status == 0) {
    46ba:	fcc42783          	lw	a5,-52(s0)
    46be:	c7a9                	beqz	a5,4708 <lazy_unmap+0x9a>
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE) {
    46c0:	994e                	add	s2,s2,s3
    46c2:	fe9913e3          	bne	s2,s1,46a8 <lazy_unmap+0x3a>
  exit(0);
    46c6:	4501                	li	a0,0
    46c8:	173000ef          	jal	503a <exit>
    46cc:	f426                	sd	s1,40(sp)
    46ce:	f04a                	sd	s2,32(sp)
    46d0:	ec4e                	sd	s3,24(sp)
    printf("sbrklazy() failed\n");
    46d2:	00003517          	auipc	a0,0x3
    46d6:	f4650513          	addi	a0,a0,-186 # 7618 <malloc+0x20fa>
    46da:	591000ef          	jal	546a <printf>
    exit(1);
    46de:	4505                	li	a0,1
    46e0:	15b000ef          	jal	503a <exit>
      printf("error forking\n");
    46e4:	00003517          	auipc	a0,0x3
    46e8:	f7450513          	addi	a0,a0,-140 # 7658 <malloc+0x213a>
    46ec:	57f000ef          	jal	546a <printf>
      exit(1);
    46f0:	4505                	li	a0,1
    46f2:	149000ef          	jal	503a <exit>
      sbrklazy(-1L * REGION_SZ);
    46f6:	c0000537          	lui	a0,0xc0000
    46fa:	123000ef          	jal	501c <sbrklazy>
      *(char **)i = i;
    46fe:	01293023          	sd	s2,0(s2) # 1000 <badarg>
      exit(0);
    4702:	4501                	li	a0,0
    4704:	137000ef          	jal	503a <exit>
        printf("memory not unmapped\n");
    4708:	00003517          	auipc	a0,0x3
    470c:	f6050513          	addi	a0,a0,-160 # 7668 <malloc+0x214a>
    4710:	55b000ef          	jal	546a <printf>
        exit(1);
    4714:	4505                	li	a0,1
    4716:	125000ef          	jal	503a <exit>

000000000000471a <lazy_copy>:
{
    471a:	7159                	addi	sp,sp,-112
    471c:	f486                	sd	ra,104(sp)
    471e:	f0a2                	sd	s0,96(sp)
    4720:	eca6                	sd	s1,88(sp)
    4722:	e8ca                	sd	s2,80(sp)
    4724:	e4ce                	sd	s3,72(sp)
    4726:	e0d2                	sd	s4,64(sp)
    4728:	fc56                	sd	s5,56(sp)
    472a:	f85a                	sd	s6,48(sp)
    472c:	1880                	addi	s0,sp,112
    char *p = sbrk(0);
    472e:	4501                	li	a0,0
    4730:	0d7000ef          	jal	5006 <sbrk>
    4734:	84aa                	mv	s1,a0
    sbrklazy(4 * PGSIZE);
    4736:	6511                	lui	a0,0x4
    4738:	0e5000ef          	jal	501c <sbrklazy>
    open(p + 8192, 0);
    473c:	4581                	li	a1,0
    473e:	6509                	lui	a0,0x2
    4740:	9526                	add	a0,a0,s1
    4742:	139000ef          	jal	507a <open>
    void *xx = sbrk(0);
    4746:	4501                	li	a0,0
    4748:	0bf000ef          	jal	5006 <sbrk>
    474c:	84aa                	mv	s1,a0
    void *ret = sbrk(-(((uint64)xx) + 1));
    474e:	fff54513          	not	a0,a0
    4752:	2501                	sext.w	a0,a0
    4754:	0b3000ef          	jal	5006 <sbrk>
    if (ret != xx) {
    4758:	00a48c63          	beq	s1,a0,4770 <lazy_copy+0x56>
    475c:	85aa                	mv	a1,a0
      printf("sbrk(sbrk(0)+1) returned %p, not old sz\n", ret);
    475e:	00003517          	auipc	a0,0x3
    4762:	f2250513          	addi	a0,a0,-222 # 7680 <malloc+0x2162>
    4766:	505000ef          	jal	546a <printf>
      exit(1);
    476a:	4505                	li	a0,1
    476c:	0cf000ef          	jal	503a <exit>
  unsigned long bad[] = {
    4770:	00003797          	auipc	a5,0x3
    4774:	5a078793          	addi	a5,a5,1440 # 7d10 <malloc+0x27f2>
    4778:	7fa8                	ld	a0,120(a5)
    477a:	63cc                	ld	a1,128(a5)
    477c:	67d0                	ld	a2,136(a5)
    477e:	6bd4                	ld	a3,144(a5)
    4780:	6fd8                	ld	a4,152(a5)
    4782:	73dc                	ld	a5,160(a5)
    4784:	f8a43823          	sd	a0,-112(s0)
    4788:	f8b43c23          	sd	a1,-104(s0)
    478c:	fac43023          	sd	a2,-96(s0)
    4790:	fad43423          	sd	a3,-88(s0)
    4794:	fae43823          	sd	a4,-80(s0)
    4798:	faf43c23          	sd	a5,-72(s0)
  for (int i = 0; i < sizeof(bad) / sizeof(bad[0]); i++) {
    479c:	f9040913          	addi	s2,s0,-112
    47a0:	fc040b13          	addi	s6,s0,-64
    int fd = open("README", 0);
    47a4:	00001a17          	auipc	s4,0x1
    47a8:	08ca0a13          	addi	s4,s4,140 # 5830 <malloc+0x312>
    fd = open("junk", O_CREATE | O_RDWR | O_TRUNC);
    47ac:	00001a97          	auipc	s5,0x1
    47b0:	f94a8a93          	addi	s5,s5,-108 # 5740 <malloc+0x222>
    int fd = open("README", 0);
    47b4:	4581                	li	a1,0
    47b6:	8552                	mv	a0,s4
    47b8:	0c3000ef          	jal	507a <open>
    47bc:	84aa                	mv	s1,a0
    if (fd < 0) {
    47be:	04054663          	bltz	a0,480a <lazy_copy+0xf0>
    if (read(fd, (char *)bad[i], 512) >= 0) {
    47c2:	00093983          	ld	s3,0(s2)
    47c6:	20000613          	li	a2,512
    47ca:	85ce                	mv	a1,s3
    47cc:	087000ef          	jal	5052 <read>
    47d0:	04055663          	bgez	a0,481c <lazy_copy+0x102>
    close(fd);
    47d4:	8526                	mv	a0,s1
    47d6:	08d000ef          	jal	5062 <close>
    fd = open("junk", O_CREATE | O_RDWR | O_TRUNC);
    47da:	60200593          	li	a1,1538
    47de:	8556                	mv	a0,s5
    47e0:	09b000ef          	jal	507a <open>
    47e4:	84aa                	mv	s1,a0
    if (fd < 0) {
    47e6:	04054463          	bltz	a0,482e <lazy_copy+0x114>
    if (write(fd, (char *)bad[i], 512) >= 0) {
    47ea:	20000613          	li	a2,512
    47ee:	85ce                	mv	a1,s3
    47f0:	06b000ef          	jal	505a <write>
    47f4:	04055663          	bgez	a0,4840 <lazy_copy+0x126>
    close(fd);
    47f8:	8526                	mv	a0,s1
    47fa:	069000ef          	jal	5062 <close>
  for (int i = 0; i < sizeof(bad) / sizeof(bad[0]); i++) {
    47fe:	0921                	addi	s2,s2,8
    4800:	fb691ae3          	bne	s2,s6,47b4 <lazy_copy+0x9a>
  exit(0);
    4804:	4501                	li	a0,0
    4806:	035000ef          	jal	503a <exit>
      printf("cannot open README\n");
    480a:	00003517          	auipc	a0,0x3
    480e:	ea650513          	addi	a0,a0,-346 # 76b0 <malloc+0x2192>
    4812:	459000ef          	jal	546a <printf>
      exit(1);
    4816:	4505                	li	a0,1
    4818:	023000ef          	jal	503a <exit>
      printf("read succeeded\n");
    481c:	00003517          	auipc	a0,0x3
    4820:	eac50513          	addi	a0,a0,-340 # 76c8 <malloc+0x21aa>
    4824:	447000ef          	jal	546a <printf>
      exit(1);
    4828:	4505                	li	a0,1
    482a:	011000ef          	jal	503a <exit>
      printf("cannot open junk\n");
    482e:	00003517          	auipc	a0,0x3
    4832:	eaa50513          	addi	a0,a0,-342 # 76d8 <malloc+0x21ba>
    4836:	435000ef          	jal	546a <printf>
      exit(1);
    483a:	4505                	li	a0,1
    483c:	7fe000ef          	jal	503a <exit>
      printf("write succeeded\n");
    4840:	00003517          	auipc	a0,0x3
    4844:	eb050513          	addi	a0,a0,-336 # 76f0 <malloc+0x21d2>
    4848:	423000ef          	jal	546a <printf>
      exit(1);
    484c:	4505                	li	a0,1
    484e:	7ec000ef          	jal	503a <exit>

0000000000004852 <lazy_sbrk>:
{
    4852:	1101                	addi	sp,sp,-32
    4854:	ec06                	sd	ra,24(sp)
    4856:	e822                	sd	s0,16(sp)
    4858:	e426                	sd	s1,8(sp)
    485a:	e04a                	sd	s2,0(sp)
    485c:	1000                	addi	s0,sp,32
  char *p = sbrk(0);
    485e:	4501                	li	a0,0
    4860:	7a6000ef          	jal	5006 <sbrk>
    4864:	84aa                	mv	s1,a0
  while ((uint64)p < MAXVA - (1 << 30)) {
    4866:	0ff00793          	li	a5,255
    486a:	07fa                	slli	a5,a5,0x1e
    486c:	00f57d63          	bgeu	a0,a5,4886 <lazy_sbrk+0x34>
    4870:	893e                	mv	s2,a5
    p = sbrklazy(1 << 30);
    4872:	40000537          	lui	a0,0x40000
    4876:	7a6000ef          	jal	501c <sbrklazy>
    p = sbrklazy(0);
    487a:	4501                	li	a0,0
    487c:	7a0000ef          	jal	501c <sbrklazy>
    4880:	84aa                	mv	s1,a0
  while ((uint64)p < MAXVA - (1 << 30)) {
    4882:	ff2568e3          	bltu	a0,s2,4872 <lazy_sbrk+0x20>
  int n = TRAPFRAME - PGSIZE - (uint64)p;
    4886:	7975                	lui	s2,0xffffd
    4888:	4099093b          	subw	s2,s2,s1
  char *p1 = sbrklazy(n);
    488c:	854a                	mv	a0,s2
    488e:	78e000ef          	jal	501c <sbrklazy>
    4892:	862a                	mv	a2,a0
  if (p1 < 0 || p1 != p) {
    4894:	00950d63          	beq	a0,s1,48ae <lazy_sbrk+0x5c>
    printf("sbrklazy(%d) returned %p, not expected %p\n", n, p1, p);
    4898:	86a6                	mv	a3,s1
    489a:	85ca                	mv	a1,s2
    489c:	00003517          	auipc	a0,0x3
    48a0:	e6c50513          	addi	a0,a0,-404 # 7708 <malloc+0x21ea>
    48a4:	3c7000ef          	jal	546a <printf>
    exit(1);
    48a8:	4505                	li	a0,1
    48aa:	790000ef          	jal	503a <exit>
  p = sbrk(PGSIZE);
    48ae:	6505                	lui	a0,0x1
    48b0:	756000ef          	jal	5006 <sbrk>
    48b4:	862a                	mv	a2,a0
  if (p < 0 || (uint64)p != TRAPFRAME - PGSIZE) {
    48b6:	040007b7          	lui	a5,0x4000
    48ba:	17f5                	addi	a5,a5,-3 # 3fffffd <base+0x3ff1335>
    48bc:	07b2                	slli	a5,a5,0xc
    48be:	00f50c63          	beq	a0,a5,48d6 <lazy_sbrk+0x84>
    printf("sbrk(%d) returned %p, not expected TRAPFRAME-PGSIZE\n", PGSIZE, p);
    48c2:	6585                	lui	a1,0x1
    48c4:	00003517          	auipc	a0,0x3
    48c8:	e7450513          	addi	a0,a0,-396 # 7738 <malloc+0x221a>
    48cc:	39f000ef          	jal	546a <printf>
    exit(1);
    48d0:	4505                	li	a0,1
    48d2:	768000ef          	jal	503a <exit>
  p[0] = 1;
    48d6:	040007b7          	lui	a5,0x4000
    48da:	17f5                	addi	a5,a5,-3 # 3fffffd <base+0x3ff1335>
    48dc:	07b2                	slli	a5,a5,0xc
    48de:	4705                	li	a4,1
    48e0:	00e78023          	sb	a4,0(a5)
  if (p[1] != 0) {
    48e4:	0017c783          	lbu	a5,1(a5)
    48e8:	cb91                	beqz	a5,48fc <lazy_sbrk+0xaa>
    printf("sbrk() returned non-zero-filled memory\n");
    48ea:	00003517          	auipc	a0,0x3
    48ee:	e8650513          	addi	a0,a0,-378 # 7770 <malloc+0x2252>
    48f2:	379000ef          	jal	546a <printf>
    exit(1);
    48f6:	4505                	li	a0,1
    48f8:	742000ef          	jal	503a <exit>
  p = sbrk(1);
    48fc:	4505                	li	a0,1
    48fe:	708000ef          	jal	5006 <sbrk>
    4902:	85aa                	mv	a1,a0
  if ((uint64)p != -1) {
    4904:	57fd                	li	a5,-1
    4906:	00f50b63          	beq	a0,a5,491c <lazy_sbrk+0xca>
    printf("sbrk(1) returned %p, expected error\n", p);
    490a:	00003517          	auipc	a0,0x3
    490e:	e8e50513          	addi	a0,a0,-370 # 7798 <malloc+0x227a>
    4912:	359000ef          	jal	546a <printf>
    exit(1);
    4916:	4505                	li	a0,1
    4918:	722000ef          	jal	503a <exit>
  p = sbrklazy(1);
    491c:	4505                	li	a0,1
    491e:	6fe000ef          	jal	501c <sbrklazy>
    4922:	85aa                	mv	a1,a0
  if ((uint64)p != -1) {
    4924:	57fd                	li	a5,-1
    4926:	00f50b63          	beq	a0,a5,493c <lazy_sbrk+0xea>
    printf("sbrklazy(1) returned %p, expected error\n", p);
    492a:	00003517          	auipc	a0,0x3
    492e:	e9650513          	addi	a0,a0,-362 # 77c0 <malloc+0x22a2>
    4932:	339000ef          	jal	546a <printf>
    exit(1);
    4936:	4505                	li	a0,1
    4938:	702000ef          	jal	503a <exit>
  exit(0);
    493c:	4501                	li	a0,0
    493e:	6fc000ef          	jal	503a <exit>

0000000000004942 <fsfull>:
{
    4942:	7171                	addi	sp,sp,-176
    4944:	f506                	sd	ra,168(sp)
    4946:	f122                	sd	s0,160(sp)
    4948:	ed26                	sd	s1,152(sp)
    494a:	e94a                	sd	s2,144(sp)
    494c:	e54e                	sd	s3,136(sp)
    494e:	e152                	sd	s4,128(sp)
    4950:	fcd6                	sd	s5,120(sp)
    4952:	f8da                	sd	s6,112(sp)
    4954:	f4de                	sd	s7,104(sp)
    4956:	f0e2                	sd	s8,96(sp)
    4958:	ece6                	sd	s9,88(sp)
    495a:	e8ea                	sd	s10,80(sp)
    495c:	e4ee                	sd	s11,72(sp)
    495e:	1900                	addi	s0,sp,176
  printf("fsfull test\n");
    4960:	00003517          	auipc	a0,0x3
    4964:	e9050513          	addi	a0,a0,-368 # 77f0 <malloc+0x22d2>
    4968:	303000ef          	jal	546a <printf>
  int fsblocks = 0;
    496c:	4a81                	li	s5,0
  for (nfiles = 0;; nfiles++) {
    496e:	4481                	li	s1,0
    name[0] = 'f';
    4970:	06600d93          	li	s11,102
    name[1] = '0' + nfiles / 1000;
    4974:	3e800c93          	li	s9,1000
    name[2] = '0' + (nfiles % 1000) / 100;
    4978:	06400c13          	li	s8,100
    name[3] = '0' + (nfiles % 100) / 10;
    497c:	4ba9                	li	s7,10
    printf("writing %s\n", name);
    497e:	00003d17          	auipc	s10,0x3
    4982:	e82d0d13          	addi	s10,s10,-382 # 7800 <malloc+0x22e2>
    name[0] = 'f';
    4986:	f5b40823          	sb	s11,-176(s0)
    name[1] = '0' + nfiles / 1000;
    498a:	0394c7bb          	divw	a5,s1,s9
    498e:	0307879b          	addiw	a5,a5,48
    4992:	f4f408a3          	sb	a5,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    4996:	0394e7bb          	remw	a5,s1,s9
    499a:	0387c7bb          	divw	a5,a5,s8
    499e:	0307879b          	addiw	a5,a5,48
    49a2:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    49a6:	0384e7bb          	remw	a5,s1,s8
    49aa:	0377c7bb          	divw	a5,a5,s7
    49ae:	0307879b          	addiw	a5,a5,48
    49b2:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    49b6:	0374e7bb          	remw	a5,s1,s7
    49ba:	0307879b          	addiw	a5,a5,48
    49be:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    49c2:	f4040aa3          	sb	zero,-171(s0)
    printf("writing %s\n", name);
    49c6:	f5040593          	addi	a1,s0,-176
    49ca:	856a                	mv	a0,s10
    49cc:	29f000ef          	jal	546a <printf>
    int fd = open(name, O_CREATE | O_RDWR);
    49d0:	20200593          	li	a1,514
    49d4:	f5040513          	addi	a0,s0,-176
    49d8:	6a2000ef          	jal	507a <open>
    49dc:	892a                	mv	s2,a0
    if (fd < 0) {
    49de:	0a055163          	bgez	a0,4a80 <fsfull+0x13e>
      printf("open %s failed\n", name);
    49e2:	f5040593          	addi	a1,s0,-176
    49e6:	00003517          	auipc	a0,0x3
    49ea:	e2a50513          	addi	a0,a0,-470 # 7810 <malloc+0x22f2>
    49ee:	27d000ef          	jal	546a <printf>
  while (nfiles >= 0) {
    49f2:	0604c163          	bltz	s1,4a54 <fsfull+0x112>
    name[0] = 'f';
    49f6:	06600b93          	li	s7,102
    name[1] = '0' + nfiles / 1000;
    49fa:	3e800a13          	li	s4,1000
    name[2] = '0' + (nfiles % 1000) / 100;
    49fe:	06400993          	li	s3,100
    name[3] = '0' + (nfiles % 100) / 10;
    4a02:	4929                	li	s2,10
  while (nfiles >= 0) {
    4a04:	5b7d                	li	s6,-1
    name[0] = 'f';
    4a06:	f5740823          	sb	s7,-176(s0)
    name[1] = '0' + nfiles / 1000;
    4a0a:	0344c7bb          	divw	a5,s1,s4
    4a0e:	0307879b          	addiw	a5,a5,48
    4a12:	f4f408a3          	sb	a5,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    4a16:	0344e7bb          	remw	a5,s1,s4
    4a1a:	0337c7bb          	divw	a5,a5,s3
    4a1e:	0307879b          	addiw	a5,a5,48
    4a22:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    4a26:	0334e7bb          	remw	a5,s1,s3
    4a2a:	0327c7bb          	divw	a5,a5,s2
    4a2e:	0307879b          	addiw	a5,a5,48
    4a32:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    4a36:	0324e7bb          	remw	a5,s1,s2
    4a3a:	0307879b          	addiw	a5,a5,48
    4a3e:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    4a42:	f4040aa3          	sb	zero,-171(s0)
    unlink(name);
    4a46:	f5040513          	addi	a0,s0,-176
    4a4a:	640000ef          	jal	508a <unlink>
    nfiles--;
    4a4e:	34fd                	addiw	s1,s1,-1
  while (nfiles >= 0) {
    4a50:	fb649be3          	bne	s1,s6,4a06 <fsfull+0xc4>
  printf("fsfull test finished, %d blocks\n", fsblocks);
    4a54:	85d6                	mv	a1,s5
    4a56:	00003517          	auipc	a0,0x3
    4a5a:	dda50513          	addi	a0,a0,-550 # 7830 <malloc+0x2312>
    4a5e:	20d000ef          	jal	546a <printf>
}
    4a62:	70aa                	ld	ra,168(sp)
    4a64:	740a                	ld	s0,160(sp)
    4a66:	64ea                	ld	s1,152(sp)
    4a68:	694a                	ld	s2,144(sp)
    4a6a:	69aa                	ld	s3,136(sp)
    4a6c:	6a0a                	ld	s4,128(sp)
    4a6e:	7ae6                	ld	s5,120(sp)
    4a70:	7b46                	ld	s6,112(sp)
    4a72:	7ba6                	ld	s7,104(sp)
    4a74:	7c06                	ld	s8,96(sp)
    4a76:	6ce6                	ld	s9,88(sp)
    4a78:	6d46                	ld	s10,80(sp)
    4a7a:	6da6                	ld	s11,72(sp)
    4a7c:	614d                	addi	sp,sp,176
    4a7e:	8082                	ret
    int total = 0;
    4a80:	4981                	li	s3,0
      int cc = write(fd, buf, BSIZE);
    4a82:	00007b17          	auipc	s6,0x7
    4a86:	246b0b13          	addi	s6,s6,582 # bcc8 <buf>
      if (cc < BSIZE)
    4a8a:	3ff00a13          	li	s4,1023
      int cc = write(fd, buf, BSIZE);
    4a8e:	40000613          	li	a2,1024
    4a92:	85da                	mv	a1,s6
    4a94:	854a                	mv	a0,s2
    4a96:	5c4000ef          	jal	505a <write>
      if (cc < BSIZE)
    4a9a:	00aa5663          	bge	s4,a0,4aa6 <fsfull+0x164>
      total += cc;
    4a9e:	00a989bb          	addw	s3,s3,a0
      fsblocks++;
    4aa2:	2a85                	addiw	s5,s5,1
    while (1) {
    4aa4:	b7ed                	j	4a8e <fsfull+0x14c>
    printf("wrote %d bytes\n", total);
    4aa6:	85ce                	mv	a1,s3
    4aa8:	00003517          	auipc	a0,0x3
    4aac:	d7850513          	addi	a0,a0,-648 # 7820 <malloc+0x2302>
    4ab0:	1bb000ef          	jal	546a <printf>
    close(fd);
    4ab4:	854a                	mv	a0,s2
    4ab6:	5ac000ef          	jal	5062 <close>
    if (total == 0)
    4aba:	f2098ce3          	beqz	s3,49f2 <fsfull+0xb0>
  for (nfiles = 0;; nfiles++) {
    4abe:	2485                	addiw	s1,s1,1
    4ac0:	b5d9                	j	4986 <fsfull+0x44>

0000000000004ac2 <run>:

// run each test in its own process. run returns 1 if child's exit()
// indicates success.
int
run(void f(char *), char *s)
{
    4ac2:	7179                	addi	sp,sp,-48
    4ac4:	f406                	sd	ra,40(sp)
    4ac6:	f022                	sd	s0,32(sp)
    4ac8:	ec26                	sd	s1,24(sp)
    4aca:	e84a                	sd	s2,16(sp)
    4acc:	1800                	addi	s0,sp,48
    4ace:	84aa                	mv	s1,a0
    4ad0:	892e                	mv	s2,a1
  int pid;
  int xstatus;

  printf("test %s: ", s);
    4ad2:	00003517          	auipc	a0,0x3
    4ad6:	d8650513          	addi	a0,a0,-634 # 7858 <malloc+0x233a>
    4ada:	191000ef          	jal	546a <printf>
  if ((pid = fork()) < 0) {
    4ade:	554000ef          	jal	5032 <fork>
    4ae2:	02054a63          	bltz	a0,4b16 <run+0x54>
    printf("runtest: fork error\n");
    exit(1);
  }
  if (pid == 0) {
    4ae6:	c129                	beqz	a0,4b28 <run+0x66>
    f(s);
    exit(0);
  } else {
    wait(&xstatus);
    4ae8:	fdc40513          	addi	a0,s0,-36
    4aec:	556000ef          	jal	5042 <wait>
    if (xstatus != 0)
    4af0:	fdc42783          	lw	a5,-36(s0)
    4af4:	cf9d                	beqz	a5,4b32 <run+0x70>
      printf("FAILED\n");
    4af6:	00003517          	auipc	a0,0x3
    4afa:	d8a50513          	addi	a0,a0,-630 # 7880 <malloc+0x2362>
    4afe:	16d000ef          	jal	546a <printf>
    else
      printf("OK\n");
    return xstatus == 0;
    4b02:	fdc42503          	lw	a0,-36(s0)
  }
}
    4b06:	00153513          	seqz	a0,a0
    4b0a:	70a2                	ld	ra,40(sp)
    4b0c:	7402                	ld	s0,32(sp)
    4b0e:	64e2                	ld	s1,24(sp)
    4b10:	6942                	ld	s2,16(sp)
    4b12:	6145                	addi	sp,sp,48
    4b14:	8082                	ret
    printf("runtest: fork error\n");
    4b16:	00003517          	auipc	a0,0x3
    4b1a:	d5250513          	addi	a0,a0,-686 # 7868 <malloc+0x234a>
    4b1e:	14d000ef          	jal	546a <printf>
    exit(1);
    4b22:	4505                	li	a0,1
    4b24:	516000ef          	jal	503a <exit>
    f(s);
    4b28:	854a                	mv	a0,s2
    4b2a:	9482                	jalr	s1
    exit(0);
    4b2c:	4501                	li	a0,0
    4b2e:	50c000ef          	jal	503a <exit>
      printf("OK\n");
    4b32:	00003517          	auipc	a0,0x3
    4b36:	d5650513          	addi	a0,a0,-682 # 7888 <malloc+0x236a>
    4b3a:	131000ef          	jal	546a <printf>
    4b3e:	b7d1                	j	4b02 <run+0x40>

0000000000004b40 <runtests>:

int
runtests(struct test *tests, char *justone, int continuous)
{
    4b40:	7139                	addi	sp,sp,-64
    4b42:	fc06                	sd	ra,56(sp)
    4b44:	f822                	sd	s0,48(sp)
    4b46:	f426                	sd	s1,40(sp)
    4b48:	ec4e                	sd	s3,24(sp)
    4b4a:	0080                	addi	s0,sp,64
    4b4c:	84aa                	mv	s1,a0
  int ntests = 0;
  for (struct test *t = tests; t->s != 0; t++) {
    4b4e:	6508                	ld	a0,8(a0)
    4b50:	cd39                	beqz	a0,4bae <runtests+0x6e>
    4b52:	f04a                	sd	s2,32(sp)
    4b54:	e852                	sd	s4,16(sp)
    4b56:	e456                	sd	s5,8(sp)
    4b58:	892e                	mv	s2,a1
    4b5a:	8a32                	mv	s4,a2
  int ntests = 0;
    4b5c:	4981                	li	s3,0
    if ((justone == 0) || strcmp(t->s, justone) == 0) {
      ntests++;
      if (!run(t->f, t->s)) {
        if (continuous != 2) {
    4b5e:	4a89                	li	s5,2
    4b60:	a021                	j	4b68 <runtests+0x28>
  for (struct test *t = tests; t->s != 0; t++) {
    4b62:	04c1                	addi	s1,s1,16
    4b64:	6488                	ld	a0,8(s1)
    4b66:	c915                	beqz	a0,4b9a <runtests+0x5a>
    if ((justone == 0) || strcmp(t->s, justone) == 0) {
    4b68:	00090663          	beqz	s2,4b74 <runtests+0x34>
    4b6c:	85ca                	mv	a1,s2
    4b6e:	264000ef          	jal	4dd2 <strcmp>
    4b72:	f965                	bnez	a0,4b62 <runtests+0x22>
      ntests++;
    4b74:	2985                	addiw	s3,s3,1 # 1000001 <base+0xff1339>
      if (!run(t->f, t->s)) {
    4b76:	648c                	ld	a1,8(s1)
    4b78:	6088                	ld	a0,0(s1)
    4b7a:	f49ff0ef          	jal	4ac2 <run>
    4b7e:	f175                	bnez	a0,4b62 <runtests+0x22>
        if (continuous != 2) {
    4b80:	ff5a01e3          	beq	s4,s5,4b62 <runtests+0x22>
          printf("SOME TESTS FAILED\n");
    4b84:	00003517          	auipc	a0,0x3
    4b88:	d0c50513          	addi	a0,a0,-756 # 7890 <malloc+0x2372>
    4b8c:	0df000ef          	jal	546a <printf>
          return -1;
    4b90:	59fd                	li	s3,-1
    4b92:	7902                	ld	s2,32(sp)
    4b94:	6a42                	ld	s4,16(sp)
    4b96:	6aa2                	ld	s5,8(sp)
    4b98:	a021                	j	4ba0 <runtests+0x60>
    4b9a:	7902                	ld	s2,32(sp)
    4b9c:	6a42                	ld	s4,16(sp)
    4b9e:	6aa2                	ld	s5,8(sp)
        }
      }
    }
  }
  return ntests;
}
    4ba0:	854e                	mv	a0,s3
    4ba2:	70e2                	ld	ra,56(sp)
    4ba4:	7442                	ld	s0,48(sp)
    4ba6:	74a2                	ld	s1,40(sp)
    4ba8:	69e2                	ld	s3,24(sp)
    4baa:	6121                	addi	sp,sp,64
    4bac:	8082                	ret
  return ntests;
    4bae:	4981                	li	s3,0
    4bb0:	bfc5                	j	4ba0 <runtests+0x60>

0000000000004bb2 <countfree>:

// use sbrk() to count how many free physical memory pages there are.
int
countfree()
{
    4bb2:	7179                	addi	sp,sp,-48
    4bb4:	f406                	sd	ra,40(sp)
    4bb6:	f022                	sd	s0,32(sp)
    4bb8:	ec26                	sd	s1,24(sp)
    4bba:	e84a                	sd	s2,16(sp)
    4bbc:	e44e                	sd	s3,8(sp)
    4bbe:	1800                	addi	s0,sp,48
  int n = 0;
  uint64 sz0 = (uint64)sbrk(0);
    4bc0:	4501                	li	a0,0
    4bc2:	444000ef          	jal	5006 <sbrk>
    4bc6:	89aa                	mv	s3,a0
  int n = 0;
    4bc8:	4481                	li	s1,0
  while (1) {
    char *a = sbrk(PGSIZE);
    if (a == SBRK_ERROR) {
    4bca:	597d                	li	s2,-1
    4bcc:	a011                	j	4bd0 <countfree+0x1e>
      break;
    }
    n += 1;
    4bce:	2485                	addiw	s1,s1,1
    char *a = sbrk(PGSIZE);
    4bd0:	6505                	lui	a0,0x1
    4bd2:	434000ef          	jal	5006 <sbrk>
    if (a == SBRK_ERROR) {
    4bd6:	ff251ce3          	bne	a0,s2,4bce <countfree+0x1c>
  }
  sbrk(-((uint64)sbrk(0) - sz0));
    4bda:	4501                	li	a0,0
    4bdc:	42a000ef          	jal	5006 <sbrk>
    4be0:	40a9853b          	subw	a0,s3,a0
    4be4:	422000ef          	jal	5006 <sbrk>
  return n;
}
    4be8:	8526                	mv	a0,s1
    4bea:	70a2                	ld	ra,40(sp)
    4bec:	7402                	ld	s0,32(sp)
    4bee:	64e2                	ld	s1,24(sp)
    4bf0:	6942                	ld	s2,16(sp)
    4bf2:	69a2                	ld	s3,8(sp)
    4bf4:	6145                	addi	sp,sp,48
    4bf6:	8082                	ret

0000000000004bf8 <drivetests>:

int
drivetests(int quick, int continuous, char *justone)
{
    4bf8:	7159                	addi	sp,sp,-112
    4bfa:	f486                	sd	ra,104(sp)
    4bfc:	f0a2                	sd	s0,96(sp)
    4bfe:	eca6                	sd	s1,88(sp)
    4c00:	e8ca                	sd	s2,80(sp)
    4c02:	e4ce                	sd	s3,72(sp)
    4c04:	e0d2                	sd	s4,64(sp)
    4c06:	fc56                	sd	s5,56(sp)
    4c08:	f85a                	sd	s6,48(sp)
    4c0a:	f45e                	sd	s7,40(sp)
    4c0c:	f062                	sd	s8,32(sp)
    4c0e:	ec66                	sd	s9,24(sp)
    4c10:	e86a                	sd	s10,16(sp)
    4c12:	e46e                	sd	s11,8(sp)
    4c14:	1880                	addi	s0,sp,112
    4c16:	8aaa                	mv	s5,a0
    4c18:	89ae                	mv	s3,a1
    4c1a:	8a32                	mv	s4,a2
  do {
    printf("usertests starting\n");
    4c1c:	00003c17          	auipc	s8,0x3
    4c20:	c8cc0c13          	addi	s8,s8,-884 # 78a8 <malloc+0x238a>
    int free0 = countfree();
    int free1 = 0;
    int ntests = 0;
    int n;
    n = runtests(quicktests, justone, continuous);
    4c24:	00003b97          	auipc	s7,0x3
    4c28:	3ecb8b93          	addi	s7,s7,1004 # 8010 <quicktests>
    if (n < 0) {
      if (continuous != 2) {
    4c2c:	4b09                	li	s6,2
      ntests += n;
    }
    if (!quick) {
      if (justone == 0)
        printf("usertests slow tests starting\n");
      n = runtests(slowtests, justone, continuous);
    4c2e:	00004c97          	auipc	s9,0x4
    4c32:	802c8c93          	addi	s9,s9,-2046 # 8430 <slowtests>
        printf("usertests slow tests starting\n");
    4c36:	00003d97          	auipc	s11,0x3
    4c3a:	c8ad8d93          	addi	s11,s11,-886 # 78c0 <malloc+0x23a2>
      } else {
        ntests += n;
      }
    }
    if ((free1 = countfree()) < free0) {
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    4c3e:	00003d17          	auipc	s10,0x3
    4c42:	ca2d0d13          	addi	s10,s10,-862 # 78e0 <malloc+0x23c2>
    4c46:	a025                	j	4c6e <drivetests+0x76>
      if (continuous != 2) {
    4c48:	09699063          	bne	s3,s6,4cc8 <drivetests+0xd0>
    int ntests = 0;
    4c4c:	4481                	li	s1,0
    4c4e:	a835                	j	4c8a <drivetests+0x92>
        printf("usertests slow tests starting\n");
    4c50:	856e                	mv	a0,s11
    4c52:	019000ef          	jal	546a <printf>
    4c56:	a835                	j	4c92 <drivetests+0x9a>
        if (continuous != 2) {
    4c58:	07699a63          	bne	s3,s6,4ccc <drivetests+0xd4>
    if ((free1 = countfree()) < free0) {
    4c5c:	f57ff0ef          	jal	4bb2 <countfree>
    4c60:	05254263          	blt	a0,s2,4ca4 <drivetests+0xac>
      if (continuous != 2) {
        return 1;
      }
    }
    if (justone != 0 && ntests == 0) {
    4c64:	000a0363          	beqz	s4,4c6a <drivetests+0x72>
    4c68:	c8a1                	beqz	s1,4cb8 <drivetests+0xc0>
      printf("NO TESTS EXECUTED\n");
      return 1;
    }
  } while (continuous);
    4c6a:	06098563          	beqz	s3,4cd4 <drivetests+0xdc>
    printf("usertests starting\n");
    4c6e:	8562                	mv	a0,s8
    4c70:	7fa000ef          	jal	546a <printf>
    int free0 = countfree();
    4c74:	f3fff0ef          	jal	4bb2 <countfree>
    4c78:	892a                	mv	s2,a0
    n = runtests(quicktests, justone, continuous);
    4c7a:	864e                	mv	a2,s3
    4c7c:	85d2                	mv	a1,s4
    4c7e:	855e                	mv	a0,s7
    4c80:	ec1ff0ef          	jal	4b40 <runtests>
    4c84:	84aa                	mv	s1,a0
    if (n < 0) {
    4c86:	fc0541e3          	bltz	a0,4c48 <drivetests+0x50>
    if (!quick) {
    4c8a:	fc0a99e3          	bnez	s5,4c5c <drivetests+0x64>
      if (justone == 0)
    4c8e:	fc0a01e3          	beqz	s4,4c50 <drivetests+0x58>
      n = runtests(slowtests, justone, continuous);
    4c92:	864e                	mv	a2,s3
    4c94:	85d2                	mv	a1,s4
    4c96:	8566                	mv	a0,s9
    4c98:	ea9ff0ef          	jal	4b40 <runtests>
      if (n < 0) {
    4c9c:	fa054ee3          	bltz	a0,4c58 <drivetests+0x60>
        ntests += n;
    4ca0:	9ca9                	addw	s1,s1,a0
    4ca2:	bf6d                	j	4c5c <drivetests+0x64>
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    4ca4:	864a                	mv	a2,s2
    4ca6:	85aa                	mv	a1,a0
    4ca8:	856a                	mv	a0,s10
    4caa:	7c0000ef          	jal	546a <printf>
      if (continuous != 2) {
    4cae:	03699163          	bne	s3,s6,4cd0 <drivetests+0xd8>
    if (justone != 0 && ntests == 0) {
    4cb2:	fa0a1be3          	bnez	s4,4c68 <drivetests+0x70>
    4cb6:	bf65                	j	4c6e <drivetests+0x76>
      printf("NO TESTS EXECUTED\n");
    4cb8:	00003517          	auipc	a0,0x3
    4cbc:	c5850513          	addi	a0,a0,-936 # 7910 <malloc+0x23f2>
    4cc0:	7aa000ef          	jal	546a <printf>
      return 1;
    4cc4:	4505                	li	a0,1
    4cc6:	a801                	j	4cd6 <drivetests+0xde>
        return 1;
    4cc8:	4505                	li	a0,1
    4cca:	a031                	j	4cd6 <drivetests+0xde>
          return 1;
    4ccc:	4505                	li	a0,1
    4cce:	a021                	j	4cd6 <drivetests+0xde>
        return 1;
    4cd0:	4505                	li	a0,1
    4cd2:	a011                	j	4cd6 <drivetests+0xde>
  return 0;
    4cd4:	854e                	mv	a0,s3
}
    4cd6:	70a6                	ld	ra,104(sp)
    4cd8:	7406                	ld	s0,96(sp)
    4cda:	64e6                	ld	s1,88(sp)
    4cdc:	6946                	ld	s2,80(sp)
    4cde:	69a6                	ld	s3,72(sp)
    4ce0:	6a06                	ld	s4,64(sp)
    4ce2:	7ae2                	ld	s5,56(sp)
    4ce4:	7b42                	ld	s6,48(sp)
    4ce6:	7ba2                	ld	s7,40(sp)
    4ce8:	7c02                	ld	s8,32(sp)
    4cea:	6ce2                	ld	s9,24(sp)
    4cec:	6d42                	ld	s10,16(sp)
    4cee:	6da2                	ld	s11,8(sp)
    4cf0:	6165                	addi	sp,sp,112
    4cf2:	8082                	ret

0000000000004cf4 <main>:

int
main(int argc, char *argv[])
{
    4cf4:	1101                	addi	sp,sp,-32
    4cf6:	ec06                	sd	ra,24(sp)
    4cf8:	e822                	sd	s0,16(sp)
    4cfa:	e426                	sd	s1,8(sp)
    4cfc:	e04a                	sd	s2,0(sp)
    4cfe:	1000                	addi	s0,sp,32
    4d00:	84aa                	mv	s1,a0
  int continuous = 0;
  int quick = 0;
  char *justone = 0;

  if (argc == 2 && strcmp(argv[1], "-q") == 0) {
    4d02:	4789                	li	a5,2
    4d04:	00f50e63          	beq	a0,a5,4d20 <main+0x2c>
    continuous = 1;
  } else if (argc == 2 && strcmp(argv[1], "-C") == 0) {
    continuous = 2;
  } else if (argc == 2 && argv[1][0] != '-') {
    justone = argv[1];
  } else if (argc > 1) {
    4d08:	4785                	li	a5,1
    4d0a:	06a7c663          	blt	a5,a0,4d76 <main+0x82>
  char *justone = 0;
    4d0e:	4601                	li	a2,0
  int quick = 0;
    4d10:	4501                	li	a0,0
  int continuous = 0;
    4d12:	4581                	li	a1,0
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    exit(1);
  }
  if (drivetests(quick, continuous, justone)) {
    4d14:	ee5ff0ef          	jal	4bf8 <drivetests>
    4d18:	cd35                	beqz	a0,4d94 <main+0xa0>
    exit(1);
    4d1a:	4505                	li	a0,1
    4d1c:	31e000ef          	jal	503a <exit>
    4d20:	892e                	mv	s2,a1
  if (argc == 2 && strcmp(argv[1], "-q") == 0) {
    4d22:	00003597          	auipc	a1,0x3
    4d26:	c0658593          	addi	a1,a1,-1018 # 7928 <malloc+0x240a>
    4d2a:	00893503          	ld	a0,8(s2) # ffffffffffffd008 <base+0xfffffffffffee340>
    4d2e:	0a4000ef          	jal	4dd2 <strcmp>
    4d32:	85aa                	mv	a1,a0
    4d34:	e501                	bnez	a0,4d3c <main+0x48>
  char *justone = 0;
    4d36:	4601                	li	a2,0
    quick = 1;
    4d38:	4505                	li	a0,1
    4d3a:	bfe9                	j	4d14 <main+0x20>
  } else if (argc == 2 && strcmp(argv[1], "-c") == 0) {
    4d3c:	00003597          	auipc	a1,0x3
    4d40:	bf458593          	addi	a1,a1,-1036 # 7930 <malloc+0x2412>
    4d44:	00893503          	ld	a0,8(s2)
    4d48:	08a000ef          	jal	4dd2 <strcmp>
    4d4c:	cd15                	beqz	a0,4d88 <main+0x94>
  } else if (argc == 2 && strcmp(argv[1], "-C") == 0) {
    4d4e:	00003597          	auipc	a1,0x3
    4d52:	c3258593          	addi	a1,a1,-974 # 7980 <malloc+0x2462>
    4d56:	00893503          	ld	a0,8(s2)
    4d5a:	078000ef          	jal	4dd2 <strcmp>
    4d5e:	c905                	beqz	a0,4d8e <main+0x9a>
  } else if (argc == 2 && argv[1][0] != '-') {
    4d60:	00893603          	ld	a2,8(s2)
    4d64:	00064703          	lbu	a4,0(a2) # 1000 <badarg>
    4d68:	02d00793          	li	a5,45
    4d6c:	00f70563          	beq	a4,a5,4d76 <main+0x82>
  int quick = 0;
    4d70:	4501                	li	a0,0
  int continuous = 0;
    4d72:	4581                	li	a1,0
    4d74:	b745                	j	4d14 <main+0x20>
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    4d76:	00003517          	auipc	a0,0x3
    4d7a:	bc250513          	addi	a0,a0,-1086 # 7938 <malloc+0x241a>
    4d7e:	6ec000ef          	jal	546a <printf>
    exit(1);
    4d82:	4505                	li	a0,1
    4d84:	2b6000ef          	jal	503a <exit>
  char *justone = 0;
    4d88:	4601                	li	a2,0
    continuous = 1;
    4d8a:	4585                	li	a1,1
    4d8c:	b761                	j	4d14 <main+0x20>
    continuous = 2;
    4d8e:	85a6                	mv	a1,s1
  char *justone = 0;
    4d90:	4601                	li	a2,0
    4d92:	b749                	j	4d14 <main+0x20>
  }
  printf("ALL TESTS PASSED\n");
    4d94:	00003517          	auipc	a0,0x3
    4d98:	bd450513          	addi	a0,a0,-1068 # 7968 <malloc+0x244a>
    4d9c:	6ce000ef          	jal	546a <printf>
  exit(0);
    4da0:	4501                	li	a0,0
    4da2:	298000ef          	jal	503a <exit>

0000000000004da6 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
    4da6:	1141                	addi	sp,sp,-16
    4da8:	e406                	sd	ra,8(sp)
    4daa:	e022                	sd	s0,0(sp)
    4dac:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
    4dae:	f47ff0ef          	jal	4cf4 <main>
  exit(r);
    4db2:	288000ef          	jal	503a <exit>

0000000000004db6 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
    4db6:	1141                	addi	sp,sp,-16
    4db8:	e422                	sd	s0,8(sp)
    4dba:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
    4dbc:	87aa                	mv	a5,a0
    4dbe:	0585                	addi	a1,a1,1
    4dc0:	0785                	addi	a5,a5,1
    4dc2:	fff5c703          	lbu	a4,-1(a1)
    4dc6:	fee78fa3          	sb	a4,-1(a5)
    4dca:	fb75                	bnez	a4,4dbe <strcpy+0x8>
    ;
  return os;
}
    4dcc:	6422                	ld	s0,8(sp)
    4dce:	0141                	addi	sp,sp,16
    4dd0:	8082                	ret

0000000000004dd2 <strcmp>:

int
strcmp(const char *p, const char *q)
{
    4dd2:	1141                	addi	sp,sp,-16
    4dd4:	e422                	sd	s0,8(sp)
    4dd6:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
    4dd8:	00054783          	lbu	a5,0(a0)
    4ddc:	cb91                	beqz	a5,4df0 <strcmp+0x1e>
    4dde:	0005c703          	lbu	a4,0(a1)
    4de2:	00f71763          	bne	a4,a5,4df0 <strcmp+0x1e>
    p++, q++;
    4de6:	0505                	addi	a0,a0,1
    4de8:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
    4dea:	00054783          	lbu	a5,0(a0)
    4dee:	fbe5                	bnez	a5,4dde <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
    4df0:	0005c503          	lbu	a0,0(a1)
}
    4df4:	40a7853b          	subw	a0,a5,a0
    4df8:	6422                	ld	s0,8(sp)
    4dfa:	0141                	addi	sp,sp,16
    4dfc:	8082                	ret

0000000000004dfe <strlen>:

uint
strlen(const char *s)
{
    4dfe:	1141                	addi	sp,sp,-16
    4e00:	e422                	sd	s0,8(sp)
    4e02:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    4e04:	00054783          	lbu	a5,0(a0)
    4e08:	cf91                	beqz	a5,4e24 <strlen+0x26>
    4e0a:	0505                	addi	a0,a0,1
    4e0c:	87aa                	mv	a5,a0
    4e0e:	86be                	mv	a3,a5
    4e10:	0785                	addi	a5,a5,1
    4e12:	fff7c703          	lbu	a4,-1(a5)
    4e16:	ff65                	bnez	a4,4e0e <strlen+0x10>
    4e18:	40a6853b          	subw	a0,a3,a0
    4e1c:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    4e1e:	6422                	ld	s0,8(sp)
    4e20:	0141                	addi	sp,sp,16
    4e22:	8082                	ret
  for (n = 0; s[n]; n++)
    4e24:	4501                	li	a0,0
    4e26:	bfe5                	j	4e1e <strlen+0x20>

0000000000004e28 <memset>:

void *
memset(void *dst, int c, uint n)
{
    4e28:	1141                	addi	sp,sp,-16
    4e2a:	e422                	sd	s0,8(sp)
    4e2c:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    4e2e:	ca19                	beqz	a2,4e44 <memset+0x1c>
    4e30:	87aa                	mv	a5,a0
    4e32:	1602                	slli	a2,a2,0x20
    4e34:	9201                	srli	a2,a2,0x20
    4e36:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    4e3a:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    4e3e:	0785                	addi	a5,a5,1
    4e40:	fee79de3          	bne	a5,a4,4e3a <memset+0x12>
  }
  return dst;
}
    4e44:	6422                	ld	s0,8(sp)
    4e46:	0141                	addi	sp,sp,16
    4e48:	8082                	ret

0000000000004e4a <strchr>:

char *
strchr(const char *s, char c)
{
    4e4a:	1141                	addi	sp,sp,-16
    4e4c:	e422                	sd	s0,8(sp)
    4e4e:	0800                	addi	s0,sp,16
  for (; *s; s++)
    4e50:	00054783          	lbu	a5,0(a0)
    4e54:	cb99                	beqz	a5,4e6a <strchr+0x20>
    if (*s == c)
    4e56:	00f58763          	beq	a1,a5,4e64 <strchr+0x1a>
  for (; *s; s++)
    4e5a:	0505                	addi	a0,a0,1
    4e5c:	00054783          	lbu	a5,0(a0)
    4e60:	fbfd                	bnez	a5,4e56 <strchr+0xc>
      return (char *)s;
  return 0;
    4e62:	4501                	li	a0,0
}
    4e64:	6422                	ld	s0,8(sp)
    4e66:	0141                	addi	sp,sp,16
    4e68:	8082                	ret
  return 0;
    4e6a:	4501                	li	a0,0
    4e6c:	bfe5                	j	4e64 <strchr+0x1a>

0000000000004e6e <gets>:

char *
gets(char *buf, int max)
{
    4e6e:	711d                	addi	sp,sp,-96
    4e70:	ec86                	sd	ra,88(sp)
    4e72:	e8a2                	sd	s0,80(sp)
    4e74:	e4a6                	sd	s1,72(sp)
    4e76:	e0ca                	sd	s2,64(sp)
    4e78:	fc4e                	sd	s3,56(sp)
    4e7a:	f852                	sd	s4,48(sp)
    4e7c:	f456                	sd	s5,40(sp)
    4e7e:	f05a                	sd	s6,32(sp)
    4e80:	ec5e                	sd	s7,24(sp)
    4e82:	1080                	addi	s0,sp,96
    4e84:	8baa                	mv	s7,a0
    4e86:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
    4e88:	892a                	mv	s2,a0
    4e8a:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if (cc < 1)
      break;
    buf[i++] = c;
    if (c == '\n' || c == '\r')
    4e8c:	4aa9                	li	s5,10
    4e8e:	4b35                	li	s6,13
  for (i = 0; i + 1 < max;) {
    4e90:	89a6                	mv	s3,s1
    4e92:	2485                	addiw	s1,s1,1
    4e94:	0344d663          	bge	s1,s4,4ec0 <gets+0x52>
    cc = read(0, &c, 1);
    4e98:	4605                	li	a2,1
    4e9a:	faf40593          	addi	a1,s0,-81
    4e9e:	4501                	li	a0,0
    4ea0:	1b2000ef          	jal	5052 <read>
    if (cc < 1)
    4ea4:	00a05e63          	blez	a0,4ec0 <gets+0x52>
    buf[i++] = c;
    4ea8:	faf44783          	lbu	a5,-81(s0)
    4eac:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
    4eb0:	01578763          	beq	a5,s5,4ebe <gets+0x50>
    4eb4:	0905                	addi	s2,s2,1
    4eb6:	fd679de3          	bne	a5,s6,4e90 <gets+0x22>
    buf[i++] = c;
    4eba:	89a6                	mv	s3,s1
    4ebc:	a011                	j	4ec0 <gets+0x52>
    4ebe:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
    4ec0:	99de                	add	s3,s3,s7
    4ec2:	00098023          	sb	zero,0(s3)
  return buf;
}
    4ec6:	855e                	mv	a0,s7
    4ec8:	60e6                	ld	ra,88(sp)
    4eca:	6446                	ld	s0,80(sp)
    4ecc:	64a6                	ld	s1,72(sp)
    4ece:	6906                	ld	s2,64(sp)
    4ed0:	79e2                	ld	s3,56(sp)
    4ed2:	7a42                	ld	s4,48(sp)
    4ed4:	7aa2                	ld	s5,40(sp)
    4ed6:	7b02                	ld	s6,32(sp)
    4ed8:	6be2                	ld	s7,24(sp)
    4eda:	6125                	addi	sp,sp,96
    4edc:	8082                	ret

0000000000004ede <stat>:

int
stat(const char *n, struct stat *st)
{
    4ede:	1101                	addi	sp,sp,-32
    4ee0:	ec06                	sd	ra,24(sp)
    4ee2:	e822                	sd	s0,16(sp)
    4ee4:	e04a                	sd	s2,0(sp)
    4ee6:	1000                	addi	s0,sp,32
    4ee8:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
    4eea:	4581                	li	a1,0
    4eec:	18e000ef          	jal	507a <open>
  if (fd < 0)
    4ef0:	02054263          	bltz	a0,4f14 <stat+0x36>
    4ef4:	e426                	sd	s1,8(sp)
    4ef6:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
    4ef8:	85ca                	mv	a1,s2
    4efa:	198000ef          	jal	5092 <fstat>
    4efe:	892a                	mv	s2,a0
  close(fd);
    4f00:	8526                	mv	a0,s1
    4f02:	160000ef          	jal	5062 <close>
  return r;
    4f06:	64a2                	ld	s1,8(sp)
}
    4f08:	854a                	mv	a0,s2
    4f0a:	60e2                	ld	ra,24(sp)
    4f0c:	6442                	ld	s0,16(sp)
    4f0e:	6902                	ld	s2,0(sp)
    4f10:	6105                	addi	sp,sp,32
    4f12:	8082                	ret
    return -1;
    4f14:	597d                	li	s2,-1
    4f16:	bfcd                	j	4f08 <stat+0x2a>

0000000000004f18 <atoi>:

int
atoi(const char *s)
{
    4f18:	1141                	addi	sp,sp,-16
    4f1a:	e422                	sd	s0,8(sp)
    4f1c:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
    4f1e:	00054683          	lbu	a3,0(a0)
    4f22:	fd06879b          	addiw	a5,a3,-48 # 3ffd0 <base+0x31308>
    4f26:	0ff7f793          	zext.b	a5,a5
    4f2a:	4625                	li	a2,9
    4f2c:	02f66863          	bltu	a2,a5,4f5c <atoi+0x44>
    4f30:	872a                	mv	a4,a0
  n = 0;
    4f32:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
    4f34:	0705                	addi	a4,a4,1 # 1000001 <base+0xff1339>
    4f36:	0025179b          	slliw	a5,a0,0x2
    4f3a:	9fa9                	addw	a5,a5,a0
    4f3c:	0017979b          	slliw	a5,a5,0x1
    4f40:	9fb5                	addw	a5,a5,a3
    4f42:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
    4f46:	00074683          	lbu	a3,0(a4)
    4f4a:	fd06879b          	addiw	a5,a3,-48
    4f4e:	0ff7f793          	zext.b	a5,a5
    4f52:	fef671e3          	bgeu	a2,a5,4f34 <atoi+0x1c>
  return n;
}
    4f56:	6422                	ld	s0,8(sp)
    4f58:	0141                	addi	sp,sp,16
    4f5a:	8082                	ret
  n = 0;
    4f5c:	4501                	li	a0,0
    4f5e:	bfe5                	j	4f56 <atoi+0x3e>

0000000000004f60 <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
    4f60:	1141                	addi	sp,sp,-16
    4f62:	e422                	sd	s0,8(sp)
    4f64:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
    4f66:	02b57463          	bgeu	a0,a1,4f8e <memmove+0x2e>
    while (n-- > 0)
    4f6a:	00c05f63          	blez	a2,4f88 <memmove+0x28>
    4f6e:	1602                	slli	a2,a2,0x20
    4f70:	9201                	srli	a2,a2,0x20
    4f72:	00c507b3          	add	a5,a0,a2
  dst = vdst;
    4f76:	872a                	mv	a4,a0
      *dst++ = *src++;
    4f78:	0585                	addi	a1,a1,1
    4f7a:	0705                	addi	a4,a4,1
    4f7c:	fff5c683          	lbu	a3,-1(a1)
    4f80:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    4f84:	fef71ae3          	bne	a4,a5,4f78 <memmove+0x18>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
    4f88:	6422                	ld	s0,8(sp)
    4f8a:	0141                	addi	sp,sp,16
    4f8c:	8082                	ret
    dst += n;
    4f8e:	00c50733          	add	a4,a0,a2
    src += n;
    4f92:	95b2                	add	a1,a1,a2
    while (n-- > 0)
    4f94:	fec05ae3          	blez	a2,4f88 <memmove+0x28>
    4f98:	fff6079b          	addiw	a5,a2,-1
    4f9c:	1782                	slli	a5,a5,0x20
    4f9e:	9381                	srli	a5,a5,0x20
    4fa0:	fff7c793          	not	a5,a5
    4fa4:	97ba                	add	a5,a5,a4
      *--dst = *--src;
    4fa6:	15fd                	addi	a1,a1,-1
    4fa8:	177d                	addi	a4,a4,-1
    4faa:	0005c683          	lbu	a3,0(a1)
    4fae:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
    4fb2:	fee79ae3          	bne	a5,a4,4fa6 <memmove+0x46>
    4fb6:	bfc9                	j	4f88 <memmove+0x28>

0000000000004fb8 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
    4fb8:	1141                	addi	sp,sp,-16
    4fba:	e422                	sd	s0,8(sp)
    4fbc:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
    4fbe:	ca05                	beqz	a2,4fee <memcmp+0x36>
    4fc0:	fff6069b          	addiw	a3,a2,-1
    4fc4:	1682                	slli	a3,a3,0x20
    4fc6:	9281                	srli	a3,a3,0x20
    4fc8:	0685                	addi	a3,a3,1
    4fca:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
    4fcc:	00054783          	lbu	a5,0(a0)
    4fd0:	0005c703          	lbu	a4,0(a1)
    4fd4:	00e79863          	bne	a5,a4,4fe4 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
    4fd8:	0505                	addi	a0,a0,1
    p2++;
    4fda:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    4fdc:	fed518e3          	bne	a0,a3,4fcc <memcmp+0x14>
  }
  return 0;
    4fe0:	4501                	li	a0,0
    4fe2:	a019                	j	4fe8 <memcmp+0x30>
      return *p1 - *p2;
    4fe4:	40e7853b          	subw	a0,a5,a4
}
    4fe8:	6422                	ld	s0,8(sp)
    4fea:	0141                	addi	sp,sp,16
    4fec:	8082                	ret
  return 0;
    4fee:	4501                	li	a0,0
    4ff0:	bfe5                	j	4fe8 <memcmp+0x30>

0000000000004ff2 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
    4ff2:	1141                	addi	sp,sp,-16
    4ff4:	e406                	sd	ra,8(sp)
    4ff6:	e022                	sd	s0,0(sp)
    4ff8:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    4ffa:	f67ff0ef          	jal	4f60 <memmove>
}
    4ffe:	60a2                	ld	ra,8(sp)
    5000:	6402                	ld	s0,0(sp)
    5002:	0141                	addi	sp,sp,16
    5004:	8082                	ret

0000000000005006 <sbrk>:

char *
sbrk(int n)
{
    5006:	1141                	addi	sp,sp,-16
    5008:	e406                	sd	ra,8(sp)
    500a:	e022                	sd	s0,0(sp)
    500c:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
    500e:	4585                	li	a1,1
    5010:	0b2000ef          	jal	50c2 <sys_sbrk>
}
    5014:	60a2                	ld	ra,8(sp)
    5016:	6402                	ld	s0,0(sp)
    5018:	0141                	addi	sp,sp,16
    501a:	8082                	ret

000000000000501c <sbrklazy>:

char *
sbrklazy(int n)
{
    501c:	1141                	addi	sp,sp,-16
    501e:	e406                	sd	ra,8(sp)
    5020:	e022                	sd	s0,0(sp)
    5022:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
    5024:	4589                	li	a1,2
    5026:	09c000ef          	jal	50c2 <sys_sbrk>
}
    502a:	60a2                	ld	ra,8(sp)
    502c:	6402                	ld	s0,0(sp)
    502e:	0141                	addi	sp,sp,16
    5030:	8082                	ret

0000000000005032 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
    5032:	4885                	li	a7,1
 ecall
    5034:	00000073          	ecall
 ret
    5038:	8082                	ret

000000000000503a <exit>:
.global exit
exit:
 li a7, SYS_exit
    503a:	4889                	li	a7,2
 ecall
    503c:	00000073          	ecall
 ret
    5040:	8082                	ret

0000000000005042 <wait>:
.global wait
wait:
 li a7, SYS_wait
    5042:	488d                	li	a7,3
 ecall
    5044:	00000073          	ecall
 ret
    5048:	8082                	ret

000000000000504a <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
    504a:	4891                	li	a7,4
 ecall
    504c:	00000073          	ecall
 ret
    5050:	8082                	ret

0000000000005052 <read>:
.global read
read:
 li a7, SYS_read
    5052:	4895                	li	a7,5
 ecall
    5054:	00000073          	ecall
 ret
    5058:	8082                	ret

000000000000505a <write>:
.global write
write:
 li a7, SYS_write
    505a:	48c1                	li	a7,16
 ecall
    505c:	00000073          	ecall
 ret
    5060:	8082                	ret

0000000000005062 <close>:
.global close
close:
 li a7, SYS_close
    5062:	48d5                	li	a7,21
 ecall
    5064:	00000073          	ecall
 ret
    5068:	8082                	ret

000000000000506a <kill>:
.global kill
kill:
 li a7, SYS_kill
    506a:	4899                	li	a7,6
 ecall
    506c:	00000073          	ecall
 ret
    5070:	8082                	ret

0000000000005072 <exec>:
.global exec
exec:
 li a7, SYS_exec
    5072:	489d                	li	a7,7
 ecall
    5074:	00000073          	ecall
 ret
    5078:	8082                	ret

000000000000507a <open>:
.global open
open:
 li a7, SYS_open
    507a:	48bd                	li	a7,15
 ecall
    507c:	00000073          	ecall
 ret
    5080:	8082                	ret

0000000000005082 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
    5082:	48c5                	li	a7,17
 ecall
    5084:	00000073          	ecall
 ret
    5088:	8082                	ret

000000000000508a <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
    508a:	48c9                	li	a7,18
 ecall
    508c:	00000073          	ecall
 ret
    5090:	8082                	ret

0000000000005092 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
    5092:	48a1                	li	a7,8
 ecall
    5094:	00000073          	ecall
 ret
    5098:	8082                	ret

000000000000509a <link>:
.global link
link:
 li a7, SYS_link
    509a:	48cd                	li	a7,19
 ecall
    509c:	00000073          	ecall
 ret
    50a0:	8082                	ret

00000000000050a2 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
    50a2:	48d1                	li	a7,20
 ecall
    50a4:	00000073          	ecall
 ret
    50a8:	8082                	ret

00000000000050aa <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
    50aa:	48a5                	li	a7,9
 ecall
    50ac:	00000073          	ecall
 ret
    50b0:	8082                	ret

00000000000050b2 <dup>:
.global dup
dup:
 li a7, SYS_dup
    50b2:	48a9                	li	a7,10
 ecall
    50b4:	00000073          	ecall
 ret
    50b8:	8082                	ret

00000000000050ba <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
    50ba:	48ad                	li	a7,11
 ecall
    50bc:	00000073          	ecall
 ret
    50c0:	8082                	ret

00000000000050c2 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
    50c2:	48b1                	li	a7,12
 ecall
    50c4:	00000073          	ecall
 ret
    50c8:	8082                	ret

00000000000050ca <pause>:
.global pause
pause:
 li a7, SYS_pause
    50ca:	48b5                	li	a7,13
 ecall
    50cc:	00000073          	ecall
 ret
    50d0:	8082                	ret

00000000000050d2 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
    50d2:	48b9                	li	a7,14
 ecall
    50d4:	00000073          	ecall
 ret
    50d8:	8082                	ret

00000000000050da <sync>:
.global sync
sync:
 li a7, SYS_sync
    50da:	48d9                	li	a7,22
 ecall
    50dc:	00000073          	ecall
 ret
    50e0:	8082                	ret

00000000000050e2 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
    50e2:	1101                	addi	sp,sp,-32
    50e4:	ec06                	sd	ra,24(sp)
    50e6:	e822                	sd	s0,16(sp)
    50e8:	1000                	addi	s0,sp,32
    50ea:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
    50ee:	4605                	li	a2,1
    50f0:	fef40593          	addi	a1,s0,-17
    50f4:	f67ff0ef          	jal	505a <write>
}
    50f8:	60e2                	ld	ra,24(sp)
    50fa:	6442                	ld	s0,16(sp)
    50fc:	6105                	addi	sp,sp,32
    50fe:	8082                	ret

0000000000005100 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
    5100:	715d                	addi	sp,sp,-80
    5102:	e486                	sd	ra,72(sp)
    5104:	e0a2                	sd	s0,64(sp)
    5106:	f84a                	sd	s2,48(sp)
    5108:	0880                	addi	s0,sp,80
    510a:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
    510c:	c299                	beqz	a3,5112 <printint+0x12>
    510e:	0805c363          	bltz	a1,5194 <printint+0x94>
  neg = 0;
    5112:	4881                	li	a7,0
    5114:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
    5118:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    511a:	00003517          	auipc	a0,0x3
    511e:	c9e50513          	addi	a0,a0,-866 # 7db8 <digits>
    5122:	883e                	mv	a6,a5
    5124:	2785                	addiw	a5,a5,1
    5126:	02c5f733          	remu	a4,a1,a2
    512a:	972a                	add	a4,a4,a0
    512c:	00074703          	lbu	a4,0(a4)
    5130:	00e68023          	sb	a4,0(a3)
  } while ((x /= base) != 0);
    5134:	872e                	mv	a4,a1
    5136:	02c5d5b3          	divu	a1,a1,a2
    513a:	0685                	addi	a3,a3,1
    513c:	fec773e3          	bgeu	a4,a2,5122 <printint+0x22>
  if (neg)
    5140:	00088b63          	beqz	a7,5156 <printint+0x56>
    buf[i++] = '-';
    5144:	fd078793          	addi	a5,a5,-48
    5148:	97a2                	add	a5,a5,s0
    514a:	02d00713          	li	a4,45
    514e:	fee78423          	sb	a4,-24(a5)
    5152:	0028079b          	addiw	a5,a6,2

  while (--i >= 0)
    5156:	02f05a63          	blez	a5,518a <printint+0x8a>
    515a:	fc26                	sd	s1,56(sp)
    515c:	f44e                	sd	s3,40(sp)
    515e:	fb840713          	addi	a4,s0,-72
    5162:	00f704b3          	add	s1,a4,a5
    5166:	fff70993          	addi	s3,a4,-1
    516a:	99be                	add	s3,s3,a5
    516c:	37fd                	addiw	a5,a5,-1
    516e:	1782                	slli	a5,a5,0x20
    5170:	9381                	srli	a5,a5,0x20
    5172:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
    5176:	fff4c583          	lbu	a1,-1(s1)
    517a:	854a                	mv	a0,s2
    517c:	f67ff0ef          	jal	50e2 <putc>
  while (--i >= 0)
    5180:	14fd                	addi	s1,s1,-1
    5182:	ff349ae3          	bne	s1,s3,5176 <printint+0x76>
    5186:	74e2                	ld	s1,56(sp)
    5188:	79a2                	ld	s3,40(sp)
}
    518a:	60a6                	ld	ra,72(sp)
    518c:	6406                	ld	s0,64(sp)
    518e:	7942                	ld	s2,48(sp)
    5190:	6161                	addi	sp,sp,80
    5192:	8082                	ret
    x = -xx;
    5194:	40b005b3          	neg	a1,a1
    neg = 1;
    5198:	4885                	li	a7,1
    x = -xx;
    519a:	bfad                	j	5114 <printint+0x14>

000000000000519c <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
    519c:	711d                	addi	sp,sp,-96
    519e:	ec86                	sd	ra,88(sp)
    51a0:	e8a2                	sd	s0,80(sp)
    51a2:	e0ca                	sd	s2,64(sp)
    51a4:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
    51a6:	0005c903          	lbu	s2,0(a1)
    51aa:	28090663          	beqz	s2,5436 <vprintf+0x29a>
    51ae:	e4a6                	sd	s1,72(sp)
    51b0:	fc4e                	sd	s3,56(sp)
    51b2:	f852                	sd	s4,48(sp)
    51b4:	f456                	sd	s5,40(sp)
    51b6:	f05a                	sd	s6,32(sp)
    51b8:	ec5e                	sd	s7,24(sp)
    51ba:	e862                	sd	s8,16(sp)
    51bc:	e466                	sd	s9,8(sp)
    51be:	8b2a                	mv	s6,a0
    51c0:	8a2e                	mv	s4,a1
    51c2:	8bb2                	mv	s7,a2
  state = 0;
    51c4:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
    51c6:	4481                	li	s1,0
    51c8:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
    51ca:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
    51ce:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
    51d2:	06c00c93          	li	s9,108
    51d6:	a005                	j	51f6 <vprintf+0x5a>
        putc(fd, c0);
    51d8:	85ca                	mv	a1,s2
    51da:	855a                	mv	a0,s6
    51dc:	f07ff0ef          	jal	50e2 <putc>
    51e0:	a019                	j	51e6 <vprintf+0x4a>
    } else if (state == '%') {
    51e2:	03598263          	beq	s3,s5,5206 <vprintf+0x6a>
  for (i = 0; fmt[i]; i++) {
    51e6:	2485                	addiw	s1,s1,1
    51e8:	8726                	mv	a4,s1
    51ea:	009a07b3          	add	a5,s4,s1
    51ee:	0007c903          	lbu	s2,0(a5)
    51f2:	22090a63          	beqz	s2,5426 <vprintf+0x28a>
    c0 = fmt[i] & 0xff;
    51f6:	0009079b          	sext.w	a5,s2
    if (state == 0) {
    51fa:	fe0994e3          	bnez	s3,51e2 <vprintf+0x46>
      if (c0 == '%') {
    51fe:	fd579de3          	bne	a5,s5,51d8 <vprintf+0x3c>
        state = '%';
    5202:	89be                	mv	s3,a5
    5204:	b7cd                	j	51e6 <vprintf+0x4a>
        c1 = fmt[i + 1] & 0xff;
    5206:	00ea06b3          	add	a3,s4,a4
    520a:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
    520e:	8636                	mv	a2,a3
      if (c1)
    5210:	c681                	beqz	a3,5218 <vprintf+0x7c>
        c2 = fmt[i + 2] & 0xff;
    5212:	9752                	add	a4,a4,s4
    5214:	00274603          	lbu	a2,2(a4)
      if (c0 == 'd') {
    5218:	05878363          	beq	a5,s8,525e <vprintf+0xc2>
      } else if (c0 == 'l' && c1 == 'd') {
    521c:	05978d63          	beq	a5,s9,5276 <vprintf+0xda>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if (c0 == 'u') {
    5220:	07500713          	li	a4,117
    5224:	0ee78763          	beq	a5,a4,5312 <vprintf+0x176>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if (c0 == 'x') {
    5228:	07800713          	li	a4,120
    522c:	12e78963          	beq	a5,a4,535e <vprintf+0x1c2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if (c0 == 'p') {
    5230:	07000713          	li	a4,112
    5234:	14e78e63          	beq	a5,a4,5390 <vprintf+0x1f4>
        printptr(fd, va_arg(ap, uint64));
      } else if (c0 == 'c') {
    5238:	06300713          	li	a4,99
    523c:	18e78e63          	beq	a5,a4,53d8 <vprintf+0x23c>
        putc(fd, va_arg(ap, uint32));
      } else if (c0 == 's') {
    5240:	07300713          	li	a4,115
    5244:	1ae78463          	beq	a5,a4,53ec <vprintf+0x250>
        if ((s = va_arg(ap, char *)) == 0)
          s = "(null)";
        for (; *s; s++)
          putc(fd, *s);
      } else if (c0 == '%') {
    5248:	02500713          	li	a4,37
    524c:	04e79563          	bne	a5,a4,5296 <vprintf+0xfa>
        putc(fd, '%');
    5250:	02500593          	li	a1,37
    5254:	855a                	mv	a0,s6
    5256:	e8dff0ef          	jal	50e2 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
    525a:	4981                	li	s3,0
    525c:	b769                	j	51e6 <vprintf+0x4a>
        printint(fd, va_arg(ap, int), 10, 1);
    525e:	008b8913          	addi	s2,s7,8
    5262:	4685                	li	a3,1
    5264:	4629                	li	a2,10
    5266:	000ba583          	lw	a1,0(s7)
    526a:	855a                	mv	a0,s6
    526c:	e95ff0ef          	jal	5100 <printint>
    5270:	8bca                	mv	s7,s2
      state = 0;
    5272:	4981                	li	s3,0
    5274:	bf8d                	j	51e6 <vprintf+0x4a>
      } else if (c0 == 'l' && c1 == 'd') {
    5276:	06400793          	li	a5,100
    527a:	02f68963          	beq	a3,a5,52ac <vprintf+0x110>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    527e:	06c00793          	li	a5,108
    5282:	04f68263          	beq	a3,a5,52c6 <vprintf+0x12a>
      } else if (c0 == 'l' && c1 == 'u') {
    5286:	07500793          	li	a5,117
    528a:	0af68063          	beq	a3,a5,532a <vprintf+0x18e>
      } else if (c0 == 'l' && c1 == 'x') {
    528e:	07800793          	li	a5,120
    5292:	0ef68263          	beq	a3,a5,5376 <vprintf+0x1da>
        putc(fd, '%');
    5296:	02500593          	li	a1,37
    529a:	855a                	mv	a0,s6
    529c:	e47ff0ef          	jal	50e2 <putc>
        putc(fd, c0);
    52a0:	85ca                	mv	a1,s2
    52a2:	855a                	mv	a0,s6
    52a4:	e3fff0ef          	jal	50e2 <putc>
      state = 0;
    52a8:	4981                	li	s3,0
    52aa:	bf35                	j	51e6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
    52ac:	008b8913          	addi	s2,s7,8
    52b0:	4685                	li	a3,1
    52b2:	4629                	li	a2,10
    52b4:	000bb583          	ld	a1,0(s7)
    52b8:	855a                	mv	a0,s6
    52ba:	e47ff0ef          	jal	5100 <printint>
        i += 1;
    52be:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
    52c0:	8bca                	mv	s7,s2
      state = 0;
    52c2:	4981                	li	s3,0
        i += 1;
    52c4:	b70d                	j	51e6 <vprintf+0x4a>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    52c6:	06400793          	li	a5,100
    52ca:	02f60763          	beq	a2,a5,52f8 <vprintf+0x15c>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    52ce:	07500793          	li	a5,117
    52d2:	06f60963          	beq	a2,a5,5344 <vprintf+0x1a8>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    52d6:	07800793          	li	a5,120
    52da:	faf61ee3          	bne	a2,a5,5296 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
    52de:	008b8913          	addi	s2,s7,8
    52e2:	4681                	li	a3,0
    52e4:	4641                	li	a2,16
    52e6:	000bb583          	ld	a1,0(s7)
    52ea:	855a                	mv	a0,s6
    52ec:	e15ff0ef          	jal	5100 <printint>
        i += 2;
    52f0:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
    52f2:	8bca                	mv	s7,s2
      state = 0;
    52f4:	4981                	li	s3,0
        i += 2;
    52f6:	bdc5                	j	51e6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
    52f8:	008b8913          	addi	s2,s7,8
    52fc:	4685                	li	a3,1
    52fe:	4629                	li	a2,10
    5300:	000bb583          	ld	a1,0(s7)
    5304:	855a                	mv	a0,s6
    5306:	dfbff0ef          	jal	5100 <printint>
        i += 2;
    530a:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
    530c:	8bca                	mv	s7,s2
      state = 0;
    530e:	4981                	li	s3,0
        i += 2;
    5310:	bdd9                	j	51e6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 10, 0);
    5312:	008b8913          	addi	s2,s7,8
    5316:	4681                	li	a3,0
    5318:	4629                	li	a2,10
    531a:	000be583          	lwu	a1,0(s7)
    531e:	855a                	mv	a0,s6
    5320:	de1ff0ef          	jal	5100 <printint>
    5324:	8bca                	mv	s7,s2
      state = 0;
    5326:	4981                	li	s3,0
    5328:	bd7d                	j	51e6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
    532a:	008b8913          	addi	s2,s7,8
    532e:	4681                	li	a3,0
    5330:	4629                	li	a2,10
    5332:	000bb583          	ld	a1,0(s7)
    5336:	855a                	mv	a0,s6
    5338:	dc9ff0ef          	jal	5100 <printint>
        i += 1;
    533c:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
    533e:	8bca                	mv	s7,s2
      state = 0;
    5340:	4981                	li	s3,0
        i += 1;
    5342:	b555                	j	51e6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
    5344:	008b8913          	addi	s2,s7,8
    5348:	4681                	li	a3,0
    534a:	4629                	li	a2,10
    534c:	000bb583          	ld	a1,0(s7)
    5350:	855a                	mv	a0,s6
    5352:	dafff0ef          	jal	5100 <printint>
        i += 2;
    5356:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
    5358:	8bca                	mv	s7,s2
      state = 0;
    535a:	4981                	li	s3,0
        i += 2;
    535c:	b569                	j	51e6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 16, 0);
    535e:	008b8913          	addi	s2,s7,8
    5362:	4681                	li	a3,0
    5364:	4641                	li	a2,16
    5366:	000be583          	lwu	a1,0(s7)
    536a:	855a                	mv	a0,s6
    536c:	d95ff0ef          	jal	5100 <printint>
    5370:	8bca                	mv	s7,s2
      state = 0;
    5372:	4981                	li	s3,0
    5374:	bd8d                	j	51e6 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 16, 0);
    5376:	008b8913          	addi	s2,s7,8
    537a:	4681                	li	a3,0
    537c:	4641                	li	a2,16
    537e:	000bb583          	ld	a1,0(s7)
    5382:	855a                	mv	a0,s6
    5384:	d7dff0ef          	jal	5100 <printint>
        i += 1;
    5388:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
    538a:	8bca                	mv	s7,s2
      state = 0;
    538c:	4981                	li	s3,0
        i += 1;
    538e:	bda1                	j	51e6 <vprintf+0x4a>
    5390:	e06a                	sd	s10,0(sp)
        printptr(fd, va_arg(ap, uint64));
    5392:	008b8d13          	addi	s10,s7,8
    5396:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
    539a:	03000593          	li	a1,48
    539e:	855a                	mv	a0,s6
    53a0:	d43ff0ef          	jal	50e2 <putc>
  putc(fd, 'x');
    53a4:	07800593          	li	a1,120
    53a8:	855a                	mv	a0,s6
    53aa:	d39ff0ef          	jal	50e2 <putc>
    53ae:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    53b0:	00003b97          	auipc	s7,0x3
    53b4:	a08b8b93          	addi	s7,s7,-1528 # 7db8 <digits>
    53b8:	03c9d793          	srli	a5,s3,0x3c
    53bc:	97de                	add	a5,a5,s7
    53be:	0007c583          	lbu	a1,0(a5)
    53c2:	855a                	mv	a0,s6
    53c4:	d1fff0ef          	jal	50e2 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    53c8:	0992                	slli	s3,s3,0x4
    53ca:	397d                	addiw	s2,s2,-1
    53cc:	fe0916e3          	bnez	s2,53b8 <vprintf+0x21c>
        printptr(fd, va_arg(ap, uint64));
    53d0:	8bea                	mv	s7,s10
      state = 0;
    53d2:	4981                	li	s3,0
    53d4:	6d02                	ld	s10,0(sp)
    53d6:	bd01                	j	51e6 <vprintf+0x4a>
        putc(fd, va_arg(ap, uint32));
    53d8:	008b8913          	addi	s2,s7,8
    53dc:	000bc583          	lbu	a1,0(s7)
    53e0:	855a                	mv	a0,s6
    53e2:	d01ff0ef          	jal	50e2 <putc>
    53e6:	8bca                	mv	s7,s2
      state = 0;
    53e8:	4981                	li	s3,0
    53ea:	bbf5                	j	51e6 <vprintf+0x4a>
        if ((s = va_arg(ap, char *)) == 0)
    53ec:	008b8993          	addi	s3,s7,8
    53f0:	000bb903          	ld	s2,0(s7)
    53f4:	00090f63          	beqz	s2,5412 <vprintf+0x276>
        for (; *s; s++)
    53f8:	00094583          	lbu	a1,0(s2)
    53fc:	c195                	beqz	a1,5420 <vprintf+0x284>
          putc(fd, *s);
    53fe:	855a                	mv	a0,s6
    5400:	ce3ff0ef          	jal	50e2 <putc>
        for (; *s; s++)
    5404:	0905                	addi	s2,s2,1
    5406:	00094583          	lbu	a1,0(s2)
    540a:	f9f5                	bnez	a1,53fe <vprintf+0x262>
        if ((s = va_arg(ap, char *)) == 0)
    540c:	8bce                	mv	s7,s3
      state = 0;
    540e:	4981                	li	s3,0
    5410:	bbd9                	j	51e6 <vprintf+0x4a>
          s = "(null)";
    5412:	00003917          	auipc	s2,0x3
    5416:	8f690913          	addi	s2,s2,-1802 # 7d08 <malloc+0x27ea>
        for (; *s; s++)
    541a:	02800593          	li	a1,40
    541e:	b7c5                	j	53fe <vprintf+0x262>
        if ((s = va_arg(ap, char *)) == 0)
    5420:	8bce                	mv	s7,s3
      state = 0;
    5422:	4981                	li	s3,0
    5424:	b3c9                	j	51e6 <vprintf+0x4a>
    5426:	64a6                	ld	s1,72(sp)
    5428:	79e2                	ld	s3,56(sp)
    542a:	7a42                	ld	s4,48(sp)
    542c:	7aa2                	ld	s5,40(sp)
    542e:	7b02                	ld	s6,32(sp)
    5430:	6be2                	ld	s7,24(sp)
    5432:	6c42                	ld	s8,16(sp)
    5434:	6ca2                	ld	s9,8(sp)
    }
  }
}
    5436:	60e6                	ld	ra,88(sp)
    5438:	6446                	ld	s0,80(sp)
    543a:	6906                	ld	s2,64(sp)
    543c:	6125                	addi	sp,sp,96
    543e:	8082                	ret

0000000000005440 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
    5440:	715d                	addi	sp,sp,-80
    5442:	ec06                	sd	ra,24(sp)
    5444:	e822                	sd	s0,16(sp)
    5446:	1000                	addi	s0,sp,32
    5448:	e010                	sd	a2,0(s0)
    544a:	e414                	sd	a3,8(s0)
    544c:	e818                	sd	a4,16(s0)
    544e:	ec1c                	sd	a5,24(s0)
    5450:	03043023          	sd	a6,32(s0)
    5454:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
    5458:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
    545c:	8622                	mv	a2,s0
    545e:	d3fff0ef          	jal	519c <vprintf>
}
    5462:	60e2                	ld	ra,24(sp)
    5464:	6442                	ld	s0,16(sp)
    5466:	6161                	addi	sp,sp,80
    5468:	8082                	ret

000000000000546a <printf>:

void
printf(const char *fmt, ...)
{
    546a:	711d                	addi	sp,sp,-96
    546c:	ec06                	sd	ra,24(sp)
    546e:	e822                	sd	s0,16(sp)
    5470:	1000                	addi	s0,sp,32
    5472:	e40c                	sd	a1,8(s0)
    5474:	e810                	sd	a2,16(s0)
    5476:	ec14                	sd	a3,24(s0)
    5478:	f018                	sd	a4,32(s0)
    547a:	f41c                	sd	a5,40(s0)
    547c:	03043823          	sd	a6,48(s0)
    5480:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
    5484:	00840613          	addi	a2,s0,8
    5488:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
    548c:	85aa                	mv	a1,a0
    548e:	4505                	li	a0,1
    5490:	d0dff0ef          	jal	519c <vprintf>
}
    5494:	60e2                	ld	ra,24(sp)
    5496:	6442                	ld	s0,16(sp)
    5498:	6125                	addi	sp,sp,96
    549a:	8082                	ret

000000000000549c <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    549c:	1141                	addi	sp,sp,-16
    549e:	e422                	sd	s0,8(sp)
    54a0:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
    54a2:	ff050693          	addi	a3,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    54a6:	00003797          	auipc	a5,0x3
    54aa:	ffa7b783          	ld	a5,-6(a5) # 84a0 <freep>
    54ae:	a02d                	j	54d8 <free+0x3c>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if (bp + bp->s.size == p->s.ptr) {
    bp->s.size += p->s.ptr->s.size;
    54b0:	4618                	lw	a4,8(a2)
    54b2:	9f2d                	addw	a4,a4,a1
    54b4:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    54b8:	6398                	ld	a4,0(a5)
    54ba:	6310                	ld	a2,0(a4)
    54bc:	a83d                	j	54fa <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
    p->s.size += bp->s.size;
    54be:	ff852703          	lw	a4,-8(a0)
    54c2:	9f31                	addw	a4,a4,a2
    54c4:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
    54c6:	ff053683          	ld	a3,-16(a0)
    54ca:	a091                	j	550e <free+0x72>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    54cc:	6398                	ld	a4,0(a5)
    54ce:	00e7e463          	bltu	a5,a4,54d6 <free+0x3a>
    54d2:	00e6ea63          	bltu	a3,a4,54e6 <free+0x4a>
{
    54d6:	87ba                	mv	a5,a4
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    54d8:	fed7fae3          	bgeu	a5,a3,54cc <free+0x30>
    54dc:	6398                	ld	a4,0(a5)
    54de:	00e6e463          	bltu	a3,a4,54e6 <free+0x4a>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    54e2:	fee7eae3          	bltu	a5,a4,54d6 <free+0x3a>
  if (bp + bp->s.size == p->s.ptr) {
    54e6:	ff852583          	lw	a1,-8(a0)
    54ea:	6390                	ld	a2,0(a5)
    54ec:	02059813          	slli	a6,a1,0x20
    54f0:	01c85713          	srli	a4,a6,0x1c
    54f4:	9736                	add	a4,a4,a3
    54f6:	fae60de3          	beq	a2,a4,54b0 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
    54fa:	fec53823          	sd	a2,-16(a0)
  if (p + p->s.size == bp) {
    54fe:	4790                	lw	a2,8(a5)
    5500:	02061593          	slli	a1,a2,0x20
    5504:	01c5d713          	srli	a4,a1,0x1c
    5508:	973e                	add	a4,a4,a5
    550a:	fae68ae3          	beq	a3,a4,54be <free+0x22>
    p->s.ptr = bp->s.ptr;
    550e:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
    5510:	00003717          	auipc	a4,0x3
    5514:	f8f73823          	sd	a5,-112(a4) # 84a0 <freep>
}
    5518:	6422                	ld	s0,8(sp)
    551a:	0141                	addi	sp,sp,16
    551c:	8082                	ret

000000000000551e <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
    551e:	7139                	addi	sp,sp,-64
    5520:	fc06                	sd	ra,56(sp)
    5522:	f822                	sd	s0,48(sp)
    5524:	f426                	sd	s1,40(sp)
    5526:	ec4e                	sd	s3,24(sp)
    5528:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
    552a:	02051493          	slli	s1,a0,0x20
    552e:	9081                	srli	s1,s1,0x20
    5530:	04bd                	addi	s1,s1,15
    5532:	8091                	srli	s1,s1,0x4
    5534:	0014899b          	addiw	s3,s1,1
    5538:	0485                	addi	s1,s1,1
  if ((prevp = freep) == 0) {
    553a:	00003517          	auipc	a0,0x3
    553e:	f6653503          	ld	a0,-154(a0) # 84a0 <freep>
    5542:	c915                	beqz	a0,5576 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
    5544:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
    5546:	4798                	lw	a4,8(a5)
    5548:	08977a63          	bgeu	a4,s1,55dc <malloc+0xbe>
    554c:	f04a                	sd	s2,32(sp)
    554e:	e852                	sd	s4,16(sp)
    5550:	e456                	sd	s5,8(sp)
    5552:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
    5554:	8a4e                	mv	s4,s3
    5556:	0009871b          	sext.w	a4,s3
    555a:	6685                	lui	a3,0x1
    555c:	00d77363          	bgeu	a4,a3,5562 <malloc+0x44>
    5560:	6a05                	lui	s4,0x1
    5562:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    5566:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
    556a:	00003917          	auipc	s2,0x3
    556e:	f3690913          	addi	s2,s2,-202 # 84a0 <freep>
  if (p == SBRK_ERROR)
    5572:	5afd                	li	s5,-1
    5574:	a081                	j	55b4 <malloc+0x96>
    5576:	f04a                	sd	s2,32(sp)
    5578:	e852                	sd	s4,16(sp)
    557a:	e456                	sd	s5,8(sp)
    557c:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
    557e:	00009797          	auipc	a5,0x9
    5582:	74a78793          	addi	a5,a5,1866 # ecc8 <base>
    5586:	00003717          	auipc	a4,0x3
    558a:	f0f73d23          	sd	a5,-230(a4) # 84a0 <freep>
    558e:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    5590:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
    5594:	b7c1                	j	5554 <malloc+0x36>
        prevp->s.ptr = p->s.ptr;
    5596:	6398                	ld	a4,0(a5)
    5598:	e118                	sd	a4,0(a0)
    559a:	a8a9                	j	55f4 <malloc+0xd6>
  hp->s.size = nu;
    559c:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
    55a0:	0541                	addi	a0,a0,16
    55a2:	efbff0ef          	jal	549c <free>
  return freep;
    55a6:	00093503          	ld	a0,0(s2)
      if ((p = morecore(nunits)) == 0)
    55aa:	c12d                	beqz	a0,560c <malloc+0xee>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
    55ac:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
    55ae:	4798                	lw	a4,8(a5)
    55b0:	02977263          	bgeu	a4,s1,55d4 <malloc+0xb6>
    if (p == freep)
    55b4:	00093703          	ld	a4,0(s2)
    55b8:	853e                	mv	a0,a5
    55ba:	fef719e3          	bne	a4,a5,55ac <malloc+0x8e>
  p = sbrk(nu * sizeof(Header));
    55be:	8552                	mv	a0,s4
    55c0:	a47ff0ef          	jal	5006 <sbrk>
  if (p == SBRK_ERROR)
    55c4:	fd551ce3          	bne	a0,s5,559c <malloc+0x7e>
        return 0;
    55c8:	4501                	li	a0,0
    55ca:	7902                	ld	s2,32(sp)
    55cc:	6a42                	ld	s4,16(sp)
    55ce:	6aa2                	ld	s5,8(sp)
    55d0:	6b02                	ld	s6,0(sp)
    55d2:	a03d                	j	5600 <malloc+0xe2>
    55d4:	7902                	ld	s2,32(sp)
    55d6:	6a42                	ld	s4,16(sp)
    55d8:	6aa2                	ld	s5,8(sp)
    55da:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
    55dc:	fae48de3          	beq	s1,a4,5596 <malloc+0x78>
        p->s.size -= nunits;
    55e0:	4137073b          	subw	a4,a4,s3
    55e4:	c798                	sw	a4,8(a5)
        p += p->s.size;
    55e6:	02071693          	slli	a3,a4,0x20
    55ea:	01c6d713          	srli	a4,a3,0x1c
    55ee:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    55f0:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    55f4:	00003717          	auipc	a4,0x3
    55f8:	eaa73623          	sd	a0,-340(a4) # 84a0 <freep>
      return (void *)(p + 1);
    55fc:	01078513          	addi	a0,a5,16
  }
}
    5600:	70e2                	ld	ra,56(sp)
    5602:	7442                	ld	s0,48(sp)
    5604:	74a2                	ld	s1,40(sp)
    5606:	69e2                	ld	s3,24(sp)
    5608:	6121                	addi	sp,sp,64
    560a:	8082                	ret
    560c:	7902                	ld	s2,32(sp)
    560e:	6a42                	ld	s4,16(sp)
    5610:	6aa2                	ld	s5,8(sp)
    5612:	6b02                	ld	s6,0(sp)
    5614:	b7f5                	j	5600 <malloc+0xe2>
